# Trash 폴더

이 폴더는 중복되거나 더 이상 사용하지 않는 가이드 문서들을 보관하는 곳입니다.

## 이동된 파일들

### 2025-07-02 이동
- **ai-project-collect-command-guide.md**: AI-PROJECT-COLLECT-GUIDE.md와 중복
- **claude-code-command-registration-guide.md**: CLAUDE-CODE-COMMANDS-GUIDE.md와 중복

## 참고사항
- 이 폴더의 파일들은 참고용으로만 보관됩니다
- 실제 개발 시에는 ai-analysis 폴더의 가이드들을 사용하세요
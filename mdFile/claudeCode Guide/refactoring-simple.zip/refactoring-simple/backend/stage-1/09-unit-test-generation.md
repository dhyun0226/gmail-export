# 🧪 Stage 9: 단위 테스트 자동 생성

## 개요
리팩토링으로 분리된 각 Service 클래스별로 단위 테스트를 자동 생성합니다. Controller가 아닌 **Service 레이어**에 집중하여 비즈니스 로직의 세세한 부분까지 검증할 수 있는 포괄적인 테스트를 생성합니다.

## 📋 실행 체크리스트

### 1. 리팩토링된 Service 클래스 탐지
- [ ] {workingDir}/first/domain/{domainName}/ 경로에서 분리된 Service 클래스 검색
- [ ] 각 Service 클래스의 public 메소드 목록 추출
- [ ] 메소드별 입력 파라미터와 반환 타입 분석
- [ ] @Transactional, @Validate 등 어노테이션 정보 수집
- [ ] 의존성 주입된 Mapper, 외부 Service 식별

### 2. 테스트 데이터 추출
- [ ] 검증 로직에서 데이터 규칙 추출
- [ ] 비즈니스 로직에서 경계값 파악
- [ ] 상태 전이 시나리오 도출
- [ ] 에러 케이스 데이터 준비

### 3. 테스트 클래스 생성
- [ ] Service별 테스트 클래스 생성
- [ ] SpringBootTest 환경 설정
- [ ] 테스트 데이터 Builder 생성
- [ ] 테스트 메소드 구현

## 🎯 실행 단계

### Step 1: 리팩토링된 Service 클래스 탐지 및 분석

#### 1.1 Service 클래스 자동 탐지
```java
public class ServiceClassDetector {
    
    public List<ServiceClass> findRefactoredServiceClasses(String workingDir) {
        List<ServiceClass> services = new ArrayList<>();
        
        // 1. {workingDir}/first/domain/ 디렉토리에서 Service 클래스 검색
        Path servicePath = Paths.get(workingDir, "first", "domain");
        
        try (Stream<Path> paths = Files.walk(servicePath)) {
            paths.filter(path -> path.toString().endsWith("Service.java"))
                 .forEach(path -> {
                     ServiceClass service = analyzeServiceClass(path);
                     services.add(service);
                 });
        }
        
        return services;
    }
    
    private ServiceClass analyzeServiceClass(Path servicePath) {
        // Service 클래스 분석
        // - 클래스명, 패키지명 추출
        // - public 메소드 목록 수집
        // - 의존성 주입 정보 파악
        // - 어노테이션 정보 수집
    }
}
```

#### 1.2 Service 메소드별 상세 분석
```java
public class ServiceMethodAnalyzer {
    
    public MethodAnalysis analyzeMethod(Method method) {
        return MethodAnalysis.builder()
            .methodName(method.getName())
            .parameters(extractParameters(method))
            .returnType(method.getReturnType())
            .businessRules(extractBusinessRules(method))
            .validationRules(extractValidationRules(method))
            .exceptionCases(extractExceptionCases(method))
            .transactionBehavior(extractTransactionBehavior(method))
            .build();
    }
    
    // 검증 로직에서 데이터 규칙 추출
    private List<ValidationRule> extractValidationRules(Method method) {
        // validate 메소드 내부 로직 분석
        // if 문, throw 문에서 검증 조건 추출
        // 필수 필드, 값 범위, 형식 검증 등 파악
    }
    
    // 비즈니스 로직에서 규칙 추출
    private List<BusinessRule> extractBusinessRules(Method method) {
        // 계산 로직, 상태 전이, 조건부 처리 등 분석
        // 할인 규칙, 등급별 처리, 임계값 등 파악
    }
}
```

#### 1.3 종합 분석 결과
```java
// 예시: OrderService 분석 결과
public class OrderServiceAnalysis {
    // Service 클래스 정보
    String className = "OrderService";
    String packageName = "com.osstem.ow.sal.domain.ord";
    
    // 메소드별 분석 결과
    Map<String, MethodTestSpec> methodSpecs = Map.of(
        "processOrder", MethodTestSpec.builder()
            .normalCases(Arrays.asList(
                "정상 주문 처리",
                "할인 적용 주문",
                "대량 주문 처리",
                "특가 상품 주문"
            ))
            .edgeCases(Arrays.asList(
                "할인 경계값 테스트",
                "최소/최대 수량 테스트",
                "가격 경계값 테스트"
            ))
            .errorCases(Arrays.asList(
                "null customerId",
                "empty items",
                "invalid quantity",
                "invalid price",
                "고객 정보 없음"
            ))
            .build(),
        
        "updateOrderStatus", MethodTestSpec.builder()
            .normalCases(Arrays.asList(
                "PENDING→CONFIRMED 전이",
                "CONFIRMED→PAID 전이",
                "PAID→COMPLETED 전이"
            ))
            .errorCases(Arrays.asList(
                "잘못된 상태 전이",
                "존재하지 않는 주문",
                "null 상태값"
            ))
            .build()
    );
}
```

### Step 2: 테스트 데이터 생성기 구현

#### 2.1 기본 데이터 생성기
```java
@Component
public class TestDataGenerator {
    
    // 정상 케이스 데이터
    public static OrderDto generateValidOrder() {
        return OrderDto.builder()
            .customerId(1L)
            .items(generateValidItems())
            .orderDate(LocalDateTime.now())
            .deliveryAddress("서울시 강남구 테스트로 123")
            .orderMemo("테스트 주문")
            .paymentMethod("CARD")
            .build();
    }
    
    // 할인 적용 케이스
    public static OrderDto generateDiscountOrder() {
        OrderDto order = generateValidOrder();
        order.setItems(Arrays.asList(
            ItemDto.builder()
                .productId(1L)
                .quantity(2)
                .price(BigDecimal.valueOf(60000)) // 총 120,000원
                .build()
        ));
        return order;
    }
}
```

#### 2.2 예외 케이스 생성기
```java
public class ErrorCaseGenerator {
    
    // 검증 실패 케이스들
    public static Map<String, OrderDto> generateValidationErrors() {
        Map<String, OrderDto> errorCases = new HashMap<>();
        
        // null customerId
        OrderDto nullCustomer = generateValidOrder();
        nullCustomer.setCustomerId(null);
        errorCases.put("nullCustomerId", nullCustomer);
        
        // empty items
        OrderDto emptyItems = generateValidOrder();
        emptyItems.setItems(new ArrayList<>());
        errorCases.put("emptyItems", emptyItems);
        
        // invalid quantity
        OrderDto invalidQuantity = generateValidOrder();
        invalidQuantity.getItems().get(0).setQuantity(0);
        errorCases.put("invalidQuantity", invalidQuantity);
        
        return errorCases;
    }
}
```

### Step 3: 단위 테스트 클래스 템플릿

#### 3.1 테스트 환경 설정 (application-test.yml)
```yaml
# src/test/resources/application-test.yml
spring:
  datasource:
    url: jdbc:mariadb://localhost:3306/testdb
    username: test
    password: test
    driver-class-name: org.mariadb.jdbc.Driver
    hikari:
      maximum-pool-size: 10
      minimum-idle: 5

  jpa:
    hibernate:
      ddl-auto: create-drop
    show-sql: true
    properties:
      hibernate:
        format_sql: true
        dialect: org.hibernate.dialect.MariaDB103Dialect

  sql:
    init:
      mode: always
      schema-locations: classpath:schema-test.sql
      data-locations: classpath:data-test.sql
      continue-on-error: false

# MyBatis 설정
mybatis:
  mapper-locations: classpath:mapper/**/*.xml
  type-aliases-package: com.osstem.ow.sal.dto
  configuration:
    map-underscore-to-camel-case: true
    use-generated-keys: true
    default-fetch-size: 100
    default-statement-timeout: 30

# 로깅 설정
logging:
  level:
    com.osstem.ow.sal: DEBUG
    org.springframework.jdbc: DEBUG
    org.springframework.transaction: DEBUG
    org.mybatis: DEBUG

# 트랜잭션 설정
spring.transaction:
  default-timeout: 30
  rollback-on-commit-failure: true
```

#### 3.2 Service 테스트 기본 구조
```java
@SpringBootTest
@Transactional
@ActiveProfiles("test")  // test 프로파일 사용
class ${ServiceName}Test {
    
    @Autowired
    private ${ServiceName} service;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    private TestDataBuilder testDataBuilder;
    
    @BeforeEach
    void setUp() {
        testDataBuilder = new TestDataBuilder(jdbcTemplate);
        // 기본 테스트 데이터 준비
        testDataBuilder.createBaseTestData();
    }
    
    @AfterEach
    void tearDown() {
        // 테스트 데이터 정리 (트랜잭션 롤백으로 자동 처리)
    }
}
```

#### 3.3 포괄적 테스트 메소드 템플릿

##### 3.3.1 정상 케이스 테스트 (Normal Cases)
```java
@Nested
@DisplayName("${MethodName} - 정상 케이스")
class ${MethodName}NormalCases {
    
    @Test
    @DisplayName("기본 정상 처리")
    void test${MethodName}_Basic_Success() {
        // Given
        ${InputType} input = TestDataGenerator.generateValid${InputType}();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        assertThat(result).isNotNull();
        // 반환값 세부 검증
        ${detailedAssertions}
    }
    
    @Test
    @DisplayName("비즈니스 규칙 적용 테스트")
    void test${MethodName}_BusinessRule_Applied() {
        // Given - 비즈니스 규칙이 적용되는 조건
        ${InputType} input = TestDataGenerator.generateBusinessRuleCase();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        // 비즈니스 규칙 적용 결과 검증
        ${businessRuleAssertions}
    }
    
    @Test
    @DisplayName("대용량 데이터 처리")
    void test${MethodName}_LargeData_Success() {
        // Given
        ${InputType} input = TestDataGenerator.generateLargeDataSet();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        assertThat(result).isNotNull();
        // 성능 및 정확성 검증
    }
}
```

##### 3.3.2 경계값 테스트 (Edge Cases)
```java
@Nested
@DisplayName("${MethodName} - 경계값 테스트")
class ${MethodName}EdgeCases {
    
    @Test
    @DisplayName("최솟값 경계 테스트")
    void test${MethodName}_MinimumBoundary() {
        // Given
        ${InputType} input = TestDataGenerator.generateMinimumCase();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        // 최솟값에서의 동작 검증
        ${minimumBoundaryAssertions}
    }
    
    @Test
    @DisplayName("최댓값 경계 테스트")
    void test${MethodName}_MaximumBoundary() {
        // Given
        ${InputType} input = TestDataGenerator.generateMaximumCase();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        // 최댓값에서의 동작 검증
        ${maximumBoundaryAssertions}
    }
    
    @Test
    @DisplayName("임계값 직전/직후 테스트")
    void test${MethodName}_ThresholdBoundary() {
        // Given - 임계값 직전
        ${InputType} inputBefore = TestDataGenerator.generateBeforeThreshold();
        ${InputType} inputAfter = TestDataGenerator.generateAfterThreshold();
        
        // When
        ${ReturnType} resultBefore = service.${methodName}(inputBefore);
        ${ReturnType} resultAfter = service.${methodName}(inputAfter);
        
        // Then
        // 임계값 전후 결과 차이 검증
        ${thresholdAssertions}
    }
}
```

##### 3.3.3 예외 케이스 테스트 (Error Cases)
```java
@Nested
@DisplayName("${MethodName} - 예외 케이스")
class ${MethodName}ErrorCases {
    
    @Test
    @DisplayName("NULL 입력값 테스트")
    void test${MethodName}_NullInput() {
        // Given
        ${InputType} input = null;
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("${nullErrorMessage}");
    }
    
    @Test
    @DisplayName("잘못된 형식 입력값 테스트")
    void test${MethodName}_InvalidFormat() {
        // Given
        ${InputType} input = TestDataGenerator.generateInvalidFormat();
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("${formatErrorMessage}");
    }
    
    @Test
    @DisplayName("비즈니스 규칙 위반 테스트")
    void test${MethodName}_BusinessRuleViolation() {
        // Given
        ${InputType} input = TestDataGenerator.generateBusinessRuleViolation();
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(${BusinessException}.class)
            .hasMessageContaining("${businessErrorMessage}");
    }
    
    @Test
    @DisplayName("데이터 존재하지 않음 테스트")
    void test${MethodName}_DataNotFound() {
        // Given
        ${InputType} input = TestDataGenerator.generateNonExistentData();
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(EntityNotFoundException.class)
            .hasMessageContaining("${notFoundErrorMessage}");
    }
}
```

##### 3.3.4 트랜잭션 테스트 (Transaction Cases)
```java
@Nested
@DisplayName("${MethodName} - 트랜잭션 테스트")
class ${MethodName}TransactionCases {
    
    @Test
    @DisplayName("트랜잭션 커밋 테스트")
    void test${MethodName}_TransactionCommit() {
        // Given
        ${InputType} input = TestDataGenerator.generateValid${InputType}();
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        // DB 상태 변경 확인
        ${transactionCommitAssertions}
    }
    
    @Test
    @DisplayName("트랜잭션 롤백 테스트")
    void test${MethodName}_TransactionRollback() {
        // Given
        ${InputType} input = TestDataGenerator.generateExceptionCausingInput();
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(RuntimeException.class);
        
        // DB 상태 롤백 확인
        ${transactionRollbackAssertions}
    }
}
```

##### 3.3.5 상태 전이 테스트 (State Transition Cases)
```java
@Nested
@DisplayName("${MethodName} - 상태 전이 테스트")
class ${MethodName}StateTransitionCases {
    
    @ParameterizedTest
    @ValueSource(strings = {"PENDING", "CONFIRMED", "PAID"})
    @DisplayName("유효한 상태 전이 테스트")
    void test${MethodName}_ValidStateTransition(String currentState) {
        // Given
        ${InputType} input = TestDataGenerator.generateWithState(currentState);
        
        // When
        ${ReturnType} result = service.${methodName}(input);
        
        // Then
        // 상태 전이 결과 검증
        ${stateTransitionAssertions}
    }
    
    @Test
    @DisplayName("잘못된 상태 전이 테스트")
    void test${MethodName}_InvalidStateTransition() {
        // Given
        ${InputType} input = TestDataGenerator.generateInvalidStateTransition();
        
        // When & Then
        assertThatThrownBy(() -> service.${methodName}(input))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("${stateTransitionErrorMessage}");
    }
}
```

##### 3.3.6 동시성 테스트 (Concurrency Cases)
```java
@Nested
@DisplayName("${MethodName} - 동시성 테스트")
class ${MethodName}ConcurrencyCases {
    
    @Test
    @DisplayName("동시 접근 테스트")
    void test${MethodName}_ConcurrentAccess() throws InterruptedException {
        // Given
        int threadCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);
        List<Future<${ReturnType}>> futures = new ArrayList<>();
        
        // When
        for (int i = 0; i < threadCount; i++) {
            ${InputType} input = TestDataGenerator.generateConcurrentCase(i);
            Future<${ReturnType}> future = executor.submit(() -> {
                try {
                    return service.${methodName}(input);
                } finally {
                    latch.countDown();
                }
            });
            futures.add(future);
        }
        
        latch.await();
        
        // Then
        // 동시성 처리 결과 검증
        ${concurrencyAssertions}
    }
}
```

### Step 4: 테스트 데이터 관리

#### 4.1 MariaDB 테스트 환경 구성
- MariaDB 10.3 이상 버전 사용 권장
- 테스트 전용 데이터베이스 생성
- 테스트 프로파일(application-test.yml) 활용
- @ActiveProfiles("test") 어노테이션으로 테스트 환경 활성화

#### 4.2 범용 동적 테스트 데이터 생성기

**⚠️ 핵심 원칙: 특정 도메인에 의존하지 않는 범용적 데이터 생성**

```java
@Component
public class UniversalTestDataGenerator {
    
    private final JdbcTemplate jdbcTemplate;
    private final Map<Class<?>, Object> generatedEntities = new HashMap<>();
    private final Map<String, BusinessRule> extractedRules = new HashMap<>();
    
    public UniversalTestDataGenerator(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    /**
     * 1. Service 클래스 분석을 통한 테스트 데이터 규칙 추출
     */
    public TestDataRules analyzeServiceClass(Class<?> serviceClass) {
        TestDataRules rules = new TestDataRules();
        
        // 1.1 메소드 파라미터 타입 분석
        for (Method method : serviceClass.getDeclaredMethods()) {
            if (Modifier.isPublic(method.getModifiers())) {
                for (Parameter param : method.getParameters()) {
                    Class<?> paramType = param.getType();
                    rules.addParameterType(method.getName(), paramType);
                    
                    // DTO 클래스인 경우 내부 필드 분석
                    if (isDtoClass(paramType)) {
                        rules.addDtoAnalysis(paramType, analyzeDtoClass(paramType));
                    }
                }
            }
        }
        
        // 1.2 소스 코드에서 비즈니스 규칙 추출
        rules.setBusinessRules(extractBusinessRulesFromSource(serviceClass));
        
        return rules;
    }
    
    /**
     * 2. DTO 클래스 분석 (어노테이션 기반)
     */
    private DtoAnalysis analyzeDtoClass(Class<?> dtoClass) {
        DtoAnalysis analysis = new DtoAnalysis();
        
        for (Field field : dtoClass.getDeclaredFields()) {
            FieldRule fieldRule = new FieldRule();
            fieldRule.setFieldName(field.getName());
            fieldRule.setFieldType(field.getType());
            
            // 검증 어노테이션 분석
            if (field.isAnnotationPresent(NotNull.class)) {
                fieldRule.setRequired(true);
            }
            if (field.isAnnotationPresent(Size.class)) {
                Size size = field.getAnnotation(Size.class);
                fieldRule.setMinSize(size.min());
                fieldRule.setMaxSize(size.max());
            }
            if (field.isAnnotationPresent(Min.class)) {
                fieldRule.setMinValue(field.getAnnotation(Min.class).value());
            }
            if (field.isAnnotationPresent(Max.class)) {
                fieldRule.setMaxValue(field.getAnnotation(Max.class).value());
            }
            if (field.isAnnotationPresent(Pattern.class)) {
                fieldRule.setPattern(field.getAnnotation(Pattern.class).regexp());
            }
            
            analysis.addFieldRule(field.getName(), fieldRule);
        }
        
        return analysis;
    }
    
    /**
     * 3. 소스 코드에서 비즈니스 규칙 추출 (정적 분석)
     */
    private Map<String, BusinessRule> extractBusinessRulesFromSource(Class<?> serviceClass) {
        Map<String, BusinessRule> rules = new HashMap<>();
        
        try {
            // 소스 파일 읽기 및 패턴 매칭
            String sourceCode = readSourceFile(serviceClass);
            
            // 3.1 상수값 추출 (할인 임계값, 최대값 등)
            extractConstantValues(sourceCode, rules);
            
            // 3.2 조건문에서 경계값 추출
            extractBoundaryValues(sourceCode, rules);
            
            // 3.3 예외 메시지에서 검증 규칙 추출
            extractValidationRules(sourceCode, rules);
            
            // 3.4 상태 전이 패턴 추출
            extractStateTransitions(sourceCode, rules);
            
        } catch (Exception e) {
            log.warn("소스 코드 분석 실패: {}", e.getMessage());
        }
        
        return rules;
    }
    
    /**
     * 4. 범용 테스트 데이터 생성
     */
    public <T> T generateTestData(Class<T> targetClass, TestDataType dataType) {
        try {
            T instance = targetClass.getDeclaredConstructor().newInstance();
            
            for (Field field : targetClass.getDeclaredFields()) {
                field.setAccessible(true);
                Object value = generateFieldValue(field, dataType);
                field.set(instance, value);
            }
            
            return instance;
        } catch (Exception e) {
            throw new RuntimeException("테스트 데이터 생성 실패: " + targetClass.getSimpleName(), e);
        }
    }
    
    /**
     * 5. 필드별 값 생성 (타입 기반)
     */
    private Object generateFieldValue(Field field, TestDataType dataType) {
        Class<?> fieldType = field.getType();
        String fieldName = field.getName().toLowerCase();
        
        // 5.1 기본 타입별 생성
        if (fieldType == String.class) {
            return generateStringValue(field, dataType);
        } else if (fieldType == Long.class || fieldType == long.class) {
            return generateLongValue(field, dataType);
        } else if (fieldType == Integer.class || fieldType == int.class) {
            return generateIntValue(field, dataType);
        } else if (fieldType == BigDecimal.class) {
            return generateBigDecimalValue(field, dataType);
        } else if (fieldType == LocalDateTime.class) {
            return generateDateTimeValue(field, dataType);
        } else if (fieldType == Boolean.class || fieldType == boolean.class) {
            return generateBooleanValue(field, dataType);
        } else if (fieldType.isEnum()) {
            return generateEnumValue(fieldType, dataType);
        } else if (List.class.isAssignableFrom(fieldType)) {
            return generateListValue(field, dataType);
        }
        
        return null;
    }
    
    /**
     * 6. 데이터 타입별 생성 전략
     */
    private String generateStringValue(Field field, TestDataType dataType) {
        String fieldName = field.getName().toLowerCase();
        
        switch (dataType) {
            case VALID:
                if (fieldName.contains("email")) return "test" + System.currentTimeMillis() + "@example.com";
                if (fieldName.contains("phone")) return "010-1234-5678";
                if (fieldName.contains("name")) return "테스트" + fieldName;
                if (fieldName.contains("address")) return "서울시 강남구 테스트로 123";
                return "valid_" + fieldName + "_" + System.currentTimeMillis();
                
            case NULL_ERROR:
                return null;
                
            case EMPTY_ERROR:
                return "";
                
            case INVALID_FORMAT:
                if (fieldName.contains("email")) return "invalid-email";
                if (fieldName.contains("phone")) return "invalid-phone";
                return "invalid_format";
                
            case BOUNDARY_MIN:
                return "a"; // 최소 길이
                
            case BOUNDARY_MAX:
                return "a".repeat(255); // 최대 길이
                
            default:
                return "default_" + fieldName;
        }
    }
    
    private Long generateLongValue(Field field, TestDataType dataType) {
        String fieldName = field.getName().toLowerCase();
        
        switch (dataType) {
            case VALID:
                return System.currentTimeMillis() % 1000000L + 1;
            case NULL_ERROR:
                return null;
            case BOUNDARY_MIN:
                return 1L;
            case BOUNDARY_MAX:
                return Long.MAX_VALUE;
            case INVALID_NEGATIVE:
                return -1L;
            case ZERO_ERROR:
                return 0L;
            default:
                return 100L;
        }
    }
    
    private BigDecimal generateBigDecimalValue(Field field, TestDataType dataType) {
        String fieldName = field.getName().toLowerCase();
        
        // 비즈니스 규칙에서 추출된 임계값 사용
        BusinessRule rule = extractedRules.get(fieldName);
        
        switch (dataType) {
            case VALID:
                return BigDecimal.valueOf(50000);
            case BOUNDARY_THRESHOLD_MINUS_1:
                return rule != null ? rule.getThreshold().subtract(BigDecimal.ONE) 
                                   : BigDecimal.valueOf(99999);
            case BOUNDARY_THRESHOLD_EXACT:
                return rule != null ? rule.getThreshold() 
                                   : BigDecimal.valueOf(100000);
            case BOUNDARY_THRESHOLD_PLUS_1:
                return rule != null ? rule.getThreshold().add(BigDecimal.ONE) 
                                   : BigDecimal.valueOf(100001);
            case ZERO_ERROR:
                return BigDecimal.ZERO;
            case NEGATIVE_ERROR:
                return BigDecimal.valueOf(-1000);
            default:
                return BigDecimal.valueOf(10000);
        }
    }
    
    /**
     * 7. 데이터베이스 엔티티 생성 (스키마 분석 기반)
     */
    public Long createDatabaseEntity(String tableName, Map<String, Object> fieldValues) {
        try {
            // 테이블 스키마 정보 조회
            List<ColumnInfo> columns = getTableSchema(tableName);
            
            // INSERT 쿼리 동적 생성
            StringBuilder sql = new StringBuilder("INSERT INTO ").append(tableName).append(" (");
            StringBuilder values = new StringBuilder("VALUES (");
            List<Object> params = new ArrayList<>();
            
            for (ColumnInfo column : columns) {
                if (!column.isAutoIncrement()) {
                    sql.append(column.getName()).append(", ");
                    values.append("?, ");
                    
                    Object value = fieldValues.getOrDefault(column.getName(), 
                                  generateDefaultValueForColumn(column));
                    params.add(value);
                }
            }
            
            sql.setLength(sql.length() - 2); // 마지막 ", " 제거
            values.setLength(values.length() - 2);
            sql.append(") ").append(values).append(")");
            
            jdbcTemplate.update(sql.toString(), params.toArray());
            return jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
            
        } catch (Exception e) {
            throw new RuntimeException("DB 엔티티 생성 실패: " + tableName, e);
        }
    }
    
    // Helper methods
    private boolean isDtoClass(Class<?> clazz) {
        return clazz.getSimpleName().endsWith("Dto") || 
               clazz.getSimpleName().endsWith("Request") ||
               clazz.getSimpleName().endsWith("Response");
    }
    
    private List<ColumnInfo> getTableSchema(String tableName) {
        // MariaDB 스키마 정보 조회
        String sql = "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA " +
                    "FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ?";
        
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            ColumnInfo column = new ColumnInfo();
            column.setName(rs.getString("COLUMN_NAME"));
            column.setDataType(rs.getString("DATA_TYPE"));
            column.setNullable("YES".equals(rs.getString("IS_NULLABLE")));
            column.setAutoIncrement("auto_increment".equals(rs.getString("EXTRA")));
            return column;
        }, tableName);
    }
}

/**
 * 테스트 데이터 타입 enum
 */
enum TestDataType {
    VALID,                      // 정상 데이터
    NULL_ERROR,                 // NULL 값
    EMPTY_ERROR,               // 빈 값
    INVALID_FORMAT,            // 잘못된 형식
    BOUNDARY_MIN,              // 최솟값
    BOUNDARY_MAX,              // 최댓값  
    BOUNDARY_THRESHOLD_MINUS_1, // 임계값 -1
    BOUNDARY_THRESHOLD_EXACT,   // 임계값 정확히
    BOUNDARY_THRESHOLD_PLUS_1,  // 임계값 +1
    ZERO_ERROR,                // 0 값
    NEGATIVE_ERROR,            // 음수 값
    INVALID_NEGATIVE,          // 잘못된 음수
    LARGE_DATA                 // 대용량 데이터
}
```

#### 4.3 범용 테스트 데이터 생성기 사용 예시

**⚠️ 핵심: 어떤 도메인이든 자동으로 적용되는 범용 솔루션**

```java
/**
 * 실제 사용 예시 - 어떤 Service든 자동 분석 및 테스트 생성
 */
@SpringBootTest
@Transactional
@ActiveProfiles("test")
class UniversalServiceTest {
    
    @Autowired
    private UniversalTestDataGenerator testDataGenerator;
    
    /**
     * 예시 1: 주문 도메인 Service 테스트
     */
    @Test
    void testOrderService_DynamicallyGenerated() {
        // 1. Service 클래스 동적 분석
        Class<?> serviceClass = OrderService.class;
        TestDataRules rules = testDataGenerator.analyzeServiceClass(serviceClass);
        
        // 2. 분석된 규칙 기반 테스트 데이터 자동 생성
        for (Method method : serviceClass.getDeclaredMethods()) {
            if (Modifier.isPublic(method.getModifiers())) {
                Class<?> paramType = method.getParameterTypes()[0];
                
                // 정상 케이스 데이터
                Object validData = testDataGenerator.generateTestData(paramType, TestDataType.VALID);
                
                // 경계값 케이스 데이터  
                Object boundaryData = testDataGenerator.generateTestData(paramType, TestDataType.BOUNDARY_MIN);
                
                // 에러 케이스 데이터
                Object errorData = testDataGenerator.generateTestData(paramType, TestDataType.NULL_ERROR);
                
                // 실제 메소드 호출 및 검증
                // assertThat(service.method(validData)).isNotNull();
            }
        }
    }
    
    /**
     * 예시 2: 게시판 도메인 Service 테스트 (완전히 다른 도메인)
     */
    @Test
    void testBoardService_DynamicallyGenerated() {
        // BoardService, BoardDto가 있다면 동일한 방식으로 자동 처리
        Class<?> serviceClass = BoardService.class;
        TestDataRules rules = testDataGenerator.analyzeServiceClass(serviceClass);
        
        // BoardDto 필드 분석 예시:
        // - title: String (@NotNull, @Size(min=1, max=100))
        // - content: String (@NotNull, @Size(min=1, max=2000))
        // - authorId: Long (@NotNull)
        // - categoryId: Long (@NotNull)
        // - viewCount: Integer (default 0)
        // - status: String (enum: DRAFT, PUBLISHED, DELETED)
        
        // 자동으로 의미있는 테스트 데이터 생성:
        // title: "테스트title_타임스탬프"
        // content: "테스트content_타임스탬프" 
        // authorId: 실제 DB에서 생성된 사용자 ID
        // etc...
    }
    
    /**
     * 예시 3: 파일 관리 도메인 Service 테스트 (또 다른 도메인)
     */
    @Test
    void testFileService_DynamicallyGenerated() {
        // FileService, FileDto가 있다면 동일한 방식으로 자동 처리
        // 필드명 기반 지능적 데이터 생성:
        // - fileName: "test_file_타임스탬프.txt"
        // - fileSize: 적절한 크기 (1024L)
        // - mimeType: "text/plain"
        // - uploadPath: "/uploads/test/"
        // etc...
    }
}
```

#### 4.4 실제 동작 시나리오

```java
/**
 * 단계별 자동 분석 및 생성 과정
 */
public class TestGenerationScenario {
    
    public void generateTestsForAnyService(Class<?> serviceClass) {
        
        // Step 1: 클래스 구조 분석
        System.out.println("=== Step 1: 클래스 분석 ===");
        for (Method method : serviceClass.getDeclaredMethods()) {
            System.out.println("메소드: " + method.getName());
            System.out.println("파라미터 타입: " + Arrays.toString(method.getParameterTypes()));
            System.out.println("반환 타입: " + method.getReturnType());
        }
        
        // Step 2: DTO 클래스 어노테이션 분석
        System.out.println("=== Step 2: DTO 분석 ===");
        Class<?> dtoClass = findDtoClass(serviceClass);
        for (Field field : dtoClass.getDeclaredFields()) {
            System.out.println("필드: " + field.getName() + " (" + field.getType() + ")");
            
            if (field.isAnnotationPresent(NotNull.class)) {
                System.out.println("  - 필수 필드");
            }
            if (field.isAnnotationPresent(Size.class)) {
                Size size = field.getAnnotation(Size.class);
                System.out.println("  - 크기 제한: " + size.min() + "~" + size.max());
            }
        }
        
        // Step 3: 소스 코드에서 비즈니스 규칙 추출
        System.out.println("=== Step 3: 비즈니스 규칙 추출 ===");
        String sourceCode = readSourceFile(serviceClass);
        
        // 할인 임계값 찾기
        Pattern thresholdPattern = Pattern.compile("compareTo\\(BigDecimal\\.valueOf\\((\\d+)\\)\\)");
        Matcher matcher = thresholdPattern.matcher(sourceCode);
        if (matcher.find()) {
            String threshold = matcher.group(1);
            System.out.println("발견된 임계값: " + threshold);
        }
        
        // 상태값 찾기
        Pattern statusPattern = Pattern.compile("\"([A-Z_]+)\"");
        Matcher statusMatcher = statusPattern.matcher(sourceCode);
        Set<String> statuses = new HashSet<>();
        while (statusMatcher.find()) {
            statuses.add(statusMatcher.group(1));
        }
        System.out.println("발견된 상태값들: " + statuses);
        
        // Step 4: 데이터베이스 스키마 분석
        System.out.println("=== Step 4: DB 스키마 분석 ===");
        String tableName = extractTableName(dtoClass);
        List<ColumnInfo> columns = getTableSchema(tableName);
        for (ColumnInfo column : columns) {
            System.out.println("컬럼: " + column.getName() + " (" + column.getDataType() + ")");
        }
        
        // Step 5: 종합하여 테스트 데이터 생성
        System.out.println("=== Step 5: 테스트 데이터 생성 ===");
        
        // 정상 케이스
        Object validData = generateTestData(dtoClass, TestDataType.VALID);
        System.out.println("정상 데이터: " + validData);
        
        // 경계값 케이스 (발견된 임계값 기준)
        Object boundaryData = generateTestData(dtoClass, TestDataType.BOUNDARY_THRESHOLD_MINUS_1);
        System.out.println("경계값 데이터: " + boundaryData);
        
        // 에러 케이스 (어노테이션 기준)
        Object errorData = generateTestData(dtoClass, TestDataType.NULL_ERROR);
        System.out.println("에러 데이터: " + errorData);
    }
}
```

#### 4.5 다양한 도메인 적용 예시

```java
/**
 * 실제 프로젝트에서 만날 수 있는 다양한 도메인들
 */
public class DiverseDomainExamples {
    
    // 🛒 전자상거래 도메인
    void testEcommerceServices() {
        // OrderService, ProductService, CartService, PaymentService
        // CouponService, InventoryService, ShippingService
    }
    
    // 📝 콘텐츠 관리 도메인  
    void testCmsServices() {
        // ArticleService, CategoryService, TagService, CommentService
        // MediaService, TemplateService, MenuService
    }
    
    // 👥 사용자 관리 도메인
    void testUserManagementServices() {
        // UserService, RoleService, PermissionService, AuthService
        // ProfileService, PreferenceService, SessionService
    }
    
    // 📊 리포팅 도메인
    void testReportingServices() {
        // ReportService, DashboardService, ChartService, ExportService
        // ScheduleService, NotificationService, AlertService  
    }
    
    // 🏭 제조업 도메인
    void testManufacturingServices() {
        // ProductionService, QualityService, InventoryService
        // MaintenanceService, SchedulingService, WorkOrderService
    }
    
    // 🏥 의료 도메인
    void testHealthcareServices() {
        // PatientService, AppointmentService, MedicalRecordService
        // PrescriptionService, BillingService, InsuranceService
    }
}
```

## 📊 테스트 커버리지 전략

### 1. 필수 테스트 시나리오
- **정상 플로우**: Happy path 테스트
- **경계값**: 최소값, 최대값, 임계값
- **예외 케이스**: 모든 validation 실패 케이스
- **상태 전이**: 가능한 모든 상태 변경
- **비즈니스 규칙**: 할인, 등급 계산 등

### 2. 데이터 조합 매트릭스
```java
public class TestScenarios {
    // 주문 금액별 할인 테스트
    public static final List<TestCase> DISCOUNT_CASES = Arrays.asList(
        new TestCase(99999, 0, "할인 미적용"),
        new TestCase(100000, 5, "할인 경계값"),
        new TestCase(200000, 5, "할인 적용")
    );
    
    // 고객 등급별 처리
    public static final List<String> CUSTOMER_GRADES = 
        Arrays.asList("BRONZE", "SILVER", "GOLD", "VIP");
}
```

## 🔧 자동 생성 스크립트

### 테스트 생성 유틸리티
```java
public class TestGenerator {
    
    public void generateServiceTest(String servicePath) {
        // 1. Service 클래스 분석
        ServiceAnalysis analysis = analyzeService(servicePath);
        
        // 2. 테스트 클래스 생성
        String testClass = generateTestClass(analysis);
        
        // 3. 테스트 메소드 생성
        for (Method method : analysis.getMethods()) {
            testClass += generateTestMethod(method);
        }
        
        // 4. 파일 저장
        saveTestFile(testClass, analysis.getServiceName());
    }
}
```

## ✅ 검증 항목

### 테스트 품질 체크리스트
- [ ] 모든 public 메소드에 대한 테스트 존재
- [ ] 정상 케이스와 예외 케이스 모두 포함
- [ ] 비즈니스 규칙 검증 포함
- [ ] 트랜잭션 롤백 확인
- [ ] 테스트 독립성 보장

## 📝 생성 파일 예시

### OrderServiceTest.java
```java
@SpringBootTest
@Transactional
@ActiveProfiles("test")  // test 프로파일 사용
class OrderServiceTest {
    
    @Autowired
    private OrderService orderService;
    
    @Test
    @DisplayName("주문 처리 - 할인 적용 케이스")
    void testProcessOrder_WithDiscount() {
        // Given
        OrderDto order = TestDataGenerator.generateDiscountOrder();
        
        // When
        ResponseOrder result = orderService.processOrder(order);
        
        // Then
        BigDecimal expectedPrice = BigDecimal.valueOf(120000)
            .multiply(BigDecimal.valueOf(0.95)); // 5% 할인
        assertThat(result.getTotalPrice()).isEqualTo(expectedPrice);
    }
}
```

## 🚀 실행 방법

### 1. Service 클래스별 테스트 자동 생성 순서

#### 1.1 리팩토링된 Service 클래스 스캔
```bash
# {workingDir}/first/domain/ 디렉토리에서 Service 클래스 검색
find {workingDir}/first/domain -name "*Service.java" -type f
```

#### 1.2 각 Service별 테스트 클래스 생성
```java
// 예시: 분리된 Service들에 대한 테스트 생성
// OrderService → OrderServiceTest.java
// CustomerService → CustomerServiceTest.java
// PaymentService → PaymentServiceTest.java
// ProductService → ProductServiceTest.java
```

#### 1.3 테스트 생성 검증 체크리스트
- [ ] 각 Service의 public 메소드마다 최소 5개 이상의 테스트 케이스 생성
- [ ] 정상 케이스, 경계값, 예외 케이스 모두 포함
- [ ] 비즈니스 로직별 세부 검증 추가
- [ ] 상태 전이 및 트랜잭션 테스트 포함
- [ ] 동시성 및 대용량 데이터 테스트 추가

### 2. 테스트 실행 및 검증

#### 2.1 개별 Service 테스트 실행
```bash
# 특정 Service 테스트 실행
./gradlew test --tests "*OrderServiceTest"
./gradlew test --tests "*CustomerServiceTest"
```

#### 2.2 전체 Service 테스트 일괄 실행
```bash
# 모든 Service 테스트 실행
./gradlew test --tests "*ServiceTest"
```

#### 2.3 테스트 커버리지 확인
```bash
# 커버리지 리포트 생성
./gradlew jacocoTestReport
```

### 3. 테스트 결과 분석 및 보고

#### 3.1 테스트 결과 요약서 생성
```markdown
# Service별 테스트 결과 요약

## OrderService 테스트 결과
- 총 테스트 케이스: 45개
- 성공: 43개
- 실패: 2개
- 커버리지: 95%

## CustomerService 테스트 결과
- 총 테스트 케이스: 38개
- 성공: 38개
- 실패: 0개
- 커버리지: 98%
```

## 📌 주요 원칙 및 주의사항

### 🎯 Service 레이어 중심 테스트 생성

**⚠️ 중요: Controller 테스트가 아닌 Service 테스트 생성**
- 리팩토링으로 분리된 각 Service 클래스별로 독립적인 테스트 클래스 생성
- {workingDir}/first/domain/{domainName}/ 경로의 Service 클래스들을 대상으로 함
- Controller 테스트는 생성하지 않고 오직 Service 레이어만 집중

### 🔍 포괄적 테스트 케이스 생성

**각 Service 메소드당 최소 6가지 테스트 유형:**
1. **정상 케이스**: 기본 동작, 비즈니스 규칙 적용, 대용량 데이터
2. **경계값 테스트**: 최솟값, 최댓값, 임계값 직전/직후
3. **예외 케이스**: NULL, 잘못된 형식, 비즈니스 규칙 위반, 데이터 없음
4. **트랜잭션 테스트**: 커밋, 롤백 확인
5. **상태 전이 테스트**: 유효/무효 상태 변경
6. **동시성 테스트**: 멀티스레드 환경 검증

### 🛢️ 실제 DB 연동 테스트

- Mock 프레임워크 사용 금지
- 실제 MariaDB 연동하여 통합 환경 검증
- application-test.yml 프로파일 활용
- @ActiveProfiles("test") 어노테이션 필수
- 트랜잭션 롤백으로 테스트 데이터 격리
- MariaDB의 LAST_INSERT_ID() 사용하여 생성된 ID 조회

### 📊 테스트 데이터 전략

- 소스 코드 분석을 통한 규칙 기반 데이터 생성
- 검증 로직에서 필수 필드 및 값 범위 추출
- 비즈니스 로직에서 경계값 및 임계값 파악
- 다양한 고객 등급, 상품 가격대, 주문 상태별 데이터 준비
- 예외 상황을 위한 특수 데이터 세트 구성

### ✅ 테스트 품질 기준

- **커버리지 목표**: 각 Service 95% 이상
- **테스트 케이스 수**: 메소드당 최소 5개 이상
- **실행 시간**: 전체 Service 테스트 5분 이내
- **독립성**: 테스트 간 상호 의존성 없음
- **재현성**: 동일한 조건에서 항상 같은 결과

### 🚫 금지사항

- Controller 레이어 테스트 생성 금지
- Mock 객체 사용 금지
- H2 인메모리 DB 사용 금지
- 테스트 간 데이터 공유 금지
- 하드코딩된 테스트 데이터 사용 금지

## 📋 최종 실행 체크리스트

### Stage 9 완료 확인사항
- [ ] 1. 리팩토링된 모든 Service 클래스 탐지 완료
- [ ] 2. 각 Service별 독립적인 테스트 클래스 생성 완료
- [ ] 3. 메소드당 최소 5개 이상의 다양한 테스트 케이스 구현
- [ ] 4. application-test.yml 설정 완료
- [ ] 5. MariaDB 테스트 환경 구축 완료
- [ ] 6. 종합 테스트 데이터 생성기 구현 완료
- [ ] 7. 모든 테스트 실행 및 통과 확인
- [ ] 8. 테스트 커버리지 95% 이상 달성
- [ ] 9. 테스트 결과 보고서 생성 완료

### 산출물 확인
- [ ] `{workingDir}/first/test/` 디렉토리에 Service별 테스트 클래스 생성
- [ ] `test-report.md` 파일에 테스트 결과 요약 기록
- [ ] 각 Service 테스트에서 비즈니스 로직 정확성 검증 완료

**✅ Stage 9 완료 시 리팩토링된 모든 Service의 기능이 올바르게 동작함을 보장**

---
**다음 단계**: Stage 9 완료 후 전체 리팩토링 프로세스가 완료되며, 도메인별로 분리된 Service 클래스들이 모두 검증됩니다.
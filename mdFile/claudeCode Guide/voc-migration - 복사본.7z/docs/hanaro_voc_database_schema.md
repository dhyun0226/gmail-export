# 하나로 VOC 데이터베이스 스키마 문서

## 개요
이 문서는 하나로 VOC(Voice of Customer) 시스템의 데이터베이스 스키마를 설명합니다.

## ERD (Entity Relationship Diagram)

### Mermaid ERD

```mermaid
erDiagram
    TB_HANARO_BOARD_INFO ||--o{ TB_HANARO_BOARD : "has"
    TB_HANARO_BOARD_INFO ||--o{ TB_HANARO_BOARD_CATEGORY : "has"
    TB_HANARO_BOARD_CATEGORY ||--o{ TB_HANARO_BOARD : "categorizes"
    TB_HANARO_BOARD ||--o{ TB_HANARO_BOARD_FILE : "has"
    TB_HANARO_BOARD ||--o{ TB_HANARO_BOARD_MEMO : "has"
    TB_HANARO_BOARD ||--o{ TB_HANARO_BOARD_MOVIE : "has"

    TB_HANARO_BOARD_INFO {
        VARCHAR2 DB PK "게시판 구분자"
        NVARCHAR2 DB_NM "게시판명"
        NVARCHAR2 DB_DESC "게시판 설명"
        VARCHAR2 REPLY_YN "답글여부"
        VARCHAR2 MEMO_YN "댓글여부"
        VARCHAR2 USE_YN "사용여부"
        NVARCHAR2 DB_NICK_NM "게시판 별명"
    }

    TB_HANARO_BOARD {
        NUMBER NO PK "게시판 일련번호"
        NVARCHAR2 DB FK "게시판 구분자"
        NUMBER CATEGORY FK "게시판카테고리"
        NVARCHAR2 SUBJECT "제목"
        NCLOB CONTENT "내용"
        NVARCHAR2 USERID "등록자아이디"
        NUMBER HIT "조회수"
        NUMBER RECOMMEND "추천수"
        NUMBER HTML "표시형식"
        DATE REGDATE "등록일"
        NVARCHAR2 UPDATER "수정자"
        DATE UPDATE_DATE "수정일"
        NUMBER UMU "공개유무"
        NUMBER NOTI_YN "공지 적용여부"
        NUMBER MAIN_YN "헤드라인 적용여부"
        VARCHAR2 ONLINEHELP1 "온라인도움말코드1"
        VARCHAR2 ONLINEHELP2 "온라인도움말코드2"
        NCLOB QNA "QNA 답변"
        DATE QNA_DATE "QNA 답변일"
        VARCHAR2 TODAY "TODAY 이슈"
        NUMBER IS_HIDDEN "숨김여부"
        NUMBER BBS_NO "게시판번호"
        CLOB CONTENT_UPPER "대소문자구분없는내용"
        VARCHAR2 SECRET "비밀글기능"
    }

    TB_HANARO_BOARD_CATEGORY {
        NUMBER CATEGORY_CODE PK "카테고리정보 일련번호"
        NVARCHAR2 CATEGORY_NAME "카테고리명"
        NVARCHAR2 DB FK "게시판 구분자"
        VARCHAR2 USE_YN "사용유무"
        NUMBER ORDER_NUM "정렬 순서"
        NVARCHAR2 CATEGORY_CSS "카테고리 CSS"
    }

    TB_HANARO_BOARD_FILE {
        NUMBER FILE_NO PK "파일 일련번호"
        NUMBER BOARD_NO FK "게시판 일련번호"
        NVARCHAR2 FILE_NAME "파일명"
        NVARCHAR2 FILE_PHYSICAL "물리적 파일명"
        NUMBER FILE_SIZE "파일 사이즈"
        NVARCHAR2 FILE_TYPE "파일 타입"
        NVARCHAR2 FILE_PATH "파일 경로"
        NUMBER BBS_NO "게시판번호"
    }

    TB_HANARO_BOARD_MEMO {
        NUMBER MEMO_NO PK "게시판 댓글일련번호"
        NUMBER BOARD_NO FK "게시판 일련번호"
        NVARCHAR2 MEMO_ID "등록자아이디"
        DATE MEMO_DT "등록일자"
        CLOB MEMO_CONTENT "댓글내용"
        NUMBER BBS_NO "게시판번호"
    }

    TB_HANARO_BOARD_MOVIE {
        NUMBER TB_HANARO_BOARD_MOVIE_SEQ PK "동영상일련번호"
        NUMBER TB_HANARO_BOARD_SEQ FK "게시판일련번호"
        VARCHAR2 FILE_NM "파일명"
        VARCHAR2 REAL_FILE_NM "실제파일명"
        NUMBER FILE_SIZE "파일사이즈"
        VARCHAR2 MOVIE_URL "동영상URL"
        VARCHAR2 MOVIE_HTML "동영상HTML"
        NUMBER MOVIE_SEQ "동영상일련번호"
        NUMBER MOVIE_PLAY_TIME "동영상재생시간"
        VARCHAR2 THUMB_URL1 "썸네일URL1"
        VARCHAR2 THUMB_URL2 "썸네일URL2"
        VARCHAR2 THUMB_URL3 "썸네일URL3"
        VARCHAR2 THUMB_URL4 "썸네일URL4"
        VARCHAR2 THUMB_URL5 "썸네일URL5"
        VARCHAR2 STATE_CD "상태코드"
        DATE REG_DT "등록일"
        VARCHAR2 REG_ID "등록자"
        DATE MOD_DT "수정일"
        VARCHAR2 MOD_ID "수정자"
        VARCHAR2 MOVIE_ATTACH_TYPE_CD "동영상첨부방식"
        VARCHAR2 MOVIE_ENC_FILE_NM "동영상인코딩파일명"
    }

    TB_HANARO_MEMBER {
        VARCHAR2 USER_ID "사용자아이디"
        NUMBER USE_CNT "사용대수"
        VARCHAR2 REG_ID "등록자"
        DATE REG_DT "등록일"
        VARCHAR2 MOD_ID "수정자"
        DATE MOD_DT "수정일"
        VARCHAR2 GUBUN "구분"
    }

    TB_HANARO_COMM_CODE {
        VARCHAR2 CODE_GRP "그룹코드"
        VARCHAR2 CODE "코드"
        NVARCHAR2 CODE_GRP_NM "그룹코드명"
        NVARCHAR2 CODE_NM "코드명"
        NVARCHAR2 CODE_SUB_NM "서브코드명"
        VARCHAR2 DEL_YN "삭제여부"
    }

    TB_HANARO_SEARCHWORD {
        NUMBER NO PK "검색어 일련번호"
        NVARCHAR2 SEARCH_WORD "검색단어"
        NUMBER SEARCH_YN "검색유무"
        TIMESTAMP REGIST_DT "검색일자"
    }

    TB_HANARO_INQUIRY {
        NUMBER NO PK "시연요청 일련번호"
        NVARCHAR2 ASK_KIND "신청종류"
        NVARCHAR2 JEPUM "제품"
        VARCHAR2 LICENCE_NO "면허번호"
        VARCHAR2 YOYANG_NO "요양기관번호"
        NVARCHAR2 BOSS_NAME "원장명"
        VARCHAR2 TEL_NO "치과전화번호"
        NVARCHAR2 DEN_NM "치과명"
        NVARCHAR2 NAME "신청인"
        VARCHAR2 ZIP_NO "우편번호"
        NVARCHAR2 ADDR "주소"
        NVARCHAR2 ADDR_DETAIL "상세주소"
        VARCHAR2 EMAIL_ADR "이메일"
        VARCHAR2 MAIL_RECV_YN "메일수신여부"
        VARCHAR2 MOBILE_NO "긴급연락처"
        VARCHAR2 REPLY_GUBUN "답변희망"
        NCLOB CONTENT "상담내용"
        TIMESTAMP REGIST_DT "등록일자"
        VARCHAR2 BUSINESS_NO "사업자등록번호"
    }

    TB_HANARO_SANGDAM {
        NUMBER NO PK "상담신청일련번호"
        NVARCHAR2 JEPUM "제품"
        NVARCHAR2 ASK_KIND "신청종류"
        VARCHAR2 LICENCE_NO "면허번호"
        VARCHAR2 YOYANG_NO "요양기관번호"
        NVARCHAR2 BOSS_NAME "원장명"
        VARCHAR2 TEL_NO "치과전화번호"
        NVARCHAR2 DEN_NM "치과명"
        NVARCHAR2 NAME "신청인"
        VARCHAR2 BUSINESS_NO "사업자등록번호"
        VARCHAR2 ZIP_NO "우편번호"
        NVARCHAR2 ADDR "주소"
        NVARCHAR2 ADDR_DETAIL "상세주소"
        VARCHAR2 EMAIL_ADR "이메일"
        VARCHAR2 MAIL_RECV_YN "메일수신여부"
        VARCHAR2 MOBILE_NO "긴급연락처"
        VARCHAR2 REPLY_GUBUN "답변희망"
        NCLOB CONTENT "상담내용"
        TIMESTAMP REGIST_DT "등록일자"
        NCLOB ANSWER "답변"
        TIMESTAMP ANSWER_DT "답변일"
        VARCHAR2 USERID "등록자아이디"
        VARCHAR2 DEL_YN "삭제여부"
        VARCHAR2 AGREE_YN "동의여부"
    }
```

## 테이블 관계 설명

### 핵심 테이블 관계

1. **게시판 정보 (TB_HANARO_BOARD_INFO)**
   - 게시판의 메타 정보를 관리하는 마스터 테이블
   - DB 컬럼을 통해 다른 테이블들과 연결

2. **게시판 게시물 (TB_HANARO_BOARD)**
   - 실제 게시물 데이터를 저장하는 메인 테이블
   - TB_HANARO_BOARD_INFO와 DB 컬럼으로 연결
   - TB_HANARO_BOARD_CATEGORY와 CATEGORY 컬럼으로 연결
   - 여러 하위 테이블들과 1:N 관계

3. **게시판 카테고리 (TB_HANARO_BOARD_CATEGORY)**
   - 게시판별 카테고리 정보 관리
   - TB_HANARO_BOARD_INFO와 DB 컬럼으로 연결

4. **게시판 첨부파일 (TB_HANARO_BOARD_FILE)**
   - 게시물의 첨부파일 정보
   - TB_HANARO_BOARD와 BOARD_NO로 연결 (1:N)

5. **게시판 댓글 (TB_HANARO_BOARD_MEMO)**
   - 게시물의 댓글 정보
   - TB_HANARO_BOARD와 BOARD_NO로 연결 (1:N)

6. **게시판 동영상 (TB_HANARO_BOARD_MOVIE)**
   - 게시물의 동영상 정보
   - TB_HANARO_BOARD와 TB_HANARO_BOARD_SEQ로 연결 (1:N)
   - CASCADE DELETE 설정으로 게시물 삭제 시 자동 삭제

### 독립 테이블

- **TB_HANARO_MEMBER**: 하나로/두번에 프로그램 사용자 정보
- **TB_HANARO_COMM_CODE**: 시스템 공통 코드 관리
- **TB_HANARO_SEARCHWORD**: 사용자 검색어 로그
- **TB_HANARO_INQUIRY**: 제품 시연 요청 정보
- **TB_HANARO_SANGDAM**: 제품 상담 게시판

### 백업 테이블

- TB_HANARO_BOARD_BACKUP
- TB_HANARO_BOARD_BAK
- TB_HANARO_BOARD_TMP
- TB_HANARO_BOARD_FILE_TMP
- TB_HANARO_BOARD_MEMO_TMP

## DDL 상세 정보

### 1. TB_HANARO_BOARD (하나로게시물정보)
- **주요 기능**: 게시판의 핵심 게시물 정보 저장
- **특징**:
  - NCLOB 타입으로 대용량 텍스트 지원 (CONTENT, QNA)
  - 공지사항, 헤드라인, 비밀글 등 다양한 기능 지원
  - 온라인 도움말 연동 기능

### 2. TB_HANARO_BOARD_FILE (하나로게시물파일정보)
- **주요 기능**: 게시물 첨부파일 관리
- **특징**: 물리적 파일명과 논리적 파일명 분리 관리

### 3. TB_HANARO_BOARD_MEMO (하나로게시물 댓글정보)
- **주요 기능**: 게시물 댓글 관리
- **특징**: CLOB 타입으로 긴 댓글 지원

### 4. TB_HANARO_BOARD_MOVIE (프로그램도움말동영상)
- **주요 기능**: 동영상 컨텐츠 관리
- **특징**:
  - 인코딩 상태 관리
  - 썸네일 5개까지 지원
  - CASCADE DELETE로 게시물 삭제 시 자동 삭제

### 5. TB_HANARO_INQUIRY (제품시연요청)
- **주요 기능**: 고객의 제품 시연 요청 관리
- **특징**: 치과 관련 정보 특화 (면허번호, 요양기관번호 등)

### 6. TB_HANARO_SANGDAM (제품상담게시판)
- **주요 기능**: 제품 상담 및 답변 관리
- **특징**: 
  - 상담 내용과 답변을 별도 컬럼으로 관리
  - 개인정보 동의 여부 관리

## 인덱스 정보

### 주요 인덱스
- `IX_HANARO_BOARD`: DB, NOTI_YN 복합 인덱스
- `IDX_HANARO_BOARD_01`: DB, NOTI_YN DESC, REGDATE DESC 복합 인덱스
- `IDX_HANARO_BOARD_HIDDEN`: IS_HIDDEN 인덱스
- `IDX_HANARO_BOARD_REGDATE`: REGDATE DESC 인덱스
- `IDX_HANARO_BOARD_MEMO_BOARD_NO`: BOARD_NO 인덱스

## 보안 및 성능 고려사항

1. **보안**
   - 비밀글 기능 (SECRET 컬럼)
   - 공개/비공개 설정 (UMU 컬럼)
   - 숨김 처리 기능 (IS_HIDDEN 컬럼)

2. **성능**
   - 적절한 인덱스 설정으로 조회 성능 최적화
   - LOB 타입 컬럼의 별도 저장 공간 관리
   - SUPPLEMENTAL LOG 설정으로 CDC(Change Data Capture) 지원

## 데이터베이스 정보
- **스키마**: DENJOB
- **테이블스페이스**: TS_DENJOB
- **문자셋**: NVARCHAR2 사용 (유니코드 지원)
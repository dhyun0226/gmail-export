# Oracle 스키마 구성 안내

## 개요
이 프로젝트는 동일한 Oracle 데이터베이스의 서로 다른 스키마에서 데이터를 마이그레이션합니다.

## 스키마 구성

### 1. DENJOB 스키마 (Hanaro VOC)
- **접속 사용자**: DENJOB
- **스키마**: DENJOB (기본 스키마)
- **테이블 접두사**: TB_HANARO_*
- **주요 테이블**:
  - DENJOB.TB_HANARO_BOARD_INFO
  - DENJOB.TB_HANARO_BOARD
  - DENJOB.TB_HANARO_BOARD_CATEGORY
  - DENJOB.TB_HANARO_BOARD_FILE
  - DENJOB.TB_HANARO_BOARD_MEMO
  - DENJOB.TB_HANARO_BOARD_MOVIE
  - DENJOB.TB_HANARO_INQUIRY
  - DENJOB.TB_HANARO_SANGDAM

### 2. EOS 스키마 (Mall VOC)
- **접속 사용자**: DENJOB (EOS 스키마 접근 권한 필요)
- **스키마**: EOS
- **테이블 접두사**: TB_BBS_*
- **주요 테이블**:
  - EOS.TB_BBS_SETUP
  - EOS.TB_BBS
  - EOS.TB_BBS_CATEGORY
  - EOS.TB_BBS_FILE
  - EOS.TB_BBS_RE
  - EOS.TB_BBS_ADD_FIELD

## 권한 설정

DENJOB 사용자가 EOS 스키마에 접근하려면 다음 권한이 필요합니다:

```sql
-- EOS 사용자로 접속하여 실행
GRANT SELECT ON EOS.TB_BBS_SETUP TO DENJOB;
GRANT SELECT ON EOS.TB_BBS TO DENJOB;
GRANT SELECT ON EOS.TB_BBS_CATEGORY TO DENJOB;
GRANT SELECT ON EOS.TB_BBS_FILE TO DENJOB;
GRANT SELECT ON EOS.TB_BBS_RE TO DENJOB;
GRANT SELECT ON EOS.TB_BBS_ADD_FIELD TO DENJOB;

-- 또는 EOS 스키마의 모든 테이블에 대한 SELECT 권한 부여
GRANT SELECT ANY TABLE TO DENJOB;
```

## MyBatis 매퍼 설정

### HanaroMapper.xml
- DENJOB 스키마의 테이블 사용
- 모든 테이블명에 `DENJOB.` 접두사 사용
- 예: `FROM DENJOB.TB_HANARO_BOARD`

### MallVocMapper.xml
- EOS 스키마의 테이블 사용
- 모든 테이블명에 `EOS.` 접두사 사용
- 예: `FROM EOS.TB_BBS`

## 연결 설정 (application.yml)

```yaml
spring:
  datasource:
    primary:
      driver-class-name: oracle.jdbc.OracleDriver
      url: jdbc:oracle:thin:@//10.10.10.101:1521/DB
      username: DENJOB
      password: dhtmxpaoracle#%90
      hikari:
        connection-init-sql: ALTER SESSION SET CURRENT_SCHEMA = DENJOB
```

## 주의사항

1. **권한 확인**: DENJOB 사용자가 EOS 스키마의 테이블에 접근할 수 있는 권한이 있는지 확인 필요
2. **스키마 명시**: 크로스 스키마 접근 시 반드시 스키마명을 명시
3. **성능**: 크로스 스키마 조회 시 인덱스 사용 등 성능에 주의
4. **트랜잭션**: 서로 다른 스키마의 데이터를 동시에 처리할 때 트랜잭션 관리 주의

## 테스트 쿼리

권한 확인을 위한 테스트 쿼리:

```sql
-- DENJOB 사용자로 접속하여 실행
-- DENJOB 스키마 테이블 조회
SELECT COUNT(*) FROM DENJOB.TB_HANARO_BOARD;

-- EOS 스키마 테이블 조회
SELECT COUNT(*) FROM EOS.TB_BBS;
```
# TV VOC 데이터베이스 스키마 분석

## 개요
이 문서는 TV VOC (Voice of Customer) 시스템의 데이터베이스 스키마를 분석한 내용입니다. 
현재 MySQL 데이터베이스에 구현된 스키마와 레거시 Oracle 스키마를 포함합니다.

## 1. 현재 MySQL 스키마 (tv_voc_database.sql)

### 1.1 주요 테이블 구조

#### notice (공지사항 관리 테이블)
- **Primary Key**: `id` (BIGINT, AUTO_INCREMENT)
- **주요 컬럼**:
  - `title` (VARCHAR 1024): 제목
  - `enable` (BIT): 사용 여부
  - `fixed_at_top` (BIT): 상단 고정 여부
  - `state` (VARCHAR 24): 상태
  - `notify` (BIT): 알림 여부
  - `contents` (TEXT): 내용
  - `page_view_count` (BIGINT): 조회수
  - `created_by`, `created_date`: 생성 정보
  - `last_modified_by`, `last_modified_date`: 수정 정보

#### event (이벤트 관리 테이블)
- **Primary Key**: `id` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `image_ref_id` → `file_info(id)`
- **주요 컬럼**:
  - `title` (VARCHAR 1024): 제목
  - `contents` (TEXT): 내용
  - `enable` (BIT): 사용 여부
  - `state` (VARCHAR 24): 상태
  - `notify` (BIT): 알림 여부
  - `page_view_count` (BIGINT): 조회수
  - `start_date`, `end_date`, `result_date`: 이벤트 날짜
  - `image_ref_id`: 이미지 파일 참조

#### faq (FAQ 관리 테이블)
- **Primary Key**: `id` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `category_ref_id` → `board_category(id)`
- **주요 컬럼**:
  - `title` (VARCHAR 1024): 제목
  - `question` (TEXT): 질문
  - `answer` (TEXT): 답변
  - `state` (VARCHAR 24): 상태
  - `unique_view_count`, `page_view_count`: 조회수
  - `frequent` (BIT): 자주 묻는 질문 여부

#### question (1:1 문의 관리 테이블)
- **Primary Key**: `id` (BIGINT, AUTO_INCREMENT)
- **Foreign Keys**: 
  - `category_ref_id` → `board_category(id)`
  - `member_ref_id` → `member(id)`
- **주요 컬럼**:
  - `title` (VARCHAR 1024): 제목
  - `state` (VARCHAR 24): 상태
  - `contents` (TEXT): 문의 내용
  - `reply` (BIT): 답변 여부
  - `reply_contents` (TEXT): 답변 내용
  - `reply_date` (DATETIME): 답변 날짜
  - `reply_notify` (BIT): 답변 알림 여부

### 1.2 첨부파일 매핑 테이블

각 주요 테이블은 파일 첨부를 위한 별도의 매핑 테이블을 가집니다:

#### notice_attach (공지사항 첨부파일 맵핑)
- **Primary Key**: `id`
- **Foreign Keys**:
  - `notice_ref_id` → `notice(id)`
  - `file_ref_id` → `file_info(id)`

#### event_attach (이벤트 첨부파일 맵핑, 최대 3개)
- **Primary Key**: `id`
- **Foreign Keys**:
  - `event_ref_id` → `event(id)`
  - `file_ref_id` → `file_info(id)`

#### faq_attach (FAQ 첨부파일 맵핑, 최대 3개)
- **Primary Key**: `id`
- **Foreign Keys**:
  - `faq_ref_id` → `faq(id)`
  - `file_ref_id` → `file_info(id)`

#### question_attach (1:1 문의 첨부파일 맵핑, 최대 3개)
- **Primary Key**: `id`
- **Foreign Keys**:
  - `question_ref_id` → `question(id)`
  - `file_ref_id` → `file_info(id)`

### 1.3 참조 테이블 (스키마에 정의되지 않음)
다음 테이블들은 외래키로 참조되지만 현재 스키마에는 정의되지 않음:
- `file_info`: 파일 정보 저장
- `board_category`: 게시판 카테고리 정보
- `member`: 회원 정보

## 2. 레거시 Oracle 스키마 (legacy_voc_ddl.sql)

### 2.1 주요 테이블

#### TB_HANARO_BOARD (하나로게시물정보)
- **Primary Key**: `NO` (NUMBER)
- **주요 컬럼**:
  - `DB` (NVARCHAR2 30): 게시판 구분자
  - `CATEGORY` (NUMBER): 카테고리
  - `SUBJECT` (NVARCHAR2 510): 제목
  - `CONTENT` (NCLOB): 내용
  - `USERID` (NVARCHAR2 70): 등록자 아이디
  - `HIT` (NUMBER): 조회수
  - `RECOMMEND` (NUMBER): 추천수
  - `HTML` (NUMBER): 표시형식 (0:TEXT, 1:HTML)
  - `REGDATE` (DATE): 등록일
  - `UMU` (NUMBER): 공개유무 (1:공개, 0:비공개)
  - `NOTI_YN` (NUMBER): 공지 적용여부
  - `QNA` (NCLOB): QNA 답변
  - `QNA_DATE` (DATE): QNA 답변일
  - `SECRET` (VARCHAR2 1): 비밀글 기능

#### TB_HANARO_BOARD_CATEGORY (하나로게시물정보 카테고리정보)
- **Primary Key**: `CATEGORY_CODE` (NUMBER)
- **주요 컬럼**:
  - `CATEGORY_NAME` (NVARCHAR2 200): 카테고리명
  - `DB` (NVARCHAR2 60): 게시판 구분자
  - `USE_YN` (VARCHAR2 2): 사용유무
  - `ORDER_NUM` (NUMBER): 정렬 순서

#### TB_HANARO_BOARD_FILE (하나로게시물파일정보)
- **Primary Key**: `FILE_NO` (NUMBER)
- **주요 컬럼**:
  - `BOARD_NO` (NUMBER): 게시판 일련번호
  - `FILE_NAME` (NVARCHAR2 150): 파일명
  - `FILE_PHYSICAL` (NVARCHAR2 150): 물리적 파일명
  - `FILE_SIZE` (NUMBER): 파일 사이즈
  - `FILE_TYPE` (NVARCHAR2 150): 파일 타입
  - `FILE_PATH` (NVARCHAR2 150): 파일 경로

#### TB_HANARO_BOARD_MEMO (하나로게시물 댓글정보)
- **Primary Key**: `MEMO_NO` (NUMBER)
- **주요 컬럼**:
  - `BOARD_NO` (NUMBER): 게시판 일련번호
  - `MEMO_ID` (NVARCHAR2 20): 등록자 아이디
  - `MEMO_DT` (DATE): 등록일자
  - `MEMO_CONTENT` (CLOB): 댓글 내용

#### TB_HANARO_SANGDAM (제품상담게시판)
- **Primary Key**: `NO` (NUMBER)
- **주요 컬럼**:
  - `JEPUM` (NVARCHAR2 50): 제품
  - `ASK_KIND` (NVARCHAR2 50): 신청종류
  - `LICENCE_NO` (VARCHAR2 50): 면허번호
  - `YOYANG_NO` (VARCHAR2 50): 요양기관번호
  - `BOSS_NAME` (NVARCHAR2 200): 원장명
  - `DEN_NM` (NVARCHAR2 200): 치과명
  - `CONTENT` (NCLOB): 상담내용
  - `ANSWER` (NCLOB): 답변
  - `ANSWER_DT` (TIMESTAMP): 답변일
  - `USERID` (VARCHAR2 20): 등록자 아이디

### 2.2 추가 테이블
- `TB_HANARO_BOARD_INFO`: 게시판 정보
- `TB_HANARO_INQUIRY`: 제품시연요청
- `TB_HANARO_MEMBER`: 하나로/두번에 프로그램 사용자
- `TB_HANARO_SEARCHWORD`: 사용자 검색어
- `TB_HANARO_BOARD_MOVIE`: 프로그램도움말동영상
- `TB_HANARO_COMM_CODE`: 하나로 코드 테이블

## 3. 목표 MySQL 스키마 (tobe_voc.sql)

### 3.1 주요 테이블

#### TB_NTFY_M (공지기본)
- **Primary Key**: `NTFY_NO` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `SVC_CTG_CD` → `TB_SVC_CTG_C(SVC_CTG_CD)`
- 공지사항 관련 정보를 저장

#### TB_EVT_M (이벤트기본)
- **Primary Key**: `EVT_NO` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `SVC_CTG_CD` → `TB_SVC_CTG_C(SVC_CTG_CD)`
- 이벤트 정보 및 참여 관련 데이터 저장

#### TB_FAQ_M (FAQ기본)
- **Primary Key**: `FAQ_NO` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `SVC_CTG_CD` → `TB_SVC_CTG_C(SVC_CTG_CD)`
- FAQ 질문과 답변 저장

#### TB_QNA_M (QNA기본)
- **Primary Key**: `QNA_NO` (BIGINT, AUTO_INCREMENT)
- **Foreign Key**: `SVC_CTG_CD` → `TB_SVC_CTG_C(SVC_CTG_CD)`
- 사용자 문의사항 저장

#### TB_QNA_ANS_D (QNA답변상세)
- **Primary Key**: (`QNA_NO`, `QNA_ANS_DTL_NO`)
- **Foreign Key**: `QNA_NO` → `TB_QNA_M(QNA_NO)`
- QNA에 대한 답변 저장 (계층구조 지원)

#### TB_EVT_PRTC_D (이벤트참여상세)
- **Primary Key**: `EVT_PRTC_DTM`
- **Foreign Key**: `EVT_NO` → `TB_EVT_M(EVT_NO)`
- 이벤트 참여 내역 저장

## 4. 데이터 마이그레이션 고려사항

### 4.1 테이블 매핑
- Oracle `TB_HANARO_BOARD` (DB='notice') → MySQL `TB_NTFY_M`
- Oracle `TB_HANARO_BOARD` (DB='event') → MySQL `TB_EVT_M`
- Oracle `TB_HANARO_BOARD` (DB='faq') → MySQL `TB_FAQ_M`
- Oracle `TB_HANARO_SANGDAM` → MySQL `TB_QNA_M` + `TB_QNA_ANS_D`

### 4.2 주요 변환 사항
1. **데이터 타입 변환**
   - Oracle NVARCHAR2 → MySQL VARCHAR
   - Oracle NCLOB/CLOB → MySQL TEXT/MEDIUMTEXT
   - Oracle NUMBER → MySQL BIGINT/SMALLINT/DECIMAL
   - Oracle DATE → MySQL DATETIME

2. **컬럼명 변경**
   - 한글 약어에서 영문 약어로 변경 (예: `NO` → `NTFY_NO`, `EVT_NO` 등)
   - 더 명확한 네이밍 규칙 적용

3. **구조적 변경**
   - 단일 테이블에서 여러 목적별 테이블로 분리
   - 파일 첨부 방식 변경 (별도 파일 테이블 참조에서 FILE_ID 방식으로)
   - 카테고리 관리 방식 변경 (서비스 카테고리 코드 사용)

4. **추가된 기능**
   - 처리 프로그램 ID 추적
   - 더 세밀한 타임스탬프 (microsecond 단위)
   - 법인코드, 부서코드, 사원번호 등 조직 정보 추가

### 4.3 인덱스 및 제약조건
- Primary Key는 모두 유지
- Foreign Key 관계는 새로운 구조에 맞게 재정의
- CASCADE 옵션은 데이터 무결성을 위해 적절히 설정
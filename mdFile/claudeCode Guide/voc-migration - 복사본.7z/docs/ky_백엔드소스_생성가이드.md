# 백엔드 소스 생성 가이드

## 1. 개요

Java 21과 Spring Boot 3.4 기반 백엔드 소스 코드 생성을 위한 AI 참조 가이드. 비즈니스 도메인에 맞는 Controller, Service, Mapper, DTO 클래스를 체계적으로 생성하며, Java 21의 최신 프로그래밍 기법을 적극 활용하여 코드 품질을 향상시킵니다.

## 2. 기술 스택 및 설계 원칙

### 2.1. 기술 스택
- **언어**: Java 21 (LTS)
- **프레임워크**: Spring Boot 3.4
- **데이터베이스**: MariaDB
- **ORM**: MyBatis
- **기본 패키지**: {basePackage}
- **API 문서화**: Swagger 3 (API 응답 제외)
- **메시지 관리**: Spring MessageSource (messages.properties)
- **예외 처리**: 글로벌 예외 핸들러 (@ControllerAdvice)

> **중요**: ApiResponse 클래스는 프레임워크에서 이미 제공하고 있으므로 별도로 생성하지 않습니다.

### 2.2. 설계 원칙

#### 2.2.1. SOLID 원칙
- **S (Single Responsibility Principle)**: 각 클래스는 하나의 책임만 가져야 함
  - Controller: HTTP 요청/응답 처리만 담당
  - Service: 비즈니스 로직 처리만 담당
  - Mapper: 데이터 액세스만 담당
  - DTO: 데이터 전송만 담당

- **O (Open/Closed Principle)**: 확장에는 열려있고 수정에는 닫혀있어야 함
  - 인터페이스를 통한 추상화 활용
  - 전략 패턴, 팩토리 패턴 등을 활용한 확장 가능한 구조

- **L (Liskov Substitution Principle)**: 파생 클래스는 기반 클래스로 교체 가능해야 함
  - 상속보다는 조합(Composition) 우선
  - 인터페이스 구현 시 계약 준수

- **I (Interface Segregation Principle)**: 클라이언트는 자신이 사용하지 않는 메서드에 의존하지 않아야 함
  - 작고 구체적인 인터페이스 설계
  - 범용 인터페이스보다는 특화된 인터페이스

- **D (Dependency Inversion Principle)**: 고수준 모듈은 저수준 모듈에 의존하지 않아야 함
  - 인터페이스를 통한 의존성 주입
  - @Autowired 필드 주입 금지, 생성자 주입 사용

#### 2.2.2. Clean Architecture 원칙
- **의존성 규칙**: 외부 계층은 내부 계층에 의존하되, 내부 계층은 외부 계층에 의존하지 않음
- **계층 간 경계**: 명확한 계층 분리를 통한 관심사 분리
- **엔티티 중심**: 비즈니스 규칙을 엔티티와 서비스에 집중
- **인터페이스 어댑터**: 외부 시스템과의 상호작용은 어댑터 패턴 활용

#### 2.2.3. 확장성 원칙 (Scalability Principles)
- **수평 확장 고려**: Stateless 설계를 통한 인스턴스 확장 가능
- **캐싱 전략**: 적절한 캐싱을 통한 성능 최적화
- **비동기 처리**: 대용량 처리를 위한 비동기 패턴 적용
- **모듈화**: 기능별 모듈 분리를 통한 독립적 확장

#### 2.2.4. 단순성 원칙 (KISS - Keep It Simple, Stupid)
- **복잡성 최소화**: 불필요한 추상화나 패턴 사용 지양
- **명확한 네이밍**: 의도가 명확히 드러나는 변수명, 메서드명 사용
- **단순한 로직**: 복잡한 조건문보다는 Guard Clause 활용
- **과도한 최적화 지양**: 필요한 시점에 최적화 적용

#### 2.2.5. 가독성 원칙 (Readable Code)
- **자기 문서화 코드**: 주석 없이도 이해 가능한 코드 작성
- **일관된 코딩 스타일**: 팀 내 통일된 코드 스타일 준수
- **적절한 길이**: 메서드는 한 화면에 들어갈 수 있는 길이로 제한
- **의미 있는 추상화**: 비즈니스 도메인을 반영한 추상화

#### 2.2.6. DRY 원칙 (Don't Repeat Yourself)
- **코드 중복 제거**: 공통 기능은 유틸리티 클래스로 분리
- **설정 중복 제거**: 공통 설정은 베이스 클래스나 설정 파일로 관리
- **로직 재사용**: 팩토리 메서드, 유틸리티 메서드를 통한 재사용

#### 2.2.7. YAGNI 원칙 (You Aren't Gonna Need It)
- **필요한 기능만 구현**: 미래에 필요할 것 같은 기능은 미리 구현하지 않음
- **점진적 개발**: 요구사항이 확정된 기능부터 순차적 개발
- **과도한 추상화 지양**: 현재 필요한 수준의 추상화만 적용

#### 2.2.8. 테스트 가능한 설계 (Testable Design)
- **의존성 주입**: 테스트 더블(Mock, Stub) 활용 가능한 구조
- **순수 함수**: 부수 효과가 없는 함수 설계
- **테스트 격리**: 각 테스트는 독립적으로 실행 가능해야 함

#### 2.2.9. 프레임워크별 원칙
- **관심사의 분리(SoC)**: 계층별 역할과 책임 명확히 분리
- **객체지향 설계(OOD)**: 상속, 캡슐화, 다형성 원칙 적용
- **적절한 디자인 패턴 적용**: 상황에 맞는 디자인 패턴 활용
- **업무 규칙 집중화**: 업무 규칙은 서비스 계층에 집중
- **Java 21 최신 기법 활용**: Record, Pattern Matching, Switch Expressions, Stream API, Optional, Virtual Threads 등 적극 활용

### 2.3. 의존성 주입 방식
- @Autowired 필드 주입 사용 금지
- 생성자 주입 방식만 사용 (@RequiredArgsConstructor 활용)

### 2.4. Audit 컬럼 정의
모든 테이블은 다음의 Audit 컬럼 포함:
```sql
PROC_PRGM_ID VARCHAR(50) NOT NULL COMMENT '처리프로그램ID',
RGST_PROCR_ID VARCHAR(50) NOT NULL COMMENT '등록처리자ID',
RGST_PROC_DTM DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '등록처리일시',
UPDT_PROCR_ID VARCHAR(50) DEFAULT NULL COMMENT '수정처리자ID',
UPDT_PROC_DTM DATETIME(6) DEFAULT NULL COMMENT '수정처리일시'
```

> **중요**: DTO의 Audit 컬럼의 값은 MyBatis Interceptor Plugin에서 자동으로 처리. 서비스 계층에서 DTO 객체의 Audit 컬럼값을 직접 설정하는 코드를 작성하지 않음

### 2.5. 예외 처리 정책
다음 공통 예외 클래스 사용 (프레임워크에서 제공):
- **BusinessException**: 업무 규칙 위반 시 발생
- **AuthorizationException**: 권한 부족 시 발생
- **ValidationException**: 입력값 검증 실패 시 발생
- **EntityNotFoundException**: 데이터가 존재하지 않을 때 발생
- **SystemException**: 시스템 오류 발생 시 사용

## 3. Java 21 최신 프로그래밍 기법 활용 원칙

### 3.1. 적용 기법
- **Record Classes**: 불변 데이터 구조, API 응답, DTO 대안으로 활용
- **Pattern Matching**: instanceof와 Switch에서 타입 안전성 확보
- **Switch Expressions**: 조건부 로직 간소화, 상태 기반 처리
- **Sealed Classes**: 제한된 상속 구조로 도메인 모델 강화
- **Stream API**: 데이터 처리 효율성 향상, 함수형 프로그래밍
- **Optional**: null 안전성 확보, 메서드 체이닝
- **Generic**: 타입 안전성과 재사용성 향상
- **Virtual Threads**: 동시성 처리 개선, 대량 데이터 처리

> **중요**: var 키워드 사용 안함

### 3.2. 적용 우선순위
1. **Record**: 불변 데이터가 필요한 경우 DTO 대신 활용
2. **Optional**: 모든 조회 메서드에서 null 안전성 확보
3. **Switch Expressions**: 상태 기반 로직, Enum 처리
4. **Stream API**: 컬렉션 처리, 데이터 변환
5. **Pattern Matching**: 타입 검사와 캐스팅이 필요한 경우

## 4. 명명 규칙

### 4.1. 클래스 명명 규칙
- **컨트롤러**: `{도메인명}Controller`
- **서비스**: `{도메인명}Service`
- **매퍼**: `{도메인명}Mapper`
- **DTO**: `{도메인명}Dto`, `{도메인명}CreateRequestDto`, `{도메인명}UpdateRequestDto`, `{도메인명}SearchDto`
- **Record**: `{도메인명}{목적}`
- **Enum**: `{도메인명}{코드유형}`

### 4.2. 메서드 명명 규칙
- **컨트롤러**: getList, get, create, update, delete, approve, reject, cancel, confirm, process, complete
- **서비스**: getList, getCount, get, create, update, delete, approve, reject, cancel, confirm, process, complete, changeStatus, validate{동작}, find{EntityName}(Optional 반환)
- **매퍼**: selectList, selectCount, select, select{연관도메인명}List, insert, update, delete, updateStatus, insertHistory

### 4.3. 테이블/컬럼 vs DTO 필드 변환 규칙
- **테이블명**: `TB_` + 대문자 약어 스네이크 표기법
- **컬럼명**: 대문자 약어 스네이크 표기법
- **DTO 필드명**: 카멜케이스 + 풀네임
- **변환 예시**: `ORD_ID` → `orderId`, `ORD_NO` → `orderNumber`, `CUST_ID` → `customerId`

### 4.4. REST API 명명 규칙
- **기본 경로**: `/api/{도메인-복수형}`
- **HTTP 메서드**: GET(조회), POST(생성/액션), PUT(수정), DELETE(삭제)

## 5. 메시지 처리 및 예외 처리

### 5.1 메시지 키 명명 규칙
- **유효성 검증**: `{필드}.{제약조건}`
- **비즈니스 예외**: `{도메인}.{에러코드}`
- **성공 메시지**: `success.{도메인}.{동작}`

### 5.2. 메시지 리소스 구조
```
src/main/resources/messages/
├── {프로젝트ID}-validation.properties  # 유효성 검증 -> Bean Validation 메시지
├── common-message.properties          # 공통 메시지
└── {프로젝트ID}-message.properties     # 비즈니스 예외, 성공 메시지 -> 프로젝트별 업무 메시지
```

### 5.3. 처리 방식
- Bean Validation: 메시지 키만 지정, 시스템이 자동 처리
- 예외 발생: 메시지 코드만 지정, 프레임워크가 자동 처리
- API 응답: 메시지 코드만 지정, 프레임워크가 자동 처리

## 6. 주석 작성 규칙

### 6.1. 클래스 주석
```java
/**
 * {도메인명} {레이어명}
 * {기능 설명}
 *
 * @author {author}
 * @version {version}
 * @since {today}
 *
 * {copyright}
 */
```

### 6.2. 메서드 주석
```java
/**
 * {메서드 기능 설명}
 *
 * @param {파라미터명} {파라미터 설명}
 * @return {반환값 설명}
 * @throws {예외클래스} {예외 발생 조건}
 */
```

### 6.3. 서비스 메서드 주석 작성 가이드

#### 6.3.1. 주석 작성 원칙
- **JavaDoc에 절차 명시**: 메소드 레벨에서 비즈니스 절차를 순서대로 기술
- **내부 주석 최소화**: 메소드 내부는 가능한 한 주석 없이 자명한 코드로 작성
- **선택적 내부 주석**: 복잡한 로직에만 선택적으로 간단한 내부 주석 사용

#### 6.3.2. JavaDoc 작성 가이드
```java
/**
 * {메소드가 수행하는 비즈니스 기능 설명}
 * 
 * 처리 절차:
 * 1. {첫 번째 처리 단계}
 * 2. {두 번째 처리 단계}
 * 3. {세 번째 처리 단계}
 * ...
 *
 * @param {파라미터명} {파라미터 설명}
 * @return {반환값 설명}
 * @throws {예외클래스} {예외 발생 조건}
 */
```

#### 6.3.3. 상황별 주석 처리 방침

**단순한 CRUD 메소드**
```java
/**
 * 주문 목록을 조회합니다.
 *
 * @param searchDto 검색 조건
 * @return 주문 목록
 */
@Transactional(readOnly = true)
public List<OrderDto> getList(OrderSearchDto searchDto) {
    return orderMapper.selectList(searchDto);
}
```

**복잡한 비즈니스 로직**
```java
/**
 * 주문 상태를 변경합니다.
 * 
 * 처리 절차:
 * 1. 주문 존재 여부 및 상태 변경 권한 검증
 * 2. 현재 상태에서 변경 가능한 상태인지 검증
 * 3. 상태별 추가 비즈니스 규칙 적용
 * 4. 상태 변경 실행 및 이력 저장
 * 5. 외부 시스템 연동 (결제, 배송 등)
 * 6. 고객 알림 발송
 *
 * @param orderId 주문 ID
 * @param newStatus 변경할 상태
 * @param processorId 처리자 ID
 * @return 변경된 주문 정보
 * @throws EntityNotFoundException 주문이 존재하지 않는 경우
 * @throws BusinessException 상태 변경이 불가능한 경우
 * @throws AuthorizationException 상태 변경 권한이 없는 경우
 */
@Transactional
public OrderDto changeStatus(Long orderId, OrderStatusCode newStatus, String processorId) {
    OrderDto existingOrder = findOrderById(orderId);
    validateStatusChangePermission(existingOrder, processorId);
    validateStatusTransition(existingOrder.getOrderStatusCode(), newStatus);
    
    applyBusinessRulesForStatus(existingOrder, newStatus);
    
    OrderDto statusChangeDto = OrderDto.of(orderId, newStatus);
    orderMapper.updateStatus(statusChangeDto);
    saveStatusChangeHistory(orderId, existingOrder.getOrderStatusCode(), newStatus, processorId);
    
    processExternalSystemIntegration(existingOrder, newStatus);
    sendCustomerNotification(existingOrder, newStatus);
    
    return get(orderId);
}
```

**복잡한 계산 로직 (예외적으로 내부 주석 허용)**
```java
/**
 * 주문 총액을 계산합니다.
 * 
 * 계산 방식:
 * 1. 기본 상품 금액 합계
 * 2. 할인 적용 (쿠폰, 회원등급, 이벤트)
 * 3. 배송비 계산 및 추가
 * 4. 부가세 계산
 *
 * @param orderItems 주문 상품 목록
 * @param customerId 고객 ID
 * @param deliveryInfo 배송 정보
 * @return 계산된 총액 정보
 */
@Transactional(readOnly = true)
public OrderAmountDto calculateTotalAmount(List<OrderItemDto> orderItems, String customerId, DeliveryInfoDto deliveryInfo) {
    BigDecimal baseAmount = calculateBaseAmount(orderItems);
    
    // 복잡한 할인 계산 로직 - 다단계 할인 적용
    BigDecimal discountAmount = calculateDiscountAmount(baseAmount, customerId, orderItems);
    
    BigDecimal deliveryFee = calculateDeliveryFee(deliveryInfo, baseAmount);
    
    // 부가세 계산 - 면세 상품 제외 계산
    BigDecimal taxAmount = calculateTaxAmount(baseAmount.subtract(discountAmount), orderItems);
    
    return OrderAmountDto.builder()
        .baseAmount(baseAmount)
        .discountAmount(discountAmount)
        .deliveryFee(deliveryFee)
        .taxAmount(taxAmount)
        .totalAmount(baseAmount.subtract(discountAmount).add(deliveryFee).add(taxAmount))
        .build();
}
```

#### 6.3.4. 내부 주석 사용 기준
- **원칙**: 가능한 한 사용하지 않음
- **예외**: 복잡한 계산 로직, 외부 시스템 연동, 특수한 비즈니스 규칙
- **형태**: 간단명료하게, 왜(Why)보다는 무엇(What)을 설명

#### 6.3.5. 코드 자체로 의도 표현
- **메소드명**: 동작을 명확히 표현하는 동사 사용
- **변수명**: 역할을 명확히 알 수 있는 명사 사용
- **메소드 분리**: 하나의 메소드는 하나의 책임만 가지도록 분리

## 7. 패키지 구조

```
{basePackage}/
├── controller/      # 컨트롤러 클래스
├── service/         # 서비스 클래스
├── mapper/          # MyBatis 매퍼 인터페이스
├── model/           # 데이터 모델
│   ├── dto/         # 데이터 전송 객체
│   ├── record/      # Record 클래스 (Java 21)
│   ├── request/     # 요청 DTO
│   ├── search/      # 검색 DTO
│   └── code/        # Enum 상수 코드 클래스
└── common/
    ├── constant/    # 상수 클래스
    ├── util/        # 유틸리티 클래스
    ├── message/     # 메시지 관련 클래스
    └── builder/     # 빌더 패턴 클래스
```

## 8. DTO 빌더 패턴 및 팩토리 메소드 적용 가이드

### 8.1. 빌더 패턴 적용 원칙

모든 DTO 클래스에는 Lombok의 @Builder 어노테이션을 적용하여 빌더 패턴을 지원합니다.

#### 8.1.1. 기본 DTO 클래스 구조
```java
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "도메인 정보")
public class SampleDto {
    // 필드 정의
}
```

#### 8.1.2. Request DTO 클래스 구조 (BaseDto 상속)
```java
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "생성 요청")
public class SampleCreateRequestDto extends BaseDto {
    // 필드 정의
}
```

### 8.2. of 팩토리 메소드 패턴 적용

#### 8.2.1. 팩토리 메소드 도입 목적
- **관심사의 분리**: DTO 생성 로직과 비즈니스 로직 분리
- **코드 가독성 향상**: 서비스 메소드에서 핵심 비즈니스 로직이 명확하게 보임
- **일관성 확보**: Java 표준 라이브러리 패턴(`LocalDate.of()`, `Optional.of()`)과 일치
- **타입 안전성**: 매개변수 시그니처로 컴파일 타임 검증

#### 8.2.2. 오버로딩된 of 팩토리 메소드 구조
```java
public class OrderDto extends BaseDto {
    // 필드 정의...
    
    /**
     * 신규 생성용 팩토리 메소드
     * ID가 없는 CreateRequestDto만 받음 → 생성 용도 명확
     */
    public static OrderDto of(OrderCreateRequestDto requestDto) {
        return OrderDto.builder()
            .orderNumber(OrderNumberGenerator.generate())
            .customerId(requestDto.getCustomerId())
            .orderDate(LocalDateTime.now())
            .orderStatusCode(WAIT)
            // 기타 필드 설정...
            .build();
    }
    
    /**
     * 수정용 팩토리 메소드
     * ID + UpdateRequestDto → 수정 용도 명확
     */
    public static OrderDto of(Long orderId, OrderUpdateRequestDto requestDto) {
        return OrderDto.builder()
            .orderId(orderId)
            .deliveryZipCode(requestDto.getDeliveryZipCode())
            .deliveryBaseAddress(requestDto.getDeliveryBaseAddress())
            // 수정 가능한 필드들만 설정...
            .build();
    }
    
    /**
     * 상태 변경용 팩토리 메소드
     * ID + 상태코드 → 상태 변경 용도 명확
     */
    public static OrderDto of(Long orderId, OrderStatusCode newStatus) {
        return OrderDto.builder()
            .orderId(orderId)
            .orderStatusCode(newStatus)
            .build();
    }
    
    /**
     * 취소용 팩토리 메소드
     * ID + CancelRequestDto → 취소 용도 명확
     */
    public static OrderDto of(Long orderId, OrderCancelRequestDto requestDto) {
        return OrderDto.builder()
            .orderId(orderId)
            .orderStatusCode(CANCEL)
            // 취소 관련 추가 정보 설정...
            .build();
    }
}
```

#### 8.2.3. 팩토리 메소드 적용 기준

**팩토리 메소드를 적용해야 하는 경우:**
- 빌더 설정 코드가 **5줄 이상**인 경우
- **동일한 생성 패턴이 여러 곳에서 반복**되는 경우
- 생성 시 **복잡한 계산이나 검증**이 필요한 경우
- **비즈니스 의미가 있는 생성 패턴**인 경우
- 서비스 메소드의 **가독성을 해치는** 경우

**빌더 패턴을 직접 사용해도 되는 경우:**
- **1-2개 필드만 설정**하는 단순한 경우
- **일회성 사용**이고 재사용 가능성이 낮은 경우
- **테스트 코드**에서 간단한 객체 생성

## 9. 검색 DTO의 정렬 처리 설계 원칙

### 9.1. 정렬 처리의 문제점과 해결책

**기존 방식의 문제점:**
- SearchDto에서 ORDER BY 절을 직접 생성하면 테이블 알리아스를 알 수 없음
- 복수 정렬 필드 처리가 어려움
- JOIN된 테이블의 컬럼 처리 불가
- 동적 SQL 처리의 한계

**올바른 접근 방법:**
- SearchDto에서는 정렬 조건만 문자열로 전달
- MyBatis XML에서 동적으로 ORDER BY 절 생성
- 정렬 조건이 없으면 ORDER BY 절 자체를 제거

### 9.2. SearchDto의 정렬 필드 설계

#### 9.2.1. 기본 구조
```java
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "검색 조건")
public class SampleSearchDto {
    
    // 검색 조건 필드들...
    
    @Schema(description = "정렬 조건", example = "orderDate:DESC,totalAmount:ASC")
    private String sortFields;
    
    @Schema(description = "페이지 번호", example = "1")
    @Builder.Default
    private Integer page = 1;
    
    @Schema(description = "페이지 크기", example = "15")
    @Builder.Default
    private Integer size = 15;
    
    /**
     * OFFSET 계산
     */
    public int getOffset() {
        return (page - 1) * size;
    }
    
    /**
     * LIMIT 값 반환
     */
    public int getLimit() {
        return size;
    }
    
    /**
     * 정렬 조건이 있는지 확인
     */
    public boolean hasSortFields() {
        return sortFields != null && !sortFields.trim().isEmpty();
    }
}
```

#### 9.2.2. 정렬 필드 형식
- **단일 정렬**: `orderDate:DESC`
- **복수 정렬**: `orderDate:DESC,totalAmount:ASC,customerName:ASC`
- **방향 생략 시 기본값**: `orderDate` → `orderDate:ASC`로 처리

### 9.3. MyBatis XML에서의 동적 ORDER BY 처리

#### 9.3.1. 기본 ORDER BY 처리 패턴
```xml
<select id="selectList" parameterType="SampleSearchDto" resultType="SampleDto">
    SELECT
        -- 컬럼들...
    FROM
        TB_SAMPLE S
    WHERE
        1 = 1
        -- 검색 조건들...
    <if test="hasSortFields()">
    ORDER BY
        <foreach collection="sortFields.split(',')" item="sortField" separator=",">
            <choose>
                <when test="sortField.trim().startsWith('orderDate')">
                    S.ORD_DT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <when test="sortField.trim().startsWith('totalAmount')">
                    S.TOT_AMT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <when test="sortField.trim().startsWith('customerName')">
                    C.CUST_NM ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <otherwise>
                    S.ORD_DT DESC
                </otherwise>
            </choose>
        </foreach>
    </if>
    <if test="!hasSortFields()">
    ORDER BY
        S.ORD_DT DESC
    </if>
</select>
```

#### 9.3.2. JOIN이 있는 경우의 ORDER BY 처리
```xml
<select id="selectList" parameterType="OrderSearchDto" resultType="OrderDto">
    SELECT
        O.ORD_ID AS ORDER_ID,
        O.ORD_NO AS ORDER_NUMBER,
        O.ORD_DT AS ORDER_DATE,
        O.TOT_AMT AS TOTAL_AMOUNT,
        C.CUST_NM AS CUSTOMER_NAME
    FROM
        TB_ORD O
        INNER JOIN TB_CUST C ON O.CUST_ID = C.CUST_ID
    WHERE
        1 = 1
        -- 검색 조건들...
    <if test="hasSortFields()">
    ORDER BY
        <foreach collection="sortFields.split(',')" item="sortField" separator=",">
            <choose>
                <when test="sortField.trim().startsWith('orderDate')">
                    O.ORD_DT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <when test="sortField.trim().startsWith('totalAmount')">
                    O.TOT_AMT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <when test="sortField.trim().startsWith('customerName')">
                    C.CUST_NM ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                </when>
                <otherwise>
                    O.ORD_DT DESC
                </otherwise>
            </choose>
        </foreach>
    </if>
    <if test="!hasSortFields()">
    ORDER BY
        O.ORD_DT DESC
    </if>
</select>
```

#### 9.3.3. 복잡한 정렬 조건 처리를 위한 개선된 방식
```xml
<!-- 더 안전한 정렬 처리를 위한 방식 -->
<select id="selectList" parameterType="OrderSearchDto" resultType="OrderDto">
    SELECT
        -- 컬럼들...
    FROM
        TB_ORD O
        LEFT JOIN TB_CUST C ON O.CUST_ID = C.CUST_ID
    WHERE
        1 = 1
        -- 검색 조건들...
    <choose>
        <when test="hasSortFields()">
        ORDER BY
            <foreach collection="sortFields.split(',')" item="sortField" separator=",">
                <trim>
                    <choose>
                        <when test="sortField.trim().matches('^orderDate:(ASC|DESC)$') or sortField.trim().equals('orderDate')">
                            O.ORD_DT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                        </when>
                        <when test="sortField.trim().matches('^totalAmount:(ASC|DESC)$') or sortField.trim().equals('totalAmount')">
                            O.TOT_AMT ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                        </when>
                        <when test="sortField.trim().matches('^customerName:(ASC|DESC)$') or sortField.trim().equals('customerName')">
                            C.CUST_NM ${sortField.contains(':DESC') ? 'DESC' : 'ASC'}
                        </when>
                        <otherwise>
                            O.ORD_DT DESC
                        </otherwise>
                    </choose>
                </trim>
            </foreach>
        </when>
        <otherwise>
        ORDER BY
            O.ORD_DT DESC
        </otherwise>
    </choose>
</select>
```

### 9.4. Controller에서의 정렬 파라미터 처리

```java
@GetMapping
public ResponseEntity<ApiResponse<List<OrderDto>>> getList(
        @RequestParam(required = false) String sortFields,
        @ModelAttribute OrderSearchDto searchDto) {
    
    // 정렬 조건 설정
    searchDto.setSortFields(sortFields);
    
    List<OrderDto> orderList = orderService.getList(searchDto);
    // ...
}
```

### 9.5. 정렬 처리 보안 고려사항

#### 9.5.1. SQL Injection 방지
- 정렬 필드명은 사전 정의된 값들만 허용
- 동적 SQL에서 화이트리스트 방식으로 검증
- 사용자 입력값을 직접 SQL에 삽입하지 않음

#### 9.5.2. 허용 가능한 정렬 필드 검증
```java
public class OrderSearchDto {
    
    private static final Set<String> ALLOWED_SORT_FIELDS = Set.of(
        "orderDate", "totalAmount", "customerName", "orderStatus"
    );
    
    public void setSortFields(String sortFields) {
        if (sortFields != null && !sortFields.trim().isEmpty()) {
            // 허용된 필드만 사용하는지 검증
            String[] fields = sortFields.split(",");
            for (String field : fields) {
                String fieldName = field.split(":")[0].trim();
                if (!ALLOWED_SORT_FIELDS.contains(fieldName)) {
                    throw new IllegalArgumentException("Invalid sort field: " + fieldName);
                }
            }
        }
        this.sortFields = sortFields;
    }
}
```

## 10. 소스 코드 생성 프로세스

### 10.1. 테이블 구조 분석
DDL 스크립트를 직접 참조하여 각 테이블과 컬럼의 구조 파악.

### 10.2. 코드성 데이터 Enum 클래스 생성

1. **생성 규칙**:
   - 네이밍: `{도메인명}{코드유형}`
   - Java 21 Switch Expression과 Pattern Matching 지원
   - Static 메서드: `of(String code)` (Optional 반환), `isValid(String code)`

2. **기본 구조**:
   ```java
   @Getter
   @RequiredArgsConstructor
   public enum OrderStatusCode {
       WAIT("결제대기", "결제를 기다리고 있는 상태"),
       PAID("결제완료", "결제가 완료된 상태"),
       // ... 기타 상태들
       
       private final String name;
       private final String description;
       
       public static Optional<OrderStatusCode> of(String code) { /* 구현 */ }
       public static boolean isValid(String code) { /* 구현 */ }
   }
   ```

### 10.3. DTO 및 Record 클래스 생성

1. **선택 기준**:
   - **DTO**: 변경 가능한 데이터, MyBatis 매핑 필요, 복잡한 유효성 검증
   - **Record**: 불변 데이터, API 응답, 간단한 데이터 전송

2. **기본 DTO**:
   - 테이블의 모든 컬럼을 필드로 포함 (Audit 컬럼은 프레임워크 BaseDto를 상속하므로 포함하지 않음)
   - Lombok 어노테이션(@Getter, @Setter, @ToString, @Builder, @NoArgsConstructor, @AllArgsConstructor) 사용
   - Swagger 어노테이션(@Schema) 사용
   - 필드명은 카멜케이스의 풀네임으로 변환
   - 코드성 필드는 Enum 타입으로 변환
   - **오버로딩된 of 팩토리 메소드 포함**

3. **요청 DTO - BaseDto 상속**:
   - 클라이언트로부터 받을 필드만 포함
   - Jakarta Validation 어노테이션(@NotBlank, @Size 등) 사용
   - INSERT/UPDATE용 DTO는 `BaseDto` 클래스를 상속하여 Audit 컬럼 자동 처리
   - @Builder, @NoArgsConstructor, @AllArgsConstructor 어노테이션 필수
   - 유효성 검증 메시지는 message.properties에서 관리하고 스프링 Framework에서 자동 처리하므로 메시지 키 지정 불필요
   - Swagger 어노테이션(@Schema)으로 문서화
   - 필드명은 카멜케이스의 풀네임으로 통일
   - 코드성 필드는 Enum 타입 또는 문자열로 처리
   - Audit 필드는 포함 불필요 (BaseDto와 Interceptor에서 자동 처리)

4. **검색 DTO**:
   - 검색 조건 필드 정의 (DB 컬럼에 대응)
   - 페이징 관련 필드(page, size, offset) 포함
   - **정렬 관련 필드**: `sortFields` 문자열 필드로 정의 (예: "orderDate:DESC,totalAmount:ASC")
   - @Builder, @NoArgsConstructor, @AllArgsConstructor 어노테이션 포함
   - 필드명은 카멜케이스의 풀네임으로 통일
   - 코드성 필드는 문자열로 처리 (검색 유연성 확보)
   - Audit 필드는 검색 조건으로 필요시에만 포함
   - **중요**: ORDER BY 절을 직접 생성하는 메서드는 포함하지 않음
   - `hasSortFields()` 메서드로 정렬 조건 존재 여부만 확인

5. **상태 변경 요청 DTO**:
   - 상태 변경에 필요한 정보만 포함 (예: 승인자, 승인 코멘트, 반려 사유 등)
   - Jakarta Validation 어노테이션 사용
   - @Builder, @NoArgsConstructor, @AllArgsConstructor 어노테이션 포함
   - 필드명은 카멜케이스의 풀네임으로 통일
   - 코드성 필드는 문자열로 처리 (클라이언트 호환성 확보)

### 10.4. Mapper 인터페이스 및 XML 생성

**Mapper 인터페이스 생성 규칙**:

1. **기본 메서드**:
   - 목록 조회: `selectList(SearchDto)`
   - 건수 조회: `selectCount(SearchDto)`
   - 상세 조회: `select(@Param("id") Long id)` - Optional 반환 고려
   - 연관 데이터 조회: `select{연관도메인명}List(@Param("id") Long id)`
   - 생성: `insert(Dto)`
   - 수정: `update(Dto)`
   - 삭제: `delete(@Param("id") Long id)`
   - 상태 업데이트: `updateStatus(@Param("id") Long id, @Param("status") String status)`
   - Audit 컬럼에 처리를 위한 파라미터를 받지 않음

**Mapper XML 생성 규칙**:

1. **기본 규칙**:
   - 키워드, 테이블명, 컬럼명은 모두 대문자로 작성
   - 들여쓰기는 4칸 공백 사용
   - <sql id=""> 태그 사용하지 않고, SQL 재사용 불필요
   - 디버깅을 위해 /* {네임스페이스}.{sql id} */ 주석을 xml 태그 안쪽 첫번째 줄에 추가
   - **중요: 주요 키워드 다음에서 줄바꿈 수행(SELECT, FROM, WHERE, ORDER BY, GROUP BY, HAVING)

2. **SELECT 문 작성**:
   - 컬럼은 한 줄에 하나씩 나열
   - **중요: SELECT 쿼리에서는 Audit 컬럼을 반드시 제외**
   - 컬럼명 다음에 `,`사용
   - 컬럼명은 대문자 스네이크 표기법, 컬럼 알리아스는 대문자 Full name 스네이크 표기법(MyBatis의 자동 카멜 케이스 변환 설정 활용)
   - 테이블 JOIN 시 테이블명과 JOIN 키워드는 같은 줄에 작성
   - WHERE 조건은 AND/OR로 시작하여 새 줄에 작성
   - **ORDER BY 절은 동적 SQL로 처리하며, 정렬 조건이 없으면 ORDER BY 절 자체를 제거**
   - Paging 처리시 PagingDto 내부에서 pageNo와 pageSize를 통한 계산이 이루어지므로 limit와 offset 파라미터 사용

3. **INSERT 문 작성**:
   - 컬럼명을 명시하여 VALUES 절에서 순서 오류 방지
   - 컬럼은 한 줄에 하나씩 나열
   - 파라미터 바인딩 표기법도 한 줄에 하나씩 나열
   - 컬럼 구분시 comma는 컬럼명 다음에 위치
   - **중요: INSERT 문에는 PROC_PRGM_ID, RGST_PROCR_ID, RGST_PROC_DTM 같은 Audit 컬럼을 포함해야 함**

4. **UPDATE 문 작성**:
   - SET 절의 각 컬럼 업데이트를 한 줄에 하나씩 작성
   - WHERE 절을 반드시 포함하여 전체 데이터 변경 방지
   - **중요: UPDATE 문에는 UPDT_PROCR_ID, UPDT_PROC_DTM과 같은 Audit 컬럼을 포함해야 함**

5. **DELETE 문 작성**:
   - WHERE 절을 반드시 포함하여 전체 데이터 삭제 방지

6. **테이블 별칭 규칙**:
   - 단일 테이블 SELECT 시 별칭 사용 불필요
   - SQL 쿼리내에서 복합 단어로 구성된 테이블은 간결성을 위해 형식 `도메인 첫 글자 + '_' + 업무처리명칭의 3-4자 축약형` 적용

7. **조인(JOIN) 작성**:
   - INNER JOIN 사용, 암시적 조인 지양
   - ON 절은 새 줄에 시작하고 들여쓰기 적용
   - 다중 조인은 각 조인을 새 줄에 시작

8. **서브쿼리 작성**:
   - 메인 쿼리보다 한 단계 더 들여쓰기
   - 별칭을 반드시 부여하여 가독성 향상
   - 가능한 FROM 절에서 인라인 뷰로 사용

9. **함수 사용**:
   - 내장 함수는 대문자로 작성
   - 함수명과 괄호 사이에 공백 불필요

10. **동적 SQL 작성**:
    - <if>, <choose>, <when> 등 사용 시 들여쓰기 준수
    - 동적 부분과 정적 부분 구분을 위해 주석 사용
    - **ORDER BY 절은 정렬 조건 존재 여부에 따라 동적으로 처리**

11. **성능 고려사항**:
    - 불필요한 서브쿼리 사용 지양
    - 대량의 데이터를 다룰 때는 페이징 처리 적용
    - 인덱스를 고려한 WHERE 절 작성

12. **Audit 컬럼 처리**:
    - 조회 쿼리: Audit 컬럼 제외
    - 생성/수정 쿼리: Audit 컬럼을 포함하되, 값은 MyBatis Interceptor에서 자동으로 처리

13. **주석 작성**:
    - 복잡한 쿼리에는 목적과 로직에 대한 설명을 주석으로 추가
    - 한 줄 주석은 --, 여러 줄 주석은 /* */ 사용

14. **ORDER BY 절 동적 처리**:
    - `hasSortFields()` 메서드로 정렬 조건 존재 여부 확인
    - 정렬 조건이 있으면 동적으로 ORDER BY 절 생성
    - 정렬 조건이 없으면 기본 정렬 적용 또는 ORDER BY 절 제거
    - 허용된 정렬 필드만 처리하여 SQL Injection 방지

### 10.5. Service 클래스 생성

Mapper 인터페이스가 준비되면, 비즈니스 로직을 처리할 Service 클래스 생성.

**Service 클래스 생성 규칙**:

1. **기본 구조**:
   - @Slf4j로 로깅 설정
   - @Service 어노테이션 사용
   - @RequiredArgsConstructor로 의존성 주입(생성자 주입 사용)
   - Enum 타입은 static import 사용하여 코드 간결화
   - Java 21 기법 적극 활용 (Optional, Switch Expression, Stream API, Pattern Matching)

2. **기본 메서드**:
   - 목록 조회: `getList(SearchDto)`
   - 건수 조회: `getCount(SearchDto)`
   - 상세 조회: `get(Long id)`
   - 생성: `create(CreateRequestDto)`
   - 수정: `update(UpdateRequestDto)`
   - 삭제: `delete(Long id)`

3. **상태 변경 메서드**:
   - 승인: `approve(Long id, ApproveRequestDto)`
   - 반려: `reject(Long id, RejectRequestDto)`
   - 취소: `cancel(Long id, CancelRequestDto)`
   - 확정: `confirm(Long id, ConfirmRequestDto)`
   - 처리: `process(Long id, ProcessRequestDto)`
   - 상태 변경: `changeStatus(Long id, String status, String updtProcrId)`

4. **트랜잭션 처리**:
   - 조회 메서드: @Transactional(readOnly = true)
   - 변경 메서드: @Transactional

5. **of 팩토리 메소드 활용으로 비즈니스 로직에 집중**:
   ```java
   /**
    * 주문을 생성합니다.
    * 
    * 처리 절차:
    * 1. 고객 존재 여부 및 주문 상품 유효성 검증
    * 2. 주문 기본 정보 생성 (주문번호 자동 생성, 상태 설정)
    * 3. 주문 정보 데이터베이스 저장
    * 4. 주문 상품 목록 저장
    * 5. 주문 생성 후속 처리 (알림 발송, 이력 기록)
    *
    * @param requestDto 주문 생성 요청 정보
    * @return 생성된 주문 정보
    * @throws BusinessException 고객이 존재하지 않거나 주문 상품이 유효하지 않은 경우
    * @throws ValidationException 필수 입력값이 누락된 경우
    */
   @Transactional
   public OrderDto create(OrderCreateRequestDto requestDto) {
       validateCustomerExists(requestDto.getCustomerId());
       validateOrderItems(requestDto.getOrderItems());
       
       OrderDto orderDto = OrderDto.of(requestDto);
       orderMapper.insert(orderDto);
       saveOrderItems(orderDto.getOrderId(), requestDto.getOrderItems());
       processAfterOrderCreation(orderDto);
       
       return orderDto;
   }
   ```

6. **비즈니스 규칙 검증**:
   ```java
   import static bxf.ai.model.code.OrderStatusCode.*;
   
   private void validateForApprove(OrderDto order) {
       if (!WAIT.equals(order.getOrderStatusCode())) {
           // 메시지 코드와 파라미터만 전달
           throw new BusinessException("order.invalidStatus", 
               new String[]{order.getOrderStatusCode().name()});
       }
       // 추가 검증 로직
   }
   ```

7. **예외 처리**:
   - 엔티티 없음: `if (order == null) throw new EntityNotFoundException("order.notFound");`
   - 비즈니스 규칙 위반: `throw new BusinessException("order.alreadyApproved");`
   - 권한 부족: `throw new AuthorizationException("common.unauthorized");`

8. **Audit 컬럼 처리**:
   - **중요: 서비스 레이어에서 DTO의 Audit 필드(procPrgmId, rgstProcrId, updtProcrId 등)를 직접 설정하는 코드를 작성하지 않음**
   - **MyBatis Interceptor에서 자동으로 처리되므로 예시와 같은 코드는 작성하지 않음:**
     ```java
     // 이런 코드는 작성하지 않음 (MyBatis Interceptor에서 자동 처리)
     orderDto.setProcPrgmId(requestDto.getProcPrgmId());
     orderDto.setRgstProcrId(requestDto.getRgstProcrId());
     orderDto.setUpdtProcrId(requestDto.getUpdtProcrId());
     ```

### 10.6. Controller 클래스 생성

마지막으로, 클라이언트 요청을 처리할 Controller 클래스 생성.

**Controller 클래스 생성 규칙**:

1. **기본 구조**:
   - @Slf4j로 로깅 설정
   - @RestController 어노테이션 사용
   - @RequestMapping("/api/{projectId}/{도메인-복수형}") 사용
   - @RequiredArgsConstructor로 의존성 주입(생성자 주입 사용)
   - @Tag로 Swagger 문서화
   - @ApiResponse 어노테이션에 의한 반환 문서화하지 않음
   - Enum 타입은 static import 사용하여 코드 간결화
   - Java 21 기법 적극 활용 (Optional, Switch Expression, Stream API, Pattern Matching)

2. **기본 메서드**:
   - 목록 조회: `getList(SearchDto)` - GET /
   - 상세 조회: `get(Long id)` - GET /{id}
   - 생성: `create(CreateRequestDto)` - POST /
   - 수정: `update(Long id, UpdateRequestDto)` - PUT /{id}
   - 삭제: `delete(Long id)` - DELETE /{id}

3. **상태 변경 메서드**:
   - 승인: `approve(Long id, ApproveRequestDto)` - POST /{id}/approve
   - 반려: `reject(Long id, RejectRequestDto)` - POST /{id}/reject
   - 취소: `cancel(Long id, CancelRequestDto)` - POST /{id}/cancel
   - 확정: `confirm(Long id, ConfirmRequestDto)` - POST /{id}/confirm
   - 처리: `process(Long id, ProcessRequestDto)` - POST /{id}/process

4. **응답 형식**:
   - ResponseEntity<ApiResponse<T>> 형식 사용
   - 메시지 코드를 활용하여 응답 생성(시스템이 자동으로 메시지 처리)
   - 빌더 패턴을 활용한 응답 생성
   ```java
   ApiResponse<OrderDto> response = ApiResponse.<OrderDto>builder()
           .success(true)
           .messageCode("success.order.create") // 메시지 코드만 지정
           .data(createdOrder)
           .build();
   ```

5. **파라미터 검증**:
   - @Validated 어노테이션으로 요청 DTO 검증
   - @PathVariable, @RequestParam 등으로 파라미터 처리
   - **정렬 파라미터**: `@RequestParam(required = false) String sortFields`로 받아서 SearchDto에 설정

6. **예외 처리**:
   - 컨트롤러 자체에서는 예외를 생성하거나 처리하지 않음
   - 글로벌 예외 핸들러(@ControllerAdvice)에서 일괄 처리

### 10.7. 메시지 리소스 생성

**메시지 리소스 파일 생성 규칙**:

1. **Bean Validation 메시지**: {프로젝트ID}-validation.properties
2. **성공 메시지 및 비즈니스 예외 메시지**: {프로젝트ID}-message.properties
3. **공통 메시지**: common-message.properties

> **중요**: 
- Bean Validation 메시지와 성공 메시지 및 비즈니스 예외 메시지는 반드시 생성할 것
- Bean Validation 메시지 다음 사항을 제외 : 기본 검증 메시지 (필드명 없이),타입별 검증 메시지, 글로벌 에러 메시지

### 10.8. 성능 최적화 고려사항

1. **Virtual Threads**: 대량 데이터 처리 시 활용
2. **Stream API**: 병렬 처리 고려
3. **Optional**: 메서드 체이닝으로 성능 최적화
4. **Record**: 불변 데이터로 메모리 효율성 확보

## 11. 코드 품질 확보 방안

### 11.1. Java 21 기법 적용 우선순위
1. Optional을 활용한 null 안전성 확보
2. Switch Expression을 활용한 조건부 로직 간소화
3. Stream API를 활용한 함수형 프로그래밍
4. Record를 활용한 불변 데이터 구조
5. Pattern Matching을 활용한 타입 안전성

### 11.2. 코드 일관성
- 명명 규칙 준수
- 어노테이션 사용 규칙 준수
- 패키지 구조 준수
- 메시지 처리 방식 준수
- 빌더 패턴 및 팩토리 메소드 활용 규칙 준수
- 정렬 처리 방식 준수 (SearchDto + MyBatis 동적 SQL)

이 가이드를 기반으로 일관되고 품질 높은 백엔드 소스 코드를 생성
# Mall VOC 데이터베이스 스키마 분석

## 개요
Mall VOC 데이터베이스는 Oracle 기반의 게시판 시스템으로, 다양한 유형의 게시판을 통합 관리하는 구조입니다. 공지사항, FAQ, QNA 등 다양한 게시판을 하나의 통합 테이블 구조로 관리합니다.

## 데이터베이스 구조

### 주요 테이블
1. **TB_BBS_SETUP** - 게시판 설정 (메타데이터)
2. **TB_BBS** - 게시판 콘텐츠 (통합 게시물)
3. **TB_BBS_CATEGORY** - 게시판 카테고리
4. **TB_BBS_FILE** - 게시판 첨부파일
5. **TB_BBS_RE** - 게시판 추천
6. **TB_BBS_ADD_FIELD** - 게시판 추가필드 (고객정보)

## ERD (Entity Relationship Diagram)

```mermaid
erDiagram
    TB_BBS_SETUP {
        VARCHAR2(20) BBS_CD PK
        VARCHAR2(20) BBS_DB UK
        VARCHAR2(50) BBS_NM
        NUMBER FILE_CNT
        NUMBER MOVIE_FILE_CNT
        VARCHAR2(1) MOVIE_ENCODING_YN
        NUMBER PRODUCT_ATTACH_CNT
        VARCHAR2(1) CATEGORY_YN
        VARCHAR2(1) ANONYMOUS_BBS_YN
        VARCHAR2(1) COMMENT_YN
        VARCHAR2(1) RE_YN
        VARCHAR2(1) REG_ID_VIEW_YN
        VARCHAR2(1) VIEW_ID_VIEW_YN
        VARCHAR2(1) FILE_VIEW_ID_VIEW_YN
        VARCHAR2(1) RE_ID_VIEW_YN
        VARCHAR2(1) SECRET_BBS_YN
        VARCHAR2(1) REF_BBS_YN
        VARCHAR2(200) TITLE_IMAGE_URL
        NUMBER VIEW_BEST_LIST_CNT
        NUMBER RE_BEST_LIST_CNT
        NUMBER COMMENT_BEST_LIST_CNT
        VARCHAR2(1) DEL_YN
        NUMBER RE_ID_LIST_CNT
        VARCHAR2(20) RE_ID
        DATE REG_DT
        VARCHAR2(20) REG_ID
        DATE MOD_DT
        VARCHAR2(20) MOD_ID
        VARCHAR2(1) RE_LIST_BBS_YN
        VARCHAR2(1) RE_CONTENT_BBS_YN
        NUMBER REG_ID_LIST_CNT
        NUMBER CATEGORY_LIST_CNT
        VARCHAR2(1) LIST_CONTENT_VIEW_YN
        VARCHAR2(1) BBS_FIELD_ADD_YN
    }
    
    TB_BBS {
        NUMBER BBS_SEQ PK
        NUMBER UP_BBS_SEQ FK
        NUMBER BBS_NO
        VARCHAR2(20) BBS_CD FK
        NUMBER CATEGORY_SEQ FK
        VARCHAR2(200) TITLE
        CLOB CONTENT
        VARCHAR2(1) NOTICE_YN
        VARCHAR2(1) SECRET_YN
        VARCHAR2(44) PASSWD
        NUMBER ORD
        VARCHAR2(1) DEL_YN
        VARCHAR2(15) REG_IP
        DATE REG_DT
        VARCHAR2(20) REG_ID
        VARCHAR2(20) REG_ID_NM
        VARCHAR2(40) REG_ID_NICK_NM
        VARCHAR2(10) REG_ID_GROUP_CD
        VARCHAR2(100) REG_ID_GROUP_NM
        DATE MOD_DT
        VARCHAR2(20) MOD_ID
        VARCHAR2(15) COMM_CD
        NUMBER HITS
        VARCHAR2(1) REPLY_YN
        VARCHAR2(1) COMPLETE_YN
    }
    
    TB_BBS_CATEGORY {
        NUMBER CATEGORY_SEQ PK
        VARCHAR2(200) CATEGORY_NM
        VARCHAR2(200) ML_CATEGORY_NM
        VARCHAR2(20) BBS_CD FK
        NUMBER ORD
        DATE REG_DT
        VARCHAR2(20) REG_ID
        DATE MOD_DT
        VARCHAR2(20) MOD_ID
        NUMBER UP_CATEGORY_SEQ
        VARCHAR2(1) DEL_YN
        VARCHAR2(1) USE_YN
        VARCHAR2(1) MEM_YN
        VARCHAR2(15) COMM_CD
    }
    
    TB_BBS_FILE {
        NUMBER BBS_FILE_SEQ PK
        NUMBER BBS_SEQ FK
        VARCHAR2(200) FILE_NM
        VARCHAR2(200) REAL_FILE_NM
        NUMBER FILE_SIZE
        VARCHAR2(300) FILE_TYPE
        DATE REG_DT
        VARCHAR2(20) REG_ID
        VARCHAR2(10) FILE_GROUP
    }
    
    TB_BBS_RE {
        NUMBER BBS_RE_SEQ PK
        NUMBER BBS_SEQ FK
        VARCHAR2(15) REG_IP
        DATE REG_DT
        VARCHAR2(20) REG_ID
        VARCHAR2(20) REG_ID_NM
        VARCHAR2(40) REG_ID_NICK_NM
        VARCHAR2(10) REG_ID_GROUP_CD
        VARCHAR2(100) REG_ID_GROUP_NM
    }
    
    TB_BBS_ADD_FIELD {
        NUMBER BBS_SEQ PK FK
        VARCHAR2(100) CST_NM
        VARCHAR2(15) TEL_NO
        VARCHAR2(15) HP_NO
        VARCHAR2(50) EMAIL
    }
    
    %% Relationships
    TB_BBS_SETUP ||--o{ TB_BBS : "has"
    TB_BBS_SETUP ||--o{ TB_BBS_CATEGORY : "has"
    TB_BBS ||--o{ TB_BBS_FILE : "has"
    TB_BBS ||--o{ TB_BBS_RE : "has"
    TB_BBS ||--o| TB_BBS_ADD_FIELD : "has"
    TB_BBS ||--o| TB_BBS_CATEGORY : "belongs to"
    TB_BBS ||--o| TB_BBS : "replies to"
```

## 테이블 상세 설명

### 1. TB_BBS_SETUP (게시판 설정)
- **목적**: 각 게시판의 메타데이터 및 설정 정보 관리
- **주요 필드**:
  - `BBS_CD`: 게시판 코드 (PRIMARY KEY)
  - `BBS_DB`: 게시판 DB 식별자 (UNIQUE)
  - `BBS_NM`: 게시판명
  - `CATEGORY_YN`: 카테고리 사용 여부
  - `COMMENT_YN`: 댓글 사용 여부
  - `SECRET_BBS_YN`: 비밀게시판 여부
  - `FILE_CNT`: 첨부파일 허용 개수

### 2. TB_BBS (게시판)
- **목적**: 모든 게시판의 게시물을 통합 관리
- **주요 필드**:
  - `BBS_SEQ`: 게시물 일련번호 (PRIMARY KEY)
  - `BBS_CD`: 게시판 코드 (어떤 게시판인지 구분)
  - `UP_BBS_SEQ`: 상위 게시물 (답변글 처리)
  - `TITLE`: 제목
  - `CONTENT`: 내용 (CLOB)
  - `NOTICE_YN`: 공지사항 여부
  - `SECRET_YN`: 비밀글 여부
  - `HITS`: 조회수
  - `REPLY_YN`: 답변 여부
  - `COMPLETE_YN`: 완료 여부

### 3. TB_BBS_CATEGORY (게시판 카테고리)
- **목적**: 게시판별 카테고리 관리
- **주요 필드**:
  - `CATEGORY_SEQ`: 카테고리 일련번호
  - `CATEGORY_NM`: 카테고리명
  - `BBS_CD`: 게시판 코드
  - `UP_CATEGORY_SEQ`: 상위 카테고리 (계층구조)

### 4. TB_BBS_FILE (게시판 파일)
- **목적**: 게시물 첨부파일 관리
- **주요 필드**:
  - `BBS_FILE_SEQ`: 파일 일련번호
  - `BBS_SEQ`: 게시물 번호
  - `FILE_NM`: 저장된 파일명
  - `REAL_FILE_NM`: 실제 파일명

### 5. TB_BBS_RE (게시판 추천)
- **목적**: 게시물 추천 이력 관리
- **주요 필드**:
  - `BBS_RE_SEQ`: 추천 일련번호
  - `BBS_SEQ`: 게시물 번호
  - `REG_ID`: 추천자 ID

### 6. TB_BBS_ADD_FIELD (게시판 추가필드)
- **목적**: 게시물별 추가 정보 (고객정보 등)
- **주요 필드**:
  - `BBS_SEQ`: 게시물 번호
  - `CST_NM`: 고객명
  - `TEL_NO`: 전화번호
  - `HP_NO`: 휴대폰번호
  - `EMAIL`: 이메일

## 마이그레이션 매핑 전략 (Mall VOC → TOBE VOC)

### 게시판 코드별 매핑
Mall VOC는 통합 테이블 구조이므로 BBS_CD로 게시판을 구분하여 각각의 타겟 테이블로 매핑합니다.

| BBS_CD 패턴 | TOBE VOC 타겟 | 설명 |
|-------------|---------------|------|
| NOTICE_% | TB_NTFY_M | 공지사항 |
| FAQ_% | TB_FAQ_M | FAQ |
| QNA_%, CS_% | TB_QNA_M | 1:1 문의 |
| EVENT_% | TB_EVT_M | 이벤트 |

### 필드 매핑

#### TB_BBS → TB_NTFY_M (공지사항)
- `TITLE` → `NTFY_TTL`
- `CONTENT` → `NTFY_CNTN`
- `HITS` → `QRY_CNT`
- `NOTICE_YN='Y'` → 상단 고정 여부로 `MAIN_YN` 설정
- `REG_ID` → `CRET_ID`
- `REG_DT` → `CRET_DTTM`
- 첫 번째 첨부파일 → `FILE_ID`

#### TB_BBS → TB_FAQ_M (FAQ)
- `TITLE` → `FAQ_TTL`
- `CONTENT` → `FAQ_CNTN`
- `CATEGORY_SEQ` → `FAQ_CLS_CD` (카테고리 매핑)
- `HITS` → `QRY_CNT`
- `REG_ID` → `CRET_ID`
- `REG_DT` → `CRET_DTTM`

#### TB_BBS → TB_QNA_M / TB_QNA_ANS_D (1:1 문의)
- `TITLE` → `QNA_TTL`
- `CONTENT` → `QNA_CNTN`
- `CATEGORY_SEQ` → `QNA_CLS_CD`
- `SECRET_YN` → `PRVC_YN`
- `PASSWD` → `QNA_PSWD`
- `REPLY_YN='Y'` → `QNA_STAT_CD='02'`
- `TB_BBS_ADD_FIELD` → 고객정보 매핑
  - `CST_NM` → `CSTMR_NM`
  - `HP_NO` → `CSTMR_MPNO`
  - `EMAIL` → `CSTMR_EML_ADDR`
- 답변글(UP_BBS_SEQ가 있는 경우) → `TB_QNA_ANS_D`

#### TB_BBS → TB_EVT_M (이벤트)
- `TITLE` → `EVT_NM`
- `CONTENT` → `EVT_CNTN`
- `REG_DT` → `EVT_FR_DT` (시작일)
- 이벤트 종료일은 별도 처리 필요
- `HITS` → `QRY_CNT`

## 데이터 변환 고려사항

1. **통합 테이블 분리**
   - BBS_CD로 게시판 유형을 판단하여 적절한 타겟 테이블로 분리
   - 각 게시판의 특성에 맞는 필드 매핑

2. **답변글 처리**
   - UP_BBS_SEQ가 있는 경우 답변글로 처리
   - QNA의 경우 TB_QNA_ANS_D로 분리 저장

3. **카테고리 코드 변환**
   - TB_BBS_CATEGORY의 계층구조를 평면화
   - COMM_CD 또는 카테고리명을 기준으로 표준 코드 매핑

4. **파일 처리**
   - TB_BBS_FILE에서 첫 번째 파일만 FILE_ID로 매핑
   - 파일 경로 및 명명 규칙 변환 필요

5. **상태 값 변환**
   - DEL_YN='N' → 활성 데이터만 마이그레이션
   - COMPLETE_YN → QNA_STAT_CD 매핑
   - 모든 타겟 테이블의 DEL_YN='N' 설정

6. **날짜 형식**
   - Oracle DATE → MariaDB DATETIME 변환

## 인덱스 및 제약조건
- 모든 PRIMARY KEY는 NUMBER 타입 사용
- 외래키 관계 유지
- 게시판 코드(BBS_CD)로 파티셔닝 고려 가능
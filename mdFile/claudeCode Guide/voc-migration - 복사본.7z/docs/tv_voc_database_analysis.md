# TV VOC 데이터베이스 스키마 분석

## 개요
TV VOC 데이터베이스는 MySQL/MariaDB 기반의 고객 서비스 관리 시스템으로, 공지사항, 이벤트, FAQ, 1:1 문의 등의 기능을 제공합니다.

## 데이터베이스 구조

### 주요 테이블
1. **notice** - 공지사항 관리
2. **event** - 이벤트 관리
3. **faq** - 자주 묻는 질문 관리
4. **question** - 1:1 문의 관리

### 보조 테이블
1. **notice_attach** - 공지사항 첨부파일 매핑
2. **event_attach** - 이벤트 첨부파일 매핑
3. **faq_attach** - FAQ 첨부파일 매핑
4. **question_attach** - 1:1 문의 첨부파일 매핑

### 참조 테이블
1. **file_info** - 파일 정보
2. **board_category** - 카테고리 정보
3. **member** - 회원 정보

## ERD (Entity Relationship Diagram)

```mermaid
erDiagram
    notice {
        bigint id PK
        varchar(1024) title
        bit enable
        bit fixed_at_top
        varchar(24) state
        bit notify
        text contents
        bigint page_view_count
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    event {
        bigint id PK
        text contents
        bit enable
        varchar(24) state
        bit notify
        bigint page_view_count
        varchar(1024) title
        datetime start_date
        datetime end_date
        datetime result_date
        bigint image_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    faq {
        bigint id PK
        bigint category_ref_id FK
        varchar(1024) title
        text question
        text answer
        varchar(24) state
        bigint unique_view_count
        bigint page_view_count
        bit frequent
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    question {
        bigint id PK
        bigint category_ref_id FK
        varchar(1024) title
        varchar(24) state
        text contents
        bit reply
        text reply_contents
        datetime reply_date
        bit reply_notify
        bigint member_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    file_info {
        bigint id PK
        varchar file_name
        varchar file_path
        bigint file_size
        varchar mime_type
    }
    
    board_category {
        bigint id PK
        varchar category_name
        varchar category_code
    }
    
    member {
        bigint id PK
        varchar member_name
        varchar member_email
        varchar member_phone
    }
    
    notice_attach {
        bigint id PK
        bigint notice_ref_id FK
        bigint file_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    event_attach {
        bigint id PK
        bigint event_ref_id FK
        bigint file_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    faq_attach {
        bigint id PK
        bigint faq_ref_id FK
        bigint file_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    question_attach {
        bigint id PK
        bigint question_ref_id FK
        bigint file_ref_id FK
        varchar(50) created_by
        timestamp created_date
        varchar(50) last_modified_by
        timestamp last_modified_date
    }
    
    %% Relationships
    event ||--o{ event_attach : "has"
    event ||--o| file_info : "has image"
    event_attach ||--|| file_info : "references"
    
    notice ||--o{ notice_attach : "has"
    notice_attach ||--|| file_info : "references"
    
    faq ||--o{ faq_attach : "has"
    faq ||--o| board_category : "belongs to"
    faq_attach ||--|| file_info : "references"
    
    question ||--o{ question_attach : "has"
    question ||--o| board_category : "belongs to"
    question ||--|| member : "created by"
    question_attach ||--|| file_info : "references"
```

## 테이블 상세 설명

### 1. notice (공지사항)
- **목적**: 사용자에게 공지할 내용을 관리
- **주요 필드**:
  - `enable`: 공지 활성화 여부
  - `fixed_at_top`: 상단 고정 여부
  - `state`: 공지 상태 (draft, published 등)
  - `notify`: 알림 여부
  - `page_view_count`: 조회수

### 2. event (이벤트)
- **목적**: 이벤트 정보 및 기간 관리
- **주요 필드**:
  - `start_date`, `end_date`: 이벤트 기간
  - `result_date`: 결과 발표일
  - `image_ref_id`: 대표 이미지 참조
  - `enable`: 이벤트 활성화 여부

### 3. faq (자주 묻는 질문)
- **목적**: 자주 묻는 질문과 답변 관리
- **주요 필드**:
  - `category_ref_id`: 카테고리 분류
  - `question`, `answer`: 질문과 답변 내용
  - `frequent`: 자주 묻는 질문 표시
  - `unique_view_count`: 고유 조회수

### 4. question (1:1 문의)
- **목적**: 회원의 1:1 문의사항 관리
- **주요 필드**:
  - `member_ref_id`: 문의한 회원 참조
  - `reply`: 답변 여부
  - `reply_contents`: 답변 내용
  - `reply_date`: 답변 일시
  - `reply_notify`: 답변 알림 여부

## 마이그레이션 매핑 전략 (TV VOC → TOBE VOC)

### 테이블 매핑
| TV VOC (소스) | TOBE VOC (타겟) | 비고 |
|---------------|-----------------|------|
| notice | TB_NTFY_M | 공지사항 |
| event | TB_EVT_M | 이벤트 |
| faq | TB_FAQ_M | FAQ |
| question | TB_QNA_M | 1:1 문의 |
| - | TB_QNA_ANS_D | 답변 분리 |

### 필드 매핑
#### notice → TB_NTFY_M
- `title` → `NTFY_TTL`
- `contents` → `NTFY_CNTN`
- `enable` → `OP_YN`
- `page_view_count` → `QRY_CNT`
- `created_by` → `CRET_ID`
- `created_date` → `CRET_DTTM`

#### event → TB_EVT_M
- `title` → `EVT_NM`
- `contents` → `EVT_CNTN`
- `start_date` → `EVT_FR_DT`
- `end_date` → `EVT_TO_DT`
- `image_ref_id` → `IMG_ID`
- `page_view_count` → `QRY_CNT`

#### faq → TB_FAQ_M
- `title` → `FAQ_TTL`
- `question` + `answer` → `FAQ_CNTN`
- `category_ref_id` → `FAQ_CLS_CD`
- `frequent` → `MAIN_YN`
- `page_view_count` → `QRY_CNT`

#### question → TB_QNA_M / TB_QNA_ANS_D
- `title` → `QNA_TTL`
- `contents` → `QNA_CNTN`
- `category_ref_id` → `QNA_CLS_CD`
- `reply` → `QNA_STAT_CD` (01: 접수, 02: 답변완료)
- `reply_contents` → `TB_QNA_ANS_D.ANS_CNTN`
- `member_ref_id` → 회원 정보 조회 필요

## 데이터 변환 고려사항

1. **상태 코드 변환**
   - TV VOC의 `state` 값을 TOBE의 표준 코드로 변환
   - `enable` bit를 `OP_YN` Y/N으로 변환

2. **날짜 형식**
   - MySQL datetime(3) → MariaDB datetime

3. **파일 첨부**
   - 각 테이블의 attach 테이블에서 FILE_ID 추출
   - 첫 번째 첨부파일만 마이그레이션 (TOBE는 단일 FILE_ID)

4. **카테고리 매핑**
   - board_category 참조를 서비스 타입 코드로 변환

5. **삭제 플래그**
   - TOBE의 `DEL_YN`은 기본값 'N'으로 설정

## 인덱스 및 제약조건
- 모든 테이블은 AUTO_INCREMENT PRIMARY KEY 사용
- 외래키는 CASCADE 옵션으로 참조 무결성 유지
- 첨부파일 매핑 테이블은 다대다 관계 구현
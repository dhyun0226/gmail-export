# VOC Migration Project

Voice of Customer Migration System built with Spring Boot 3.4.1

## Project Structure

```
voc-migration/
├── build.gradle
├── settings.gradle
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── ow/
│   │   │           └── voc/
│   │   │               ├── VocMigrationApplication.java
│   │   │               ├── config/
│   │   │               │   ├── PrimaryDataSourceConfig.java
│   │   │               │   ├── SecondaryDataSourceConfig.java
│   │   │               │   ├── PrimaryMyBatisConfig.java
│   │   │               │   ├── SecondaryMyBatisConfig.java
│   │   │               │   └── SwaggerConfig.java
│   │   │               ├── controller/
│   │   │               │   └── HealthCheckController.java
│   │   │               ├── service/
│   │   │               ├── mapper/
│   │   │               │   ├── primary/
│   │   │               │   │   └── VocMapper.java
│   │   │               │   └── secondary/
│   │   │               └── dto/
│   │   │                   ├── VocDto.java
│   │   │                   ├── request/
│   │   │                   │   └── VocCreateRequest.java
│   │   │                   └── response/
│   │   │                       ├── VocResponse.java
│   │   │                       └── ApiResponse.java
│   │   └── resources/
│   │       ├── application.yml
│   │       └── mapper/
│   │           └── voc/
│   │               └── VocMapper.xml
│   └── test/
│       ├── java/
│       └── resources/
```

## Technology Stack

- **Java Version**: 21
- **Framework**: Spring Boot 3.4.1
- **Build Tool**: Gradle
- **ORM**: MyBatis
- **API Documentation**: Swagger/OpenAPI v3
- **Utility**: Lombok
- **Databases**: 
  - Primary: Oracle
  - Secondary: MariaDB

## Running the Application

1. Ensure Java 21 is installed
2. Configure database connections in `application.yml`
3. Run: `./gradlew bootRun`

## API Documentation

Once the application is running, access Swagger UI at:
- http://localhost:8080/api/swagger-ui.html

## Database Configuration

The application is configured with two data sources:
- **Primary (Oracle)**: Main transactional database
- **Secondary (MariaDB)**: Secondary/read-replica database

Update the database credentials in `application.yml` before running the application.
# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Common Development Commands

### Build and Run
- **Run application**: `./gradlew bootRun`
- **Build project**: `./gradlew build`
- **Clean build**: `./gradlew clean build`
- **Run tests**: `./gradlew test`
- **Run specific test**: `./gradlew test --tests "TestClassName.testMethodName"`

### Development URLs
- **Application**: http://localhost:8080/api
- **Swagger UI**: http://localhost:8080/api/swagger-ui.html
- **API Docs**: http://localhost:8080/api/v3/api-docs

## Architecture Overview

This is a Spring Boot 3.4.1 application designed for Voice of Customer (VOC) data migration between Oracle and MariaDB databases.

### Dual Database Architecture
The application uses a dual-datasource pattern:
- **Primary DataSource (Oracle)**: Main transactional database configured in `PrimaryDataSourceConfig.java` and `PrimaryMyBatisConfig.java`
- **Secondary DataSource (MariaDB)**: Secondary/read database configured in `SecondaryDataSourceConfig.java` and `SecondaryMyBatisConfig.java`

MyBatis mappers are segregated by datasource:
- Primary mappers: `com.ow.voc.mapper.primary`
- Secondary mappers: `com.ow.voc.mapper.secondary`

### Key Configuration Files
- `application.yml`: Contains all application configuration including database connections, server settings, and logging levels
- MyBatis XML mappers: Located in `src/main/resources/mapper/voc/`

### Package Structure
- `config/`: Spring configuration classes for datasources, MyBatis, and Swagger
- `controller/`: REST API endpoints
- `service/`: Business logic layer (implement services here)
- `mapper/`: MyBatis mapper interfaces split by database
- `dto/`: Data transfer objects including request/response models

### Technology Stack
- Java 21
- Spring Boot 3.4.1
- MyBatis 3.0.4 for ORM
- HikariCP for connection pooling
- Lombok for reducing boilerplate code
- SpringDoc OpenAPI 2.7.0 for API documentation

### Database Configuration
Before running, update database credentials in `application.yml`:
- Primary Oracle: `spring.datasource.primary`
- Secondary MariaDB: `spring.datasource.secondary`
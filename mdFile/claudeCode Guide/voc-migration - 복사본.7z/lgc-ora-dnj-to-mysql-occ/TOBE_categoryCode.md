|SVC_CTG_CD  |UP_SVC_CTG_CD|SVC_CTG_NM  |
|------------|-------------|------------|
|D001        |             |TV          |
|D001_EVT    |D001         |이벤트         |
|D001_FAQ    |D001         |FAQ         |
|D001_FAQ_001|D001_FAQ     |자주하는질문      |
|D001_FAQ_002|D001_FAQ     |가입/로그인      |
|D001_FAQ_003|D001_FAQ     |계정/탈퇴       |
|D001_FAQ_004|D001_FAQ     |콘텐츠         |
|D001_FAQ_005|D001_FAQ     |서비스         |
|D001_INQ    |D001         |1:1문의       |
|D001_INQ_001|D001_INQ     |회원/로그인      |
|D001_INQ_002|D001_INQ     |덴탈인포 상담예약   |
|D001_INQ_003|D001_INQ     |영상(VOD/LIVE)|
|D001_INQ_004|D001_INQ     |이벤트         |
|D001_INQ_005|D001_INQ     |장애/오류신고     |
|D001_INQ_006|D001_INQ     |제휴/광고제안     |
|D001_INQ_999|D001_INQ     |기타          |
|D001_NTF    |D001         |공지사항        |
|D001_NTF_000|D001_NTF     |공지사항        |
|D001_QNA    |D001         |문의          |
|D001_QNA_001|D001_QNA     |회원/로그인      |
|D001_QNA_002|D001_QNA     |덴탈인포 상담예약   |
|D001_QNA_003|D001_QNA     |영상(VOD/LIVE)|
|D001_QNA_004|D001_QNA     |이벤트         |
|D001_QNA_005|D001_QNA     |장애/오류신고     |
|D001_QNA_006|D001_QNA     |제휴/광고제안     |
|D001_QNA_999|D001_QNA     |기타          |
|D002        |             |Mall        |
|D002_EVT    |D002         |이벤트         |
|D002_FAQ    |D002         |FAQ         |
|D002_FAQ_001|D002_FAQ     |배송          |
|D002_FAQ_002|D002_FAQ     |주문/결제       |
|D002_FAQ_003|D002_FAQ     |반품          |
|D002_FAQ_004|D002_FAQ     |서비스이용       |
|D002_FAQ_005|D002_FAQ     |DDS         |
|D002_FAQ_006|D002_FAQ     |증빙서류        |
|D002_INQ    |D002         |1:1문의       |
|D002_INQ_001|D002_INQ     |상품          |
|D002_INQ_002|D002_INQ     |반품/교환       |
|D002_INQ_003|D002_INQ     |주문/결제       |
|D002_INQ_004|D002_INQ     |배송          |
|D002_INQ_005|D002_INQ     |서비스이용       |
|D002_INQ_006|D002_INQ     |건의          |
|D002_INQ_999|D002_INQ     |기타          |
|D002_NTF    |D002         |공지사항        |
|D002_NTF_002|D002_NTF     |반품/교환       |
|D002_NTF_003|D002_NTF     |주문/결제       |
|D002_NTF_004|D002_NTF     |배송          |
|D002_NTF_999|D002_NTF     |기타          |
|D002_QNA    |D002         |문의          |
|D002_QNA_001|D002_QNA     |상품          |
|D002_QNA_002|D002_QNA     |반품/교환       |
|D002_QNA_003|D002_QNA     |주문/결제       |
|D002_QNA_004|D002_QNA     |배송          |
|D002_QNA_005|D002_QNA     |서비스이용       |
|D002_QNA_006|D002_QNA     |건의          |
|D002_QNA_999|D002_QNA     |기타          |
|D003        |             |Education   |
|D003_FAQ    |D003         |FAQ         |
|D003_FAQ_001|D003_FAQ     |OICSeminar  |
|D003_FAQ_002|D003_FAQ     |병원사무관리사     |
|D003_INQ    |D003         |1:1문의       |
|D003_INQ_001|D003_INQ     |OICSeminar  |
|D003_INQ_002|D003_INQ     |병원사무관리사     |
|D003_NTF    |D003         |공지사항        |
|D003_NTF_001|D003_NTF     |OICSeminar  |
|D003_NTF_002|D003_NTF     |병원사무관리사     |
|D003_QNA    |D003         |문의          |
|D003_QNA_001|D003_QNA     |OICSeminar  |
|D003_QNA_002|D003_QNA     |병원사무관리사     |
|D004        |             |Job         |
|D004_EVT    |D004         |이벤트         |
|D004_FAQ    |D004         |FAQ         |
|D004_FAQ_001|D004_FAQ     |구인자(치과)     |
|D004_FAQ_002|D004_FAQ     |구직자(개인)     |
|D004_INQ    |D004         |1:1문의       |
|D004_INQ_001|D004_INQ     |구직          |
|D004_INQ_002|D004_INQ     |구인          |
|D004_INQ_003|D004_INQ     |이벤트         |
|D004_INQ_004|D004_INQ     |장애/오류신고     |
|D004_INQ_005|D004_INQ     |불량정보신고      |
|D004_INQ_006|D004_INQ     |건의/불만사항     |
|D004_INQ_999|D004_INQ     |기타          |
|D004_NTF    |D004         |공지사항        |
|D004_NTF_000|D004_NTF     |공지사항        |
|D004_QNA    |D004         |문의          |
|D004_QNA_001|D004_QNA     |구직          |
|D004_QNA_002|D004_QNA     |구인          |
|D004_QNA_003|D004_QNA     |이벤트         |
|D004_QNA_004|D004_QNA     |장애/오류신고     |
|D004_QNA_005|D004_QNA     |불량정보신고      |
|D004_QNA_006|D004_QNA     |건의/불만사항     |
|D004_QNA_999|D004_QNA     |기타          |
|D005        |             |Software    |
|D005_FAQ    |D005         |FAQ         |
|D005_FAQ_001|D005_FAQ     |두번에/하나로     |
|D005_FAQ_002|D005_FAQ     |OneClick    |
|D005_FAQ_003|D005_FAQ     |보험정보        |
|D005_FAQ_004|D005_FAQ     |V-Ceph      |
|D005_FAQ_005|D005_FAQ     |One2        |
|D005_FAQ_006|D005_FAQ     |One3        |
|D005_FAQ_007|D005_FAQ     |소프트웨어꿀팁     |
|D005_FAQ_008|D005_FAQ     |보험청구꿀팁      |
|D005_INQ    |D005         |1:1문의       |
|D005_INQ_001|D005_INQ     |두번에/하나로     |
|D005_INQ_002|D005_INQ     |OneClick    |
|D005_INQ_003|D005_INQ     |보험정보        |
|D005_INQ_004|D005_INQ     |V-Ceph      |
|D005_INQ_005|D005_INQ     |One2        |
|D005_INQ_006|D005_INQ     |One3        |
|D005_NTF    |D005         |공지사항        |
|D005_NTF_001|D005_NTF     |두번에/하나로     |
|D005_NTF_002|D005_NTF     |OneClick    |
|D005_NTF_003|D005_NTF     |보험정보        |
|D005_NTF_004|D005_NTF     |V-Ceph      |
|D005_NTF_005|D005_NTF     |One2        |
|D005_NTF_006|D005_NTF     |One3        |
|D005_NTF_999|D005_NTF     |기타          |
|D005_QNA    |D005         |문의          |
|D005_QNA_001|D005_QNA     |두번에/하나로     |
|D005_QNA_002|D005_QNA     |OneClick    |
|D005_QNA_003|D005_QNA     |보험정보        |
|D005_QNA_004|D005_QNA     |V-Ceph      |
|D005_QNA_005|D005_QNA     |One2        |
|D005_QNA_006|D005_QNA     |One3        |
|D006        |             |Osstem Home |
|D006_EVT    |D006         |이벤트         |
|D006_FAQ    |D006         |FAQ         |
|D006_FAQ_001|D006_FAQ     |사용문의        |
|D006_FAQ_002|D006_FAQ     |계정          |
|D006_FAQ_999|D006_FAQ     |기타          |
|D006_INQ    |D006         |1:1문의       |
|D006_INQ_001|D006_INQ     |사용문의        |
|D006_INQ_002|D006_INQ     |계정          |
|D006_INQ_999|D006_INQ     |기타          |
|D006_NTF    |D006         |공지사항        |
|D006_NTF_001|D006_NTF     |사용문의        |
|D006_NTF_002|D006_NTF     |계정          |
|D006_NTF_999|D006_NTF     |기타          |
|D006_QNA    |D006         |문의          |
|D006_QNA_001|D006_QNA     |사용문의        |
|D006_QNA_002|D006_QNA     |계정          |
|D006_QNA_003|D006_QNA     |기타          |

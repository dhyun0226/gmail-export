-- DTV.notice definition

CREATE TABLE `notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) COLLATE utf8mb3_bin DEFAULT NULL,
  `enable` bit(1) DEFAULT b'0',
  `fixed_at_top` bit(1) DEFAULT b'0',
  `state` varchar(24) COLLATE utf8mb3_bin DEFAULT NULL,
  `notify` bit(1) DEFAULT b'0',
  `contents` text COLLATE utf8mb3_bin,
  `page_view_count` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=468 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='공지사항 관리 테이블';


-- DTV.event definition

CREATE TABLE `event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contents` text COLLATE utf8mb3_bin,
  `enable` bit(1) DEFAULT b'0',
  `state` varchar(24) COLLATE utf8mb3_bin DEFAULT NULL,
  `notify` bit(1) DEFAULT b'0',
  `page_view_count` bigint DEFAULT NULL,
  `title` varchar(1024) COLLATE utf8mb3_bin DEFAULT NULL,
  `start_date` datetime(3) DEFAULT NULL,
  `end_date` datetime(3) DEFAULT NULL,
  `result_date` datetime(3) DEFAULT NULL,
  `image_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Event_image_ref_id` (`image_ref_id`),
  CONSTRAINT `FK_Event_image_ref_id` FOREIGN KEY (`image_ref_id`) REFERENCES `file_info` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='이벤트 관리 테이블';


-- DTV.event_attach definition

CREATE TABLE `event_attach` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_ref_id` bigint DEFAULT NULL,
  `file_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_EventAttach_event_ref_id` (`event_ref_id`),
  KEY `FK_EventAttach_file_ref_id` (`file_ref_id`),
  CONSTRAINT `FK_EventAttach_event_ref_id` FOREIGN KEY (`event_ref_id`) REFERENCES `event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EventAttach_file_ref_id` FOREIGN KEY (`file_ref_id`) REFERENCES `file_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='이벤트 첨부파일 맵핑 테이블(이벤트당 최대 3개)';


-- DTV.faq definition

CREATE TABLE `faq` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_ref_id` bigint DEFAULT NULL,
  `title` varchar(1024) COLLATE utf8mb3_bin DEFAULT NULL,
  `question` text COLLATE utf8mb3_bin,
  `answer` text COLLATE utf8mb3_bin,
  `state` varchar(24) COLLATE utf8mb3_bin DEFAULT NULL,
  `unique_view_count` bigint DEFAULT NULL,
  `page_view_count` bigint DEFAULT NULL,
  `frequent` bit(1) DEFAULT b'0',
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Faq_category_ref_id` (`category_ref_id`),
  CONSTRAINT `FK_Faq_category_ref_id` FOREIGN KEY (`category_ref_id`) REFERENCES `board_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='FAQ 관리 테이블';


-- DTV.faq_attach definition

CREATE TABLE `faq_attach` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `faq_ref_id` bigint DEFAULT NULL,
  `file_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_FaqAttach_faq_ref_id` (`faq_ref_id`),
  KEY `FK_FaqAttach_file_ref_id` (`file_ref_id`),
  CONSTRAINT `FK_FaqAttach_faq_ref_id` FOREIGN KEY (`faq_ref_id`) REFERENCES `faq` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_FaqAttach_file_ref_id` FOREIGN KEY (`file_ref_id`) REFERENCES `file_info` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='FAQ 첨부파일 맵핑 테이블(최대 3개)';


-- DTV.notice_attach definition

CREATE TABLE `notice_attach` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_ref_id` bigint DEFAULT NULL,
  `notice_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_NoticeAttach_file_ref_id` (`file_ref_id`),
  KEY `FK_NoticeAttach_notice_ref_id` (`notice_ref_id`),
  CONSTRAINT `FK_NoticeAttach_file_ref_id` FOREIGN KEY (`file_ref_id`) REFERENCES `file_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_NoticeAttach_notice_ref_id` FOREIGN KEY (`notice_ref_id`) REFERENCES `notice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10032 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='공지사항내 첨부될 첨부파일 맵핑 테이블';


-- DTV.question definition

CREATE TABLE `question` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_ref_id` bigint DEFAULT NULL,
  `title` varchar(1024) COLLATE utf8mb3_bin DEFAULT NULL,
  `state` varchar(24) COLLATE utf8mb3_bin DEFAULT NULL,
  `contents` text COLLATE utf8mb3_bin,
  `reply` bit(1) DEFAULT b'0',
  `reply_contents` text COLLATE utf8mb3_bin,
  `reply_date` datetime(3) DEFAULT NULL,
  `reply_notify` bit(1) DEFAULT b'0',
  `member_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Question_category_ref_id` (`category_ref_id`),
  KEY `FK_Question_member_ref_id` (`member_ref_id`),
  CONSTRAINT `FK_Question_category_ref_id` FOREIGN KEY (`category_ref_id`) REFERENCES `board_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_Question_member_ref_id` FOREIGN KEY (`member_ref_id`) REFERENCES `member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=438 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='1:1 문의 관리 테이블';


-- DTV.question_attach definition

CREATE TABLE `question_attach` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_ref_id` bigint DEFAULT NULL,
  `question_ref_id` bigint DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QuestionAttach_file_ref_id` (`file_ref_id`),
  KEY `FK_QuestionAttach_question_ref_id` (`question_ref_id`),
  CONSTRAINT `FK_QuestionAttach_file_ref_id` FOREIGN KEY (`file_ref_id`) REFERENCES `file_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_QuestionAttach_question_ref_id` FOREIGN KEY (`question_ref_id`) REFERENCES `question` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='1:1 문의 첨부파일 관리 테이블(최대 3개)';

-- DTV.`member` definition

CREATE TABLE `member` (
  `id` bigint NOT NULL,
  `active` bit(1) DEFAULT b'0',
  `member_state` varchar(50) COLLATE utf8mb3_bin NOT NULL DEFAULT 'Active',
  `agree_email` bit(1) DEFAULT b'0',
  `agree_sms` bit(1) DEFAULT b'0',
  `agree_marketing` bit(1) DEFAULT b'0',
  `birth_date` date DEFAULT NULL,
  `email` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `address1` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `address2` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `job_type` varchar(64) COLLATE utf8mb3_bin DEFAULT 'ETC',
  `last_login_date` datetime(3) DEFAULT NULL,
  `canceled_date` date DEFAULT NULL COMMENT '탈퇴일',
  `gender` tinyint DEFAULT '0' COMMENT 'Unknown(0), Male(1), Female(2)',
  `js` bit(1) DEFAULT b'0',
  `member_id` varchar(256) COLLATE utf8mb3_bin NOT NULL,
  `name` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `phone_number` varchar(256) COLLATE utf8mb3_bin DEFAULT NULL,
  `zip_code` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `nick_name` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `customer_id` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `license_number` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `employee_id` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `employee_name` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `employee_department` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `employee_grade` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `member_unique_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='회원(멤버,관리자) 관리 테이블';
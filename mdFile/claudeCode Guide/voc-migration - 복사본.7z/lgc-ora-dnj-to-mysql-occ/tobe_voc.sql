-- OCC.TB_EVT_M definition

CREATE TABLE `TB_EVT_M` (
  `EVT_NO` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '이벤트번호',
  `SVC_CTG_CD` varchar(12) NOT NULL COMMENT '서비스분류코드',
  `EVT_TTL` varchar(100) NOT NULL COMMENT '이벤트제목',
  `EVT_CN` mediumtext NOT NULL COMMENT '이벤트내용',
  `EVT_STRT_DTM` datetime NOT NULL COMMENT '이벤트시작일시',
  `EVT_END_DTM` datetime NOT NULL COMMENT '이벤트종료일시',
  `RGSTR_CPRN_CD` varchar(3) NOT NULL COMMENT '등록자법인코드',
  `RGSTR_DEPT_CD` varchar(30) NOT NULL COMMENT '등록자부서코드',
  `RGSTR_EMP_NO` varchar(60) NOT NULL COMMENT '등록자사원번호',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `SORT_ORD` decimal(10,0) DEFAULT NULL COMMENT '정렬순서',
  `USE_YN` char(1) NOT NULL DEFAULT 'Y' COMMENT '사용여부',
  `EVT_PRTC_DVCD` varchar(2) NOT NULL COMMENT '이벤트참여구분코드',
  `INQ_CNT` smallint(6) NOT NULL COMMENT '조회건수',
  `EVT_RGST_DTM` datetime NOT NULL COMMENT '이벤트등록일시',
  `THNL_FILE_ID` varchar(50) DEFAULT NULL COMMENT '섬네일파일ID',
  `TOP_FXD_YN` char(1) NOT NULL COMMENT '상단고정여부',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`EVT_NO`),
  KEY `FK_TB_SVC_CTG_C_TO_TB_EVT_M` (`SVC_CTG_CD`),
  CONSTRAINT `FK_TB_SVC_CTG_C_TO_TB_EVT_M` FOREIGN KEY (`SVC_CTG_CD`) REFERENCES `TB_SVC_CTG_C` (`SVC_CTG_CD`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='이벤트기본';


-- OCC.TB_EVT_PRTC_D definition

CREATE TABLE `TB_EVT_PRTC_D` (
  `EVT_NO` bigint(20) NOT NULL COMMENT '이벤트번호',
  `EVT_PRTC_DTM` datetime NOT NULL COMMENT '이벤트참여일시',
  `PRTCR_MEM_ID` varchar(20) NOT NULL COMMENT '참여자회원ID',
  `EVT_PRTC_CN` varchar(1000) NOT NULL COMMENT '이벤트참여내용',
  `DEL_YN` char(1) NOT NULL COMMENT '삭제여부',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL DEFAULT current_timestamp(6) COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`EVT_PRTC_DTM`),
  KEY `FK_TB_EVT_M_TO_TB_EVT_PRTC_D` (`EVT_NO`),
  CONSTRAINT `FK_TB_EVT_M_TO_TB_EVT_PRTC_D` FOREIGN KEY (`EVT_NO`) REFERENCES `TB_EVT_M` (`EVT_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='이벤트참여상세';


-- OCC.TB_FAQ_M definition

CREATE TABLE `TB_FAQ_M` (
  `FAQ_NO` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'FAQ번호',
  `SVC_CTG_CD` varchar(12) NOT NULL COMMENT '서비스분류코드',
  `FAQ_TTL` varchar(100) NOT NULL COMMENT 'FAQ제목',
  `FAQ_CN` mediumtext NOT NULL COMMENT 'FAQ내용',
  `RGSTR_CPRN_CD` varchar(3) NOT NULL COMMENT '등록자법인코드',
  `RGSTR_DEPT_CD` varchar(30) NOT NULL COMMENT '등록자부서코드',
  `RGSTR_EMP_NO` varchar(60) NOT NULL COMMENT '등록자사원번호',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `SORT_ORD` decimal(10,0) DEFAULT NULL COMMENT '정렬순서',
  `USE_YN` char(1) NOT NULL DEFAULT 'Y' COMMENT '사용여부',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL DEFAULT current_timestamp(6) COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`FAQ_NO`),
  KEY `FK_TB_SVC_CTG_C_TO_TB_FAQ_M` (`SVC_CTG_CD`),
  CONSTRAINT `FK_TB_SVC_CTG_C_TO_TB_FAQ_M` FOREIGN KEY (`SVC_CTG_CD`) REFERENCES `TB_SVC_CTG_C` (`SVC_CTG_CD`)
) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='FAQ기본';


-- OCC.TB_NTFY_M definition

CREATE TABLE `TB_NTFY_M` (
  `NTFY_NO` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '공지번호',
  `SVC_CTG_CD` varchar(12) NOT NULL COMMENT '서비스분류코드',
  `OPEN_YN` char(1) NOT NULL DEFAULT 'Y' COMMENT '공개여부',
  `TOP_FXD_YN` char(1) NOT NULL COMMENT '상단고정여부',
  `NTFY_TTL` varchar(100) NOT NULL COMMENT '공지제목',
  `NTFY_CN` mediumtext NOT NULL COMMENT '공지내용',
  `RGSTR_CPRN_CD` varchar(3) NOT NULL COMMENT '등록자법인코드',
  `RGSTR_DEPT_CD` varchar(30) NOT NULL COMMENT '등록자부서코드',
  `RGSTR_EMP_NO` varchar(60) NOT NULL COMMENT '등록자사원번호',
  `NTFY_RGST_DTM` datetime NOT NULL COMMENT '공지등록일시',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `INQ_CNT` smallint(6) DEFAULT NULL COMMENT '조회건수',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL DEFAULT current_timestamp(6) COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`NTFY_NO`),
  KEY `FK_TB_SVC_CTG_C_TO_TB_NTFY_M` (`SVC_CTG_CD`),
  CONSTRAINT `FK_TB_SVC_CTG_C_TO_TB_NTFY_M` FOREIGN KEY (`SVC_CTG_CD`) REFERENCES `TB_SVC_CTG_C` (`SVC_CTG_CD`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='공지기본';


-- OCC.TB_QNA_ANS_D definition

CREATE TABLE `TB_QNA_ANS_D` (
  `QNA_NO` bigint(20) NOT NULL COMMENT 'QNA번호',
  `QNA_ANS_DTL_NO` smallint(3) NOT NULL COMMENT 'QNA답변상세번호',
  `QNA_ANS_DTM` datetime NOT NULL COMMENT 'QNA답변일시',
  `UP_QNA_ANS_DTL_NO` smallint(3) DEFAULT NULL COMMENT '상위QNA답변상세번호',
  `ANSR_MEM_ID` varchar(20) DEFAULT NULL COMMENT '답변자회원ID',
  `ANSR_CPRN_CD` varchar(3) DEFAULT NULL COMMENT '답변자법인코드',
  `ANSR_DEPT_CD` varchar(30) DEFAULT NULL COMMENT '답변자부서코드',
  `ANSR_EMP_NO` varchar(60) DEFAULT NULL COMMENT '답변자사원번호',
  `QNA_ANS_CN` mediumtext NOT NULL COMMENT 'QNA답변내용',
  `DEL_YN` char(1) NOT NULL COMMENT '삭제여부',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL DEFAULT current_timestamp(6) COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`QNA_NO`,`QNA_ANS_DTL_NO`),
  CONSTRAINT `FK_TB_QNA_M_TO_TB_QNA_ANS_D` FOREIGN KEY (`QNA_NO`) REFERENCES `TB_QNA_M` (`QNA_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='QNA답변상세';


-- OCC.TB_QNA_M definition

CREATE TABLE `TB_QNA_M` (
  `QNA_NO` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'QNA번호',
  `SVC_CTG_CD` varchar(12) NOT NULL COMMENT '서비스분류코드',
  `WRTR_MEM_ID` varchar(20) NOT NULL COMMENT '작성자회원ID',
  `ITM_CD` varchar(90) DEFAULT NULL COMMENT '품목코드',
  `OPEN_YN` char(1) NOT NULL DEFAULT 'Y' COMMENT '공개여부',
  `QNA_TTL` varchar(100) NOT NULL COMMENT 'QNA제목',
  `QNA_CN` mediumtext NOT NULL COMMENT 'QNA내용',
  `QNA_RGST_DTM` datetime NOT NULL COMMENT 'QNA등록일시',
  `FILE_ID` varchar(50) DEFAULT NULL COMMENT '파일ID',
  `ANS_CNT` smallint(6) DEFAULT NULL COMMENT '답변건수',
  `INQ_CNT` smallint(6) NOT NULL COMMENT '조회건수',
  `PROC_PRGM_ID` varchar(50) NOT NULL COMMENT '처리프로그램ID',
  `RGST_PROCR_ID` varchar(50) NOT NULL COMMENT '등록처리자ID',
  `RGST_PROC_DTM` datetime(6) NOT NULL DEFAULT current_timestamp(6) COMMENT '등록처리일시',
  `UPDT_PROCR_ID` varchar(50) DEFAULT NULL COMMENT '수정처리자ID',
  `UPDT_PROC_DTM` datetime(6) DEFAULT NULL COMMENT '수정처리일시',
  PRIMARY KEY (`QNA_NO`),
  KEY `FK_TB_SVC_CTG_C_TO_TB_QNA_M` (`SVC_CTG_CD`),
  CONSTRAINT `FK_TB_SVC_CTG_C_TO_TB_QNA_M` FOREIGN KEY (`SVC_CTG_CD`) REFERENCES `TB_SVC_CTG_C` (`SVC_CTG_CD`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='QNA기본';
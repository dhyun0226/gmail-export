|CATEGORY|CATEGORY_NAME|DB        |
|--------|-------------|----------|
|35      |OneClick     |QNA       |
|19      |두번에          |QNA       |
|11      |두번에          |FAQ       |
|35      |OneClick     |NOTI      |
|9       |V-Ceph       |ONLINEHELP|
|34      |OneClick     |DOWN      |
|100     |공통           |FAQ       |
|49      |One3         |DOWN      |
|102     |공통           |DOWN      |
|107     |공통           |ITIP      |
|106     |공통           |STIP      |
|111     |OneClick     |REVIEW    |
|56      |One2         |QNA       |
|46      |One3         |NOTI      |
|16      |두번에          |DOWN      |
|4       |두번에          |NOTI      |
|18      |V-Ceph       |DOWN      |
|13      |V-Ceph       |FAQ       |
|7       |두번에          |ONLINEHELP|
|33      |OneClick     |FAQ       |
|51      |보험정보         |FAQ       |
|31      |OneClick     |NOTI      |
|17      |하나로          |DOWN      |
|20      |하나로          |QNA       |
|104     |공통           |QNA       |
|12      |하나로          |FAQ       |
|101     |공통           |NOTI      |
|5       |하나로          |NOTI      |
|32      |OneClick     |ONLINEHELP|
|50      |One3         |QNA       |
|53      |One2         |NOTI      |
|52      |보험정보         |QNA       |
|6       |V-Ceph       |NOTI      |
|21      |V-Ceph       |QNA       |
|8       |하나로          |ONLINEHELP|
|105     |공통           |CUSTM     |

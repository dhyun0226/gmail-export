package com.ow.voc.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Mall VOC 카테고리를 TOBE 카테고리 코드로 매핑하는 유틸리티 클래스
 */
@Slf4j
@Component
public class MallCategoryMapper {
    
    // ASIS 카테고리 매핑 테이블
    private static final Map<String, Map<String, String>> CATEGORY_MAPPING = new HashMap<>();
    
    static {
        // Notice 카테고리 매핑 - 공지사항(NTF)으로 매핑
        Map<String, String> noticeMapping = new HashMap<>();
        noticeMapping.put("B2B 몰", "D002_NTF_999");           // 기타
        noticeMapping.put("덴올/할인마트", "D002_NTF_999");      // 기타
        noticeMapping.put("DDS 정기배송", "D002_NTF_999");      // 기타
        CATEGORY_MAPPING.put("notice", noticeMapping);
        
        // FAQ 카테고리 매핑
        Map<String, String> faqMapping = new HashMap<>();
        faqMapping.put("서비스이용", "D002_FAQ_004");           // 서비스이용
        faqMapping.put("반품/교환", "D002_FAQ_003");           // 반품
        faqMapping.put("패키지", "D002_FAQ_004");              // 서비스이용으로 매핑
        faqMapping.put("주문/결제", "D002_FAQ_002");           // 주문/결제
        faqMapping.put("배송", "D002_FAQ_001");               // 배송
        faqMapping.put("증빙서류", "D002_FAQ_006");            // 증빙서류
        CATEGORY_MAPPING.put("faq", faqMapping);
        
        // CS (고객문의) 카테고리 매핑 - 1:1문의(INQ)로 매핑
        Map<String, String> csMapping = new HashMap<>();
        csMapping.put("서비스이용", "D002_INQ_005");           // 서비스이용
        csMapping.put("제안/건의", "D002_INQ_006");           // 건의
        csMapping.put("기타", "D002_INQ_999");               // 기타
        csMapping.put("1:1 문의", "D002_INQ_999");           // 기타
        csMapping.put("협력업체 입점 문의", "D002_INQ_006");    // 건의
        csMapping.put("덴탈인포", "D002_INQ_005");            // 서비스이용
        csMapping.put("배송", "D002_INQ_004");               // 배송
        csMapping.put("주문/결제", "D002_INQ_003");           // 주문/결제
        csMapping.put("커스터마이징PC 견적문의", "D002_INQ_001"); // 상품
        csMapping.put("상품", "D002_INQ_001");               // 상품
        csMapping.put("Dental 장비 A/S 신청", "D002_INQ_005"); // 서비스이용
        csMapping.put("개원 상담신청", "D002_INQ_005");        // 서비스이용
        csMapping.put("B2B 이용문의", "D002_INQ_005");        // 서비스이용
        csMapping.put("사업자 전환신청", "D002_INQ_005");       // 서비스이용
        csMapping.put("상품입점문의", "D002_INQ_006");         // 건의
        csMapping.put("반품/교환", "D002_INQ_002");           // 반품/교환
        CATEGORY_MAPPING.put("cs", csMapping);
    }
    
    /**
     * ASIS 카테고리를 TOBE 카테고리 코드로 변환
     * 
     * @param type ASIS 카테고리 타입 (notice, faq, cs)
     * @param name ASIS 카테고리명
     * @return TOBE 카테고리 코드
     */
    public String mapCategory(String type, String name) {
        if (type == null || name == null) {
            log.warn("카테고리 타입 또는 이름이 null입니다. 기본값 반환. type: {}, name: {}", type, name);
            return getDefaultCategory(type);
        }
        
        Map<String, String> typeMapping = CATEGORY_MAPPING.get(type.toLowerCase());
        if (typeMapping == null) {
            log.warn("알 수 없는 카테고리 타입: {}. 기본값 반환", type);
            return getDefaultCategory(type);
        }
        
        String categoryCode = typeMapping.get(name);
        if (categoryCode == null) {
            log.warn("매핑되지 않은 카테고리: type={}, name={}. 유사 카테고리 탐색 시도", type, name);
            
            // 유사 카테고리 찾기
            categoryCode = findSimilarCategory(typeMapping, name);
            
            if (categoryCode == null) {
                categoryCode = getDefaultCategoryForType(type);
                log.warn("유사 카테고리를 찾을 수 없습니다. 타입별 기본값 사용: {}", categoryCode);
            }
        }
        
        log.debug("카테고리 매핑 완료: {}:{} -> {}", type, name, categoryCode);
        return categoryCode;
    }
    
    /**
     * 유사한 카테고리 찾기
     */
    private String findSimilarCategory(Map<String, String> typeMapping, String name) {
        // 키워드 기반 매칭
        String lowerName = name.toLowerCase();
        
        for (Map.Entry<String, String> entry : typeMapping.entrySet()) {
            String key = entry.getKey().toLowerCase();
            if (lowerName.contains(key) || key.contains(lowerName)) {
                log.info("유사 카테고리 매핑: {} -> {}", name, entry.getKey());
                return entry.getValue();
            }
        }
        
        // 특정 키워드 매칭
        if (lowerName.contains("배송")) {
            return typeMapping.get("배송");
        }
        if (lowerName.contains("주문") || lowerName.contains("결제")) {
            return typeMapping.get("주문/결제");
        }
        if (lowerName.contains("반품") || lowerName.contains("교환")) {
            return typeMapping.get("반품/교환");
        }
        if (lowerName.contains("상품")) {
            return typeMapping.get("상품");
        }
        if (lowerName.contains("서비스")) {
            return typeMapping.get("서비스이용");
        }
        if (lowerName.contains("건의") || lowerName.contains("제안")) {
            return typeMapping.get("제안/건의");
        }
        
        return null;
    }
    
    /**
     * 타입별 기본 카테고리 코드 반환
     */
    private String getDefaultCategoryForType(String type) {
        if (type == null) {
            return "D002_INQ_999";
        }
        
        switch (type.toLowerCase()) {
            case "notice":
                return "D002_NTF_999";      // 기타 공지사항
            case "faq":
                return "D002_FAQ_004";      // 서비스이용
            case "cs":
                return "D002_INQ_999";      // 기타 1:1문의
            default:
                return "D002_INQ_999";      // 기본값
        }
    }
    
    /**
     * 기본 카테고리 코드 반환
     */
    private String getDefaultCategory(String type) {
        return getDefaultCategoryForType(type);
    }
    
    /**
     * 카테고리 시퀀스 ID로부터 TOBE 카테고리 코드 매핑
     * Mall VOC의 CATEGORY_SEQ를 사용하여 직접 매핑
     */
    public String mapCategoryBySeq(Long categorySeq, String type) {
        if (categorySeq == null) {
            return getDefaultCategory(type);
        }
        
        // CATEGORY_SEQ 기반 직접 매핑
        Map<Long, String> seqMapping = new HashMap<>();
        
        // Notice 매핑
        seqMapping.put(89L, "D002_NTF_999");  // B2B 몰
        seqMapping.put(87L, "D002_NTF_999");  // 덴올/할인마트
        seqMapping.put(88L, "D002_NTF_999");  // DDS 정기배송
        
        // FAQ 매핑
        seqMapping.put(24L, "D002_FAQ_004");  // 서비스이용
        seqMapping.put(23L, "D002_FAQ_003");  // 반품/교환
        seqMapping.put(25L, "D002_FAQ_004");  // 패키지 -> 서비스이용
        seqMapping.put(22L, "D002_FAQ_002");  // 주문/결제
        seqMapping.put(21L, "D002_FAQ_001");  // 배송
        seqMapping.put(78L, "D002_FAQ_006");  // 증빙서류
        
        // CS 매핑
        seqMapping.put(39L, "D002_INQ_005");  // 서비스이용
        seqMapping.put(40L, "D002_INQ_006");  // 제안/건의
        seqMapping.put(41L, "D002_INQ_999");  // 기타
        seqMapping.put(85L, "D002_INQ_999");  // 1:1 문의
        seqMapping.put(86L, "D002_INQ_006");  // 협력업체 입점 문의
        seqMapping.put(91L, "D002_INQ_005");  // 덴탈인포
        seqMapping.put(38L, "D002_INQ_004");  // 배송
        seqMapping.put(37L, "D002_INQ_003");  // 주문/결제
        seqMapping.put(92L, "D002_INQ_001");  // 커스터마이징PC 견적문의
        seqMapping.put(35L, "D002_INQ_001");  // 상품
        seqMapping.put(84L, "D002_INQ_005");  // Dental 장비 A/S 신청
        seqMapping.put(83L, "D002_INQ_005");  // 개원 상담신청
        seqMapping.put(82L, "D002_INQ_005");  // B2B 이용문의
        seqMapping.put(81L, "D002_INQ_005");  // 사업자 전환신청
        seqMapping.put(90L, "D002_INQ_006");  // 상품입점문의
        seqMapping.put(36L, "D002_INQ_002");  // 반품/교환
        
        String mappedCode = seqMapping.get(categorySeq);
        if (mappedCode != null) {
            log.debug("카테고리 SEQ 매핑: {} -> {}", categorySeq, mappedCode);
            return mappedCode;
        }
        
        log.warn("매핑되지 않은 카테고리 SEQ: {}. 타입별 기본값 사용", categorySeq);
        return getDefaultCategory(type);
    }
    
    /**
     * BBS_DB를 TOBE 카테고리 타입으로 변환
     */
    public String mapBbsDbToType(String bbsDb) {
        if (bbsDb == null) {
            return "INQ";
        }
        
        switch (bbsDb.toLowerCase()) {
            case "notice":
                return "NTF";
            case "faq":
                return "FAQ";
            case "cs":
                return "INQ";
            default:
                return "INQ";
        }
    }
}
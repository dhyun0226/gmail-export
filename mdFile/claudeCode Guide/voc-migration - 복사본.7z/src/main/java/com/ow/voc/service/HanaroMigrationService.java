package com.ow.voc.service;

import com.ow.voc.common.BaseMigrationService;
import com.ow.voc.dto.oracle.*;
import com.ow.voc.dto.mariadb.*;
import com.ow.voc.mapper.primary.HanaroMapper;
import com.ow.voc.mapper.secondary.TobeMapper;
import com.ow.voc.util.HanaroCategoryMapper;
import com.ow.voc.util.ConnectionMonitor;
import com.ow.voc.util.DatabaseRetryHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import javax.sql.DataSource;
import java.sql.SQLException;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;

/**
 * 하나로 VOC 데이터 마이그레이션 서비스
 * Oracle(DENJOB) -> MariaDB(OCC) 마이그레이션
 */
@Slf4j
@Service
public class HanaroMigrationService extends BaseMigrationService {

    @Autowired
    private HanaroMapper hanaroMapper;
    
    @Autowired
    private TobeMapper tobeMapper;
    
    @Autowired
    private HanaroCategoryMapper hanaroCategoryMapper;
    
    @Autowired
    private ConnectionMonitor connectionMonitor;
    
    @Autowired
    private DatabaseRetryHandler retryHandler;
    
    @Autowired
    @Qualifier("secondaryDataSource")
    private DataSource secondaryDataSource;

    /**
     * 전체 하나로 데이터 마이그레이션
     */
    @Transactional
    public Map<String, Object> migrateAllHanaroData() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            // 1. 게시판 정보 마이그레이션
            int boardInfoCount = migrateBoardInfo();
            result.put("boardInfoCount", boardInfoCount);
            
            // 2. 게시판 카테고리 마이그레이션
            int categoryCount = migrateBoardCategory();
            result.put("categoryCount", categoryCount);
            
            // 3. 게시판 게시물 마이그레이션
            int boardCount = migrateBoards();
            result.put("boardCount", boardCount);
            
            // 4. 게시판 파일 마이그레이션
            int fileCount = migrateBoardFiles();
            result.put("fileCount", fileCount);
            
            // 5. 게시판 댓글 마이그레이션
            int memoCount = migrateBoardMemos();
            result.put("memoCount", memoCount);
            
            // 6. 제품 시연요청 마이그레이션
            int inquiryCount = migrateInquiries();
            result.put("inquiryCount", inquiryCount);
            
            // 7. 제품 상담 마이그레이션
            int sangdamCount = migrateSangdam();
            result.put("sangdamCount", sangdamCount);

            // 통계 정보 추가
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            
            // 실패 및 중복 항목 정보 추가
            result.put("failedItems", getFailedItemsSummary());
            result.put("duplicateItems", getDuplicateItemsSummary());
            
            result.put("status", "SUCCESS");
            result.put("message", "하나로 VOC 데이터 마이그레이션 완료");
            
            // 실패 항목 로그 출력
            printFailedItemsLog();
            
            // 마이그레이션 리포트 저장
            saveReport("Hanaro", result);
            
        } catch (Exception e) {
            log.error("하나로 데이터 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            // 실패 시에도 리포트 저장
            saveReport("Hanaro", result);
            throw new RuntimeException("마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }

    /**
     * Hanaro 공지사항만 마이그레이션 (DB 페이징 최적화 + 재시도 로직)
     */
    public Map<String, Object> migrateHanaroNotices() {
        log.info("Hanaro 공지사항 마이그레이션 시작 (DB 페이징 처리)");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            // 마이그레이션 시작 시 초기 상태 체크
            connectionMonitor.logConnectionStatus(secondaryDataSource, "MIGRATION_START", "Hanaro 공지사항 마이그레이션");
            connectionMonitor.logMemoryUsage("MIGRATION_START");
            
            // 전체 NOTI 타입 게시물 건수 확인
            int totalNotices = hanaroMapper.countBoardByDbType("NOTI");
            totalCount.set(totalNotices);
            log.info("NOTI 타입 총 게시물 {} 건", totalNotices);
            
            if (totalNotices == 0) {
                result.put("migratedCount", 0);
                result.put("totalCount", 0);
                result.put("status", "SUCCESS");
                result.put("message", "마이그레이션할 공지사항이 없습니다.");
                return result;
            }
            
            int migrationCount = 0;
            final int PAGE_SIZE = 100; // DB 페이징 크기
            final int BATCH_SIZE = 50;  // 처리 배치 크기
            
            // DB 페이징으로 처리 (캐시 제거로 안정성 확보)
            for (int offset = 0; offset < totalNotices; offset += PAGE_SIZE) {
                // DB에서 페이징 단위로 조회
                List<HanaroBoard> noticeBoards = hanaroMapper.selectBoardListByDbTypeWithPaging("NOTI", offset, PAGE_SIZE);
                log.info("DB 페이징 처리: {}~{} / {} 건 조회", offset + 1, Math.min(offset + PAGE_SIZE, totalNotices), totalNotices);
                
                // 배치 단위로 처리
                List<TobeNtfyM> noticeBatch = new ArrayList<>();
                
                for (int i = 0; i < noticeBoards.size(); i++) {
                    HanaroBoard board = noticeBoards.get(i);
                    processedCount.incrementAndGet();
                    
                    try {
                        // 매번 DB에서 boardInfo 조회 (캐시 제거)
                        HanaroBoardInfo boardInfo = hanaroMapper.selectBoardInfo(board.getBoardCode());
                        if (boardInfo == null) {
                            boardInfo = new HanaroBoardInfo();
                            boardInfo.setBoardCode(board.getBoardCode());
                            boardInfo.setBoardNm(board.getBoardCode());
                        }
                        
                        TobeNtfyM ntfy = convertBoardToNtfy(board, boardInfo);
                        if (ntfy.getSvcCtgCd() != null) {
                            noticeBatch.add(ntfy);
                        }
                        
                        // 배치가 꽉 차면 DB에 저장
                        if (noticeBatch.size() >= BATCH_SIZE || i == noticeBoards.size() - 1) {
                            // 배치 INSERT로 성능 개선 및 트랜잭션 분할
                            migrationCount += processBatchWithRetry(noticeBatch, migrationCount);
                            noticeBatch.clear();
                            
                            // 진행상황 출력 및 상태 모니터링
                            if (migrationCount % 200 == 0) {
                                log.info("공지사항 마이그레이션 진행: {}/{} ({}%)", 
                                    processedCount.get(), totalCount.get(), 
                                    String.format("%.2f", (processedCount.get() * 100.0 / totalCount.get())));
                                
                                // 주기적인 커넥션 상태 스냅샷
                                connectionMonitor.captureSnapshot(secondaryDataSource, 
                                    "PROGRESS_" + migrationCount, (int) processedCount.get(), (int) totalCount.get());
                            }
                        }
                        
                    } catch (Exception e) {
                        failCount.incrementAndGet();
                        String title = board.getTitle() != null ? board.getTitle() : "No Title";
                        log.error("공지사항 마이그레이션 실패 - BoardNo: {}, Title: {}", board.getBoardSeq(), title, e);
                        
                        // 실패 시 상세한 커넥션 상태 로깅
                        if (e instanceof SQLException) {
                            connectionMonitor.logSQLException((SQLException) e, 
                                "MIGRATION_FAIL_BOARD_" + board.getBoardSeq());
                        }
                        connectionMonitor.postExecutionCheck(secondaryDataSource, 
                            "PROCESS_BOARD_" + board.getBoardSeq(), false, e);
                        
                        addFailedItem("Notice", board.getBoardSeq(), title, e.getMessage());
                    }
                }
                
                // 페이지 처리 완료 후 잠시 대기 (DB 부하 조절)
                try {
                    Thread.sleep(100); // 100ms 대기
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
                
                // 중간 진행상황 저장 (대용량 처리 시)
                if (offset > 0 && offset % 1000 == 0) {
                    Map<String, Object> progressReport = new HashMap<>();
                    progressReport.put("progress", processedCount.get());
                    progressReport.put("total", totalCount.get());
                    progressReport.put("migrated", migrationCount);
                    progressReport.put("failed", failCount.get());
                    saveReport("Hanaro_Notice_Progress_" + offset, progressReport);
                    
                    // 1000건마다 전체 상태 점검
                    log.info("🔍 === 중간 점검 ({}건 처리 완료) ===", offset);
                    connectionMonitor.captureSnapshot(secondaryDataSource, 
                        "CHECKPOINT_" + offset, (int) processedCount.get(), (int) totalCount.get());
                    
                    // 커넥션 유효성 재검증
                    if (!connectionMonitor.validateConnection(secondaryDataSource, "CHECKPOINT_" + offset)) {
                        log.warn("⚠️ 커넥션 유효성 검사 실패 - 잠시 대기 후 계속...");
                        Thread.sleep(5000); // 5초 대기
                    }
                }
            }
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro 공지사항 마이그레이션 완료");
            
            saveReport("Hanaro_Notice", result);
            log.info("Hanaro 공지사항 {} 건 마이그레이션 완료 (성공: {}, 실패: {})", 
                migrationCount, successCount.get(), failCount.get());
            
            // 마이그레이션 완료 후 최종 상태 체크
            connectionMonitor.logConnectionStatus(secondaryDataSource, "MIGRATION_COMPLETE", 
                "Hanaro 공지사항 마이그레이션 완료");
            connectionMonitor.logMemoryUsage("MIGRATION_COMPLETE");
            
        } catch (Exception e) {
            log.error("Hanaro 공지사항 마이그레이션 실패", e);
            
            // 마이그레이션 실패 시 상세 분석
            if (e instanceof SQLException) {
                connectionMonitor.logSQLException((SQLException) e, "MIGRATION_FATAL_ERROR");
            }
            connectionMonitor.postExecutionCheck(secondaryDataSource, "MIGRATION_COMPLETE", false, e);
            
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            result.put("processedCount", processedCount.get());
            result.put("failedAt", processedCount.get());
            saveReport("Hanaro_Notice", result);
            throw new RuntimeException("공지사항 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * 배치 처리 with 재시도 로직 (트랜잭션 분할)
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private int processBatchWithRetry(List<TobeNtfyM> noticeBatch, int currentCount) {
        if (noticeBatch.isEmpty()) {
            return 0;
        }
        
        connectionMonitor.preExecutionCheck(secondaryDataSource, "BATCH_INSERT", noticeBatch.size());
        
        return retryHandler.executeWithRetry(
            "BATCH_INSERT_" + currentCount + "_SIZE_" + noticeBatch.size(),
            () -> {
                int batchSuccessCount = 0;
                
                // 배치 크기가 크면 더 작은 단위로 분할
                int subBatchSize = noticeBatch.size() > 20 ? 10 : noticeBatch.size();
                
                for (int i = 0; i < noticeBatch.size(); i += subBatchSize) {
                    int endIndex = Math.min(i + subBatchSize, noticeBatch.size());
                    List<TobeNtfyM> subBatch = noticeBatch.subList(i, endIndex);
                    
                    try {
                        // 서브배치 전체 INSERT 시도
                        for (TobeNtfyM notice : subBatch) {
                            tobeMapper.insertNtfyM(notice);
                            successCount.incrementAndGet();
                            batchSuccessCount++;
                        }
                        
                        log.debug("서브배치 성공: {}/{} 건", subBatch.size(), noticeBatch.size());
                        
                    } catch (Exception e) {
                        log.error("서브배치 실패 (크기: {}): {}", subBatch.size(), e.getMessage());
                        
                        // 중복 INSERT 방지: 서브배치 실패 시 개별 처리로 fallback
                        // 단, successCount는 이미 증가했으므로 롤백하고 개별 처리
                        int rollbackCount = 0;
                        for (TobeNtfyM notice : subBatch) {
                            if (batchSuccessCount > rollbackCount) {
                                successCount.decrementAndGet();
                                batchSuccessCount--;
                                rollbackCount++;
                            }
                        }
                        
                        // 개별 재처리
                        batchSuccessCount += processIndividuallyWithRetry(subBatch);
                    }
                }
                
                connectionMonitor.postExecutionCheck(secondaryDataSource, "BATCH_INSERT", true, null);
                return batchSuccessCount;
            }
        );
    }
    
    /**
     * 개별 INSERT with 재시도 (최후의 fallback)
     */
    private int processIndividuallyWithRetry(List<TobeNtfyM> notices) {
        int individualSuccessCount = 0;
        
        for (TobeNtfyM notice : notices) {
            try {
                retryHandler.executeWithRetry(
                    "INDIVIDUAL_INSERT_" + (notice.getNtfyTtl() != null ? notice.getNtfyTtl().substring(0, Math.min(20, notice.getNtfyTtl().length())) : "NO_TITLE"),
                    () -> {
                        tobeMapper.insertNtfyM(notice);
                        return null;
                    }
                );
                successCount.incrementAndGet();
                individualSuccessCount++;
                
            } catch (Exception e) {
                failCount.incrementAndGet();
                String title = notice.getNtfyTtl() != null ? notice.getNtfyTtl() : "No Title";
                log.error("개별 INSERT 최종 실패 - Title: {}", title, e);
                
                if (e instanceof SQLException) {
                    connectionMonitor.logSQLException((SQLException) e, "INDIVIDUAL_INSERT_FAIL");
                }
                
                addFailedItem("Notice", 0L, title, e.getMessage());
            }
        }
        
        return individualSuccessCount;
    }
    
    /**
     * HTML 태그 제거 및 제목 길이 제한
     */
    private String cleanAndTruncateTitle(String title, int maxLength) {
        if (title == null) {
            return null;
        }
        
        // HTML 태그 제거
        String cleaned = title.replaceAll("<[^>]*>", "")  // 모든 HTML 태그 제거
                              .replaceAll("&nbsp;", " ")
                              .replaceAll("&amp;", "&")
                              .replaceAll("&lt;", "<")
                              .replaceAll("&gt;", ">")
                              .replaceAll("&quot;", "\"")
                              .trim();
        
        // 연속된 공백 정리
        cleaned = cleaned.replaceAll("\\s+", " ");
        
        // 길이 제한
        if (cleaned.length() > maxLength) {
            cleaned = cleaned.substring(0, maxLength - 3) + "...";
        }
        
        return cleaned;
    }
    
    /**
     * Hanaro FAQ만 마이그레이션 (DB 페이징 최적화)
     */
    @Transactional
    public Map<String, Object> migrateHanaroFaqs() {
        log.info("Hanaro FAQ 마이그레이션 시작 (DB 페이징 처리)");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            // 전체 FAQ 타입 게시물 건수 확인
            int totalFaqs = hanaroMapper.countBoardByDbType("FAQ");
            totalCount.set(totalFaqs);
            log.info("FAQ 타입 총 게시물 {} 건", totalFaqs);
            
            if (totalFaqs == 0) {
                result.put("migratedCount", 0);
                result.put("totalCount", 0);
                result.put("status", "SUCCESS");
                result.put("message", "마이그레이션할 FAQ가 없습니다.");
                return result;
            }
            
            int migrationCount = 0;
            final int PAGE_SIZE = 100; // DB 페이징 크기
            final int BATCH_SIZE = 50;  // 처리 배치 크기
            
            // DB 페이징으로 처리 (캐시 제거로 안정성 확보)
            for (int offset = 0; offset < totalFaqs; offset += PAGE_SIZE) {
                // DB에서 페이징 단위로 조회
                List<HanaroBoard> faqBoards = hanaroMapper.selectBoardListByDbTypeWithPaging("FAQ", offset, PAGE_SIZE);
                log.info("DB 페이징 처리: {}~{} / {} 건 조회", offset + 1, Math.min(offset + PAGE_SIZE, totalFaqs), totalFaqs);
                
                // 배치 단위로 처리
                List<TobeFaqM> faqBatch = new ArrayList<>();
                
                for (int i = 0; i < faqBoards.size(); i++) {
                    HanaroBoard board = faqBoards.get(i);
                    processedCount.incrementAndGet();
                    
                    try {
                        // 매번 DB에서 boardInfo 조회 (캐시 제거)
                        HanaroBoardInfo boardInfo = hanaroMapper.selectBoardInfo(board.getBoardCode());
                        if (boardInfo == null) {
                            boardInfo = new HanaroBoardInfo();
                            boardInfo.setBoardCode(board.getBoardCode());
                            boardInfo.setBoardNm(board.getBoardCode());
                        }
                        
                        TobeFaqM faq = convertBoardToFaq(board, boardInfo);
                        if (faq.getSvcCtgCd() != null) {
                            faqBatch.add(faq);
                        }
                        
                        // 배치가 꽉 차면 DB에 저장
                        if (faqBatch.size() >= BATCH_SIZE || i == faqBoards.size() - 1) {
                            for (TobeFaqM f : faqBatch) {
                                tobeMapper.insertFaqM(f);
                                successCount.incrementAndGet();
                                migrationCount++;
                            }
                            faqBatch.clear();
                            
                            // 진행상황 출력
                            if (migrationCount % 200 == 0) {
                                log.info("FAQ 마이그레이션 진행: {}/{} ({}%)", 
                                    processedCount.get(), totalCount.get(), 
                                    String.format("%.2f", (processedCount.get() * 100.0 / totalCount.get())));
                            }
                        }
                        
                    } catch (Exception e) {
                        failCount.incrementAndGet();
                        String title = board.getTitle() != null ? board.getTitle() : "No Title";
                        log.error("FAQ 마이그레이션 실패 - BoardNo: {}, Title: {}", board.getBoardSeq(), title, e);
                        addFailedItem("FAQ", board.getBoardSeq(), title, e.getMessage());
                    }
                }
                
                // 페이지 처리 완료 후 잠시 대기 (DB 부하 조절)
                try {
                    Thread.sleep(100); // 100ms 대기
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
                
                // 중간 진행상황 저장 (대용량 처리 시)
                if (offset > 0 && offset % 1000 == 0) {
                    Map<String, Object> progressReport = new HashMap<>();
                    progressReport.put("progress", processedCount.get());
                    progressReport.put("total", totalCount.get());
                    progressReport.put("migrated", migrationCount);
                    progressReport.put("failed", failCount.get());
                    saveReport("Hanaro_FAQ_Progress_" + offset, progressReport);
                }
            }
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro FAQ 마이그레이션 완료");
            
            saveReport("Hanaro_FAQ", result);
            log.info("Hanaro FAQ {} 건 마이그레이션 완료 (성공: {}, 실패: {})", 
                migrationCount, successCount.get(), failCount.get());
            
        } catch (Exception e) {
            log.error("Hanaro FAQ 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            result.put("processedCount", processedCount.get());
            result.put("failedAt", processedCount.get());
            saveReport("Hanaro_FAQ", result);
            throw new RuntimeException("FAQ 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * Hanaro QNA만 마이그레이션 (QNA, STIP, ITIP 포함)
     */
    @Transactional
    public Map<String, Object> migrateHanaroQnas() {
        log.info("Hanaro QNA 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            // QNA, STIP, ITIP 타입의 게시물 카운트 먼저 확인
            List<String> qnaTypes = Arrays.asList("QNA", "STIP", "ITIP");
            int totalQnaCount = 0;
            for (String type : qnaTypes) {
                int count = hanaroMapper.countBoardByDbType(type);
                totalQnaCount += count;
                log.info("{} 타입 게시물: {} 건", type, count);
            }
            totalCount.set(totalQnaCount);
            log.info("전체 QNA 타입 게시물: {} 건", totalQnaCount);
            
            int migrationCount = 0;
            int pageSize = 1000; // 한 번에 처리할 게시물 수
            int offset = 0;
            
            // 페이징 처리로 조회 및 마이그레이션 (캐시 제거로 안정성 확보)
            while (offset < totalQnaCount) {
                log.info("QNA 마이그레이션 페이지 처리: {}-{}/{}", offset, Math.min(offset + pageSize, totalQnaCount), totalQnaCount);
                
                // 페이징으로 조회 (실제로는 HanaroMapper에 페이징 메서드 추가 필요)
                List<HanaroBoard> qnaBoards = hanaroMapper.selectBoardListByDbTypes(qnaTypes);
                
                // 배치 단위로 처리 (트랜잭션 분리를 위해)
                int batchSize = 100;
                List<TobeQnaM> qnaBatch = new ArrayList<>();
                List<TobeQnaAnsD> answerBatch = new ArrayList<>();
                
                for (int i = 0; i < qnaBoards.size(); i++) {
                    HanaroBoard board = qnaBoards.get(i);
                    processedCount.incrementAndGet();
                    
                    try {
                        // 매번 DB에서 boardInfo 조회 (캐시 제거)
                        HanaroBoardInfo boardInfo = hanaroMapper.selectBoardInfo(board.getBoardCode());
                        if (boardInfo == null) {
                            boardInfo = new HanaroBoardInfo();
                            boardInfo.setBoardCode(board.getBoardCode());
                            boardInfo.setBoardNm(board.getBoardCode());
                        }
                        
                        TobeQnaM qna = convertBoardToQna(board, boardInfo);
                        if (qna.getSvcCtgCd() != null) {
                            qnaBatch.add(qna);
                            
                            // QNA 답변이 있으면 답변도 배치에 추가
                            if (board.getQna() != null && !board.getQna().trim().isEmpty()) {
                                TobeQnaAnsD answer = new TobeQnaAnsD();
                                answer.setQnaNo(qna.getQnaNo());
                                answer.setQnaAnsDtlNo((short) 1);
                                answer.setQnaAnsDtm(board.getModiDate());
                                answer.setUpQnaAnsDtlNo(null);
                                answer.setAnsrMemId(null);
                                answer.setAnsrCprnCd("OW");
                                answer.setAnsrDeptCd("IT");
                                answer.setAnsrEmpNo("MIGRATION");
                                answer.setQnaAnsCn(board.getQna());
                                answer.setDelYn("N");
                                answer.setFileId(null);
                                answer.setProcPrgmId("HANARO_MIGRATION");
                                answer.setRgstProcrId("MIGRATION");
                                answer.setRgstProcDtm(board.getModiDate());
                                answer.setUpdtProcrId("MIGRATION");
                                answer.setUpdtProcDtm(board.getModiDate());
                                answerBatch.add(answer);
                            }
                        }
                        
                        // 배치가 꽉 차면 DB에 저장
                        if (qnaBatch.size() >= batchSize) {
                            // 배치 인서트
                            for (TobeQnaM q : qnaBatch) {
                                tobeMapper.insertQnaM(q);
                                successCount.incrementAndGet();
                                migrationCount++;
                            }
                            for (TobeQnaAnsD a : answerBatch) {
                                tobeMapper.insertQnaAnsD(a);
                            }
                            
                            qnaBatch.clear();
                            answerBatch.clear();
                            
                            // 메모리 관리 및 진행상황 출력
                            if (processedCount.get() % 1000 == 0) {
                                log.info("QNA 마이그레이션 진행: {}/{} ({}%)", 
                                    processedCount.get(), totalCount.get(), 
                                    String.format("%.2f", (processedCount.get() * 100.0 / totalCount.get())));
                                    
                                // 가비지 컬렉션 힌트
                                System.gc();
                            }
                        }
                        
                    } catch (Exception e) {
                        failCount.incrementAndGet();
                        String title = board.getTitle() != null ? board.getTitle() : "No Title";
                        log.error("QNA 마이그레이션 실패 - BoardNo: {}, Title: {}", board.getBoardSeq(), title, e);
                        addFailedItem("QNA", board.getBoardSeq(), title, e.getMessage());
                    }
                }
                
                // 남은 배치 처리
                if (!qnaBatch.isEmpty()) {
                    for (TobeQnaM q : qnaBatch) {
                        tobeMapper.insertQnaM(q);
                        successCount.incrementAndGet();
                        migrationCount++;
                    }
                    for (TobeQnaAnsD a : answerBatch) {
                        tobeMapper.insertQnaAnsD(a);
                    }
                }
                
                offset += pageSize;
                
                // 너무 오래 걸리는 경우를 대비한 중간 진행상황 저장
                if (offset % 10000 == 0) {
                    Map<String, Object> progressReport = new HashMap<>();
                    progressReport.put("progress", processedCount.get());
                    progressReport.put("total", totalCount.get());
                    progressReport.put("migrated", migrationCount);
                    progressReport.put("failed", failCount.get());
                    saveReport("Hanaro_QNA_Progress_" + offset, progressReport);
                }
            }
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro QNA 마이그레이션 완료");
            
            saveReport("Hanaro_QNA", result);
            log.info("Hanaro QNA {} 건 마이그레이션 완료", migrationCount);
            
        } catch (Exception e) {
            log.error("Hanaro QNA 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            result.put("processedCount", processedCount.get());
            result.put("failedAt", processedCount.get());
            saveReport("Hanaro_QNA", result);
            throw new RuntimeException("QNA 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * Hanaro 제품시연요청만 마이그레이션
     */
    @Transactional
    public Map<String, Object> migrateHanaroInquiries() {
        log.info("Hanaro 제품시연요청 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            List<HanaroInquiry> inquiries = hanaroMapper.selectInquiryList();
            totalCount.addAndGet(inquiries.size());
            
            int migrationCount = 0;
            for (HanaroInquiry inquiry : inquiries) {
                processedCount.incrementAndGet();
                try {
                    TobeQnaM qna = convertInquiryToQna(inquiry);
                    tobeMapper.insertQnaM(qna);
                    successCount.incrementAndGet();
                    migrationCount++;
                } catch (Exception e) {
                    failCount.incrementAndGet();
                    String title = inquiry.getJepum() != null ? inquiry.getJepum() : "No Product";
                    log.error("제품시연요청 마이그레이션 실패 - Idx: {}, Product: {}", inquiry.getInqSeq(), title, e);
                    addFailedItem("Inquiry", inquiry.getInqSeq(), title, e.getMessage());
                }
            }
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro 제품시연요청 마이그레이션 완료");
            
            saveReport("Hanaro_Inquiry", result);
            log.info("Hanaro 제품시연요청 {} 건 마이그레이션 완료", migrationCount);
            
        } catch (Exception e) {
            log.error("Hanaro 제품시연요청 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            saveReport("Hanaro_Inquiry", result);
            throw new RuntimeException("제품시연요청 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * Hanaro 제품상담만 마이그레이션
     */
    @Transactional
    public Map<String, Object> migrateHanaroSangdam() {
        log.info("Hanaro 제품상담 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            List<HanaroSangdam> sangdamList = hanaroMapper.selectSangdamList();
            totalCount.addAndGet(sangdamList.size());
            
            int migrationCount = 0;
            for (HanaroSangdam sangdam : sangdamList) {
                processedCount.incrementAndGet();
                try {
                    TobeQnaM qna = convertSangdamToQna(sangdam);
                    tobeMapper.insertQnaM(qna);
                    successCount.incrementAndGet();
                    
                    // 답변이 있으면 답변도 마이그레이션
                    if (sangdam.getAnswer() != null && !sangdam.getAnswer().trim().isEmpty()) {
                        try {
                            TobeQnaAnsD answer = new TobeQnaAnsD();
                            answer.setQnaNo(qna.getQnaNo());
                            answer.setQnaAnsDtlNo((short) 1);
                            answer.setQnaAnsDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                            answer.setUpQnaAnsDtlNo(null);
                            answer.setAnsrMemId(null);
                            answer.setAnsrCprnCd("OW");
                            answer.setAnsrDeptCd("IT");
                            answer.setAnsrEmpNo(sangdam.getUserid() != null ? sangdam.getUserid() : "MIGRATION");
                            answer.setQnaAnsCn(sangdam.getAnswer());
                            answer.setDelYn("N");
                            answer.setFileId(null);
                            answer.setProcPrgmId("HANARO_MIGRATION");
                            answer.setRgstProcrId("MIGRATION");
                            answer.setRgstProcDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                            answer.setUpdtProcrId("MIGRATION");
                            answer.setUpdtProcDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                            tobeMapper.insertQnaAnsD(answer);
                        } catch (Exception e) {
                            log.error("상담 답변 마이그레이션 실패 - Idx: {}", sangdam.getSangSeq(), e);
                        }
                    }
                    migrationCount++;
                } catch (Exception e) {
                    failCount.incrementAndGet();
                    String title = sangdam.getJepum() != null ? sangdam.getJepum() : "No Product";
                    log.error("제품상담 마이그레이션 실패 - Idx: {}, Product: {}", sangdam.getSangSeq(), title, e);
                    addFailedItem("Sangdam", sangdam.getSangSeq(), title, e.getMessage());
                }
            }
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro 제품상담 마이그레이션 완료");
            
            saveReport("Hanaro_Sangdam", result);
            log.info("Hanaro 제품상담 {} 건 마이그레이션 완료", migrationCount);
            
        } catch (Exception e) {
            log.error("Hanaro 제품상담 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            saveReport("Hanaro_Sangdam", result);
            throw new RuntimeException("제품상담 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * 게시판 정보 마이그레이션
     */
    private int migrateBoardInfo() {
        log.info("게시판 정보 마이그레이션 시작");
        List<HanaroBoardInfo> boardInfoList = hanaroMapper.selectBoardInfoList();
        totalCount.addAndGet(boardInfoList.size());
        
        int count = 0;
        for (HanaroBoardInfo boardInfo : boardInfoList) {
            processedCount.incrementAndGet();
            try {
                // TB_HANARO_BOARD_INFO -> TB_NTFY_M (공지사항으로 변환)
                if ("Y".equals(boardInfo.getUseYn())) {
                    TobeNtfyM ntfy = convertBoardInfoToNtfy(boardInfo);
                    tobeMapper.insertNtfyM(ntfy);
                    successCount.incrementAndGet();
                    count++;
                }
            } catch (Exception e) {
                failCount.incrementAndGet();
                log.error("게시판 정보 마이그레이션 실패 - BoardCode: {}", boardInfo.getBoardCode(), e);
                addFailedItem("BoardInfo", boardInfo.getBoardCode(), boardInfo.getBoardNm(), e.getMessage());
            }
        }
        
        log.info("게시판 정보 {} 건 마이그레이션 완료", count);
        return count;
    }

    /**
     * 게시판 카테고리 마이그레이션
     */
    private int migrateBoardCategory() {
        log.info("게시판 카테고리 마이그레이션 시작");
        // 모든 게시판의 카테고리를 FAQ 카테고리로 변환
        List<HanaroBoardInfo> boardList = hanaroMapper.selectBoardInfoList();
        
        int count = 0;
        for (HanaroBoardInfo board : boardList) {
            try {
                List<HanaroBoardCategory> categories = hanaroMapper.selectCategoryList(board.getBoardCode());
                totalCount.addAndGet(categories.size());
                
                for (HanaroBoardCategory category : categories) {
                    processedCount.incrementAndGet();
                    if ("Y".equals(category.getViewYn())) {
                        // 카테고리는 FAQ의 카테고리로 활용
                        successCount.incrementAndGet();
                        count++;
                    }
                }
            } catch (Exception e) {
                failCount.incrementAndGet();
                log.error("카테고리 마이그레이션 실패 - BoardCode: {}", board.getBoardCode(), e);
                addFailedItem("BoardCategory", board.getBoardCode(), board.getBoardNm(), e.getMessage());
            }
        }
        
        log.info("게시판 카테고리 {} 건 처리 완료", count);
        return count;
    }

    /**
     * 게시판 게시물 마이그레이션 (전체 마이그레이션용)
     */
    private int migrateBoards() {
        log.info("게시판 게시물 마이그레이션 시작");
        
        // 마이그레이션 대상 DB 타입들만 조회
        List<String> migrationTargetTypes = Arrays.asList("NOTI", "FAQ", "QNA", "STIP", "ITIP");
        List<HanaroBoard> allBoards = hanaroMapper.selectBoardListByDbTypes(migrationTargetTypes);
        totalCount.addAndGet(allBoards.size());
        log.info("마이그레이션 대상 게시물 {} 건 조회", allBoards.size());
        
        int migrationCount = 0;
        int batchSize = 100;
        
        // 배치 처리 (캐시 제거로 안정성 확보)
        for (int i = 0; i < allBoards.size(); i += batchSize) {
            int endIndex = Math.min(i + batchSize, allBoards.size());
            List<HanaroBoard> batch = allBoards.subList(i, endIndex);
            
            for (HanaroBoard board : batch) {
                processedCount.incrementAndGet();
                try {
                    // 매번 DB에서 boardInfo 조회 (캐시 제거)
                    HanaroBoardInfo boardInfo = hanaroMapper.selectBoardInfo(board.getBoardCode());
                    if (boardInfo == null) {
                        boardInfo = new HanaroBoardInfo();
                        boardInfo.setBoardCode(board.getBoardCode());
                        boardInfo.setBoardNm(board.getBoardCode());
                    }
                    
                    // DB 타입 추출
                    String dbType = extractDbTypeFromBoardCode(board.getBoardCode(), "QNA");
                    
                    // 게시판 유형에 따라 다르게 변환
                    if ("FAQ".equals(dbType)) {
                        // FAQ로 변환
                        TobeFaqM faq = convertBoardToFaq(board, boardInfo);
                        if (faq.getSvcCtgCd() != null) {
                            tobeMapper.insertFaqM(faq);
                            successCount.incrementAndGet();
                            migrationCount++;
                        }
                    } else if ("NOTI".equals(dbType)) {
                        // 공지사항으로 변환
                        TobeNtfyM ntfy = convertBoardToNtfy(board, boardInfo);
                        if (ntfy.getSvcCtgCd() != null) {
                            tobeMapper.insertNtfyM(ntfy);
                            successCount.incrementAndGet();
                            migrationCount++;
                        }
                    } else if ("QNA".equals(dbType) || "STIP".equals(dbType) || "ITIP".equals(dbType)) {
                        // QNA로 변환 (STIP, ITIP도 QNA로 처리)
                        TobeQnaM qna = convertBoardToQna(board, boardInfo);
                        if (qna.getSvcCtgCd() != null) {
                            tobeMapper.insertQnaM(qna);
                            successCount.incrementAndGet();
                            migrationCount++;
                            
                            // QNA 답변이 있으면 답변도 마이그레이션
                            if (board.getQna() != null && !board.getQna().trim().isEmpty()) {
                                TobeQnaAnsD answer = new TobeQnaAnsD();
                                answer.setQnaNo(qna.getQnaNo());
                                answer.setQnaAnsDtlNo((short) 1);
                                answer.setQnaAnsDtm(board.getModiDate());
                                answer.setUpQnaAnsDtlNo(null);
                                answer.setAnsrMemId(null);
                                answer.setAnsrCprnCd("OW");
                                answer.setAnsrDeptCd("IT");
                                answer.setAnsrEmpNo("MIGRATION");
                                answer.setQnaAnsCn(board.getQna());
                                answer.setDelYn("N");
                                answer.setFileId(null);
                                answer.setProcPrgmId("HANARO_MIGRATION");
                                answer.setRgstProcrId("MIGRATION");
                                answer.setRgstProcDtm(board.getModiDate());
                                answer.setUpdtProcrId("MIGRATION");
                                answer.setUpdtProcDtm(board.getModiDate());
                                tobeMapper.insertQnaAnsD(answer);
                            }
                            
                            // 댓글(메모)도 답변으로 마이그레이션
                            List<HanaroBoardMemo> memos = hanaroMapper.selectMemoList(board.getBoardSeq());
                            short answerSeq = (short) (board.getQna() != null && !board.getQna().trim().isEmpty() ? 2 : 1);
                            for (HanaroBoardMemo memo : memos) {
                                try {
                                    TobeQnaAnsD memoAnswer = convertMemoToQnaAnsD(memo, qna.getQnaNo());
                                    memoAnswer.setQnaAnsDtlNo(answerSeq++);
                                    tobeMapper.insertQnaAnsD(memoAnswer);
                                } catch (Exception e) {
                                    log.error("댓글 마이그레이션 실패 - MemoNo: {}, BoardNo: {}", memo.getMemoSeq(), board.getBoardSeq(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    failCount.incrementAndGet();
                    String title = board.getTitle() != null ? board.getTitle() : "No Title";
                    log.error("게시물 마이그레이션 실패 - BoardNo: {}, Title: {}", board.getBoardSeq(), title, e);
                    addFailedItem("Board", board.getBoardSeq(), title, e.getMessage());
                }
            }
            
            if (processedCount.get() % 1000 == 0) {
                log.info("게시판 게시물 마이그레이션 진행: {}/{}", processedCount.get(), totalCount.get());
            }
        }
        
        log.info("게시판 게시물 {} 건 마이그레이션 완료", migrationCount);
        return migrationCount;
    }

    /**
     * 게시판 파일 마이그레이션
     */
    private int migrateBoardFiles() {
        log.info("게시판 파일 마이그레이션 시작");
        // 파일 정보는 별도 파일 서비스로 처리 필요
        // 여기서는 메타데이터만 기록
        return 0;
    }

    /**
     * 게시판 댓글 마이그레이션 (마이그레이션 대상 게시물의 댓글만)
     * 주의: 이 메서드는 주로 개별 댓글 마이그레이션에 사용됩니다.
     * QNA 마이그레이션 시 댓글은 자동으로 처리되므로 별도 실행이 필요하지 않습니다.
     */
    private int migrateBoardMemos() {
        log.info("게시판 댓글 마이그레이션 시작 - 단독 실행 모드");
        
        // QNA, STIP, ITIP 타입의 게시물만 조회
        List<String> qnaTypes = Arrays.asList("QNA", "STIP", "ITIP");
        List<HanaroBoard> qnaBoards = hanaroMapper.selectBoardListByDbTypes(qnaTypes);
        log.info("QNA 타입 게시물 {} 건 조회", qnaBoards.size());
        
        int totalMemoCount = 0;
        int batchSize = 100;
        
        for (int i = 0; i < qnaBoards.size(); i += batchSize) {
            int endIndex = Math.min(i + batchSize, qnaBoards.size());
            List<HanaroBoard> batch = qnaBoards.subList(i, endIndex);
            
            for (HanaroBoard board : batch) {
                try {
                    List<HanaroBoardMemo> memos = hanaroMapper.selectMemoList(board.getBoardSeq());
                    totalCount.addAndGet(memos.size());
                    
                    // 댓글을 QNA 답변으로 변환
                    for (HanaroBoardMemo memo : memos) {
                        processedCount.incrementAndGet();
                        try {
                            // 실제로는 마이그레이션된 QNA_NO를 찾아야 하지만,
                            // 여기서는 간단히 board.getBoardSeq()를 사용
                            Long qnaNo = board.getBoardSeq();
                            
                            TobeQnaAnsD answer = convertMemoToQnaAnsD(memo, qnaNo);
                            tobeMapper.insertQnaAnsD(answer);
                            successCount.incrementAndGet();
                            totalMemoCount++;
                        } catch (Exception e) {
                            failCount.incrementAndGet();
                            log.error("댓글 마이그레이션 실패 - MemoNo: {}, BoardNo: {}", memo.getMemoSeq(), board.getBoardSeq(), e);
                            addFailedItem("BoardMemo", memo.getMemoSeq(), "댓글", e.getMessage());
                        }
                    }
                } catch (Exception e) {
                    log.error("게시물 댓글 처리 실패 - BoardSeq: {}", board.getBoardSeq(), e);
                }
            }
            
            if (processedCount.get() % 1000 == 0) {
                log.info("댓글 마이그레이션 진행: {}/{}", processedCount.get(), totalCount.get());
            }
        }
        
        log.info("게시판 댓글 {} 건 마이그레이션 완료", totalMemoCount);
        return totalMemoCount;
    }
    
    /**
     * Hanaro 댓글만 마이그레이션
     */
    @Transactional
    public Map<String, Object> migrateHanaroMemos() {
        log.info("Hanaro 댓글 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            resetStatistics();
            
            int migrationCount = migrateBoardMemos();
            
            result.put("migratedCount", migrationCount);
            result.put("totalCount", totalCount.get());
            result.put("processedCount", processedCount.get());
            result.put("successCount", successCount.get());
            result.put("failCount", failCount.get());
            result.put("failedItems", getFailedItemsSummary());
            result.put("status", "SUCCESS");
            result.put("message", "Hanaro 댓글 마이그레이션 완료");
            
            saveReport("Hanaro_Memo", result);
            log.info("Hanaro 댓글 {} 건 마이그레이션 완료", migrationCount);
            
        } catch (Exception e) {
            log.error("Hanaro 댓글 마이그레이션 실패", e);
            result.put("status", "FAILED");
            result.put("message", e.getMessage());
            saveReport("Hanaro_Memo", result);
            throw new RuntimeException("댓글 마이그레이션 실패: " + e.getMessage(), e);
        }
        
        return result;
    }
    
    /**
     * Hanaro 댓글을 QNA 답변으로 변환
     */
    private TobeQnaAnsD convertMemoToQnaAnsD(HanaroBoardMemo memo, Long qnaNo) {
        TobeQnaAnsD answer = new TobeQnaAnsD();
        
        answer.setQnaNo(qnaNo);
        answer.setQnaAnsDtlNo((short) 1); // 순차적으로 증가해야 하지만 여기서는 단순화
        answer.setQnaAnsDtm(memo.getRegiDate());
        answer.setUpQnaAnsDtlNo(null); // 상위 답변 없음
        answer.setAnsrMemId(null); // 답변자 회원 ID
        answer.setAnsrCprnCd("OW"); // 답변자 법인코드
        answer.setAnsrDeptCd("IT"); // 답변자 부서코드
        answer.setAnsrEmpNo(memo.getUserId() != null ? memo.getUserId() : "MIGRATION");
        answer.setQnaAnsCn(memo.getMemoCont());
        answer.setDelYn("N");
        answer.setFileId(null); // 파일 ID
        answer.setProcPrgmId("HANARO_MIGRATION");
        answer.setRgstProcrId(memo.getUserId() != null ? memo.getUserId() : "MIGRATION");
        answer.setRgstProcDtm(memo.getRegiDate());
        answer.setUpdtProcrId("MIGRATION");
        answer.setUpdtProcDtm(memo.getRegiDate());
        
        return answer;
    }

    /**
     * 제품 시연요청 마이그레이션
     */
    private int migrateInquiries() {
        log.info("제품 시연요청 마이그레이션 시작");
        List<HanaroInquiry> inquiries = hanaroMapper.selectInquiryList();
        totalCount.addAndGet(inquiries.size());
        
        int count = 0;
        for (HanaroInquiry inquiry : inquiries) {
            processedCount.incrementAndGet();
            try {
                // 시연요청을 QNA로 변환
                TobeQnaM qna = convertInquiryToQna(inquiry);
                tobeMapper.insertQnaM(qna);
                successCount.incrementAndGet();
                count++;
            } catch (Exception e) {
                failCount.incrementAndGet();
                String title = inquiry.getJepum() != null ? inquiry.getJepum() : "No Product";
                log.error("제품 시연요청 마이그레이션 실패 - Idx: {}, Product: {}", inquiry.getInqSeq(), title, e);
                addFailedItem("Inquiry", inquiry.getInqSeq(), title, e.getMessage());
            }
        }
        
        log.info("제품 시연요청 {} 건 마이그레이션 완료", count);
        return count;
    }

    /**
     * 제품 상담 마이그레이션
     */
    private int migrateSangdam() {
        log.info("제품 상담 마이그레이션 시작");
        List<HanaroSangdam> sangdamList = hanaroMapper.selectSangdamList();
        totalCount.addAndGet(sangdamList.size());
        
        int count = 0;
        for (HanaroSangdam sangdam : sangdamList) {
            processedCount.incrementAndGet();
            try {
                // 상담을 QNA로 변환
                TobeQnaM qna = convertSangdamToQna(sangdam);
                tobeMapper.insertQnaM(qna);
                successCount.incrementAndGet();
                
                // 답변이 있으면 답변도 마이그레이션
                if (sangdam.getAnswer() != null && !sangdam.getAnswer().trim().isEmpty()) {
                    try {
                        TobeQnaAnsD answer = new TobeQnaAnsD();
                        answer.setQnaNo(qna.getQnaNo());
                        answer.setQnaAnsDtlNo((short) 1);
                        answer.setQnaAnsDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                        answer.setUpQnaAnsDtlNo(null); // 상위 답변 번호
                        answer.setAnsrMemId(null); // 답변자 회원 ID
                        answer.setAnsrCprnCd("OW"); // 답변자 법인코드
                        answer.setAnsrDeptCd("IT"); // 답변자 부서코드
                        answer.setAnsrEmpNo(sangdam.getUserid() != null ? sangdam.getUserid() : "MIGRATION");
                        answer.setQnaAnsCn(sangdam.getAnswer());
                        answer.setDelYn("N");
                        answer.setFileId(null); // 파일 ID
                        answer.setProcPrgmId("HANARO_MIGRATION");
                        answer.setRgstProcrId("MIGRATION");
                        answer.setRgstProcDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                        answer.setUpdtProcrId("MIGRATION");
                        answer.setUpdtProcDtm(sangdam.getAnswerDt() != null ? sangdam.getAnswerDt() : sangdam.getRegistDt());
                        tobeMapper.insertQnaAnsD(answer);
                    } catch (Exception e) {
                        log.error("상담 답변 마이그레이션 실패 - Idx: {}", sangdam.getSangSeq(), e);
                        // 답변 실패는 부가적인 실패로 처리
                    }
                }
                count++;
            } catch (Exception e) {
                failCount.incrementAndGet();
                String title = sangdam.getJepum() != null ? sangdam.getJepum() : "No Product";
                log.error("제품 상담 마이그레이션 실패 - Idx: {}, Product: {}", sangdam.getSangSeq(), title, e);
                addFailedItem("Sangdam", sangdam.getSangSeq(), title, e.getMessage());
            }
        }
        
        log.info("제품 상담 {} 건 마이그레이션 완료", count);
        return count;
    }

    // 변환 메서드들
    private TobeNtfyM convertBoardInfoToNtfy(HanaroBoardInfo boardInfo) {
        TobeNtfyM ntfy = new TobeNtfyM();
        
        // 게시판 정보를 기반으로 카테고리 매핑 - 일반 공지사항으로 매핑
        String categoryCode = hanaroCategoryMapper.mapCategory("공통", "NOTI");
        ntfy.setSvcCtgCd(categoryCode);
        
        ntfy.setNtfyTtl(boardInfo.getBoardNm());
        ntfy.setNtfyCn(boardInfo.getDbDesc() != null ? boardInfo.getDbDesc() : boardInfo.getBoardNm());
        ntfy.setFileId(null); // 파일 ID
        ntfy.setTopFxdYn("N");
        ntfy.setInqCnt(0);
        ntfy.setOpenYn("Y");
        ntfy.setRgstrCprnCd("OW"); // 기본 법인코드
        ntfy.setRgstrDeptCd("IT"); // 기본 부서코드
        ntfy.setRgstrEmpNo("MIGRATION");
        ntfy.setNtfyRgstDtm(new Date());
        ntfy.setProcPrgmId("HANARO_MIGRATION");
        ntfy.setRgstProcrId("MIGRATION");
        ntfy.setRgstProcDtm(new Date());
        ntfy.setUpdtProcrId("MIGRATION");
        ntfy.setUpdtProcDtm(new Date());
        return ntfy;
    }

    private TobeFaqM convertBoardToFaq(HanaroBoard board, HanaroBoardInfo boardInfo) {
        TobeFaqM faq = new TobeFaqM();
        
        // 카테고리 매핑 - boardCode와 cateCode를 사용
        String categoryCode = mapBoardCategory(board, "FAQ");
        faq.setSvcCtgCd(categoryCode);
        
        // 제목에서 HTML 태그 제거 및 길이 제한
        String cleanedTitle = cleanAndTruncateTitle(board.getTitle(), 200);
        faq.setFaqTtl(cleanedTitle);
        
        // 내용은 원본 그대로
        faq.setFaqCn(board.getContents());
        faq.setRgstrCprnCd("OW"); // 기본 법인코드
        faq.setRgstrDeptCd("IT"); // 기본 부서코드
        faq.setRgstrEmpNo(board.getUserId() != null ? board.getUserId() : "MIGRATION");
        faq.setFileId(null); // 파일 ID
        faq.setSortOrd(999); // 기본 정렬 순서
        faq.setUseYn(board.getShowYn() != null && board.getShowYn() == 1 ? "Y" : "N");
        faq.setProcPrgmId("HANARO_MIGRATION");
        faq.setRgstProcrId(board.getUserId() != null ? board.getUserId() : "MIGRATION");
        faq.setRgstProcDtm(board.getRegiDate());
        faq.setUpdtProcrId("MIGRATION");
        faq.setUpdtProcDtm(board.getModiDate());
        return faq;
    }

    private TobeNtfyM convertBoardToNtfy(HanaroBoard board, HanaroBoardInfo boardInfo) {
        TobeNtfyM ntfy = new TobeNtfyM();
        
        // 카테고리 매핑 - boardCode와 cateCode를 사용
        String categoryCode = mapBoardCategory(board, "NOTI");
        ntfy.setSvcCtgCd(categoryCode);
        
        // 제목에서 HTML 태그 제거 및 길이 제한 (DB 컬럼 길이에 맞춤)
        String cleanedTitle = cleanAndTruncateTitle(board.getTitle(), 200);
        ntfy.setNtfyTtl(cleanedTitle);
        
        // 내용은 원본 그대로 (CLOB 타입이므로 길이 제한 없음)
        ntfy.setNtfyCn(board.getContents());
        ntfy.setFileId(null); // 파일 ID
        ntfy.setTopFxdYn(board.getMainYn() != null && board.getMainYn() == 1 ? "Y" : "N");
        ntfy.setInqCnt(board.getViewCnt() != null ? board.getViewCnt().intValue() : 0);
        ntfy.setOpenYn(board.getShowYn() != null && board.getShowYn() == 1 ? "Y" : "N");
        ntfy.setRgstrCprnCd("OW"); // 기본 법인코드
        ntfy.setRgstrDeptCd("IT"); // 기본 부서코드
        ntfy.setRgstrEmpNo(board.getUserId() != null ? board.getUserId() : "MIGRATION");
        ntfy.setNtfyRgstDtm(board.getRegiDate());
        ntfy.setProcPrgmId("HANARO_MIGRATION");
        ntfy.setRgstProcrId(board.getUserId() != null ? board.getUserId() : "MIGRATION");
        ntfy.setRgstProcDtm(board.getRegiDate());
        ntfy.setUpdtProcrId("MIGRATION");
        ntfy.setUpdtProcDtm(board.getModiDate());
        return ntfy;
    }

    private TobeQnaM convertBoardToQna(HanaroBoard board, HanaroBoardInfo boardInfo) {
        TobeQnaM qna = new TobeQnaM();
        
        // 카테고리 매핑 - boardCode와 cateCode를 사용
        String categoryCode = mapBoardCategory(board, "QNA");
        qna.setSvcCtgCd(categoryCode);
        
        // QNA 필드 매핑
        // 제목에서 HTML 태그 제거 및 길이 제한
        String cleanedTitle = cleanAndTruncateTitle(board.getTitle(), 200);
        qna.setQnaTtl(cleanedTitle);
        
        // 내용은 원본 그대로
        qna.setQnaCn(board.getContents());
        qna.setFileId(null); // 파일 ID
        qna.setOpenYn(board.getSecret() != null && "Y".equals(board.getSecret()) ? "N" : "Y");
        qna.setItmCd(null); // 품목코드
        qna.setWrtrMemId(board.getUserId());
        qna.setQnaRgstDtm(board.getRegiDate());
        qna.setAnsCnt(0); // 답변 건수
        qna.setInqCnt(0); // 조회수
        qna.setProcPrgmId("HANARO_MIGRATION");
        qna.setRgstProcrId(board.getUserId() != null ? board.getUserId() : "MIGRATION");
        qna.setRgstProcDtm(board.getRegiDate());
        qna.setUpdtProcrId("MIGRATION");
        qna.setUpdtProcDtm(board.getModiDate());
        return qna;
    }

    private TobeQnaM convertInquiryToQna(HanaroInquiry inquiry) {
        TobeQnaM qna = new TobeQnaM();
        
        // 제품시연요청은 해당 제품의 INQ 카테고리로 매핑
        String categoryCode = hanaroCategoryMapper.mapCategory(inquiry.getJepum(), "QNA");
        qna.setSvcCtgCd(categoryCode);
        
        // QNA 필드 매핑
        qna.setQnaTtl("[제품시연요청] " + inquiry.getJepum());
        qna.setQnaCn(buildInquiryContent(inquiry));
        qna.setFileId(null); // 파일 ID
        qna.setOpenYn("Y");
        qna.setItmCd(null); // 품목코드
        qna.setWrtrMemId(inquiry.getName()); // 작성자 이름을 회원ID로 사용
        qna.setQnaRgstDtm(inquiry.getRegistDt());
        qna.setAnsCnt(0); // 답변 건수
        qna.setInqCnt(0); // 조회수
        qna.setProcPrgmId("HANARO_MIGRATION");
        qna.setRgstProcrId("MIGRATION");
        qna.setRgstProcDtm(inquiry.getRegistDt());
        qna.setUpdtProcrId("MIGRATION");
        qna.setUpdtProcDtm(inquiry.getRegistDt());
        return qna;
    }

    private TobeQnaM convertSangdamToQna(HanaroSangdam sangdam) {
        TobeQnaM qna = new TobeQnaM();
        
        // 제품상담은 해당 제품의 INQ 카테고리로 매핑
        String categoryCode = hanaroCategoryMapper.mapCategory(sangdam.getJepum(), "QNA");
        qna.setSvcCtgCd(categoryCode);
        
        // QNA 필드 매핑
        qna.setQnaTtl("[제품상담] " + sangdam.getJepum());
        qna.setQnaCn(sangdam.getContent());
        qna.setFileId(null); // 파일 ID
        qna.setOpenYn("Y");
        qna.setItmCd(null); // 품목코드
        qna.setWrtrMemId(sangdam.getUserid() != null ? sangdam.getUserid() : sangdam.getName());
        qna.setQnaRgstDtm(sangdam.getRegistDt());
        qna.setAnsCnt(sangdam.getAnswer() != null && !sangdam.getAnswer().trim().isEmpty() ? 1 : 0); // 답변 건수
        qna.setInqCnt(0); // 조회수
        qna.setProcPrgmId("HANARO_MIGRATION");
        qna.setRgstProcrId(sangdam.getUserid() != null ? sangdam.getUserid() : "MIGRATION");
        qna.setRgstProcDtm(sangdam.getRegistDt());
        qna.setUpdtProcrId("MIGRATION");
        qna.setUpdtProcDtm(sangdam.getRegistDt());
        return qna;
    }

    private String buildInquiryContent(HanaroInquiry inquiry) {
        StringBuilder content = new StringBuilder();
        content.append("제품: ").append(inquiry.getJepum()).append("\n");
        content.append("치과명: ").append(inquiry.getDenNm()).append("\n");
        content.append("원장명: ").append(inquiry.getBossName()).append("\n");
        content.append("연락처: ").append(inquiry.getTelNo()).append("\n");
        content.append("휴대폰: ").append(inquiry.getMobileNo()).append("\n");
        content.append("주소: ").append(inquiry.getAddr()).append(" ").append(inquiry.getAddrDetail()).append("\n");
        content.append("\n상담내용:\n").append(inquiry.getContent());
        return content.toString();
    }
    
    /**
     * HanaroBoard의 정보를 바탕으로 적절한 카테고리 매핑
     */
    private String mapBoardCategory(HanaroBoard board, String defaultDbType) {
        try {
            // 1. boardCode에서 카테고리명 추출 시도
            String categoryName = extractCategoryFromBoardCode(board.getBoardCode());
            
            // 2. cateCode가 있으면 카테고리 정보 조회
            if (board.getCateCode() != null) {
                try {
                    HanaroBoardCategory category = hanaroMapper.selectCategory(board.getCateCode().toString());
                    if (category != null && category.getCateNm() != null) {
                        categoryName = category.getCateNm();
                    }
                } catch (Exception e) {
                    log.warn("카테고리 정보 조회 실패 - cateCode: {}", board.getCateCode(), e);
                }
            }
            
            // 3. boardCode에서 DB 타입 추출
            String dbType = extractDbTypeFromBoardCode(board.getBoardCode(), defaultDbType);
            
            // 4. 마이그레이션 대상 여부 확인
            if (!hanaroCategoryMapper.isMigrationTarget(dbType)) {
                log.debug("마이그레이션 대상이 아닌 게시판: boardCode={}, dbType={}", board.getBoardCode(), dbType);
                return null;
            }
            
            // 5. 카테고리 매핑 실행
            return hanaroCategoryMapper.mapCategory(categoryName, dbType);
            
        } catch (Exception e) {
            log.warn("카테고리 매핑 실패 - boardCode: {}, cateCode: {}.", 
                board.getBoardCode(), board.getCateCode(), e);
            return null;
        }
    }
    
    /**
     * boardCode에서 카테고리명 추출
     */
    private String extractCategoryFromBoardCode(String boardCode) {
        if (boardCode == null) {
            return "공통";
        }
        
        // boardCode 패턴 분석 예: "ONECLICK_FAQ", "HANARONE_NOTICE" 등
        String[] parts = boardCode.split("_");
        if (parts.length > 0) {
            String prefix = parts[0].toLowerCase();
            switch (prefix) {
                case "oneclick":
                    return "OneClick";
                case "hanarone":
                case "hanaro":
                    return "하나로";
                case "dubuny":
                case "dubunae":
                    return "두번에";
                case "vceph":
                    return "V-Ceph";
                case "one2":
                    return "One2";
                case "one3":
                    return "One3";
                case "boheom":
                case "insurance":
                    return "보험정보";
                default:
                    return "공통";
            }
        }
        return "공통";
    }
    
    /**
     * boardCode에서 DB 타입 추출
     */
    private String extractDbTypeFromBoardCode(String boardCode, String defaultDbType) {
        if (boardCode == null) {
            return defaultDbType;
        }
        
        String lowerCode = boardCode.toLowerCase();
        if (lowerCode.contains("faq")) {
            return "FAQ";
        } else if (lowerCode.contains("notice") || lowerCode.contains("noti")) {
            return "NOTI";
        } else if (lowerCode.contains("qna")) {
            return "QNA";
        } else if (lowerCode.contains("help")) {
            return "ONLINEHELP";
        } else if (lowerCode.contains("down")) {
            return "DOWN";
        } else if (lowerCode.contains("review")) {
            return "REVIEW";
        } else {
            return defaultDbType;
        }
    }
    
    /**
     * 마이그레이션 통계 정보 조회
     */
    public Map<String, Object> getTotalStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", totalCount.get());
        stats.put("processed", processedCount.get());
        stats.put("success", successCount.get());
        stats.put("fail", failCount.get());
        stats.put("progressPercent", totalCount.get() > 0 ? 
            (processedCount.get() * 100.0 / totalCount.get()) : 0);
        return stats;
    }
    
    /**
     * 마이그레이션 상태 조회
     */
    public Map<String, Object> getMigrationStatus() {
        Map<String, Object> status = getTotalStatistics();
        status.put("failedItemsCount", failedItems.size());
        status.put("duplicateItemsCount", duplicateItems.size());
        return status;
    }
}
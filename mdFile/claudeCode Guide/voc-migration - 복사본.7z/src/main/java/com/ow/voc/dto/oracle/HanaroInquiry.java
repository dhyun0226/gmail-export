package com.ow.voc.dto.oracle;

import lombok.Data;

import java.sql.Timestamp;

/**
 * TB_HANARO_INQUIRY 테이블 DTO
 * 제품시연요청 - 스키마 문서 기반
 */
@Data
public class HanaroInquiry {
    private Long inqSeq;             // NO -> inqSeq (매핑용)
    private String boardCode;        // ASK_KIND -> boardCode (매핑용)
    private String jepum;            // JEPUM
    private String licenceNo;        // LICENCE_NO
    private String yoyangNo;         // YOYANG_NO
    private String bossName;         // BOSS_NAME
    private String telNo;            // TEL_NO
    private String denNm;            // DEN_NM
    private String name;             // NAME
    private String zipNo;            // ZIP_NO
    private String addr;             // ADDR
    private String addrDetail;       // ADDR_DETAIL
    private String emailAdr;         // EMAIL_ADR
    private String mailRecvYn;       // MAIL_RECV_YN
    private String mobileNo;         // MOBILE_NO
    private String replyGubun;       // REPLY_GUBUN
    private String content;          // CONTENT
    private Timestamp registDt;      // REGIST_DT
    private String businessNo;       // BUSINESS_NO
}
package com.ow.voc.util;

import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * DB 커넥션 상태 모니터링 및 로깅 유틸리티
 */
@Slf4j
@Component
public class ConnectionMonitor {
    
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    
    /**
     * 커넥션 상태를 상세히 로깅
     */
    public void logConnectionStatus(DataSource dataSource, String operation, String context) {
        if (dataSource instanceof HikariDataSource) {
            HikariDataSource hikariDataSource = (HikariDataSource) dataSource;
            HikariPoolMXBean poolBean = hikariDataSource.getHikariPoolMXBean();
            
            if (poolBean != null) {
                log.info("=== DB Connection Status [{}] [{}] ===", operation, context);
                log.info("시간: {}", LocalDateTime.now().format(formatter));
                log.info("활성 커넥션: {}/{}", poolBean.getActiveConnections(), poolBean.getTotalConnections());
                log.info("대기 중인 커넥션: {}", poolBean.getIdleConnections());
                log.info("대기 중인 스레드: {}", poolBean.getThreadsAwaitingConnection());
                log.info("커넥션 풀 이름: {}", hikariDataSource.getPoolName());
                
                // 커넥션 부족 경고
                if (poolBean.getActiveConnections() >= poolBean.getTotalConnections() * 0.9) {
                    log.warn("🚨 커넥션 풀 사용률 90% 초과! 활성: {}, 전체: {}", 
                        poolBean.getActiveConnections(), poolBean.getTotalConnections());
                }
                
                // 대기 스레드 경고
                if (poolBean.getThreadsAwaitingConnection() > 0) {
                    log.warn("⏳ 커넥션 대기 스레드 발견: {} 개", poolBean.getThreadsAwaitingConnection());
                }
            } else {
                log.warn("HikariPoolMXBean을 가져올 수 없습니다.");
            }
        } else {
            log.info("HikariDataSource가 아닌 DataSource: {}", dataSource.getClass().getSimpleName());
        }
    }
    
    /**
     * 커넥션 유효성 검사
     */
    public boolean validateConnection(DataSource dataSource, String context) {
        try (Connection connection = dataSource.getConnection()) {
            boolean isValid = connection.isValid(5); // 5초 타임아웃
            log.info("커넥션 유효성 검사 [{}]: {}", context, isValid ? "성공" : "실패");
            
            if (!isValid) {
                log.error("🚨 커넥션이 유효하지 않습니다! Context: {}", context);
            }
            
            // 커넥션 상세 정보
            log.debug("커넥션 정보 - URL: {}, 자동커밋: {}, 읽기전용: {}", 
                connection.getMetaData().getURL(),
                connection.getAutoCommit(),
                connection.isReadOnly());
                
            return isValid;
            
        } catch (SQLException e) {
            log.error("🚨 커넥션 획득/검증 실패 [{}]: {}", context, e.getMessage(), e);
            
            // 상세 에러 정보 로깅
            logSQLException(e, context);
            return false;
        }
    }
    
    /**
     * SQLException 상세 분석
     */
    public void logSQLException(SQLException e, String context) {
        log.error("=== SQLException 상세 분석 [{}] ===", context);
        log.error("시간: {}", LocalDateTime.now().format(formatter));
        log.error("에러 코드: {}", e.getErrorCode());
        log.error("SQL 상태: {}", e.getSQLState());
        log.error("메시지: {}", e.getMessage());
        
        // 특정 에러 타입별 분석
        String message = e.getMessage().toLowerCase();
        if (message.contains("connection") && message.contains("closed")) {
            log.error("🔴 커넥션 종료 에러 감지!");
            log.error("가능한 원인: 1) 네트워크 문제, 2) DB 서버 재시작, 3) 타임아웃, 4) 커넥션 풀 고갈");
        } else if (message.contains("socket")) {
            log.error("🔴 소켓 에러 감지!");
            log.error("가능한 원인: 1) 네트워크 불안정, 2) 방화벽 차단, 3) DB 서버 응답 없음");
        } else if (message.contains("timeout")) {
            log.error("🔴 타임아웃 에러 감지!");
            log.error("가능한 원인: 1) 쿼리 실행 시간 초과, 2) 커넥션 획득 시간 초과");
        }
        
        // 연결된 예외 정보
        SQLException nextException = e.getNextException();
        int exceptionCount = 1;
        while (nextException != null && exceptionCount < 5) {
            log.error("연결된 예외 #{}: {}", exceptionCount++, nextException.getMessage());
            nextException = nextException.getNextException();
        }
    }
    
    /**
     * DB 작업 실행 전 커넥션 상태 체크
     */
    public void preExecutionCheck(DataSource dataSource, String operation, Object... params) {
        log.info("🔍 [PRE-EXECUTION] 작업: {}, 파라미터: {}", operation, java.util.Arrays.toString(params));
        logConnectionStatus(dataSource, "PRE-EXECUTION", operation);
        validateConnection(dataSource, "PRE-EXECUTION: " + operation);
    }
    
    /**
     * DB 작업 실행 후 커넥션 상태 체크
     */
    public void postExecutionCheck(DataSource dataSource, String operation, boolean success, Exception error) {
        String status = success ? "SUCCESS" : "FAILED";
        log.info("✅ [POST-EXECUTION] 작업: {}, 결과: {}", operation, status);
        
        if (!success && error != null) {
            log.error("작업 실패 상세: {}", error.getMessage());
            if (error instanceof SQLException) {
                logSQLException((SQLException) error, "POST-EXECUTION: " + operation);
            }
        }
        
        logConnectionStatus(dataSource, "POST-EXECUTION", operation + " (" + status + ")");
    }
    
    /**
     * 메모리 사용량 로깅
     */
    public void logMemoryUsage(String context) {
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;
        long maxMemory = runtime.maxMemory();
        
        log.info("=== 메모리 사용량 [{}] ===", context);
        log.info("사용 중: {} MB", usedMemory / 1024 / 1024);
        log.info("전체: {} MB", totalMemory / 1024 / 1024);
        log.info("최대: {} MB", maxMemory / 1024 / 1024);
        log.info("사용률: {}%", String.format("%.2f", (usedMemory * 100.0 / maxMemory)));
        
        // 메모리 부족 경고
        if (usedMemory > maxMemory * 0.8) {
            log.warn("🚨 메모리 사용률 80% 초과! GC 실행을 고려하세요.");
        }
    }
    
    /**
     * 주기적인 상태 모니터링을 위한 스냅샷
     */
    public void captureSnapshot(DataSource dataSource, String phase, int processedCount, int totalCount) {
        log.info("📊 === 마이그레이션 상태 스냅샷 [{}] ===", phase);
        log.info("진행률: {}/{} ({}%)", processedCount, totalCount, 
            totalCount > 0 ? String.format("%.2f", (processedCount * 100.0 / totalCount)) : "0");
        
        logConnectionStatus(dataSource, "SNAPSHOT", phase);
        logMemoryUsage(phase);
        
        log.info("=== 스냅샷 종료 ===");
    }
}
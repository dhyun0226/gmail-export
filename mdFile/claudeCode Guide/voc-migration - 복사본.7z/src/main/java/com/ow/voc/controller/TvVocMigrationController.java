package com.ow.voc.controller;

import com.ow.voc.service.TvVocMigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * TV VOC 마이그레이션 컨트롤러
 * TV VOC 데이터베이스에서 TOBE VOC로 데이터를 마이그레이션하는 API
 */
@Slf4j
@Tag(name = "TV VOC Migration", description = "TV VOC 데이터 마이그레이션 API")
@RestController
@RequestMapping("/api/migration/tv-voc")
@RequiredArgsConstructor
public class TvVocMigrationController {

    private final TvVocMigrationService tvVocMigrationService;

    @Operation(summary = "TV VOC 전체 데이터 마이그레이션", 
              description = "TV VOC(DTV)에서 TOBE VOC(OCC)로 모든 데이터를 마이그레이션합니다.")
    @PostMapping("/all")
    public ResponseEntity<Map<String, Object>> migrateAll() {
        log.info("TV VOC 전체 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = tvVocMigrationService.migrateAll();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "TV VOC 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV VOC 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV VOC 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV Notice → 공지사항 마이그레이션", 
              description = "TV VOC의 notice 테이블을 TB_NTFY_M으로 마이그레이션합니다.")
    @PostMapping("/notices")
    public ResponseEntity<Map<String, Object>> migrateTvNotices() {
        log.info("TV Notice 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = tvVocMigrationService.migrateTvNotices();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "TV Notice 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV Notice 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV Notice 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV Event → 이벤트 마이그레이션", 
              description = "TV VOC의 event 테이블을 TB_EVT_M으로 마이그레이션합니다.")
    @PostMapping("/events")
    public ResponseEntity<Map<String, Object>> migrateTvEvents() {
        log.info("TV Event 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = tvVocMigrationService.migrateTvEvents();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "TV Event 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV Event 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV Event 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV FAQ → FAQ 마이그레이션", 
              description = "TV VOC의 faq 테이블을 TB_FAQ_M으로 마이그레이션합니다.")
    @PostMapping("/faqs")
    public ResponseEntity<Map<String, Object>> migrateTvFaqs() {
        log.info("TV FAQ 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = tvVocMigrationService.migrateTvFaqs();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "TV FAQ 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV FAQ 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV FAQ 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV Question → QNA 마이그레이션", 
              description = "TV VOC의 question 테이블을 TB_QNA_M/TB_QNA_ANS_D로 마이그레이션합니다.")
    @PostMapping("/questions")
    public ResponseEntity<Map<String, Object>> migrateTvQuestions() {
        log.info("TV Question 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = tvVocMigrationService.migrateTvQuestions();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "TV Question 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV Question 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV Question 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV VOC 마이그레이션 상태 조회", 
              description = "현재 TV VOC 마이그레이션 진행 상태와 통계를 조회합니다.")
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getMigrationStatus() {
        log.info("TV VOC 마이그레이션 상태 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> status = tvVocMigrationService.getMigrationStatus();
            response.put("success", true);
            response.put("data", status);
            response.put("message", "TV VOC 마이그레이션 상태 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("TV VOC 마이그레이션 상태 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "TV VOC 마이그레이션 상태 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "실패한 항목 조회", 
              description = "마이그레이션 중 실패한 항목들을 조회합니다.")
    @GetMapping("/failed-items")
    public ResponseEntity<Map<String, Object>> getFailedItems() {
        log.info("TV VOC 마이그레이션 실패 항목 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            response.put("success", true);
            response.put("data", tvVocMigrationService.getFailedItems());
            response.put("message", "실패 항목 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("실패 항목 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "실패 항목 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "중복된 항목 조회", 
              description = "마이그레이션 중 중복으로 제외된 항목들을 조회합니다.")
    @GetMapping("/duplicate-items")
    public ResponseEntity<Map<String, Object>> getDuplicateItems() {
        log.info("TV VOC 마이그레이션 중복 항목 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            response.put("success", true);
            response.put("data", tvVocMigrationService.getDuplicateItems());
            response.put("message", "중복 항목 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("중복 항목 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "중복 항목 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "TV VOC 마이그레이션 서비스 상태 확인", 
              description = "TV VOC 마이그레이션 서비스의 상태를 확인합니다.")
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "TV VOC Migration Service");
        response.put("source", "DTV Database");
        response.put("target", "OCC Database");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}
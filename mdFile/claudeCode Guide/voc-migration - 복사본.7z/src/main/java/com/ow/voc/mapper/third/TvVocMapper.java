package com.ow.voc.mapper.third;

import com.ow.voc.dto.third.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

/**
 * TV VOC Database Mapper Interface
 * TV VOC 데이터베이스 조회를 위한 Mapper
 */
@Mapper
public interface TvVocMapper {
    
    // Notice 관련
    List<TvNotice> selectNoticeList();
    List<TvNotice> selectNoticeListWithPaging(@Param("offset") int offset, @Param("limit") int limit);
    TvNotice selectNotice(@Param("id") Long id);
    int countNotice();
    
    // Notice 첨부파일
    List<TvNoticeAttach> selectNoticeAttachList(@Param("noticeId") Long noticeId);
    String selectFirstNoticeFileId(@Param("noticeId") Long noticeId);
    
    // Event 관련
    List<TvEvent> selectEventList();
    List<TvEvent> selectEventListWithPaging(@Param("offset") int offset, @Param("limit") int limit);
    TvEvent selectEvent(@Param("id") Long id);
    int countEvent();
    
    // Event 첨부파일
    List<TvEventAttach> selectEventAttachList(@Param("eventId") Long eventId);
    String selectFirstEventFileId(@Param("eventId") Long eventId);
    
    // FAQ 관련
    List<TvFaq> selectFaqList();
    List<TvFaq> selectFaqListWithPaging(@Param("offset") int offset, @Param("limit") int limit);
    TvFaq selectFaq(@Param("id") Long id);
    int countFaq();
    
    // FAQ 첨부파일
    List<TvFaqAttach> selectFaqAttachList(@Param("faqId") Long faqId);
    String selectFirstFaqFileId(@Param("faqId") Long faqId);
    
    // Question(1:1 문의) 관련
    List<TvQuestion> selectQuestionList();
    List<TvQuestion> selectQuestionListWithPaging(@Param("offset") int offset, @Param("limit") int limit);
    TvQuestion selectQuestion(@Param("id") Long id);
    int countQuestion();
    
    // Question 첨부파일
    List<TvQuestionAttach> selectQuestionAttachList(@Param("questionId") Long questionId);
    String selectFirstQuestionFileId(@Param("questionId") Long questionId);
    
    // 카테고리 정보 조회
    Map<String, Object> selectCategoryInfo(@Param("categoryId") Long categoryId);
    
    // 회원 정보 조회
    Map<String, Object> selectMemberInfo(@Param("memberId") Long memberId);
    
    // 통계 조회
    Map<String, Object> selectMigrationStatistics();
}
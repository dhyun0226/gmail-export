package com.ow.voc.dto.third;

import lombok.Data;
import java.util.Date;

@Data
public class TvQuestion {
    private Long id;
    private Long categoryRefId;
    private String title;
    private String state;
    private String contents;
    private Boolean reply;
    private String replyContents;
    private Date replyDate;
    private Boolean replyNotify;
    private Long memberRefId;
    private String createdBy;
    private Date createdDate;
    private String lastModifiedBy;
    private Date lastModifiedDate;
}
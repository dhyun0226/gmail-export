package com.ow.voc.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VocDto {
    
    private Long vocId;
    private String vocType;
    private String title;
    private String content;
    private String customerName;
    private String customerEmail;
    private String customerPhone;
    private String status;
    private String priority;
    private String assignedTo;
    private LocalDateTime createdAt;
    private String createdBy;
    private LocalDateTime updatedAt;
    private String updatedBy;
    private String resolution;
    private LocalDateTime resolvedAt;
}
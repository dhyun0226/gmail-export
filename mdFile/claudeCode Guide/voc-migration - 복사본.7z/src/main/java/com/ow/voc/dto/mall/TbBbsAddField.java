package com.ow.voc.dto.mall;

import lombok.Data;

@Data
public class TbBbsAddField {
    private Long bbsSeq;
    private String cstNm;
    private String telNo;
    private String hpNo;
    private String email;
}
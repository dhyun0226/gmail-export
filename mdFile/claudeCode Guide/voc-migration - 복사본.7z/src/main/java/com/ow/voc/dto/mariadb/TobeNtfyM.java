package com.ow.voc.dto.mariadb;

import lombok.Data;
import java.util.Date;

@Data
public class TobeNtfyM {
    private Long ntfyNo;            // NTFY_NO (insert 시 auto-generated)
    private String svcCtgCd;        // SVC_CTG_CD
    private String openYn;          // OPEN_YN
    private String topFxdYn;        // TOP_FXD_YN (상단고정여부)
    private String ntfyTtl;         // NTFY_TTL
    private String ntfyCn;          // NTFY_CN
    private String rgstrCprnCd;     // RGSTR_CPRN_CD (등록자법인코드)
    private String rgstrDeptCd;     // RGSTR_DEPT_CD (등록자부서코드)
    private String rgstrEmpNo;      // RGSTR_EMP_NO (등록자사원번호)
    private Date ntfyRgstDtm;       // NTFY_RGST_DTM (공지등록일시)
    private String fileId;          // FILE_ID
    private Integer inqCnt;         // INQ_CNT
    private String procPrgmId;      // PROC_PRGM_ID
    private String rgstProcrId;     // RGST_PROCR_ID
    private Date rgstProcDtm;       // RGST_PROC_DTM
    private String updtProcrId;     // UPDT_PROCR_ID
    private Date updtProcDtm;       // UPDT_PROC_DTM
}
package com.ow.voc.mapper.primary;

import com.ow.voc.dto.mall.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

/**
 * Mall VOC Database Mapper Interface
 * Mall VOC (Oracle) 데이터베이스 조회를 위한 Mapper
 */
@Mapper
public interface MallVocMapper {
    
    // TB_BBS_SETUP 관련
    List<TbBbsSetup> selectBbsSetupList();
    TbBbsSetup selectBbsSetup(@Param("bbsCd") String bbsCd);
    List<TbBbsSetup> selectBbsSetupByPattern(@Param("pattern") String pattern);
    
    // TB_BBS 관련 - 게시판별 조회
    List<TbBbs> selectBbsList(@Param("bbsCd") String bbsCd);
    List<TbBbs> selectBbsListByPattern(@Param("bbsCdPattern") String bbsCdPattern);
    List<TbBbs> selectBbsListWithPaging(@Param("bbsCd") String bbsCd, 
                                        @Param("offset") int offset, 
                                        @Param("limit") int limit);
    TbBbs selectBbs(@Param("bbsSeq") Long bbsSeq);
    int countBbs(@Param("bbsCd") String bbsCd);
    int countBbsByPattern(@Param("bbsCdPattern") String bbsCdPattern);
    
    // 답변글 조회
    List<TbBbs> selectReplyList(@Param("upBbsSeq") Long upBbsSeq);
    
    // TB_BBS_CATEGORY 관련
    List<TbBbsCategory> selectCategoryList(@Param("bbsCd") String bbsCd);
    TbBbsCategory selectCategory(@Param("categorySeq") Long categorySeq);
    List<TbBbsCategory> selectSubCategoryList(@Param("upCategorySeq") Long upCategorySeq);
    
    // TB_BBS_FILE 관련
    List<TbBbsFile> selectFileList(@Param("bbsSeq") Long bbsSeq);
    TbBbsFile selectFile(@Param("bbsFileSeq") Long bbsFileSeq);
    String selectFirstFileId(@Param("bbsSeq") Long bbsSeq);
    
    // TB_BBS_RE 관련
    List<TbBbsRe> selectReList(@Param("bbsSeq") Long bbsSeq);
    int countRe(@Param("bbsSeq") Long bbsSeq);
    
    // TB_BBS_ADD_FIELD 관련
    TbBbsAddField selectAddField(@Param("bbsSeq") Long bbsSeq);
    
    // 게시판 유형별 조회
    List<TbBbs> selectNoticeList();
    List<TbBbs> selectFaqList();
    List<TbBbs> selectQnaList();
    List<TbBbs> selectEventList();
    
    // 통계 조회
    Map<String, Object> selectBbsStatistics(@Param("bbsCd") String bbsCd);
    Map<String, Object> selectMigrationStatistics();
}
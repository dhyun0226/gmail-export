package com.ow.voc.service;

import com.ow.voc.common.BaseMigrationService;
import com.ow.voc.dto.oracle.*;
import com.ow.voc.dto.mariadb.*;
import com.ow.voc.mapper.primary.HanaroMapper;
import com.ow.voc.mapper.secondary.TobeMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Service
public class MigrationService extends BaseMigrationService {

    @Autowired
    private HanaroMapper hanaroMapper;
    
    @Autowired
    private TobeMapper tobeMapper;
    
    @Autowired
    @Qualifier("primaryDataSource")
    private DataSource primaryDataSource;
    
    @Autowired
    @Qualifier("secondaryDataSource")
    private DataSource secondaryDataSource;
    
    // 통계 필드는 BaseMigrationService에서 상속받음
    
    private static final SimpleDateFormat ORACLE_DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final SimpleDateFormat MYSQL_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final String DEFAULT_USER = "MIGRATION";
    private static final int BATCH_SIZE = 100;

    @Transactional
    public Map<String, Object> migrateAll() {
        log.info("전체 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            // 각 게시판별 마이그레이션 실행
            Map<String, Object> noticeResult = migrateNotices();
            Map<String, Object> faqResult = migrateFAQs();
            Map<String, Object> qnaResult = migrateQnAs();
            Map<String, Object> eventResult = migrateEvents();
            
            // 결과 집계
            result.put("notice", noticeResult);
            result.put("faq", faqResult);
            result.put("qna", qnaResult);
            result.put("event", eventResult);
            result.put("total", getTotalStatistics());
            result.put("failedItems", getFailedItemsSummary());
            result.put("duplicateItems", getDuplicateItemsSummary());
            
            // 실패 항목 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            saveReport("VocMigration", result);
            
            log.info("전체 마이그레이션 완료: {}", result);
            
        } catch (Exception e) {
            log.error("마이그레이션 중 오류 발생", e);
            result.put("error", e.getMessage());
            addFailedItem("SYSTEM", "N/A", "전체 마이그레이션", e.getMessage());
        }
        
        return result;
    }
    
    public Map<String, Object> migrateNotices() {
        log.info("공지사항 마이그레이션 시작");
        resetStatistics();
        Map<String, Object> result = new HashMap<>();
        
        try {
            // NOTICE 게시판 데이터 조회
            List<HanaroBoard> noticeList = hanaroMapper.selectBoardList("NOTI");
            result.put("sourceCount", noticeList.size());
            totalCount.set(noticeList.size());
            
            List<TobeNtfyM> ntfyList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (HanaroBoard board : noticeList) {
                try {
                    TobeNtfyM ntfy = convertToNtfyM(board);

                    ntfyList.add(ntfy);

                    // 배치 처리
                    if (ntfyList.size() >= BATCH_SIZE) {
                        tobeMapper.insertNtfyMBatch(ntfyList);
                        migrated += ntfyList.size();
                        ntfyList.clear();
                    }
                    
                    // 중복 체크
//                    if (tobeMapper.checkDuplicateNtfy(ntfy.getSvcCtgCd(), ntfy.getNtfyTtl()) == 0) {
//                        ntfyList.add(ntfy);
//
//                        // 배치 처리
//                        if (ntfyList.size() >= BATCH_SIZE) {
//                            tobeMapper.insertNtfyMBatch(ntfyList);
//                            migrated += ntfyList.size();
//                            ntfyList.clear();
//                        }
//                    } else {
//                        duplicated++;
//                        addDuplicateItem("NOTICE", board.getBoardSeq(), board.getTitle(), "동일한 서비스 카테고리와 제목이 이미 존재합니다.");
//                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("공지사항 변환 오류 - BoardSeq: {}", board.getBoardSeq(), e);
                    failCount.incrementAndGet();
                    addFailedItem("NOTICE", board.getBoardSeq(), board.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!ntfyList.isEmpty()) {
                tobeMapper.insertNtfyMBatch(ntfyList);
                migrated += ntfyList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("notice", result);
            saveReport("VOC_Notice", reportData);
            
        } catch (Exception e) {
            log.error("공지사항 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("notice", result);
            saveReport("VOC_Notice_Failed", reportData);
        }
        
        return result;
    }
    
    public Map<String, Object> migrateFAQs() {
        log.info("FAQ 마이그레이션 시작");
        resetStatistics();
        Map<String, Object> result = new HashMap<>();
        
        try {
            // FAQ 게시판 데이터 조회
            List<HanaroBoard> faqList = hanaroMapper.selectBoardList("FAQ");
            result.put("sourceCount", faqList.size());
            totalCount.set(faqList.size());
            
            List<TobeFaqM> faqMList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (HanaroBoard board : faqList) {
                try {
                    TobeFaqM faq = convertToFaqM(board);

                    faqMList.add(faq);

                    // 배치 처리
                    if (faqMList.size() >= BATCH_SIZE) {
                        tobeMapper.insertFaqMBatch(faqMList);
                        migrated += faqMList.size();
                        faqMList.clear();
                    }

                    // 중복 체크
//                    if (tobeMapper.checkDuplicateFaq(faq.getSvcCtgCd(), faq.getFaqTtl()) == 0) {
//
//                    } else {
//                        duplicated++;
//                        addDuplicateItem("FAQ", board.getBoardSeq(), board.getTitle(), "동일한 서비스 카테고리와 제목이 이미 존재합니다.");
//                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("FAQ 변환 오류 - BoardSeq: {}", board.getBoardSeq(), e);
                    failCount.incrementAndGet();
                    addFailedItem("FAQ", board.getBoardSeq(), board.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!faqMList.isEmpty()) {
                tobeMapper.insertFaqMBatch(faqMList);
                migrated += faqMList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("faq", result);
            saveReport("VOC_FAQ", reportData);
            
        } catch (Exception e) {
            log.error("FAQ 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("faq", result);
            saveReport("VOC_FAQ_Failed", reportData);
        }
        
        return result;
    }
    
    public Map<String, Object> migrateQnAs() {
        log.info("QNA 마이그레이션 시작");
        resetStatistics();
        Map<String, Object> result = new HashMap<>();
        
        try {
            // QNA 게시판 데이터 조회
            List<HanaroBoard> qnaList = hanaroMapper.selectBoardList("QNA");
            result.put("sourceCount", qnaList.size());
            totalCount.set(qnaList.size());
            
            int migrated = 0;
            int answerMigrated = 0;
            int duplicated = 0;
            
            for (HanaroBoard board : qnaList) {
                try {
                    TobeQnaM qna = convertToQnaM(board);
                    
                    // 중복 체크
                    if (tobeMapper.checkDuplicateQna(qna.getSvcCtgCd(), qna.getQnaTtl()) == 0) {
                        tobeMapper.insertQnaM(qna);
                        migrated++;
                        
                        // 답변(메모) 마이그레이션
                        List<HanaroBoardMemo> memos = hanaroMapper.selectMemoList(board.getBoardSeq());
                        for (HanaroBoardMemo memo : memos) {
                            TobeQnaAnsD ans = convertToQnaAnsD(memo, qna.getQnaNo());
                            tobeMapper.insertQnaAnsD(ans);
                            answerMigrated++;
                        }
                    } else {
                        duplicated++;
                        addDuplicateItem("QNA", board.getBoardSeq(), board.getTitle(), "동일한 서비스 카테고리와 제목이 이미 존재합니다.");
                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("QNA 변환 오류 - BoardSeq: {}", board.getBoardSeq(), e);
                    failCount.incrementAndGet();
                    addFailedItem("QNA", board.getBoardSeq(), board.getTitle(), e.getMessage());
                }
            }
            
            result.put("migratedCount", migrated);
            result.put("answerMigratedCount", answerMigrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("qna", result);
            saveReport("VOC_QNA", reportData);
            
        } catch (Exception e) {
            log.error("QNA 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("qna", result);
            saveReport("VOC_QNA_Failed", reportData);
        }
        
        return result;
    }
    
    public Map<String, Object> migrateEvents() {
        log.info("이벤트 마이그레이션 시작");
        resetStatistics();
        Map<String, Object> result = new HashMap<>();
        
        try {
            // EVENT 게시판 데이터 조회
            List<HanaroBoard> eventList = hanaroMapper.selectBoardList("EVENT");
            result.put("sourceCount", eventList.size());
            totalCount.set(eventList.size());
            
            List<TobeEvtM> evtList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (HanaroBoard board : eventList) {
                try {
                    TobeEvtM evt = convertToEvtM(board);
                    
                    // 중복 체크
                    if (tobeMapper.checkDuplicateEvt(evt.getSvcCtgCd(), evt.getEvtTtl()) == 0) {
                        evtList.add(evt);
                        
                        // 배치 처리
                        if (evtList.size() >= BATCH_SIZE) {
                            tobeMapper.insertEvtMBatch(evtList);
                            migrated += evtList.size();
                            evtList.clear();
                        }
                    } else {
                        duplicated++;
                        addDuplicateItem("EVENT", board.getBoardSeq(), board.getTitle(), "동일한 서비스 카테고리와 제목이 이미 존재합니다.");
                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("이벤트 변환 오류 - BoardSeq: {}", board.getBoardSeq(), e);
                    failCount.incrementAndGet();
                    addFailedItem("EVENT", board.getBoardSeq(), board.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!evtList.isEmpty()) {
                tobeMapper.insertEvtMBatch(evtList);
                migrated += evtList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("event", result);
            saveReport("VOC_Event", reportData);
            
        } catch (Exception e) {
            log.error("이벤트 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("event", result);
            saveReport("VOC_Event_Failed", reportData);
        }
        
        return result;
    }
    
    // 변환 메소드들
    private TobeNtfyM convertToNtfyM(HanaroBoard board) {
        TobeNtfyM ntfy = new TobeNtfyM();
        
        ntfy.setSvcCtgCd(determineSvcCtgCd(board));
        ntfy.setNtfyTtl(board.getTitle());
        ntfy.setNtfyCn(board.getContents());
        ntfy.setFileId(getFileId(board.getBoardSeq())); // 파일 ID
        ntfy.setTopFxdYn(board.getMainYn() != null && board.getMainYn() == 1 ? "Y" : "N");
        ntfy.setInqCnt(board.getViewCnt() != null ? board.getViewCnt().intValue() : 0);
        ntfy.setOpenYn(board.getShowYn() != null && board.getShowYn() == 1 ? "Y" : "N");
        ntfy.setRgstrCprnCd("OW"); // 기본 법인코드
        ntfy.setRgstrDeptCd("IT"); // 기본 부서코드
        ntfy.setRgstrEmpNo(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        ntfy.setNtfyRgstDtm(board.getRegiDate());
        ntfy.setProcPrgmId("HANARO_MIGRATION");
        ntfy.setRgstProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        ntfy.setRgstProcDtm(board.getRegiDate());
        ntfy.setUpdtProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        ntfy.setUpdtProcDtm(board.getModiDate());
        
        return ntfy;
    }
    
    private TobeFaqM convertToFaqM(HanaroBoard board) {
        TobeFaqM faq = new TobeFaqM();
        
        faq.setSvcCtgCd(determineSvcCtgCd(board));
        faq.setFaqTtl(board.getTitle());
        faq.setFaqCn(board.getContents());
        faq.setRgstrCprnCd("OW"); // 기본 법인코드
        faq.setRgstrDeptCd("IT"); // 기본 부서코드
        faq.setRgstrEmpNo(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        faq.setFileId(getFileId(board.getBoardSeq())); // 파일 ID
        faq.setSortOrd(999); // 기본 정렬 순서
        faq.setUseYn(board.getShowYn() != null && board.getShowYn() == 1 ? "Y" : "N");
        faq.setProcPrgmId("HANARO_MIGRATION");
        faq.setRgstProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        faq.setRgstProcDtm(board.getRegiDate());
        faq.setUpdtProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        faq.setUpdtProcDtm(board.getModiDate());
        
        return faq;
    }
    
    private TobeQnaM convertToQnaM(HanaroBoard board) {
        TobeQnaM qna = new TobeQnaM();
        
        qna.setSvcCtgCd(determineSvcCtgCd(board));
        // QNA 필드 매핑
        qna.setQnaTtl(board.getTitle());
        qna.setQnaCn(board.getContents());
        qna.setFileId(getFileId(board.getBoardSeq())); // 파일 ID
        qna.setOpenYn("Y");
        qna.setItmCd(null); // 품목코드
        qna.setWrtrMemId(board.getUserId());
        qna.setQnaRgstDtm(board.getRegiDate());
        qna.setAnsCnt(board.getQna() != null && !board.getQna().trim().isEmpty() ? 1 : 0); // 답변 건수
        qna.setInqCnt(0); // 조회수
        qna.setProcPrgmId("HANARO_MIGRATION");
        qna.setRgstProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        qna.setRgstProcDtm(board.getRegiDate());
        qna.setUpdtProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        qna.setUpdtProcDtm(board.getModiDate());
        
        return qna;
    }
    
    private TobeQnaAnsD convertToQnaAnsD(HanaroBoardMemo memo, Long qnaId) {
        TobeQnaAnsD ans = new TobeQnaAnsD();
        
        ans.setQnaNo(qnaId);
        ans.setQnaAnsDtlNo((short) 1); // 순번
        ans.setQnaAnsDtm(memo.getRegiDate());
        ans.setUpQnaAnsDtlNo(null); // 상위 답변 번호
        ans.setAnsrMemId(null); // 답변자 회원 ID
        ans.setAnsrCprnCd("OW"); // 답변자 법인코드
        ans.setAnsrDeptCd("IT"); // 답변자 부서코드
        ans.setAnsrEmpNo(memo.getUserId() != null ? memo.getUserId() : DEFAULT_USER);
        ans.setQnaAnsCn(memo.getMemoCont());
        ans.setDelYn("N");
        ans.setFileId(null); // 파일 ID
        ans.setProcPrgmId("HANARO_MIGRATION");
        ans.setRgstProcrId(memo.getUserId() != null ? memo.getUserId() : DEFAULT_USER);
        ans.setRgstProcDtm(memo.getRegiDate());
        ans.setUpdtProcrId(memo.getUserId() != null ? memo.getUserId() : DEFAULT_USER);
        ans.setUpdtProcDtm(memo.getRegiDate());
        
        return ans;
    }
    
    private TobeEvtM convertToEvtM(HanaroBoard board) {
        TobeEvtM evt = new TobeEvtM();
        
        evt.setSvcCtgCd(determineSvcCtgCd(board));
        evt.setEvtTtl(board.getTitle());
        evt.setEvtCn(board.getContents());
        evt.setEvtStrtDtm(board.getRegiDate()); // 이벤트 시작일을 등록일로 대체
        evt.setEvtEndDtm(calculateEventEndDate(board.getRegiDate())); // 종료일 계산
        evt.setRgstrCprnCd("OW"); // 기본 법인코드
        evt.setRgstrDeptCd("IT"); // 기본 부서코드
        evt.setRgstrEmpNo(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        evt.setFileId(getFileId(board.getBoardSeq())); // 파일 ID
        evt.setSortOrd(999); // 기본 정렬 순서
        evt.setUseYn(board.getShowYn() != null && board.getShowYn() == 1 ? "Y" : "N");
        evt.setEvtPrtcDvcd("01"); // 기본 이벤트 참여 구분 코드
        evt.setInqCnt(board.getViewCnt() != null ? board.getViewCnt().intValue() : 0);
        evt.setEvtRgstDtm(board.getRegiDate());
        evt.setThnlFileId(null); // 썸네일 파일 ID
        evt.setTopFxdYn("N");
        evt.setProcPrgmId("HANARO_MIGRATION");
        evt.setRgstProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        evt.setRgstProcDtm(board.getRegiDate());
        evt.setUpdtProcrId(board.getUserId() != null ? board.getUserId() : DEFAULT_USER);
        evt.setUpdtProcDtm(board.getModiDate());
        
        return evt;
    }
    
    // 유틸리티 메소드들
    private String determineSvcCtgCd(HanaroBoard board) {
        // 서비스 카테고리 코드 결정 로직
        // 게시판 코드에 따라 결정
        String boardCode = board.getBoardCode();
        if (boardCode != null) {
            if (boardCode.contains("HANARO")) return "HANARO";
            if (boardCode.contains("DENS")) return "DENS";
            if (boardCode.contains("DUBONE")) return "DUBONE";
        }
        return "ETC"; // 기본값
    }
    
    private String determineQnaStatCd(HanaroBoard board) {
        // QNA 상태 코드 결정
        // QNA 답변이 있으면 답변완료
        if (board.getQna() != null && !board.getQna().trim().isEmpty()) {
            return "02"; // 답변완료
        }
        return "01"; // 접수
    }
    
    private String getFileId(Long boardSeq) {
        // 파일 ID 조회
        List<HanaroBoardFile> files = hanaroMapper.selectFileList(boardSeq);
        if (!files.isEmpty()) {
            return String.valueOf(files.get(0).getFileId());
        }
        return null;
    }
    
    private Date calculateEventEndDate(Date startDate) {
        // 이벤트 종료일 계산 - 기본적으로 시작일로부터 30일 후
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate != null ? startDate : new Date());
        cal.add(Calendar.DAY_OF_MONTH, 30);
        return cal.getTime();
    }
    
    private Date parseDate(Object dateObj) {
        if (dateObj == null) {
            return new Date();
        }
        
        if (dateObj instanceof Date) {
            return (Date) dateObj;
        }
        
        String dateStr = dateObj.toString();
        if (dateStr.trim().isEmpty()) {
            return new Date();
        }
        
        try {
            // Oracle 날짜 형식 (yyyyMMddHHmmss)을 Date로 변환
            if (dateStr.length() == 14) {
                return ORACLE_DATE_FORMAT.parse(dateStr);
            }
            // 다른 형식 처리
            return new Date();
        } catch (ParseException e) {
            log.warn("날짜 변환 오류: {}", dateStr, e);
            return new Date();
        }
    }
    
    // resetStatistics() 메서드는 BaseMigrationService에서 상속받음
    
    public Map<String, Object> getTotalStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", totalCount.get());
        stats.put("processed", processedCount.get());
        stats.put("success", successCount.get());
        stats.put("fail", failCount.get());
        stats.put("progressPercent", totalCount.get() > 0 ? 
            (processedCount.get() * 100.0 / totalCount.get()) : 0);
        return stats;
    }
    
    public Map<String, Object> getMigrationStatus() {
        return getTotalStatistics();
    }
    
    public Map<String, Object> checkAllConnections() {
        Map<String, Object> connectionStatus = new HashMap<>();
        
        // Primary DataSource (Oracle) 연결 확인
        try {
            primaryDataSource.getConnection().close();
            connectionStatus.put("primaryDatabase", Map.of(
                "name", "Oracle (DENJOB/EOS)",
                "status", "CONNECTED",
                "type", "Oracle Database",
                "message", "연결 성공"
            ));
        } catch (Exception e) {
            log.error("Primary 데이터베이스 연결 실패", e);
            connectionStatus.put("primaryDatabase", Map.of(
                "name", "Oracle (DENJOB/EOS)",
                "status", "DISCONNECTED",
                "type", "Oracle Database",
                "message", "연결 실패: " + e.getMessage()
            ));
        }
        
        // Secondary DataSource (MariaDB OCC) 연결 확인
        try {
            secondaryDataSource.getConnection().close();
            connectionStatus.put("secondaryDatabase", Map.of(
                "name", "MariaDB (OCC)",
                "status", "CONNECTED",
                "type", "MariaDB Database",
                "message", "연결 성공"
            ));
        } catch (Exception e) {
            log.error("Secondary 데이터베이스 연결 실패", e);
            connectionStatus.put("secondaryDatabase", Map.of(
                "name", "MariaDB (OCC)",
                "status", "DISCONNECTED",
                "type", "MariaDB Database",
                "message", "연결 실패: " + e.getMessage()
            ));
        }
        
        // 테이블 존재 여부 확인
        try {
            Map<String, Object> tableInfo = new HashMap<>();
            
            // Oracle 테이블 확인
            Map<String, Object> oracleTables = new HashMap<>();
            oracleTables.put("DENJOB_HANARO_BOARD", hanaroMapper.countBoard("NOTICE") >= 0 ? "EXISTS" : "NOT_EXISTS");
            tableInfo.put("oracleTables", oracleTables);
            
            // MariaDB 테이블 확인
            Map<String, Object> mariadbTables = new HashMap<>();
            mariadbTables.put("TB_NTFY_M", tobeMapper.checkTableExists("TB_NTFY_M") > 0 ? "EXISTS" : "NOT_EXISTS");
            mariadbTables.put("TB_FAQ_M", tobeMapper.checkTableExists("TB_FAQ_M") > 0 ? "EXISTS" : "NOT_EXISTS");
            mariadbTables.put("TB_QNA_M", tobeMapper.checkTableExists("TB_QNA_M") > 0 ? "EXISTS" : "NOT_EXISTS");
            mariadbTables.put("TB_EVT_M", tobeMapper.checkTableExists("TB_EVT_M") > 0 ? "EXISTS" : "NOT_EXISTS");
            tableInfo.put("mariadbTables", mariadbTables);
            
            connectionStatus.put("tableInfo", tableInfo);
            
        } catch (Exception e) {
            log.error("테이블 정보 확인 실패", e);
            connectionStatus.put("tableInfo", "확인 실패: " + e.getMessage());
        }
        
        connectionStatus.put("timestamp", new Date());
        connectionStatus.put("service", "Hanaro VOC Migration Service");
        
        return connectionStatus;
    }
}
package com.ow.voc.dto.mariadb;

import lombok.Data;
import java.util.Date;

@Data
public class TobeFaqM {
    private Long faqNo;             // FAQ_NO (insert 시 auto-generated)
    private String svcCtgCd;        // SVC_CTG_CD
    private String faqTtl;          // FAQ_TTL
    private String faqCn;           // FAQ_CN
    private String rgstrCprnCd;     // RGSTR_CPRN_CD (등록자법인코드)
    private String rgstrDeptCd;     // RGSTR_DEPT_CD (등록자부서코드)
    private String rgstrEmpNo;      // RGSTR_EMP_NO (등록자사원번호)
    private String fileId;          // FILE_ID
    private Integer sortOrd;        // SORT_ORD (정렬순서)
    private String useYn;           // USE_YN
    private String procPrgmId;      // PROC_PRGM_ID
    private String rgstProcrId;     // RGST_PROCR_ID
    private Date rgstProcDtm;       // RGST_PROC_DTM
    private String updtProcrId;     // UPDT_PROCR_ID
    private Date updtProcDtm;       // UPDT_PROC_DTM
}
package com.ow.voc.dto.oracle;

import lombok.Data;

/**
 * TB_HANARO_BOARD_FILE 테이블 DTO
 * 하나로게시물파일정보 - 스키마 문서 기반
 */
@Data
public class HanaroBoardFile {
    private Long fileId;             // FILE_NO -> fileId (매핑용)
    private Long boardSeq;           // BOARD_NO -> boardSeq (매핑용)
    private String fileRealNm;       // FILE_NAME -> fileRealNm (매핑용)
    private String fileFakeNm;       // FILE_PHYSICAL -> fileFakeNm (매핑용)
    private Long fileSize;           // FILE_SIZE
    private String fileType;         // FILE_TYPE
    private String filePath;         // FILE_PATH
    private Integer bbsNo;           // BBS_NO
}
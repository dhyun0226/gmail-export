package com.ow.voc.mapper.third;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

/**
 * DTV Database Mapper Interface
 * Example mapper for third datasource (DTV MariaDB)
 */
@Mapper
public interface DtvMapper {
    
    /**
     * Test connection to DTV database
     * @return current timestamp from database
     */
    String testConnection();
    
    /**
     * Example: Select all tables in DTV database
     * @return list of table names
     */
    List<String> getAllTables();
    
    /**
     * Example: Get table information
     * @param tableName table name to query
     * @return table information as map
     */
    Map<String, Object> getTableInfo(@Param("tableName") String tableName);
    
    /**
     * Example: Execute custom query
     * @param query SQL query to execute
     * @return query results as list of maps
     */
    List<Map<String, Object>> executeQuery(@Param("query") String query);
    
    /**
     * Example: Count records in a table
     * @param tableName table name
     * @return record count
     */
    Long countRecords(@Param("tableName") String tableName);
}
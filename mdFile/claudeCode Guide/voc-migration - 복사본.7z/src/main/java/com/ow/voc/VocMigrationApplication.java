package com.ow.voc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VocMigrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(VocMigrationApplication.class, args);
    }

}
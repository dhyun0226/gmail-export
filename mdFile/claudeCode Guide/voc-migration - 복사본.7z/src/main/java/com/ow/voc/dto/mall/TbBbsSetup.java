package com.ow.voc.dto.mall;

import lombok.Data;
import java.util.Date;

@Data
public class TbBbsSetup {
    private String bbsCd;
    private String bbsDb;
    private String bbsNm;
    private Integer fileCnt;
    private Integer movieFileCnt;
    private String movieEncodingYn;
    private Integer productAttachCnt;
    private String categoryYn;
    private String anonymousBbsYn;
    private String commentYn;
    private String reYn;
    private String regIdViewYn;
    private String viewIdViewYn;
    private String fileViewIdViewYn;
    private String reIdViewYn;
    private String secretBbsYn;
    private String refBbsYn;
    private String titleImageUrl;
    private Integer viewBestListCnt;
    private Integer reBestListCnt;
    private Integer commentBestListCnt;
    private String delYn;
    private Integer reIdListCnt;
    private String reId;
    private Date regDt;
    private String regId;
    private Date modDt;
    private String modId;
    private String reListBbsYn;
    private String reContentBbsYn;
    private Integer regIdListCnt;
    private Integer categoryListCnt;
    private String listContentViewYn;
    private String bbsFieldAddYn;
}
package com.ow.voc.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 마이그레이션 결과 리포트 생성 유틸리티
 */
@Slf4j
@Component
public class MigrationReportUtil {
    
    @Value("${migration.report.path:./migration-reports}")
    private String reportPath;
    
    private final ObjectMapper objectMapper;
    
    public MigrationReportUtil() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        this.objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
    }
    
    /**
     * 마이그레이션 결과를 파일로 저장
     */
    public void saveMigrationReport(String serviceName, Map<String, Object> result, 
                                  List<Map<String, Object>> failedItems, 
                                  List<Map<String, Object>> duplicateItems) {
        try {
            // 리포트 디렉토리 생성
            Path reportDir = Paths.get(reportPath);
            if (!Files.exists(reportDir)) {
                Files.createDirectories(reportDir);
            }
            
            // 타임스탬프 생성
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            
            // 전체 리포트 생성
            Map<String, Object> fullReport = new HashMap<>();
            fullReport.put("serviceName", serviceName);
            fullReport.put("timestamp", new Date());
            fullReport.put("result", result);
            fullReport.put("failedItems", failedItems);
            fullReport.put("duplicateItems", duplicateItems);
            
            // JSON 파일로 저장
            String jsonFileName = String.format("%s/%s_migration_report_%s.json", 
                reportPath, serviceName, timestamp);
            saveAsJson(jsonFileName, fullReport);
            
            // 실패 항목 CSV 저장
            if (!failedItems.isEmpty()) {
                String failedCsvFileName = String.format("%s/%s_failed_items_%s.csv", 
                    reportPath, serviceName, timestamp);
                saveAsCsv(failedCsvFileName, failedItems, "실패 항목");
            }
            
            // 중복 항목 CSV 저장
            if (!duplicateItems.isEmpty()) {
                String duplicateCsvFileName = String.format("%s/%s_duplicate_items_%s.csv", 
                    reportPath, serviceName, timestamp);
                saveAsCsv(duplicateCsvFileName, duplicateItems, "중복 항목");
            }
            
            // 요약 텍스트 파일 저장
            String summaryFileName = String.format("%s/%s_summary_%s.txt", 
                reportPath, serviceName, timestamp);
            saveSummary(summaryFileName, serviceName, result, failedItems.size(), duplicateItems.size());
            
            log.info("마이그레이션 리포트 저장 완료: {}", reportPath);
            
        } catch (Exception e) {
            log.error("마이그레이션 리포트 저장 중 오류", e);
        }
    }
    
    /**
     * JSON 형식으로 저장
     */
    private void saveAsJson(String fileName, Object data) throws IOException {
        objectMapper.writeValue(new File(fileName), data);
        log.info("JSON 리포트 저장: {}", fileName);
    }
    
    /**
     * CSV 형식으로 저장
     */
    private void saveAsCsv(String fileName, List<Map<String, Object>> items, String type) throws IOException {
        try (FileWriter writer = new FileWriter(fileName)) {
            // CSV 헤더
            writer.append("타입,ID,제목,");
            if ("실패 항목".equals(type)) {
                writer.append("오류메시지");
            } else {
                writer.append("중복이유");
            }
            writer.append(",타임스탬프\n");
            
            // 데이터 행
            for (Map<String, Object> item : items) {
                writer.append(escapeSpecialCharacters(String.valueOf(item.get("type"))))
                      .append(",")
                      .append(escapeSpecialCharacters(String.valueOf(item.get("id"))))
                      .append(",")
                      .append(escapeSpecialCharacters(String.valueOf(item.get("title"))))
                      .append(",");
                
                if ("실패 항목".equals(type)) {
                    writer.append(escapeSpecialCharacters(String.valueOf(item.get("error"))));
                } else {
                    writer.append(escapeSpecialCharacters(String.valueOf(item.get("reason"))));
                }
                
                writer.append(",")
                      .append(escapeSpecialCharacters(String.valueOf(item.get("timestamp"))))
                      .append("\n");
            }
        }
        log.info("CSV 리포트 저장: {}", fileName);
    }
    
    /**
     * 요약 텍스트 파일 저장
     */
    private void saveSummary(String fileName, String serviceName, Map<String, Object> result, 
                           int failedCount, int duplicateCount) throws IOException {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write("====================================\n");
            writer.write("마이그레이션 요약 리포트\n");
            writer.write("====================================\n\n");
            
            writer.write("서비스명: " + serviceName + "\n");
            writer.write("실행시간: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\n\n");
            
            writer.write("--- 전체 결과 ---\n");
            writeResultSummary(writer, result);
            
            writer.write("\n--- 문제 항목 요약 ---\n");
            writer.write("실패 항목 수: " + failedCount + "\n");
            writer.write("중복 항목 수: " + duplicateCount + "\n");
            
            writer.write("\n====================================\n");
        }
        log.info("요약 리포트 저장: {}", fileName);
    }
    
    /**
     * 결과 요약 작성
     */
    private void writeResultSummary(FileWriter writer, Map<String, Object> result) throws IOException {
        if (result.containsKey("notice")) {
            writeTableSummary(writer, "공지사항", (Map<String, Object>) result.get("notice"));
        }
        if (result.containsKey("event")) {
            writeTableSummary(writer, "이벤트", (Map<String, Object>) result.get("event"));
        }
        if (result.containsKey("faq")) {
            writeTableSummary(writer, "FAQ", (Map<String, Object>) result.get("faq"));
        }
        if (result.containsKey("qna")) {
            writeTableSummary(writer, "QNA", (Map<String, Object>) result.get("qna"));
        }
    }
    
    /**
     * 테이블별 요약 작성
     */
    private void writeTableSummary(FileWriter writer, String tableName, Map<String, Object> tableResult) throws IOException {
        if (tableResult == null) return;
        
        writer.write("\n[" + tableName + "]\n");
        writer.write("  원본 건수: " + tableResult.getOrDefault("sourceCount", 0) + "\n");
        writer.write("  마이그레이션 건수: " + tableResult.getOrDefault("migratedCount", 0) + "\n");
        writer.write("  중복 건수: " + tableResult.getOrDefault("duplicatedCount", 0) + "\n");
        writer.write("  실패 건수: " + tableResult.getOrDefault("failedCount", 0) + "\n");
    }
    
    /**
     * CSV 특수문자 이스케이프
     */
    private String escapeSpecialCharacters(String data) {
        if (data == null) return "";
        
        String escapedData = data.replaceAll("\\R", " ");
        if (data.contains(",") || data.contains("\"") || data.contains("'")) {
            data = data.replace("\"", "\"\"");
            escapedData = "\"" + data + "\"";
        }
        return escapedData;
    }
    
    /**
     * 리포트 저장 경로 조회
     */
    public String getReportPath() {
        return reportPath;
    }
}
package com.ow.voc.service;

import com.ow.voc.mapper.third.DtvMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DTV Database Service
 * Example service for third datasource operations
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DtvService {

    private final DtvMapper dtvMapper;

    /**
     * Test DTV database connection
     * @return connection status and timestamp
     */
    public Map<String, Object> testConnection() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            String timestamp = dtvMapper.testConnection();
            result.put("status", "connected");
            result.put("timestamp", timestamp);
            result.put("database", "DTV");
            log.info("DTV database connection successful: {}", timestamp);
        } catch (Exception e) {
            log.error("DTV database connection failed", e);
            result.put("status", "failed");
            result.put("error", e.getMessage());
        }
        
        return result;
    }

    /**
     * Get all tables in DTV database
     * @return list of table names
     */
    public List<String> getAllTables() {
        log.info("Fetching all tables from DTV database");
        List<String> tables = dtvMapper.getAllTables();
        log.info("Found {} tables in DTV database", tables.size());
        return tables;
    }

    /**
     * Get detailed information about a specific table
     * @param tableName name of the table
     * @return table information
     */
    public Map<String, Object> getTableInfo(String tableName) {
        log.info("Fetching information for table: {}", tableName);
        Map<String, Object> tableInfo = dtvMapper.getTableInfo(tableName);
        
        if (tableInfo != null && !tableInfo.isEmpty()) {
            Long recordCount = dtvMapper.countRecords(tableName);
            tableInfo.put("current_record_count", recordCount);
        }
        
        return tableInfo;
    }

    /**
     * Execute a custom query on DTV database
     * Use with caution - for admin purposes only
     * @param query SQL query to execute
     * @return query results
     */
    @Transactional(transactionManager = "thirdTransactionManager", readOnly = true)
    public List<Map<String, Object>> executeQuery(String query) {
        log.warn("Executing custom query on DTV database: {}", query);
        
        // Basic validation - only allow SELECT queries
        if (!query.trim().toUpperCase().startsWith("SELECT")) {
            throw new IllegalArgumentException("Only SELECT queries are allowed");
        }
        
        return dtvMapper.executeQuery(query);
    }

    /**
     * Get database statistics
     * @return database statistics including table count and sizes
     */
    public Map<String, Object> getDatabaseStatistics() {
        Map<String, Object> stats = new HashMap<>();
        
        try {
            List<String> tables = getAllTables();
            stats.put("tableCount", tables.size());
            stats.put("tables", tables);
            
            // Get size information for each table
            Map<String, Object> tableSizes = new HashMap<>();
            for (String table : tables) {
                Map<String, Object> info = getTableInfo(table);
                if (info != null) {
                    tableSizes.put(table, info);
                }
            }
            stats.put("tableDetails", tableSizes);
            
        } catch (Exception e) {
            log.error("Error getting database statistics", e);
            stats.put("error", e.getMessage());
        }
        
        return stats;
    }
}
package com.ow.voc.service;

import com.ow.voc.common.BaseMigrationService;
import com.ow.voc.dto.mariadb.*;
import com.ow.voc.dto.third.*;
import com.ow.voc.mapper.secondary.TobeMapper;
import com.ow.voc.mapper.third.TvVocMapper;
import com.ow.voc.util.TvCategoryMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * TV VOC 마이그레이션 서비스
 * TV VOC 데이터베이스에서 TOBE VOC로 데이터를 마이그레이션
 */
@Slf4j
@Service
public class TvVocMigrationService extends BaseMigrationService {

    @Autowired
    private TvVocMapper tvVocMapper;
    
    @Autowired
    private TobeMapper tobeMapper;
    
    @Autowired
    private TvCategoryMapper tvCategoryMapper;
    
    private static final String DEFAULT_USER = "TV_MIGRATION";
    private static final String DEFAULT_SVC_TP_CD = "01"; // 기본 서비스 타입 코드
    private static final int BATCH_SIZE = 100;

    /**
     * 전체 TV VOC 데이터 마이그레이션
     */
    @Transactional
    public Map<String, Object> migrateAll() {
        log.info("TV VOC 전체 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            // 각 테이블별 마이그레이션 실행
            Map<String, Object> noticeResult = migrateTvNotices();
            Map<String, Object> eventResult = migrateTvEvents();
            Map<String, Object> faqResult = migrateTvFaqs();
            Map<String, Object> questionResult = migrateTvQuestions();
            
            // 결과 집계
            result.put("notice", noticeResult);
            result.put("event", eventResult);
            result.put("faq", faqResult);
            result.put("question", questionResult);
            result.put("total", getTotalStatistics());
            
            // 실패 및 중복 항목 요약
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 실패한 항목들 로그 출력
            printFailedItemsLog();
            
            // 리포트 파일로 저장
            saveReport("TV_VOC", result);
            
            log.info("TV VOC 전체 마이그레이션 완료: {}", result);
            
        } catch (Exception e) {
            log.error("TV VOC 마이그레이션 중 오류 발생", e);
            result.put("error", e.getMessage());
        }
        
        return result;
    }
    
    /**
     * TV Notice → TB_NTFY_M 마이그레이션
     */
    public Map<String, Object> migrateTvNotices() {
        log.info("TV Notice 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            List<TvNotice> noticeList = tvVocMapper.selectNoticeList();
            result.put("sourceCount", noticeList.size());
            totalCount.set(noticeList.size());
            
            List<TobeNtfyM> ntfyList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (TvNotice notice : noticeList) {
                try {
                    TobeNtfyM ntfy = convertTvNoticeToNtfyM(notice);
                    ntfyList.add(ntfy);

                    // 배치 처리
                    if (ntfyList.size() >= BATCH_SIZE) {
                        tobeMapper.insertNtfyMBatch(ntfyList);
                        migrated += ntfyList.size();
                        ntfyList.clear();
                    }

                    // 중복 체크
//                    if (tobeMapper.checkDuplicateNtfy(ntfy.getSvcCtgCd(), ntfy.getNtfyTtl()) == 0) {
//
//                    } else {
//                        duplicated++;
//                        addDuplicateItem("NOTICE", notice.getId(), notice.getTitle(),
//                            "동일한 제목의 공지사항이 이미 존재합니다");
//                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("TV Notice 변환 오류 - ID: {}", notice.getId(), e);
                    failCount.incrementAndGet();
                    addFailedItem("NOTICE", notice.getId(), notice.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!ntfyList.isEmpty()) {
                tobeMapper.insertNtfyMBatch(ntfyList);
                migrated += ntfyList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("notice", result);
            saveReport("TV_VOC_Notice", reportData);
            
        } catch (Exception e) {
            log.error("TV Notice 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("notice", result);
            saveReport("TV_VOC_Notice_Failed", reportData);
        }
        
        return result;
    }
    
    /**
     * TV Event → TB_EVT_M 마이그레이션
     */
    public Map<String, Object> migrateTvEvents() {
        log.info("TV Event 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            List<TvEvent> eventList = tvVocMapper.selectEventList();
            result.put("sourceCount", eventList.size());
            totalCount.set(eventList.size());
            
            List<TobeEvtM> evtList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (TvEvent event : eventList) {
                try {
                    TobeEvtM evt = convertTvEventToEvtM(event);
                    
                    // 중복 체크
                    if (tobeMapper.checkDuplicateEvt(evt.getSvcCtgCd(), evt.getEvtTtl()) == 0) {
                        evtList.add(evt);
                        
                        // 배치 처리
                        if (evtList.size() >= BATCH_SIZE) {
                            tobeMapper.insertEvtMBatch(evtList);
                            migrated += evtList.size();
                            evtList.clear();
                        }
                    } else {
                        duplicated++;
                        addDuplicateItem("EVENT", event.getId(), event.getTitle(), 
                            "동일한 제목의 이벤트가 이미 존재합니다");
                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("TV Event 변환 오류 - ID: {}", event.getId(), e);
                    failCount.incrementAndGet();
                    addFailedItem("EVENT", event.getId(), event.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!evtList.isEmpty()) {
                tobeMapper.insertEvtMBatch(evtList);
                migrated += evtList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("event", result);
            saveReport("TV_VOC_Event", reportData);
            
        } catch (Exception e) {
            log.error("TV Event 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("event", result);
            saveReport("TV_VOC_Event_Failed", reportData);
        }
        
        return result;
    }
    
    /**
     * TV FAQ → TB_FAQ_M 마이그레이션
     */
    public Map<String, Object> migrateTvFaqs() {
        log.info("TV FAQ 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            List<TvFaq> faqList = tvVocMapper.selectFaqList();
            result.put("sourceCount", faqList.size());
            totalCount.set(faqList.size());
            
            List<TobeFaqM> faqMList = new ArrayList<>();
            int migrated = 0;
            int duplicated = 0;
            
            for (TvFaq faq : faqList) {
                try {
                    TobeFaqM faqM = convertTvFaqToFaqM(faq);
                    
                    // 중복 체크
                    if (tobeMapper.checkDuplicateFaq(faqM.getSvcCtgCd(), faqM.getFaqTtl()) == 0) {
                        faqMList.add(faqM);
                        
                        // 배치 처리
                        if (faqMList.size() >= BATCH_SIZE) {
                            tobeMapper.insertFaqMBatch(faqMList);
                            migrated += faqMList.size();
                            faqMList.clear();
                        }
                    } else {
                        duplicated++;
                        addDuplicateItem("FAQ", faq.getId(), faq.getTitle(), 
                            "동일한 제목의 FAQ가 이미 존재합니다");
                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("TV FAQ 변환 오류 - ID: {}", faq.getId(), e);
                    failCount.incrementAndGet();
                    addFailedItem("FAQ", faq.getId(), faq.getTitle(), e.getMessage());
                }
            }
            
            // 남은 데이터 처리
            if (!faqMList.isEmpty()) {
                tobeMapper.insertFaqMBatch(faqMList);
                migrated += faqMList.size();
            }
            
            result.put("migratedCount", migrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("faq", result);
            saveReport("TV_VOC_FAQ", reportData);
            
        } catch (Exception e) {
            log.error("TV FAQ 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("faq", result);
            saveReport("TV_VOC_FAQ_Failed", reportData);
        }
        
        return result;
    }
    
    /**
     * TV Question → TB_QNA_M / TB_QNA_ANS_D 마이그레이션
     */
    public Map<String, Object> migrateTvQuestions() {
        log.info("TV Question 마이그레이션 시작");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 통계 초기화
            resetStatistics();
            
            List<TvQuestion> questionList = tvVocMapper.selectQuestionList();
            result.put("sourceCount", questionList.size());
            totalCount.set(questionList.size());
            
            int migrated = 0;
            int answerMigrated = 0;
            int duplicated = 0;
            
            for (TvQuestion question : questionList) {
                try {
                    TobeQnaM qna = convertTvQuestionToQnaM(question);

                    tobeMapper.insertQnaM(qna);
                    migrated++;

                    // 답변이 있는 경우 답변 테이블에도 저장
                    if (Boolean.TRUE.equals(question.getReply()) && question.getReplyContents() != null) {
                        TobeQnaAnsD ans = convertTvQuestionToQnaAnsD(question, qna.getQnaNo());
                        tobeMapper.insertQnaAnsD(ans);
                        answerMigrated++;
                    }
                    // 중복 체크
//                    if (tobeMapper.checkDuplicateQna(qna.getSvcCtgCd(), qna.getQnaTtl()) == 0) {
//                        tobeMapper.insertQnaM(qna);
//                        migrated++;
//
//                        // 답변이 있는 경우 답변 테이블에도 저장
//                        if (Boolean.TRUE.equals(question.getReply()) && question.getReplyContents() != null) {
//                            TobeQnaAnsD ans = convertTvQuestionToQnaAnsD(question, qna.getQnaNo());
//                            tobeMapper.insertQnaAnsD(ans);
//                            answerMigrated++;
//                        }
//                    } else {
//                        duplicated++;
//                        addDuplicateItem("QUESTION", question.getId(), question.getTitle(),
//                            "동일한 제목의 QNA가 이미 존재합니다");
//                    }
                    
                    processedCount.incrementAndGet();
                    successCount.incrementAndGet();
                    
                } catch (Exception e) {
                    log.error("TV Question 변환 오류 - ID: {}", question.getId(), e);
                    failCount.incrementAndGet();
                    addFailedItem("QUESTION", question.getId(), question.getTitle(), e.getMessage());
                }
            }
            
            result.put("migratedCount", migrated);
            result.put("answerMigratedCount", answerMigrated);
            result.put("duplicatedCount", duplicated);
            result.put("failedCount", failCount.get());
            result.put("success", true);
            
            // 실패 및 중복 항목 요약 추가
            result.put("failedItemsSummary", getFailedItemsSummary());
            result.put("duplicateItemsSummary", getDuplicateItemsSummary());
            
            // 로그 출력
            printFailedItemsLog();
            
            // 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("question", result);
            saveReport("TV_VOC_Question", reportData);
            
        } catch (Exception e) {
            log.error("TV Question 마이그레이션 오류", e);
            result.put("success", false);
            result.put("error", e.getMessage());
            
            // 실패시에도 리포트 저장
            Map<String, Object> reportData = new HashMap<>();
            reportData.put("question", result);
            saveReport("TV_VOC_Question_Failed", reportData);
        }
        
        return result;
    }
    
    // 변환 메소드들
    private TobeNtfyM convertTvNoticeToNtfyM(TvNotice notice) {
        TobeNtfyM ntfy = new TobeNtfyM();
        
        // Notice는 카테고리 정보가 없으므로 NEWS 타입으로 기본 공지사항 카테고리 매핑
        String categoryCode = tvCategoryMapper.mapCategory("NEWS", "공지사항");

        ntfy.setSvcCtgCd(categoryCode);
        ntfy.setNtfyTtl(notice.getTitle());
        ntfy.setNtfyCn(notice.getContents());
        ntfy.setFileId(tvVocMapper.selectFirstNoticeFileId(notice.getId()));
        ntfy.setTopFxdYn(Boolean.TRUE.equals(notice.getFixedAtTop()) ? "Y" : "N");
        ntfy.setInqCnt(notice.getPageViewCount() != null ? notice.getPageViewCount().intValue() : 0);
        ntfy.setOpenYn(Boolean.TRUE.equals(notice.getEnable()) ? "Y" : "N");
        ntfy.setRgstrCprnCd("OW"); // 기본 법인코드
        ntfy.setRgstrDeptCd("IT"); // 기본 부서코드
        ntfy.setRgstrEmpNo(notice.getCreatedBy() != null ? notice.getCreatedBy() : DEFAULT_USER);
        ntfy.setNtfyRgstDtm(notice.getCreatedDate());
        ntfy.setProcPrgmId("TV_MIGRATION");
        ntfy.setRgstProcrId(notice.getCreatedBy() != null ? notice.getCreatedBy() : DEFAULT_USER);
        ntfy.setRgstProcDtm(notice.getCreatedDate());
        ntfy.setUpdtProcrId(notice.getLastModifiedBy() != null ? notice.getLastModifiedBy() : DEFAULT_USER);
        ntfy.setUpdtProcDtm(notice.getLastModifiedDate());
        
        return ntfy;
    }
    
    private TobeEvtM convertTvEventToEvtM(TvEvent event) {
        TobeEvtM evt = new TobeEvtM();
        
        // Event는 카테고리 정보가 없으므로 D001_EVT (TV 이벤트) 카테고리로 고정 매핑
        evt.setSvcCtgCd("D001_EVT");
        
        evt.setEvtTtl(event.getTitle());
        evt.setEvtCn(event.getContents());
        evt.setEvtStrtDtm(event.getStartDate());
        evt.setEvtEndDtm(event.getEndDate());
        evt.setRgstrCprnCd("OW"); // 기본 법인코드
        evt.setRgstrDeptCd("IT"); // 기본 부서코드
        evt.setRgstrEmpNo(event.getCreatedBy() != null ? event.getCreatedBy() : DEFAULT_USER);
        evt.setFileId(event.getImageRefId() != null ? event.getImageRefId().toString() : 
                     tvVocMapper.selectFirstEventFileId(event.getId()));
        evt.setSortOrd(999); // 기본 정렬 순서
        evt.setUseYn(Boolean.TRUE.equals(event.getEnable()) ? "Y" : "N");
        evt.setEvtPrtcDvcd("01"); // 기본 이벤트 참여 구분 코드
        evt.setInqCnt(event.getPageViewCount() != null ? event.getPageViewCount().intValue() : 0);
        evt.setEvtRgstDtm(event.getCreatedDate());
        evt.setThnlFileId(null); // 섬네일 파일 ID
        evt.setTopFxdYn("N");
        evt.setProcPrgmId("TV_MIGRATION");
        evt.setRgstProcrId(event.getCreatedBy() != null ? event.getCreatedBy() : DEFAULT_USER);
        evt.setRgstProcDtm(event.getCreatedDate());
        evt.setUpdtProcrId(event.getLastModifiedBy() != null ? event.getLastModifiedBy() : DEFAULT_USER);
        evt.setUpdtProcDtm(event.getLastModifiedDate());
        
        return evt;
    }
    
    private TobeFaqM convertTvFaqToFaqM(TvFaq faq) {
        TobeFaqM faqM = new TobeFaqM();
        
        // FAQ 카테고리 매핑 - categoryRefId 활용
        String categoryCode = tvCategoryMapper.mapCategoryById(faq.getCategoryRefId(), "FAQ");
        faqM.setSvcCtgCd(categoryCode);
        
        faqM.setFaqTtl(faq.getTitle());
        // FAQ 내용은 질문과 답변을 합쳐서 저장
        String content = "";
        if (faq.getQuestion() != null) {
            content += "[질문]\n" + faq.getQuestion() + "\n\n";
        }
        if (faq.getAnswer() != null) {
            content += "[답변]\n" + faq.getAnswer();
        }
        faqM.setFaqCn(content);
        faqM.setRgstrCprnCd("OW"); // 기본 법인코드
        faqM.setRgstrDeptCd("IT"); // 기본 부서코드
        faqM.setRgstrEmpNo(faq.getCreatedBy() != null ? faq.getCreatedBy() : DEFAULT_USER);
        faqM.setFileId(null); // 파일 ID
        faqM.setSortOrd(999); // 기본 정렬 순서
        faqM.setUseYn("published".equals(faq.getState()) ? "Y" : "N");
        faqM.setProcPrgmId("TV_MIGRATION");
        faqM.setRgstProcrId(faq.getCreatedBy() != null ? faq.getCreatedBy() : DEFAULT_USER);
        faqM.setRgstProcDtm(faq.getCreatedDate());
        faqM.setUpdtProcrId(faq.getLastModifiedBy() != null ? faq.getLastModifiedBy() : DEFAULT_USER);
        faqM.setUpdtProcDtm(faq.getLastModifiedDate());
        
        return faqM;
    }
    
    private TobeQnaM convertTvQuestionToQnaM(TvQuestion question) {
        TobeQnaM qna = new TobeQnaM();
        
        // Question 카테고리 매핑 - categoryRefId 활용
        String categoryCode = tvCategoryMapper.mapCategoryById(question.getCategoryRefId(), "QUESTION");
        qna.setSvcCtgCd(categoryCode);
        
        // QNA 필드 매핑
        qna.setQnaTtl(question.getTitle());
        qna.setQnaCn(question.getContents());
        qna.setFileId(tvVocMapper.selectFirstQuestionFileId(question.getId()));
        qna.setOpenYn("Y");
        qna.setItmCd(null); // 품목코드
        
        // 회원 정보 조회
        if (question.getMemberRefId() != null) {
            Map<String, Object> memberInfo = tvVocMapper.selectMemberInfo(question.getMemberRefId());
            if (memberInfo != null) {
                qna.setWrtrMemId((String) memberInfo.get("member_id"));
            }
        } else {
            qna.setWrtrMemId(question.getCreatedBy() != null ? question.getCreatedBy() : DEFAULT_USER);
        }
        
        qna.setQnaRgstDtm(question.getCreatedDate());
        qna.setAnsCnt(Boolean.TRUE.equals(question.getReply()) ? 1 : 0); // 답변 건수
        qna.setInqCnt(0); // 조회수
        qna.setProcPrgmId("TV_MIGRATION");
        qna.setRgstProcrId(question.getCreatedBy() != null ? question.getCreatedBy() : DEFAULT_USER);
        qna.setRgstProcDtm(question.getCreatedDate());
        qna.setUpdtProcrId(question.getLastModifiedBy() != null ? question.getLastModifiedBy() : DEFAULT_USER);
        qna.setUpdtProcDtm(question.getLastModifiedDate());
        
        return qna;
    }
    
    private TobeQnaAnsD convertTvQuestionToQnaAnsD(TvQuestion question, Long qnaId) {
        TobeQnaAnsD ans = new TobeQnaAnsD();
        
        ans.setQnaNo(qnaId);
        ans.setQnaAnsDtlNo((short) 1);
        ans.setQnaAnsDtm(question.getReplyDate());
        ans.setUpQnaAnsDtlNo(null); // 상위 답변 번호
        ans.setAnsrMemId(null); // 답변자 회원 ID
        ans.setAnsrCprnCd("OW"); // 답변자 법인코드
        ans.setAnsrDeptCd("IT"); // 답변자 부서코드
        ans.setAnsrEmpNo(question.getLastModifiedBy() != null ? question.getLastModifiedBy() : DEFAULT_USER);
        ans.setQnaAnsCn(question.getReplyContents());
        ans.setDelYn("N");
        ans.setFileId(null); // 파일 ID
        ans.setProcPrgmId("TV_MIGRATION");
        ans.setRgstProcrId(question.getLastModifiedBy() != null ? question.getLastModifiedBy() : DEFAULT_USER);
        ans.setRgstProcDtm(question.getReplyDate());
        ans.setUpdtProcrId(question.getLastModifiedBy() != null ? question.getLastModifiedBy() : DEFAULT_USER);
        ans.setUpdtProcDtm(question.getReplyDate());
        
        return ans;
    }
    
    
    
    public Map<String, Object> getTotalStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", totalCount.get());
        stats.put("processed", processedCount.get());
        stats.put("success", successCount.get());
        stats.put("fail", failCount.get());
        stats.put("progressPercent", totalCount.get() > 0 ? 
            (processedCount.get() * 100.0 / totalCount.get()) : 0);
        
        // TV VOC 통계 추가
        Map<String, Object> tvStats = tvVocMapper.selectMigrationStatistics();
        stats.put("tvVocStatistics", tvStats);
        
        return stats;
    }
    
    public Map<String, Object> getMigrationStatus() {
        Map<String, Object> status = getTotalStatistics();
        status.put("failedItemsCount", failedItems.size());
        status.put("duplicateItemsCount", duplicateItems.size());
        return status;
    }
}
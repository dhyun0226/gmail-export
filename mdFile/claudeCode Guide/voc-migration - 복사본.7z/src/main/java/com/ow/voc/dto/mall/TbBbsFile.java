package com.ow.voc.dto.mall;

import lombok.Data;
import java.util.Date;

@Data
public class TbBbsFile {
    private Long bbsFileSeq;
    private Long bbsSeq;
    private String fileNm;
    private String realFileNm;
    private Long fileSize;
    private String fileType;
    private Date regDt;
    private String regId;
    private String fileGroup;
}
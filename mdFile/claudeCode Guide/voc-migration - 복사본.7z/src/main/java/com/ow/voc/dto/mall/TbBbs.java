package com.ow.voc.dto.mall;

import lombok.Data;
import java.util.Date;

@Data
public class TbBbs {
    private Long bbsSeq;
    private Long upBbsSeq;
    private Long bbsNo;
    private String bbsCd;
    private Long categorySeq;
    private String title;
    private String content;
    private String noticeYn;
    private String secretYn;
    private String passwd;
    private Integer ord;
    private String delYn;
    private String regIp;
    private Date regDt;
    private String regId;
    private String regIdNm;
    private String regIdNickNm;
    private String regIdGroupCd;
    private String regIdGroupNm;
    private Date modDt;
    private String modId;
    private String commCd;
    private Long hits;
    private String replyYn;
    private String completeYn;
}
package com.ow.voc.dto.mall;

import lombok.Data;
import java.util.Date;

@Data
public class TbBbsRe {
    private Long bbsReSeq;
    private Long bbsSeq;
    private String regIp;
    private Date regDt;
    private String regId;
    private String regIdNm;
    private String regIdNickNm;
    private String regIdGroupCd;
    private String regIdGroupNm;
}
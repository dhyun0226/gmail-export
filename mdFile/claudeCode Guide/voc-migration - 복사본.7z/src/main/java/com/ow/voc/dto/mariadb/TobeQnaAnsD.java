package com.ow.voc.dto.mariadb;

import lombok.Data;
import java.util.Date;

@Data
public class TobeQnaAnsD {
    private Long qnaNo;             // QNA_NO
    private Short qnaAnsDtlNo;      // QNA_ANS_DTL_NO
    private Date qnaAnsDtm;         // QNA_ANS_DTM (QNA답변일시)
    private Short upQnaAnsDtlNo;    // UP_QNA_ANS_DTL_NO (상위QNA답변상세번호)
    private String ansrMemId;       // ANSR_MEM_ID (답변자회원ID)
    private String ansrCprnCd;      // ANSR_CPRN_CD (답변자법인코드)
    private String ansrDeptCd;      // ANSR_DEPT_CD (답변자부서코드)
    private String ansrEmpNo;       // ANSR_EMP_NO (답변자사원번호)
    private String qnaAnsCn;        // QNA_ANS_CN
    private String delYn;           // DEL_YN
    private String fileId;          // FILE_ID
    private String procPrgmId;      // PROC_PRGM_ID
    private String rgstProcrId;     // RGST_PROCR_ID
    private Date rgstProcDtm;       // RGST_PROC_DTM
    private String updtProcrId;     // UPDT_PROCR_ID
    private Date updtProcDtm;       // UPDT_PROC_DTM
}
package com.ow.voc.dto.oracle;

import lombok.Data;
import java.util.Date;

/**
 * TB_HANARO_BOARD_INFO 테이블 DTO
 * 하나로게시판 정보 - 실제 DDL 기반
 */
@Data
public class HanaroBoardInfo {
    private String boardCode;        // DB -> boardCode (매핑용)
    private String boardNm;          // DB_NM -> boardNm (매핑용)
    private String dbDesc;           // DB_DESC
    private String replyYn;          // REPLY_YN
    private String memoYn;           // MEMO_YN
    private String useYn;            // USE_YN
    private String dbNickNm;         // DB_NICK_NM
}
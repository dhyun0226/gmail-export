package com.ow.voc.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Hanaro VOC 카테고리를 TOBE 카테고리 코드로 매핑하는 유틸리티 클래스
 */
@Slf4j
@Component
public class HanaroCategoryMapper {
    
    // ASIS 카테고리 매핑 테이블
    private static final Map<String, String> CATEGORY_NAME_MAPPING = new HashMap<>();
    private static final Map<String, String> DB_TYPE_MAPPING = new HashMap<>();
    
    static {
        // 카테고리명 매핑 (소프트웨어/제품명)
        CATEGORY_NAME_MAPPING.put("두번에", "001");        // 두번에/하나로
        CATEGORY_NAME_MAPPING.put("하나로", "001");        // 두번에/하나로
        CATEGORY_NAME_MAPPING.put("OneClick", "002");     // OneClick
        CATEGORY_NAME_MAPPING.put("보험정보", "003");       // 보험정보
        CATEGORY_NAME_MAPPING.put("V-Ceph", "004");      // V-Ceph
        CATEGORY_NAME_MAPPING.put("One2", "005");        // One2
        CATEGORY_NAME_MAPPING.put("One3", "006");        // One3
        CATEGORY_NAME_MAPPING.put("공통", "999");          // 기타/공통
        
        // 새로운 DB 타입 매핑 규칙
        // 마이그레이션 대상: NOTI, FAQ, QNA, STIP, ITIP
        DB_TYPE_MAPPING.put("FAQ", "FAQ");               // FAQ
        DB_TYPE_MAPPING.put("QNA", "INQ");               // 1:1문의
        DB_TYPE_MAPPING.put("NOTI", "NTF");              // 공지사항
        DB_TYPE_MAPPING.put("STIP", "INQ");              // 특별공지 → 1:1문의로 변경
        DB_TYPE_MAPPING.put("ITIP", "INQ");              // ITIP → 1:1문의로 변경
        
        // 마이그레이션 제외 대상들 (매핑하지 않음)
        // ONLINEHELP, DOWN, REVIEW, CUSTM 등은 제외
    }
    
    /**
     * ASIS 카테고리를 TOBE 카테고리 코드로 변환
     * 
     * @param categoryName 카테고리명 (제품명)
     * @param dbType DB 타입
     * @return TOBE 카테고리 코드 (마이그레이션 대상이 아닌 경우 null 반환)
     */
    public String mapCategory(String categoryName, String dbType) {
        if (categoryName == null || dbType == null) {
            log.warn("카테고리명 또는 DB타입이 null입니다. categoryName: {}, dbType: {}", categoryName, dbType);
            return null;
        }
        
        // 마이그레이션 대상 여부 확인
        if (!isMigrationTarget(dbType)) {
            log.debug("마이그레이션 대상이 아닌 DB타입: {}", dbType);
            return null;
        }
        
        // 카테고리명 매핑
        String categoryNum = CATEGORY_NAME_MAPPING.get(categoryName);
        if (categoryNum == null) {
            log.warn("매핑되지 않은 카테고리명: {}. 유사 카테고리 탐색 시도", categoryName);
            categoryNum = findSimilarCategoryName(categoryName);
            if (categoryNum == null) {
                categoryNum = "999"; // 기타
                log.warn("유사 카테고리를 찾을 수 없습니다. 기타로 매핑: {}", categoryName);
            }
        }
        
        // DB 타입 매핑
        String mappedDbType = DB_TYPE_MAPPING.get(dbType.toUpperCase());
        if (mappedDbType == null) {
            log.warn("매핑되지 않은 DB타입: {}. 마이그레이션 제외", dbType);
            return null;
        }
        
        // 최종 카테고리 코드 생성
        String categoryCode = "D005_" + mappedDbType + "_" + categoryNum;
        
        log.debug("카테고리 매핑 완료: {}:{} -> {}", categoryName, dbType, categoryCode);
        return categoryCode;
    }
    
    /**
     * 유사한 카테고리명 찾기
     */
    private String findSimilarCategoryName(String categoryName) {
        String lowerName = categoryName.toLowerCase();
        
        // 키워드 기반 매칭
        if (lowerName.contains("하나로") || lowerName.contains("두번에")) {
            return "001";
        }
        if (lowerName.contains("oneclick") || lowerName.contains("원클릭")) {
            return "002";
        }
        if (lowerName.contains("보험")) {
            return "003";
        }
        if (lowerName.contains("ceph") || lowerName.contains("v-ceph")) {
            return "004";
        }
        if (lowerName.contains("one2")) {
            return "005";
        }
        if (lowerName.contains("one3")) {
            return "006";
        }
        if (lowerName.contains("공통") || lowerName.contains("일반")) {
            return "999";
        }
        
        return null;
    }
    
    /**
     * 카테고리 ID로부터 TOBE 카테고리 코드 매핑
     * 새로운 카테고리 규칙에 따라 마이그레이션 대상만 매핑
     */
    public String mapCategoryById(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        
        // 새로운 카테고리 데이터 기반 매핑 (마이그레이션 대상만)
        Map<Long, String> idMapping = new HashMap<>();
        
        // 마이그레이션 대상: NOTI, FAQ, QNA, STIP, ITIP
        idMapping.put(35L, "D005_INQ_002");   // OneClick QNA
        idMapping.put(19L, "D005_INQ_001");   // 두번에 QNA  
        idMapping.put(11L, "D005_FAQ_001");   // 두번에 FAQ
        idMapping.put(35L, "D005_NTF_002");   // OneClick NOTI (중복 ID, 타입으로 구분 필요)
        idMapping.put(100L, "D005_FAQ_999");  // 공통 FAQ
        idMapping.put(107L, "D005_INQ_999");  // 공통 ITIP (QNA로 매핑)
        idMapping.put(106L, "D005_INQ_999");  // 공통 STIP (QNA로 매핑)
        idMapping.put(56L, "D005_INQ_005");   // One2 QNA
        idMapping.put(46L, "D005_NTF_006");   // One3 NOTI
        idMapping.put(4L, "D005_NTF_001");    // 두번에 NOTI
        idMapping.put(13L, "D005_FAQ_004");   // V-Ceph FAQ
        
        // 마이그레이션 제외 대상들은 매핑하지 않음
        // ONLINEHELP(9), DOWN(34, 49, 102, 16, 18, 17), REVIEW(111) 등
        
        String mappedCode = idMapping.get(categoryId);
        if (mappedCode != null) {
            log.debug("카테고리 ID 매핑: {} -> {}", categoryId, mappedCode);
            return mappedCode;
        }
        
        log.debug("마이그레이션 제외 또는 매핑되지 않은 카테고리 ID: {}", categoryId);
        return null;
    }
    
    /**
     * 카테고리명과 DB타입으로 카테고리 코드 조합 생성
     */
    public String buildCategoryCode(String categoryName, String dbType) {
        String categoryNum = CATEGORY_NAME_MAPPING.getOrDefault(categoryName, "999");
        String mappedDbType = DB_TYPE_MAPPING.getOrDefault(dbType.toUpperCase(), "INQ");
        return "D005_" + mappedDbType + "_" + categoryNum;
    }
    
    /**
     * DB 타입을 TOBE 카테고리 타입으로 변환
     */
    public String mapDbTypeToTobeType(String dbType) {
        if (dbType == null) {
            return "INQ";
        }
        return DB_TYPE_MAPPING.getOrDefault(dbType.toUpperCase(), "INQ");
    }
    
    /**
     * 마이그레이션 대상 DB 타입인지 확인
     * 
     * @param dbType DB 타입
     * @return 마이그레이션 대상 여부
     */
    public boolean isMigrationTarget(String dbType) {
        if (dbType == null) {
            return false;
        }
        
        String upperDbType = dbType.toUpperCase();
        return "NOTI".equals(upperDbType) || 
               "FAQ".equals(upperDbType) || 
               "QNA".equals(upperDbType) || 
               "STIP".equals(upperDbType) || 
               "ITIP".equals(upperDbType);
    }
    
    /**
     * 기본 카테고리 코드 반환 (deprecated - 새 규칙에서는 null 반환)
     */
    @Deprecated
    private String getDefaultCategory() {
        return null; // 새 규칙에서는 마이그레이션 대상이 아니면 null
    }
    
    /**ㄱ
     * 카테고리명이 특정 제품인지 확인
     */
    public boolean isProductCategory(String categoryName) {
        return CATEGORY_NAME_MAPPING.containsKey(categoryName);
    }
    
    /**
     * 지원되는 모든 카테고리명 목록 반환
     */
    public Map<String, String> getSupportedCategories() {
        return new HashMap<>(CATEGORY_NAME_MAPPING);
    }
    
    /**
     * 지원되는 모든 DB 타입 목록 반환
     */
    public Map<String, String> getSupportedDbTypes() {
        return new HashMap<>(DB_TYPE_MAPPING);
    }
}
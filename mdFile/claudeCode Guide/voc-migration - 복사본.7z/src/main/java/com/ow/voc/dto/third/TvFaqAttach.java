package com.ow.voc.dto.third;

import lombok.Data;
import java.util.Date;

@Data
public class TvFaqAttach {
    private Long id;
    private Long faqRefId;
    private Long fileRefId;
    private String createdBy;
    private Date createdDate;
    private String lastModifiedBy;
    private Date lastModifiedDate;
}
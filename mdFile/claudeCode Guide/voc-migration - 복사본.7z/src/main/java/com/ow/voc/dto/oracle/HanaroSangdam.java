package com.ow.voc.dto.oracle;

import lombok.Data;

import java.sql.Timestamp;

/**
 * TB_HANARO_SANGDAM 테이블 DTO
 * 제품상담게시판 - 스키마 문서 기반
 */
@Data
public class HanaroSangdam {
    private Long sangSeq;            // NO -> sangSeq (매핑용)
    private String jepum;            // JEPUM
    private String askKind;          // ASK_KIND
    private String licenceNo;        // LICENCE_NO
    private String yoyangNo;         // YOYANG_NO
    private String bossName;         // BOSS_NAME
    private String telNo;            // TEL_NO
    private String denNm;            // DEN_NM
    private String name;             // NAME
    private String businessNo;       // BUSINESS_NO
    private String zipNo;            // ZIP_NO
    private String addr;             // ADDR
    private String addrDetail;       // ADDR_DETAIL
    private String emailAdr;         // EMAIL_ADR
    private String mailRecvYn;       // MAIL_RECV_YN
    private String mobileNo;         // MOBILE_NO
    private String replyGubun;       // REPLY_GUBUN
    private String content;          // CONTENT
    private Timestamp registDt;      // REGIST_DT
    private String answer;           // ANSWER
    private Timestamp answerDt;      // ANSWER_DT
    private String userid;           // USERID
    private String delYn;            // DEL_YN
    private String agreeYn;          // AGREE_YN
}
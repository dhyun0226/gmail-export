package com.ow.voc.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

/**
 * Third MyBatis Configuration for DTV MariaDB
 * This configuration sets up MyBatis for the third data source (DTV database)
 */
@Configuration
@EnableTransactionManagement
@MapperScan(
        basePackages = "com.ow.voc.mapper.third",
        sqlSessionFactoryRef = "thirdSqlSessionFactory"
)
public class ThirdMyBatisConfig {

    /**
     * Third SqlSessionFactory
     * Creates SqlSessionFactory for third datasource with MyBatis configuration
     */
    @Bean(name = "thirdSqlSessionFactory")
    @ConfigurationProperties(prefix = "mybatis")
    public SqlSessionFactory thirdSqlSessionFactory(
            @Qualifier("thirdDataSource") DataSource dataSource,
            ApplicationContext applicationContext) throws Exception {
        
        SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        
        // Set mapper locations for third datasource
        sessionFactory.setMapperLocations(
                applicationContext.getResources("classpath:mapper/third/*.xml")
        );
        
        // Set type aliases package
        sessionFactory.setTypeAliasesPackage("com.ow.voc.dto.third");
        
        // Configure MyBatis settings
        org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setCacheEnabled(false);
        configuration.setUseGeneratedKeys(true);
        sessionFactory.setConfiguration(configuration);
        
        return sessionFactory.getObject();
    }

    /**
     * Third SqlSessionTemplate
     * Creates SqlSessionTemplate for third datasource
     */
    @Bean(name = "thirdSqlSessionTemplate")
    public SqlSessionTemplate thirdSqlSessionTemplate(
            @Qualifier("thirdSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    /**
     * Third Transaction Manager
     * Creates transaction manager for third datasource
     */
    @Bean(name = "thirdTransactionManager")
    public PlatformTransactionManager thirdTransactionManager(
            @Qualifier("thirdDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
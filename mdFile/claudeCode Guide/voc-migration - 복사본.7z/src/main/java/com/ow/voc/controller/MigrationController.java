package com.ow.voc.controller;

import com.ow.voc.service.MigrationService;
import com.ow.voc.service.HanaroMigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Tag(name = "Migration", description = "VOC 데이터 마이그레이션 API")
@RestController
@RequestMapping("/api/migration")
@RequiredArgsConstructor
public class MigrationController {

    private final MigrationService migrationService;
    private final HanaroMigrationService hanaroMigrationService;

    @Operation(summary = "전체 데이터 마이그레이션", description = "Oracle에서 MariaDB로 모든 VOC 데이터를 마이그레이션합니다.")
    @PostMapping("/all")
    public ResponseEntity<Map<String, Object>> migrateAll() {
        log.info("전체 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = migrationService.migrateAll();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "공지사항 마이그레이션", description = "공지사항 데이터만 마이그레이션합니다.")
    @PostMapping("/notices")
    public ResponseEntity<Map<String, Object>> migrateNotices() {
        log.info("공지사항 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = migrationService.migrateNotices();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "공지사항 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("공지사항 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "공지사항 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "FAQ 마이그레이션", description = "FAQ 데이터만 마이그레이션합니다.")
    @PostMapping("/faqs")
    public ResponseEntity<Map<String, Object>> migrateFAQs() {
        log.info("FAQ 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = migrationService.migrateFAQs();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "FAQ 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("FAQ 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "FAQ 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "QNA 마이그레이션", description = "QNA 데이터와 답변을 마이그레이션합니다.")
    @PostMapping("/qnas")
    public ResponseEntity<Map<String, Object>> migrateQnAs() {
        log.info("QNA 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = migrationService.migrateQnAs();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "QNA 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("QNA 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "QNA 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "이벤트 마이그레이션", description = "이벤트 데이터만 마이그레이션합니다.")
    @PostMapping("/events")
    public ResponseEntity<Map<String, Object>> migrateEvents() {
        log.info("이벤트 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = migrationService.migrateEvents();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "이벤트 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("이벤트 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "이벤트 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "마이그레이션 상태 조회", description = "현재 마이그레이션 진행 상태를 조회합니다.")
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getMigrationStatus() {
        log.info("마이그레이션 상태 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> status = migrationService.getMigrationStatus();
            response.put("success", true);
            response.put("data", status);
            response.put("message", "마이그레이션 상태 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("마이그레이션 상태 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "마이그레이션 상태 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "마이그레이션 건강 체크", description = "마이그레이션 서비스 상태를 확인합니다.")
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "VOC Migration Service");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "데이터베이스 연결 상태 확인", description = "모든 데이터베이스의 연결 상태를 확인합니다.")
    @GetMapping("/connections")
    public ResponseEntity<Map<String, Object>> checkConnections() {
        log.info("데이터베이스 연결 상태 확인 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> connections = migrationService.checkAllConnections();
            response.put("success", true);
            response.put("data", connections);
            response.put("message", "데이터베이스 연결 상태 확인 완료");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("데이터베이스 연결 상태 확인 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "데이터베이스 연결 상태 확인 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "하나로 데이터 마이그레이션", description = "하나로 VOC 시스템의 데이터를 마이그레이션합니다.")
    @PostMapping("/hanaro")
    public ResponseEntity<Map<String, Object>> migrateHanaro() {
        log.info("하나로 데이터 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateAllHanaroData();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "하나로 데이터 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("하나로 데이터 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "하나로 데이터 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }
}
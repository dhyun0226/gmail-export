package com.ow.voc.dto.third;

import lombok.Data;
import java.util.Date;

@Data
public class TvNotice {
    private Long id;
    private String title;
    private Boolean enable;
    private Boolean fixedAtTop;
    private String state;
    private Boolean notify;
    private String contents;
    private Long pageViewCount;
    private String createdBy;
    private Date createdDate;
    private String lastModifiedBy;
    private Date lastModifiedDate;
}
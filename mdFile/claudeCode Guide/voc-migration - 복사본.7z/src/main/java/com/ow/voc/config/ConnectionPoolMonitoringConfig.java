package com.ow.voc.config;

import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.metrics.IMetricsTracker;
import com.zaxxer.hikari.metrics.MetricsTrackerFactory;
import com.zaxxer.hikari.metrics.PoolStats;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

/**
 * HikariCP 커넥션 풀 모니터링 설정
 */
@Slf4j
@Configuration
public class ConnectionPoolMonitoringConfig {
    
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    
    /**
     * 커스텀 메트릭 트래커 팩토리
     */
    @Bean
    public MetricsTrackerFactory metricsTrackerFactory() {
        return new MetricsTrackerFactory() {
            @Override
            public IMetricsTracker create(String poolName, PoolStats poolStats) {
                return new CustomMetricsTracker(poolName, poolStats);
            }
        };
    }
    
    /**
     * 커스텀 메트릭 트래커 구현체
     */
    public static class CustomMetricsTracker implements IMetricsTracker {
        
        private final String poolName;
        private final PoolStats poolStats;
        private long connectionCreatedCount = 0;
        private long connectionAcquiredCount = 0;
        private long connectionTimeoutCount = 0;
        private long lastLogTime = System.currentTimeMillis();
        
        public CustomMetricsTracker(String poolName, PoolStats poolStats) {
            this.poolName = poolName;
            this.poolStats = poolStats;
            log.info("🔧 메트릭 트래커 초기화: 풀명={}", poolName);
        }
        
        @Override
        public void recordConnectionCreatedMillis(long connectionCreatedMillis) {
            connectionCreatedCount++;
            log.debug("🔗 새 커넥션 생성: 풀={}, 소요시간={}ms, 총생성수={}", 
                poolName, connectionCreatedMillis, connectionCreatedCount);
            
            if (connectionCreatedMillis > 5000) { // 5초 이상
                log.warn("⚠️ 커넥션 생성 지연: 풀={}, 소요시간={}ms", poolName, connectionCreatedMillis);
            }
        }
        
        @Override
        public void recordConnectionAcquiredNanos(long elapsedAcquiredNanos) {
            long elapsedMs = TimeUnit.NANOSECONDS.toMillis(elapsedAcquiredNanos);
            connectionAcquiredCount++;
            
            // 주기적 로깅 (100회마다 또는 10초마다)
            if (connectionAcquiredCount % 100 == 0 || 
                System.currentTimeMillis() - lastLogTime > 10000) {
                
                log.info("📊 커넥션 획득 통계: 풀={}, 획득수={}, 최근소요시간={}ms, " +
                    "활성={}, 대기={}, 전체={}", 
                    poolName, connectionAcquiredCount, elapsedMs,
                    poolStats.getActiveConnections(),
                    poolStats.getIdleConnections(), 
                    poolStats.getTotalConnections());
                    
                lastLogTime = System.currentTimeMillis();
            }
            
            // 느린 커넥션 획득 경고
            if (elapsedMs > 3000) { // 3초 이상
                log.warn("🐌 커넥션 획득 지연: 풀={}, 소요시간={}ms, 활성커넥션={}/{}", 
                    poolName, elapsedMs, 
                    poolStats.getActiveConnections(), poolStats.getTotalConnections());
            }
        }
        
        @Override
        public void recordConnectionUsageMillis(long elapsedBorrowedMillis) {
            // 커넥션 사용 시간이 너무 긴 경우 경고
            if (elapsedBorrowedMillis > 30000) { // 30초 이상
                log.warn("⏰ 장시간 커넥션 사용: 풀={}, 사용시간={}ms", 
                    poolName, elapsedBorrowedMillis);
            }
        }
        
        @Override
        public void recordConnectionTimeout() {
            connectionTimeoutCount++;
            log.error("🚨 커넥션 타임아웃 발생! 풀={}, 타임아웃수={}, 현재상태[활성={}, 대기={}, 전체={}]", 
                poolName, connectionTimeoutCount,
                poolStats.getActiveConnections(),
                poolStats.getIdleConnections(),
                poolStats.getTotalConnections());
                
            // 연속된 타임아웃 발생 시 추가 경고
            if (connectionTimeoutCount % 5 == 0) {
                log.error("🔴 연속 커넥션 타임아웃 {}회 발생! 시스템 점검 필요", connectionTimeoutCount);
            }
        }
        
        // 메트릭 정보 제공 메서드들
        public long getConnectionCreatedCount() { return connectionCreatedCount; }
        public long getConnectionAcquiredCount() { return connectionAcquiredCount; }
        public long getConnectionTimeoutCount() { return connectionTimeoutCount; }
    }
    
    /**
     * Secondary DataSource에 메트릭 트래커 적용
     */
    public void configureSecondaryDataSourceMonitoring(@Qualifier("secondaryDataSource") DataSource dataSource) {
        if (dataSource instanceof HikariDataSource) {
            HikariDataSource hikariDataSource = (HikariDataSource) dataSource;
            
            // 메트릭 트래커 설정
            hikariDataSource.setMetricsTrackerFactory(metricsTrackerFactory());
            
            // 추가적인 모니터링 설정
            hikariDataSource.setLeakDetectionThreshold(60000); // 1분
            
            log.info("✅ Secondary DataSource 모니터링 설정 완료: {}", 
                hikariDataSource.getPoolName());
        }
    }
    
    /**
     * 커넥션 풀 상태를 주기적으로 로깅하는 스케줄러용 메서드
     */
    public void logPoolStatus(DataSource dataSource) {
        if (dataSource instanceof HikariDataSource) {
            HikariDataSource hikariDataSource = (HikariDataSource) dataSource;
            
            try {
                log.info("=== 정기 커넥션 풀 상태 보고 [{}] ===", 
                    LocalDateTime.now().format(formatter));
                log.info("풀 이름: {}", hikariDataSource.getPoolName());
                
                if (hikariDataSource.getHikariPoolMXBean() != null) {
                    var mxBean = hikariDataSource.getHikariPoolMXBean();
                    log.info("활성 커넥션: {}/{}", mxBean.getActiveConnections(), mxBean.getTotalConnections());
                    log.info("대기 커넥션: {}", mxBean.getIdleConnections());
                    log.info("대기 스레드: {}", mxBean.getThreadsAwaitingConnection());
                    
                    // 상태별 알림
                    float utilizationRate = (float) mxBean.getActiveConnections() / mxBean.getTotalConnections();
                    if (utilizationRate > 0.9f) {
                        log.warn("🚨 커넥션 풀 사용률 {}% - 풀 크기 확장 고려 필요", 
                            String.format("%.1f", utilizationRate * 100));
                    } else if (utilizationRate < 0.1f && mxBean.getTotalConnections() > 5) {
                        log.info("💡 커넥션 풀 사용률 {}% - 풀 크기 축소 고려 가능", 
                            String.format("%.1f", utilizationRate * 100));
                    }
                }
                
            } catch (Exception e) {
                log.error("커넥션 풀 상태 조회 실패: {}", e.getMessage());
            }
        }
    }
}
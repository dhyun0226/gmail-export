package com.ow.voc.dto.mariadb;

import lombok.Data;
import java.util.Date;

@Data
public class TobeQnaM {
    private Long qnaNo;             // QNA_NO (insert 시 auto-generated)
    private String svcCtgCd;        // SVC_CTG_CD
    private String wrtrMemId;       // WRTR_MEM_ID (작성자회원ID)
    private String itmCd;           // ITM_CD (품목코드)
    private String openYn;          // OPEN_YN
    private String qnaTtl;          // QNA_TTL
    private String qnaCn;           // QNA_CN
    private Date qnaRgstDtm;        // QNA_RGST_DTM (QNA등록일시)
    private String fileId;          // FILE_ID
    private Integer ansCnt;         // ANS_CNT (답변건수)
    private Integer inqCnt;         // INQ_CNT
    private String procPrgmId;      // PROC_PRGM_ID
    private String rgstProcrId;     // RGST_PROCR_ID
    private Date rgstProcDtm;       // RGST_PROC_DTM
    private String updtProcrId;     // UPDT_PROCR_ID
    private Date updtProcDtm;       // UPDT_PROC_DTM
}
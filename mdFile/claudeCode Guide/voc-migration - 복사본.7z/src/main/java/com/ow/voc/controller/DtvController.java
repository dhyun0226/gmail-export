package com.ow.voc.controller;

import com.ow.voc.service.DtvService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DTV Database Controller
 * REST API endpoints for DTV database operations
 */
@Slf4j
@Tag(name = "DTV Database", description = "DTV 데이터베이스 연결 및 조회 API")
@RestController
@RequestMapping("/api/dtv")
@RequiredArgsConstructor
public class DtvController {

    private final DtvService dtvService;

    @Operation(summary = "DTV 데이터베이스 연결 테스트", description = "DTV 데이터베이스 연결 상태를 확인합니다.")
    @GetMapping("/test-connection")
    public ResponseEntity<Map<String, Object>> testConnection() {
        log.info("Testing DTV database connection");
        
        Map<String, Object> result = dtvService.testConnection();
        
        if ("connected".equals(result.get("status"))) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.internalServerError().body(result);
        }
    }

    @Operation(summary = "DTV 테이블 목록 조회", description = "DTV 데이터베이스의 모든 테이블 목록을 조회합니다.")
    @GetMapping("/tables")
    public ResponseEntity<Map<String, Object>> getAllTables() {
        log.info("Fetching all tables from DTV database");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            List<String> tables = dtvService.getAllTables();
            response.put("success", true);
            response.put("data", tables);
            response.put("count", tables.size());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error fetching tables", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "특정 테이블 정보 조회", description = "DTV 데이터베이스의 특정 테이블 정보를 조회합니다.")
    @GetMapping("/tables/{tableName}")
    public ResponseEntity<Map<String, Object>> getTableInfo(
            @Parameter(description = "테이블명", required = true)
            @PathVariable String tableName) {
        
        log.info("Fetching information for table: {}", tableName);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> tableInfo = dtvService.getTableInfo(tableName);
            
            if (tableInfo != null && !tableInfo.isEmpty()) {
                response.put("success", true);
                response.put("data", tableInfo);
            } else {
                response.put("success", false);
                response.put("message", "Table not found: " + tableName);
                return ResponseEntity.notFound().build();
            }
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error fetching table info", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "데이터베이스 통계 조회", description = "DTV 데이터베이스의 전체 통계 정보를 조회합니다.")
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getDatabaseStatistics() {
        log.info("Fetching DTV database statistics");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> stats = dtvService.getDatabaseStatistics();
            response.put("success", true);
            response.put("data", stats);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error fetching database statistics", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "커스텀 쿼리 실행", description = "DTV 데이터베이스에 SELECT 쿼리를 실행합니다. (관리자 전용)")
    @PostMapping("/query")
    public ResponseEntity<Map<String, Object>> executeQuery(
            @Parameter(description = "실행할 SELECT 쿼리", required = true)
            @RequestBody Map<String, String> request) {
        
        String query = request.get("query");
        log.info("Executing custom query on DTV database");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (query == null || query.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Query cannot be empty");
                return ResponseEntity.badRequest().body(response);
            }
            
            List<Map<String, Object>> results = dtvService.executeQuery(query);
            response.put("success", true);
            response.put("data", results);
            response.put("count", results.size());
            
            return ResponseEntity.ok(response);
            
        } catch (IllegalArgumentException e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
            
        } catch (Exception e) {
            log.error("Error executing query", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "DTV 서비스 상태 확인", description = "DTV 서비스의 상태를 확인합니다.")
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "DTV Database Service");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}
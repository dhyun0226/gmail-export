package com.ow.voc.dto.third;

import lombok.Data;
import java.util.Date;

@Data
public class TvEvent {
    private Long id;
    private String contents;
    private Boolean enable;
    private String state;
    private Boolean notify;
    private Long pageViewCount;
    private String title;
    private Date startDate;
    private Date endDate;
    private Date resultDate;
    private Long imageRefId;
    private String createdBy;
    private Date createdDate;
    private String lastModifiedBy;
    private Date lastModifiedDate;
}
package com.ow.voc.dto.oracle;

import lombok.Data;
import java.util.Date;

/**
 * TB_HANARO_BOARD 테이블 DTO
 * 하나로게시물정보 - 스키마 문서 기반
 */
@Data
public class HanaroBoard {
    private Long boardSeq;        // NO -> boardSeq (매핑용)
    private String boardCode;     // DB -> boardCode (매핑용)
    private Integer cateCode;     // CATEGORY -> cateCode (매핑용)
    private String userId;        // USERID
    private String title;         // SUBJECT -> title (매핑용)
    private String contents;      // CONTENT -> contents (매핑용)
    private Integer showYn;       // UMU -> showYn (매핑용, 공개:1, 비공개:0)
    private Integer mainYn;       // MAIN_YN (헤드라인 적용:1, 미적용:0)
    private Long viewCnt;         // HIT -> viewCnt (매핑용)
    private Date regiDate;        // REGDATE -> regiDate (매핑용)
    private Date modiDate;        // UPDATE_DATE -> modiDate (매핑용)
    private Integer boardScore;   // RECOMMEND -> boardScore (매핑용)
    private Integer notiYn;       // NOTI_YN (공지올리기:1, 공지내리기:0)
    private String updater;       // UPDATER
    private Integer html;         // HTML (TEXT:0, HTML:1)
    private String secret;        // SECRET (비밀글 Y/N)
    private Integer isHidden;     // IS_HIDDEN (숨김여부)
    private Integer bbsNo;        // BBS_NO
    private String qna;           // QNA (QNA 답변)
    private Date qnaDate;         // QNA_DATE
    private String today;         // TODAY (TODAY 이슈)
    private String onlinehelp1;   // ONLINEHELP1
    private String onlinehelp2;   // ONLINEHELP2
}
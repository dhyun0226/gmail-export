package com.ow.voc.dto.mariadb;

import lombok.Data;
import java.util.Date;

@Data
public class TobeEvtPrtcD {
    private Long evtNo;             // EVT_NO (이벤트번호)
    private Date evtPrtcDtm;        // EVT_PRTC_DTM (이벤트참여일시 - Primary Key)
    private String prtcrMemId;      // PRTCR_MEM_ID (참여자회원ID)
    private String evtPrtcCn;       // EVT_PRTC_CN (이벤트참여내용)
    private String delYn;           // DEL_YN (삭제여부)
    private String fileId;          // FILE_ID (파일ID)
    private String procPrgmId;      // PROC_PRGM_ID (처리프로그램ID)
    private String rgstProcrId;     // RGST_PROCR_ID (등록처리자ID)
    private Date rgstProcDtm;       // RGST_PROC_DTM (등록처리일시)
    private String updtProcrId;     // UPDT_PROCR_ID (수정처리자ID)
    private Date updtProcDtm;       // UPDT_PROC_DTM (수정처리일시)
}
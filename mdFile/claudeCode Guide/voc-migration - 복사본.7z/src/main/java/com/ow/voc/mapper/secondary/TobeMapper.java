package com.ow.voc.mapper.secondary;

import com.ow.voc.dto.mariadb.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface TobeMapper {
    
    // 이벤트 관련
    int insertEvtM(TobeEvtM evt);
    int updateEvtM(TobeEvtM evt);
    int deleteEvtM(@Param("evtNo") Long evtNo);
    TobeEvtM selectEvtM(@Param("evtNo") Long evtNo);
    List<TobeEvtM> selectEvtMList();
    
    // 이벤트 참여 관련
    int insertEvtPrtcD(TobeEvtPrtcD prtc);
    int updateEvtPrtcD(TobeEvtPrtcD prtc);
    int deleteEvtPrtcD(@Param("evtNo") Long evtNo, @Param("evtPrtcDtm") String evtPrtcDtm);
    List<TobeEvtPrtcD> selectEvtPrtcDList(@Param("evtNo") Long evtNo);
    
    // FAQ 관련
    int insertFaqM(TobeFaqM faq);
    int updateFaqM(TobeFaqM faq);
    int deleteFaqM(@Param("faqNo") Long faqNo);
    TobeFaqM selectFaqM(@Param("faqNo") Long faqNo);
    List<TobeFaqM> selectFaqMList();
    
    // 공지사항 관련
    int insertNtfyM(TobeNtfyM ntfy);
    int updateNtfyM(TobeNtfyM ntfy);
    int deleteNtfyM(@Param("ntfyNo") Long ntfyNo);
    TobeNtfyM selectNtfyM(@Param("ntfyNo") Long ntfyNo);
    List<TobeNtfyM> selectNtfyMList();
    
    // QNA 관련
    int insertQnaM(TobeQnaM qna);
    int updateQnaM(TobeQnaM qna);
    int deleteQnaM(@Param("qnaNo") Long qnaNo);
    TobeQnaM selectQnaM(@Param("qnaNo") Long qnaNo);
    List<TobeQnaM> selectQnaMList();
    
    // QNA 답변 관련
    int insertQnaAnsD(TobeQnaAnsD ans);
    int updateQnaAnsD(TobeQnaAnsD ans);
    int deleteQnaAnsD(@Param("qnaNo") Long qnaNo, @Param("qnaAnsDtlNo") Short qnaAnsDtlNo);
    List<TobeQnaAnsD> selectQnaAnsDList(@Param("qnaNo") Long qnaNo);
    
    // 배치 삽입 (성능 향상을 위해)
    int insertEvtMBatch(@Param("list") List<TobeEvtM> list);
    int insertFaqMBatch(@Param("list") List<TobeFaqM> list);
    int insertNtfyMBatch(@Param("list") List<TobeNtfyM> list);
    int insertQnaMBatch(@Param("list") List<TobeQnaM> list);
    int insertQnaAnsDatch(@Param("list") List<TobeQnaAnsD> list);
    
    // 중복 체크
    int checkDuplicateEvt(@Param("svcCtgCd") String svcCtgCd, @Param("evtTtl") String evtTtl);
    int checkDuplicateFaq(@Param("svcCtgCd") String svcCtgCd, @Param("faqTtl") String faqTtl);
    int checkDuplicateNtfy(@Param("svcCtgCd") String svcCtgCd, @Param("ntfyTtl") String ntfyTtl);
    int checkDuplicateQna(@Param("svcCtgCd") String svcCtgCd, @Param("qnaTtl") String qnaTtl);
    
    // 테이블 존재 여부 확인
    int checkTableExists(@Param("tableName") String tableName);
}
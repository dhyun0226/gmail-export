package com.ow.voc.dto.oracle;

import lombok.Data;

import java.util.Date;

/**
 * TB_HANARO_BOARD_MEMO 테이블 DTO
 * 하나로게시물 댓글정보 - 스키마 문서 기반
 */
@Data
public class HanaroBoardMemo {
    private Long memoSeq;            // MEMO_NO -> memoSeq (매핑용)
    private Long boardSeq;           // BOARD_NO -> boardSeq (매핑용)
    private String userId;           // MEMO_ID -> userId (매핑용)
    private Date regiDate;           // MEMO_DT -> regiDate (매핑용)
    private String memoCont;         // MEMO_CONTENT -> memoCont (매핑용)
    private Integer bbsNo;           // BBS_NO
}
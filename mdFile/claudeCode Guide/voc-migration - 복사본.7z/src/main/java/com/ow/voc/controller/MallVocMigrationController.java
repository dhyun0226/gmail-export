package com.ow.voc.controller;

import com.ow.voc.service.MallVocMigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Mall VOC 마이그레이션 컨트롤러
 * Mall VOC (Oracle) 데이터베이스에서 TOBE VOC (MariaDB)로 데이터를 마이그레이션하는 API
 */
@Slf4j
@Tag(name = "Mall VOC Migration", description = "Mall VOC 데이터 마이그레이션 API")
@RestController
@RequestMapping("/api/migration/mall-voc")
@RequiredArgsConstructor
public class MallVocMigrationController {

    private final MallVocMigrationService mallVocMigrationService;

    @Operation(summary = "Mall VOC 전체 데이터 마이그레이션", 
              description = "Mall VOC (Oracle)에서 TOBE VOC (MariaDB)로 모든 데이터를 마이그레이션합니다. " +
                           "BBS_CD 패턴에 따라 NOTICE, FAQ, QNA, EVENT 테이블로 분류하여 저장합니다.")
    @PostMapping("/all")
    public ResponseEntity<Map<String, Object>> migrateAll() {
        log.info("Mall VOC 전체 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = mallVocMigrationService.migrateAll();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Mall VOC 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall VOC 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall VOC 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall Notice → 공지사항 마이그레이션", 
              description = "Mall VOC의 NOTICE_* 게시판을 TB_NTFY_M으로 마이그레이션합니다.")
    @PostMapping("/notices")
    public ResponseEntity<Map<String, Object>> migrateMallNotices() {
        log.info("Mall Notice 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = mallVocMigrationService.migrateMallNotices();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Mall Notice 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall Notice 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall Notice 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall FAQ → FAQ 마이그레이션", 
              description = "Mall VOC의 FAQ_* 게시판을 TB_FAQ_M으로 마이그레이션합니다.")
    @PostMapping("/faqs")
    public ResponseEntity<Map<String, Object>> migrateMallFaqs() {
        log.info("Mall FAQ 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = mallVocMigrationService.migrateMallFaqs();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Mall FAQ 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall FAQ 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall FAQ 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall QNA → QNA 마이그레이션", 
              description = "Mall VOC의 QNA_*, CS_* 게시판을 TB_QNA_M/TB_QNA_ANS_D로 마이그레이션합니다. " +
                           "답변글(UP_BBS_SEQ)은 TB_QNA_ANS_D로 분리 저장됩니다.")
    @PostMapping("/qnas")
    public ResponseEntity<Map<String, Object>> migrateMallQnas() {
        log.info("Mall QNA 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = mallVocMigrationService.migrateMallQnas();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Mall QNA 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall QNA 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall QNA 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall Event → 이벤트 마이그레이션", 
              description = "Mall VOC의 EVENT_* 게시판을 TB_EVT_M으로 마이그레이션합니다.")
    @PostMapping("/events")
    public ResponseEntity<Map<String, Object>> migrateMallEvents() {
        log.info("Mall Event 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = mallVocMigrationService.migrateMallEvents();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Mall Event 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall Event 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall Event 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall VOC 마이그레이션 상태 조회", 
              description = "현재 Mall VOC 마이그레이션 진행 상태와 통계를 조회합니다.")
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getMigrationStatus() {
        log.info("Mall VOC 마이그레이션 상태 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> status = mallVocMigrationService.getMigrationStatus();
            response.put("success", true);
            response.put("data", status);
            response.put("message", "Mall VOC 마이그레이션 상태 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall VOC 마이그레이션 상태 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall VOC 마이그레이션 상태 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Mall VOC 마이그레이션 서비스 상태 확인", 
              description = "Mall VOC 마이그레이션 서비스의 상태를 확인합니다.")
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Mall VOC Migration Service");
        response.put("source", "Oracle Database (Mall VOC)");
        response.put("target", "MariaDB Database (TOBE VOC)");
        response.put("description", "통합 게시판 구조를 개별 테이블로 분리 마이그레이션");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Mall VOC 데이터베이스 연결 상태 확인", 
              description = "Oracle(EOS)와 MariaDB(OCC) 데이터베이스의 연결 상태를 확인합니다.")
    @GetMapping("/connections")
    public ResponseEntity<Map<String, Object>> checkConnections() {
        log.info("Mall VOC 데이터베이스 연결 상태 확인 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> connections = mallVocMigrationService.checkDatabaseConnections();
            response.put("success", true);
            response.put("data", connections);
            response.put("message", "Mall VOC 데이터베이스 연결 상태 확인 완료");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Mall VOC 데이터베이스 연결 상태 확인 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Mall VOC 데이터베이스 연결 상태 확인 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }
}
package com.ow.voc.dto.mall;

import lombok.Data;
import java.util.Date;

@Data
public class TbBbsCategory {
    private Long categorySeq;
    private String categoryNm;
    private String mlCategoryNm;
    private String bbsCd;
    private Integer ord;
    private Date regDt;
    private String regId;
    private Date modDt;
    private String modId;
    private Long upCategorySeq;
    private String delYn;
    private String useYn;
    private String memYn;
    private String commCd;
}
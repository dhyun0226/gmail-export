package com.ow.voc.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Third DataSource Configuration for DTV MariaDB
 * This configuration sets up the third data source for connecting to DTV database
 */
@Configuration
public class ThirdDataSourceConfig {

    /**
     * Third DataSource Properties
     * Reads configuration from spring.datasource.third
     */
    @Bean
    @ConfigurationProperties("spring.datasource.third")
    public DataSourceProperties thirdDataSourceProperties() {
        return new DataSourceProperties();
    }

    /**
     * Third DataSource
     * Creates HikariDataSource using third datasource properties
     */
    @Bean(name = "thirdDataSource")
    @ConfigurationProperties("spring.datasource.third.hikari")
    public DataSource thirdDataSource(@Qualifier("thirdDataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
    }
}
package com.ow.voc.mapper.primary;

import com.ow.voc.dto.oracle.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface HanaroMapper {
    
    // 게시판 정보 조회
    List<HanaroBoardInfo> selectBoardInfoList();
    HanaroBoardInfo selectBoardInfo(@Param("boardCode") String boardCode);
    
    // 게시판 데이터 조회
    List<HanaroBoard> selectBoardList(@Param("boardCode") String boardCode);
    List<HanaroBoard> selectBoardListWithPaging(@Param("boardCode") String boardCode, 
                                               @Param("offset") int offset, 
                                               @Param("limit") int limit);
    HanaroBoard selectBoard(@Param("boardSeq") Long boardSeq);
    int countBoard(@Param("boardCode") String boardCode);
    
    // DB 타입별 게시판 데이터 조회
    List<HanaroBoard> selectBoardListByDbType(@Param("dbType") String dbType);
    List<HanaroBoard> selectBoardListByDbTypes(@Param("dbTypes") List<String> dbTypes);
    List<HanaroBoard> selectBoardListByDbTypesWithPaging(@Param("dbTypes") List<String> dbTypes, 
                                                        @Param("offset") int offset, 
                                                        @Param("limit") int limit);
    List<HanaroBoard> selectBoardListByDbTypeWithPaging(@Param("dbType") String dbType,
                                                        @Param("offset") int offset,
                                                        @Param("limit") int limit);
    int countBoardByDbType(@Param("dbType") String dbType);
    int countBoardByDbTypes(@Param("dbTypes") List<String> dbTypes);
    
    // 카테고리 조회
    List<HanaroBoardCategory> selectCategoryList(@Param("boardCode") String boardCode);
    HanaroBoardCategory selectCategory(@Param("cateCode") String cateCode);
    
    // 파일 조회
    List<HanaroBoardFile> selectFileList(@Param("boardSeq") Long boardSeq);
    HanaroBoardFile selectFile(@Param("fileId") String fileId);
    
    // 댓글(메모) 조회
    List<HanaroBoardMemo> selectMemoList(@Param("boardSeq") Long boardSeq);
    HanaroBoardMemo selectMemo(@Param("memoSeq") Long memoSeq);
    
    // 제품 시연 요청 조회
    List<HanaroInquiry> selectInquiryList();
    HanaroInquiry selectInquiry(@Param("inqSeq") Long inqSeq);
    
    // 제품 상담 조회
    List<HanaroSangdam> selectSangdamList();
    HanaroSangdam selectSangdam(@Param("sangSeq") Long sangSeq);
    
    // 통계 조회
    Map<String, Object> selectBoardStatistics(@Param("boardCode") String boardCode);
}
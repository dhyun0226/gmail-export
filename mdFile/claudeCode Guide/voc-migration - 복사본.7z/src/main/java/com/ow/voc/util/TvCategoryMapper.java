package com.ow.voc.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * TV VOC 카테고리를 TOBE 카테고리 코드로 매핑하는 유틸리티 클래스
 */
@Slf4j
@Component
public class TvCategoryMapper {
    
    // ASIS 카테고리 매핑 테이블
    private static final Map<String, Map<String, String>> CATEGORY_MAPPING = new HashMap<>();
    
    static {
        // FAQ 카테고리 매핑
        Map<String, String> faqMapping = new HashMap<>();
        faqMapping.put("가입/로그인", "D001_FAQ_002");  // 가입/로그인
        faqMapping.put("계정/탈퇴", "D001_FAQ_003");    // 계정/탈퇴
        faqMapping.put("콘텐츠", "D001_FAQ_004");       // 콘텐츠
        faqMapping.put("서비스", "D001_FAQ_005");       // 서비스
        faqMapping.put("기타", "D001_FAQ_001");         // 자주하는질문(기본)
        CATEGORY_MAPPING.put("FAQ", faqMapping);
        
        // QUESTION 카테고리 매핑 - 1:1문의(QNA)로 매핑
        Map<String, String> questionMapping = new HashMap<>();
        questionMapping.put("회원/로그인", "D001_QNA_001");        // 회원/로그인
        questionMapping.put("영상(VOD/LIVE)", "D001_QNA_003");    // 영상(VOD/LIVE)
        questionMapping.put("덴탈인포 상담예약", "D001_QNA_002");  // 덴탈인포 상담예약
        questionMapping.put("이벤트", "D001_QNA_004");            // 이벤트
        questionMapping.put("장애/오류신고", "D001_QNA_005");      // 장애/오류신고
        questionMapping.put("제휴/광고제안", "D001_QNA_006");      // 제휴/광고제안
        questionMapping.put("기타", "D001_QNA_999");              // 기타
        CATEGORY_MAPPING.put("QUESTION", questionMapping);
        
        // USER_REPORT 카테고리 매핑 - QNA(문의)로 매핑
        Map<String, String> userReportMapping = new HashMap<>();
        userReportMapping.put("임상 케이스 제보", "D001_QNA_999");  // 기타로 매핑
        userReportMapping.put("출연자 추천", "D001_QNA_999");       // 기타로 매핑
        userReportMapping.put("뉴스 제보", "D001_QNA_999");         // 기타로 매핑
        userReportMapping.put("임상 촬영 요청", "D001_QNA_999");    // 기타로 매핑
        userReportMapping.put("기타", "D001_QNA_999");              // 기타
        CATEGORY_MAPPING.put("USER_REPORT", userReportMapping);
        
        // NEWS 카테고리 매핑 - 공지사항(NTF)으로 매핑 (모두 일반 공지사항으로)
        Map<String, String> newsMapping = new HashMap<>();
        newsMapping.put("정책", "D001_NTF");
        newsMapping.put("산업", "D001_NTF");
        newsMapping.put("전시", "D001_NTF");
        newsMapping.put("부고", "D001_NTF");
        newsMapping.put("보험", "D001_NTF");
        newsMapping.put("학술", "D001_NTF");
        newsMapping.put("대학", "D001_NTF");
        newsMapping.put("병•의원", "D001_NTF");
        newsMapping.put("기공", "D001_NTF");
        newsMapping.put("치위생", "D001_NTF");
        newsMapping.put("경사", "D001_NTF");
        newsMapping.put("인사동정", "D001_NTF");
        newsMapping.put("봉사", "D001_NTF");
        newsMapping.put("채용", "D001_NTF");
        newsMapping.put("회무", "D001_NTF");
        CATEGORY_MAPPING.put("NEWS", newsMapping);
    }
    
    /**
     * ASIS 카테고리를 TOBE 카테고리 코드로 변환
     * 
     * @param type ASIS 카테고리 타입 (FAQ, QUESTION, USER_REPORT, NEWS)
     * @param name ASIS 카테고리명
     * @return TOBE 카테고리 코드
     */
    public String mapCategory(String type, String name) {
        if (type == null || name == null) {
            log.warn("카테고리 타입 또는 이름이 null입니다. 기본값 반환. type: {}, name: {}", type, name);
            return getDefaultCategory(type);
        }
        
        Map<String, String> typeMapping = CATEGORY_MAPPING.get(type.toUpperCase());
        if (typeMapping == null) {
            log.warn("알 수 없는 카테고리 타입: {}. 기본값 반환", type);
            return getDefaultCategory(type);
        }
        
        String categoryCode = typeMapping.get(name);
        if (categoryCode == null) {
            log.warn("매핑되지 않은 카테고리: type={}, name={}. 유사 카테고리 탐색 시도", type, name);
            
            // 유사 카테고리 찾기
            categoryCode = findSimilarCategory(typeMapping, name);
            
            if (categoryCode == null) {
                categoryCode = getDefaultCategoryForType(type);
                log.warn("유사 카테고리를 찾을 수 없습니다. 타입별 기본값 사용: {}", categoryCode);
            }
        }
        
        log.debug("카테고리 매핑 완료: {}:{} -> {}", type, name, categoryCode);
        return categoryCode;
    }
    
    /**
     * 유사한 카테고리 찾기
     */
    private String findSimilarCategory(Map<String, String> typeMapping, String name) {
        // 키워드 기반 매칭
        String lowerName = name.toLowerCase();
        
        for (Map.Entry<String, String> entry : typeMapping.entrySet()) {
            String key = entry.getKey().toLowerCase();
            if (lowerName.contains(key) || key.contains(lowerName)) {
                log.info("유사 카테고리 매핑: {} -> {}", name, entry.getKey());
                return entry.getValue();
            }
        }
        
        // 특정 키워드 매칭
        if (lowerName.contains("로그인") || lowerName.contains("가입")) {
            return typeMapping.get("회원/로그인") != null ? typeMapping.get("회원/로그인") : typeMapping.get("가입/로그인");
        }
        if (lowerName.contains("이벤트")) {
            return typeMapping.get("이벤트");
        }
        if (lowerName.contains("장애") || lowerName.contains("오류")) {
            return typeMapping.get("장애/오류신고");
        }
        
        return null;
    }
    
    /**
     * 타입별 기본 카테고리 코드 반환
     */
    private String getDefaultCategoryForType(String type) {
        switch (type.toUpperCase()) {
            case "FAQ":
                return "D001_FAQ_001";      // 자주하는질문
            case "QUESTION":
                return "D001_QNA_999";      // 기타 1:1문의
            case "USER_REPORT":
                return "D001_QNA_999";      // 기타 문의
            case "NEWS":
                return "D001_NTF";      // 공지사항
            default:
                return "D001_QNA_999";      // 기본값
        }
    }
    
    /**
     * 기본 카테고리 코드 반환
     */
    private String getDefaultCategory(String type) {
        if (type == null) {
            return "D001_QNA_999";
        }
        return getDefaultCategoryForType(type);
    }
    
    /**
     * 카테고리 ID로부터 TOBE 카테고리 코드 매핑
     * TV VOC의 category_id를 사용하여 직접 매핑
     */
    public String mapCategoryById(Long categoryId, String type) {
        if (categoryId == null) {
            return getDefaultCategory(type);
        }
        
        // ID 기반 직접 매핑
        Map<Long, String> idMapping = new HashMap<>();
        idMapping.put(5L, "D001_FAQ_002");   // 가입/로그인
        idMapping.put(7L, "D001_FAQ_003");   // 계정/탈퇴
        idMapping.put(10L, "D001_FAQ_005");  // 서비스
        idMapping.put(11L, "D001_FAQ_004");  // 콘텐츠
        idMapping.put(12L, "D001_QNA_999");  // 기타 (QUESTION)
        idMapping.put(13L, "D001_QNA_001");  // 회원/로그인
        idMapping.put(14L, "D001_QNA_003");  // 영상(VOD/LIVE)
        idMapping.put(15L, "D001_QNA_002");  // 덴탈인포 상담예약
        idMapping.put(16L, "D001_QNA_004");  // 이벤트
        idMapping.put(17L, "D001_QNA_005");  // 장애/오류신고
        idMapping.put(40L, "D001_QNA_006");  // 제휴/광고제안
        
        // USER_REPORT는 모두 기타 문의로
        idMapping.put(42L, "D001_QNA_999");  // 임상 케이스 제보
        idMapping.put(19L, "D001_QNA_999");  // 출연자 추천
        idMapping.put(21L, "D001_QNA_999");  // 뉴스 제보
        idMapping.put(22L, "D001_QNA_999");  // 임상 촬영 요청
        idMapping.put(23L, "D001_QNA_999");  // 기타
        
        // NEWS는 모두 공지사항으로
        for (long i = 24; i <= 38; i++) {
            if (i == 39) continue; // 39는 없음
            idMapping.put(i, "D001_NTF");
        }
        
        String mappedCode = idMapping.get(categoryId);
        if (mappedCode != null) {
            log.debug("카테고리 ID 매핑: {} -> {}", categoryId, mappedCode);
            return mappedCode;
        }
        
        log.warn("매핑되지 않은 카테고리 ID: {}. 타입별 기본값 사용", categoryId);
        return getDefaultCategory(type);
    }
}
package com.ow.voc.controller;

import com.ow.voc.service.HanaroMigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Hanaro VOC 마이그레이션 컨트롤러
 * Hanaro VOC 데이터베이스에서 TOBE VOC로 데이터를 마이그레이션하는 API
 */
@Slf4j
@Tag(name = "Hanaro VOC Migration", description = "Hanaro VOC 데이터 마이그레이션 API")
@RestController
@RequestMapping("/api/migration/hanaro-voc")
@RequiredArgsConstructor
public class HanaroMigrationController {

    private final HanaroMigrationService hanaroMigrationService;

    @Operation(summary = "Hanaro VOC 전체 데이터 마이그레이션", 
              description = "Hanaro VOC(DENJOB)에서 TOBE VOC(OCC)로 모든 데이터를 마이그레이션합니다. NOTI, FAQ, QNA, STIP, ITIP만 마이그레이션 대상입니다.")
    @PostMapping("/all")
    public ResponseEntity<Map<String, Object>> migrateAll() {
        log.info("Hanaro VOC 전체 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateAllHanaroData();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro VOC 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro VOC 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro VOC 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro 공지사항 → 공지사항 마이그레이션", 
              description = "Hanaro VOC의 NOTI 타입 게시물을 TB_NTFY_M으로 마이그레이션합니다.")
    @PostMapping("/notices")
    public ResponseEntity<Map<String, Object>> migrateHanaroNotices() {
        log.info("Hanaro 공지사항 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroNotices();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro 공지사항 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro 공지사항 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro 공지사항 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro FAQ → FAQ 마이그레이션", 
              description = "Hanaro VOC의 FAQ 타입 게시물을 TB_FAQ_M으로 마이그레이션합니다.")
    @PostMapping("/faqs")
    public ResponseEntity<Map<String, Object>> migrateHanaroFaqs() {
        log.info("Hanaro FAQ 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroFaqs();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro FAQ 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro FAQ 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro FAQ 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro QNA → QNA 마이그레이션", 
              description = "Hanaro VOC의 QNA, STIP, ITIP 타입 게시물을 TB_QNA_M/TB_QNA_ANS_D로 마이그레이션합니다. STIP, ITIP은 QNA로 처리됩니다.")
    @PostMapping("/qnas")
    public ResponseEntity<Map<String, Object>> migrateHanaroQnas() {
        log.info("Hanaro QNA 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroQnas();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro QNA 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro QNA 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro QNA 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro 제품시연요청 → QNA 마이그레이션", 
              description = "Hanaro VOC의 TB_HANARO_INQUIRY 테이블을 TB_QNA_M으로 마이그레이션합니다.")
    @PostMapping("/inquiries")
    public ResponseEntity<Map<String, Object>> migrateHanaroInquiries() {
        log.info("Hanaro 제품시연요청 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroInquiries();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro 제품시연요청 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro 제품시연요청 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro 제품시연요청 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro 제품상담 → QNA 마이그레이션", 
              description = "Hanaro VOC의 TB_HANARO_SANGDAM 테이블을 TB_QNA_M/TB_QNA_ANS_D로 마이그레이션합니다.")
    @PostMapping("/sangdam")
    public ResponseEntity<Map<String, Object>> migrateHanaroSangdam() {
        log.info("Hanaro 제품상담 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroSangdam();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro 제품상담 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro 제품상담 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro 제품상담 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro 댓글 → QNA 답변 마이그레이션", 
              description = "Hanaro VOC의 TB_HANARO_BOARD_MEMO 테이블을 TB_QNA_ANS_D로 마이그레이션합니다. 마이그레이션 대상 게시물의 댓글만 처리됩니다.")
    @PostMapping("/memos")
    public ResponseEntity<Map<String, Object>> migrateHanaroMemos() {
        log.info("Hanaro 댓글 마이그레이션 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> result = hanaroMigrationService.migrateHanaroMemos();
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Hanaro 댓글 마이그레이션이 완료되었습니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro 댓글 마이그레이션 실행 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro 댓글 마이그레이션 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro VOC 마이그레이션 상태 조회", 
              description = "현재 Hanaro VOC 마이그레이션 진행 상태와 통계를 조회합니다.")
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getMigrationStatus() {
        log.info("Hanaro VOC 마이그레이션 상태 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            Map<String, Object> status = hanaroMigrationService.getMigrationStatus();
            response.put("success", true);
            response.put("data", status);
            response.put("message", "Hanaro VOC 마이그레이션 상태 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Hanaro VOC 마이그레이션 상태 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Hanaro VOC 마이그레이션 상태 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "실패한 항목 조회", 
              description = "마이그레이션 중 실패한 항목들을 조회합니다.")
    @GetMapping("/failed-items")
    public ResponseEntity<Map<String, Object>> getFailedItems() {
        log.info("Hanaro VOC 마이그레이션 실패 항목 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            response.put("success", true);
            response.put("data", hanaroMigrationService.getFailedItems());
            response.put("message", "실패 항목 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("실패 항목 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "실패 항목 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "중복된 항목 조회", 
              description = "마이그레이션 중 중복으로 제외된 항목들을 조회합니다.")
    @GetMapping("/duplicate-items")
    public ResponseEntity<Map<String, Object>> getDuplicateItems() {
        log.info("Hanaro VOC 마이그레이션 중복 항목 조회 요청");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            response.put("success", true);
            response.put("data", hanaroMigrationService.getDuplicateItems());
            response.put("message", "중복 항목 조회 성공");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("중복 항목 조회 중 오류", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "중복 항목 조회 중 오류가 발생했습니다.");
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @Operation(summary = "Hanaro VOC 마이그레이션 서비스 상태 확인", 
              description = "Hanaro VOC 마이그레이션 서비스의 상태를 확인합니다.")
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Hanaro VOC Migration Service");
        response.put("source", "DENJOB Database (Oracle)");
        response.put("target", "OCC Database (MariaDB)");
        response.put("supportedTypes", new String[]{"NOTI", "FAQ", "QNA", "STIP", "ITIP"});
        response.put("excludedTypes", new String[]{"ONLINEHELP", "DOWN", "REVIEW", "CUSTM"});
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}
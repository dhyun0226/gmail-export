package com.ow.voc.dto.oracle;

import lombok.Data;

/**
 * TB_HANARO_BOARD_CATEGORY 테이블 DTO
 * 하나로게시물정보 카테고리정보 - 스키마 문서 기반
 */
@Data
public class HanaroBoardCategory {
    private Integer cateCode;        // CATEGORY_CODE -> cateCode (매핑용)
    private String cateNm;           // CATEGORY_NAME -> cateNm (매핑용)
    private String boardCode;        // DB -> boardCode (매핑용)
    private String viewYn;           // USE_YN -> viewYn (매핑용)
    private Integer orderBy;         // ORDER_NUM -> orderBy (매핑용)
    private String categoryCss;      // CATEGORY_CSS
}
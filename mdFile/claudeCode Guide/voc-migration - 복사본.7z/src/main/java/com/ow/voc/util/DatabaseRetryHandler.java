package com.ow.voc.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.sql.SQLTransientConnectionException;
import java.sql.SQLNonTransientConnectionException;
import java.util.function.Supplier;

/**
 * DB 연결 실패 시 재시도 처리 유틸리티
 */
@Slf4j
@Component
public class DatabaseRetryHandler {
    
    private static final int MAX_RETRY_COUNT = 3;
    private static final long[] RETRY_DELAYS = {1000, 3000, 5000}; // 1초, 3초, 5초
    
    /**
     * DB 작업 재시도 실행
     */
    public <T> T executeWithRetry(String operation, Supplier<T> dbOperation) {
        Exception lastException = null;
        
        for (int attempt = 0; attempt < MAX_RETRY_COUNT; attempt++) {
            try {
                log.debug("DB 작업 시도 {} - 작업: {}", attempt + 1, operation);
                return dbOperation.get();
                
            } catch (Exception e) {
                lastException = e;
                
                if (!isRetryableException(e)) {
                    log.error("재시도 불가능한 에러 - 작업: {}, 에러: {}", operation, e.getMessage());
                    throw new RuntimeException("재시도 불가능한 에러: " + e.getMessage(), e);
                }
                
                if (attempt < MAX_RETRY_COUNT - 1) {
                    long delay = RETRY_DELAYS[attempt];
                    log.warn("DB 작업 실패 (시도 {}/{}) - 작업: {}, 에러: {}, {}ms 후 재시도", 
                        attempt + 1, MAX_RETRY_COUNT, operation, e.getMessage(), delay);
                    
                    try {
                        Thread.sleep(delay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("재시도 중 인터럽트 발생", ie);
                    }
                } else {
                    log.error("DB 작업 최종 실패 - 작업: {}, 총 시도: {}", operation, MAX_RETRY_COUNT);
                }
            }
        }
        
        throw new RuntimeException("DB 작업 최종 실패 (작업: " + operation + ")", lastException);
    }
    
    /**
     * void 작업용 재시도 실행
     */
    public void executeWithRetry(String operation, Runnable dbOperation) {
        executeWithRetry(operation, () -> {
            dbOperation.run();
            return null;
        });
    }
    
    /**
     * 재시도 가능한 예외인지 판단
     */
    private boolean isRetryableException(Exception e) {
        // SQLException 계열 체크
        if (e instanceof SQLException) {
            SQLException sqlEx = (SQLException) e;
            String message = sqlEx.getMessage().toLowerCase();
            
            // 재시도 가능한 에러들
            if (e instanceof SQLTransientConnectionException ||
                e instanceof SQLNonTransientConnectionException ||
                message.contains("connection") && message.contains("closed") ||
                message.contains("socket error") ||
                message.contains("connection timeout") ||
                message.contains("communications link failure") ||
                message.contains("connection reset")) {
                
                log.debug("재시도 가능한 SQL 에러 감지: {}", message);
                return true;
            }
            
            // 재시도 불가능한 에러들
            if (message.contains("data too long") ||
                message.contains("duplicate entry") ||
                message.contains("syntax error") ||
                message.contains("table doesn't exist") ||
                message.contains("column") && message.contains("doesn't exist")) {
                
                log.debug("재시도 불가능한 SQL 에러 감지: {}", message);
                return false;
            }
        }
        
        // RuntimeException 내부의 SQLException 체크
        if (e instanceof RuntimeException && e.getCause() instanceof SQLException) {
            return isRetryableException((SQLException) e.getCause());
        }
        
        // 기본적으로 네트워크/연결 관련 에러는 재시도
        String message = e.getMessage().toLowerCase();
        return message.contains("connection") || message.contains("socket") || message.contains("timeout");
    }
    
    /**
     * 재시도 통계 정보
     */
    public static class RetryStats {
        private int totalAttempts = 0;
        private int successfulRetries = 0;
        private int failedOperations = 0;
        
        public void recordAttempt() { totalAttempts++; }
        public void recordSuccess() { successfulRetries++; }
        public void recordFailure() { failedOperations++; }
        
        public void logStats() {
            log.info("재시도 통계 - 총시도: {}, 성공한재시도: {}, 실패작업: {}", 
                totalAttempts, successfulRetries, failedOperations);
        }
        
        // Getters
        public int getTotalAttempts() { return totalAttempts; }
        public int getSuccessfulRetries() { return successfulRetries; }
        public int getFailedOperations() { return failedOperations; }
    }
}
package com.ow.voc.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 마이그레이션 서비스 베이스 클래스
 * 모든 마이그레이션 서비스가 상속받아 사용
 */
@Slf4j
public abstract class BaseMigrationService {
    
    @Autowired
    protected MigrationReportUtil reportUtil;
    
    // 통계 정보
    protected final AtomicLong totalCount = new AtomicLong(0);
    protected final AtomicLong processedCount = new AtomicLong(0);
    protected final AtomicLong successCount = new AtomicLong(0);
    protected final AtomicLong failCount = new AtomicLong(0);
    
    // 실패 및 중복 항목 저장
    protected final List<Map<String, Object>> failedItems = Collections.synchronizedList(new ArrayList<>());
    protected final List<Map<String, Object>> duplicateItems = Collections.synchronizedList(new ArrayList<>());
    
    /**
     * 마이그레이션 완료 후 리포트 저장
     */
    protected void saveReport(String serviceName, Map<String, Object> result) {
        try {
            // 리포트 저장
            reportUtil.saveMigrationReport(serviceName, result, failedItems, duplicateItems);
            
            // 리포트 경로를 결과에 추가
            result.put("reportPath", reportUtil.getReportPath());
            
        } catch (Exception e) {
            log.error("리포트 저장 중 오류", e);
        }
    }
    
    /**
     * 실패 항목 추가
     */
    protected void addFailedItem(String type, Object id, String title, String errorMessage) {
        Map<String, Object> failedItem = new HashMap<>();
        failedItem.put("type", type);
        failedItem.put("id", id);
        failedItem.put("title", title);
        failedItem.put("error", errorMessage);
        failedItem.put("timestamp", new Date());
        failedItems.add(failedItem);
    }
    
    /**
     * 중복 항목 추가
     */
    protected void addDuplicateItem(String type, Object id, String title, String reason) {
        Map<String, Object> duplicateItem = new HashMap<>();
        duplicateItem.put("type", type);
        duplicateItem.put("id", id);
        duplicateItem.put("title", title);
        duplicateItem.put("reason", reason);
        duplicateItem.put("timestamp", new Date());
        duplicateItems.add(duplicateItem);
    }
    
    /**
     * 통계 초기화
     */
    protected void resetStatistics() {
        totalCount.set(0);
        processedCount.set(0);
        successCount.set(0);
        failCount.set(0);
        failedItems.clear();
        duplicateItems.clear();
    }
    
    /**
     * 실패 항목 요약 정보
     */
    protected Map<String, Object> getFailedItemsSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("totalFailedCount", failedItems.size());
        
        // 타입별 실패 카운트
        Map<String, Long> failedByType = new HashMap<>();
        for (Map<String, Object> item : failedItems) {
            String type = (String) item.get("type");
            failedByType.put(type, failedByType.getOrDefault(type, 0L) + 1);
        }
        summary.put("failedByType", failedByType);
        
        // 최근 실패 항목 10개
        int size = Math.min(failedItems.size(), 10);
        summary.put("recentFailedItems", failedItems.subList(Math.max(0, failedItems.size() - size), failedItems.size()));
        
        return summary;
    }
    
    /**
     * 중복 항목 요약 정보
     */
    protected Map<String, Object> getDuplicateItemsSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("totalDuplicateCount", duplicateItems.size());
        
        // 타입별 중복 카운트
        Map<String, Long> duplicateByType = new HashMap<>();
        for (Map<String, Object> item : duplicateItems) {
            String type = (String) item.get("type");
            duplicateByType.put(type, duplicateByType.getOrDefault(type, 0L) + 1);
        }
        summary.put("duplicateByType", duplicateByType);
        
        // 최근 중복 항목 10개
        int size = Math.min(duplicateItems.size(), 10);
        summary.put("recentDuplicateItems", duplicateItems.subList(Math.max(0, duplicateItems.size() - size), duplicateItems.size()));
        
        return summary;
    }
    
    /**
     * 실패 항목 로그 출력
     */
    protected void printFailedItemsLog() {
        if (!failedItems.isEmpty()) {
            log.error("========== 마이그레이션 실패 항목 리스트 ==========");
            log.error("총 {} 건의 실패 항목이 있습니다.", failedItems.size());
            
            for (Map<String, Object> item : failedItems) {
                log.error("[{}] ID: {}, 제목: {}, 오류: {}", 
                    item.get("type"), 
                    item.get("id"), 
                    item.get("title"), 
                    item.get("error"));
            }
            log.error("================================================");
        }
        
        if (!duplicateItems.isEmpty()) {
            log.warn("========== 중복으로 제외된 항목 리스트 ==========");
            log.warn("총 {} 건의 중복 항목이 있습니다.", duplicateItems.size());
            
            for (Map<String, Object> item : duplicateItems) {
                log.warn("[{}] ID: {}, 제목: {}, 이유: {}", 
                    item.get("type"), 
                    item.get("id"), 
                    item.get("title"), 
                    item.get("reason"));
            }
            log.warn("================================================");
        }
    }
    
    /**
     * 실패한 항목들 반환
     */
    public List<Map<String, Object>> getFailedItems() {
        return new ArrayList<>(failedItems);
    }
    
    /**
     * 중복된 항목들 반환
     */
    public List<Map<String, Object>> getDuplicateItems() {
        return new ArrayList<>(duplicateItems);
    }
}
rootProject.name = "voc-was"

package com.denall.voc.controller;
import com.denall.voc.model.table.VocAnswerDto;
import com.denall.voc.domain.VocAnswerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/voc-answers")
@RequiredArgsConstructor
@Tag(name = "VOC 답변", description = "VOC 답변 CRUD API")
public class VocAnswerController {

    private final VocAnswerService vocAnswerService;

    @Operation(summary = "VOC 답변 등록", description = "VOC에 대한 답변을 등록합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "답변 등록 성공",
                    content = @Content(schema = @Schema(implementation = VocAnswerDto.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청"),
            @ApiResponse(responseCode = "404", description = "VOC를 찾을 수 없음")
    })
    @PostMapping
    public ResponseEntity<VocAnswerDto> create(
            @Parameter(description = "VOC 답변 등록 정보", required = true)
            @RequestBody @Valid VocAnswerDto dto) {
        VocAnswerDto created = vocAnswerService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @Operation(summary = "전체 VOC 답변 조회", description = "모든 VOC 답변 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = VocAnswerDto.class)))
    @GetMapping
    public ResponseEntity<List<VocAnswerDto>> list() {
        List<VocAnswerDto> all = vocAnswerService.getAll();
        return ResponseEntity.ok(all);
    }

    @Operation(summary = "VOC 답변 상세 조회", description = "답변 ID로 VOC 답변 상세 정보를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공",
                    content = @Content(schema = @Schema(implementation = VocAnswerDto.class))),
            @ApiResponse(responseCode = "404", description = "답변을 찾을 수 없음")
    })
    @GetMapping("/{id}")
    public ResponseEntity<VocAnswerDto> get(
            @Parameter(description = "VOC 답변 ID", required = true)
            @PathVariable Long id) {
        VocAnswerDto dto = vocAnswerService.getById(id);
        return ResponseEntity.ok(dto);
    }

    @Operation(summary = "VOC 답변 수정", description = "VOC 답변을 수정합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "수정 성공",
                    content = @Content(schema = @Schema(implementation = VocAnswerDto.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청"),
            @ApiResponse(responseCode = "404", description = "답변을 찾을 수 없음")
    })
    @PutMapping("/{id}")
    public ResponseEntity<VocAnswerDto> update(
            @Parameter(description = "VOC 답변 ID", required = true)
            @PathVariable Long id,
            @Parameter(description = "VOC 답변 수정 정보", required = true)
            @RequestBody @Valid VocAnswerDto dto
    ) {
        VocAnswerDto updated = vocAnswerService.update(id, dto);
        return ResponseEntity.ok(updated);
    }

    @Operation(summary = "VOC 답변 삭제", description = "VOC 답변을 삭제합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "삭제 성공"),
            @ApiResponse(responseCode = "404", description = "답변을 찾을 수 없음")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "VOC 답변 ID", required = true)
            @PathVariable Long id) {
        vocAnswerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

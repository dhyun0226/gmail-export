package com.denall.voc.mapper;

import com.denall.voc.entity.EventAnswer;
import com.denall.voc.entity.EventAnswerId;
import com.denall.voc.model.table.EventAnswerDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.time.LocalDateTime;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EventAnswerStruct extends StructMapper<EventAnswer, EventAnswerDto> {

    @Mapping(target = "eventNumber", source = "event.eventNumber")
    @Mapping(target = "eventParticipationDatetime", source = "id.eventParticipationDatetime")
    EventAnswerDto toDto(EventAnswer entity);
    @Mapping(target = "id", expression = "java(createEventAnswerId(dto))")
    @Mapping(target = "event", ignore = true)
    EventAnswer toEntity(EventAnswerDto dto);

    default EventAnswerId createEventAnswerId(EventAnswerDto dto) {
        if (dto.getEventNumber() == null) {
            return null;
        }

        LocalDateTime participationDatetime = dto.getEventParticipationDatetime();
        if (participationDatetime == null) {
            participationDatetime = LocalDateTime.now();
        }

        return new EventAnswerId(dto.getEventNumber(), participationDatetime);
    }
}

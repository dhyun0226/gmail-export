package com.denall.voc.model.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.denall.voc.model.base.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@Getter
@Setter
@Schema(description = "개인문의 요청 DTO")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IndividualInquiryRequestDto implements PagingDto {

    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @Size(max = 4)
    @Schema(description = "개인문의 등록 구분 코드", example = "0001")
    private String serviceCategoryCode;

    @Size(max = 20)
    @Schema(description = "작성자 회원 ID", example = "user123")
    private String writerMemberId;

    @Schema(description = "검색 타입 (title:제목, content:내용, both:제목+내용)", example = "both")
    private String searchType;

    @Schema(description = "검색 키워드", example = "문의합니다")
    private String keyword;

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @JsonIgnore
    public Pageable getPageable() {
        int pageIndex = getOffset() / getLimit();
        return PageRequest.of(pageIndex, getLimit());
    }
}
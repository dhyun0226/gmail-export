package com.denall.voc.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum SearchType {
    TITLE("TITLE", "제목"),
    CONTENT("CONTENT", "내용"),
    BOTH("BOTH", "제목+내용+작성자"),
    WRITER("WRITER", "작성자");

    private final String code;
    private final String description;

    /**
     * 코드 값으로 SearchType Enum을 찾음
     *
     * @param code 검색 타입 코드
     * @return SearchType Enum, 일치하는 코드가 없으면 기본값(BOTH) 반환
     */
    public static SearchType fromCode(String code) {
        if (code == null) {
            return BOTH; // 기본값
        }

        for (SearchType type : SearchType.values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return BOTH; // 일치하는 코드가 없는 경우 기본값
    }
}
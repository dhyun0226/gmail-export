package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_NTFY_CN_D")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
public class NoticeContent extends BaseEntity {

    @Id
    @Column(name = "NTFY_NO", nullable = false)
    private Long noticeNo;

    @Column(name = "NTFY_CN", nullable = false, columnDefinition = "MEDIUMTEXT")
    private String noticeContent;

}
package com.denall.voc.domain;

import com.denall.voc.entity.Faq;
import com.denall.voc.entity.FaqContent;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.FaqStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.FaqRequestDto;
import com.denall.voc.model.table.FaqDto;
import com.denall.voc.repository.FaqContentRepository;
import com.denall.voc.repository.FaqQueryRepository;
import com.denall.voc.repository.FaqRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FaqService {

    private final FaqRepository faqRepository;
    private final FaqContentRepository faqContentRepository;
    private final FaqQueryRepository faqQueryRepository;
    private final FaqStruct faqStruct;
    private final ServiceChargePersonService serviceChargePersonService;

    /**
     * FAQ 생성
     *
     * @param faqDto FAQ DTO
     * @return 생성된 FAQ DTO
     */
    @Transactional
    public FaqDto create(FaqDto faqDto) {
        Faq faq = faqStruct.toEntity(faqDto);
        faq = faqRepository.save(faq);
        
        // FaqContent 생성 및 저장
        FaqContent faqContent = FaqContent.builder()
                .faqNo(faq.getFaqNumber())
                .faqContent(faqDto.getFaqContent())
                .build();
        faqContentRepository.save(faqContent);
        
        FaqDto result = faqStruct.toDto(faq);
        // Content 별도 조회하여 설정
        FaqContent savedFaqContent = faqContentRepository.findById(faq.getFaqNumber()).orElse(null);
        if (savedFaqContent != null) {
            result.setFaqContent(savedFaqContent.getFaqContent());
        }
        return result;
    }

    /**
     * FAQ 조회
     *
     * @param faqNumber FAQ 번호
     * @return FAQ DTO
     */
    @Transactional(readOnly = true)
    public FaqDto get(Long faqNumber) {
        FaqDto faqDto = faqQueryRepository.findByIdWithContent(faqNumber);
        if (faqDto == null) {
            throw new BusinessException("faq.notFound", faqNumber);
        }
        return faqDto;
    }

    /**
     * FAQ 수정
     *
     * @param faqNumber FAQ 번호
     * @param faqDto FAQ DTO
     * @return 수정된 FAQ DTO
     */
    @Transactional
    public FaqDto update(Long faqNumber, FaqDto faqDto) {
        Faq faq = faqRepository.findById(faqNumber)
                .orElseThrow(() -> new BusinessException("faq.notFound", faqNumber));

        faq.updateFaq(
                faqDto.getFaqTitle(),
                faqDto.getServiceCategoryCode(),
                faqDto.getSortOrder(),
                faqDto.getUseYn()
        );
        
        // FaqContent 수정
        FaqContent faqContent = faqContentRepository.findById(faqNumber)
                .orElse(FaqContent.builder()
                        .faqNo(faqNumber)
                        .faqContent(faqDto.getFaqContent())
                        .build());
        
        if (faqContent.getFaqNo() != null) {
            faqContent.setFaqContent(faqDto.getFaqContent());
        }
        faqContentRepository.save(faqContent);

        if (faqDto.getRegistererCorporationCode() != null
                && faqDto.getRegistererDepartmentCode() != null
                && faqDto.getRegistererEmployeeNumber() != null) {
            faq.updateRegisterer(
                    faqDto.getRegistererCorporationCode(),
                    faqDto.getRegistererDepartmentCode(),
                    faqDto.getRegistererEmployeeNumber()
            );
        }

        faq = faqRepository.save(faq);
        FaqDto result = faqStruct.toDto(faq);
        // Content 별도 조회하여 설정
        FaqContent savedFaqContent = faqContentRepository.findById(faq.getFaqNumber()).orElse(null);
        if (savedFaqContent != null) {
            result.setFaqContent(savedFaqContent.getFaqContent());
        }
        return result;
    }

    /**
     * FAQ 삭제
     *
     * @param faqNumber FAQ 번호
     */
    @Transactional
    public void delete(Long faqNumber) {
        Faq faq = faqRepository.findById(faqNumber)
                .orElseThrow(() -> new BusinessException("faq.notFound", faqNumber));

        // FaqContent 삭제
        faqContentRepository.deleteById(faqNumber);

        faqRepository.delete(faq);
    }

    /**
     * FAQ 검색
     *
     * @param requestDto FAQ 검색 조건
     * @return 검색 결과 및 총 건수
     */
    @Transactional(readOnly = true)
    public ResultDto<FaqDto> search(FaqRequestDto requestDto) {

        List<FaqDto> faqList = faqQueryRepository.searchFaqs(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getChannelCode(),
                requestDto.getUseYn(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getServiceCategoryCode()
        );

        long totalCount = faqQueryRepository.countFaqs(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getChannelCode(),
                requestDto.getUseYn(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
               requestDto.getServiceCategoryCode()
        );
        return new ResultDto<>(faqList, totalCount , requestDto.getServiceCategoryCode());
    }

    /**
     * 사용중인 FAQ 목록 조회
     *
     * @return 사용중인 FAQ DTO 목록
     */
    @Transactional(readOnly = true)
    public List<FaqDto> getActiveList() {
        List<Faq> faqList = faqRepository.findByUseYn("Y");
        return faqStruct.toDtoList(faqList);
    }

    /**
     * 정렬순서순 FAQ 목록 조회
     *
     * @return 정렬순서순 FAQ DTO 목록
     */
    @Transactional(readOnly = true)
    public List<FaqDto> getOrderedList() {
        List<Faq> faqList = faqRepository.findAllByOrderBySortOrderAsc();
        return faqStruct.toDtoList(faqList);
    }

    @Transactional(readOnly = true)
    public long getPosition(long faqNumber, String channelCode) {
        // 기존 단건 조회 로직 사용
        FaqDto faqDto = get(faqNumber);
        return faqQueryRepository.countPosition(faqNumber, channelCode, faqDto.getRgstProcDtm());
    }
}
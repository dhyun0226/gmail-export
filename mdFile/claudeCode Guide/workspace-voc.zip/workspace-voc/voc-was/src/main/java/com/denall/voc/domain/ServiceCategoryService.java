package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.ServiceCategory;
import com.denall.voc.mapper.ServiceCategoryStruct;
import com.denall.voc.model.response.TaskCategoryResponseDto;
import com.denall.voc.model.table.ServiceCategoryDto;
import com.denall.voc.repository.ServiceCategoryQueryRepository;
import com.denall.voc.repository.ServiceCategoryRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
public class ServiceCategoryService {

    private final ServiceCategoryRepository serviceCategoryRepository;
    private final ServiceCategoryStruct serviceCategoryStruct;
    private final ServiceCategoryQueryRepository serviceCategoryQueryRepository;

    /**
     * 모든 Service 카테고리 조회 (DTO 변환)
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getAllServiceCategories() {
        List<ServiceCategory> entities = serviceCategoryRepository.findAllByOrderBySortOrderAsc();
        return serviceCategoryStruct.toDtoList(entities);
    }

    /**
     * 특정 Service 카테고리 조회 (DTO 변환)
     */
    @Transactional(readOnly = true)
    public ServiceCategoryDto getServiceCategoryById(String ServiceCategoryCode) {
        return serviceCategoryRepository.findById(ServiceCategoryCode)
                .map(serviceCategoryStruct::toDto)
                .orElseThrow(() -> new EntityNotFoundException("Service 카테고리를 찾을 수 없습니다: " + ServiceCategoryCode));
    }
    /**
     * Service 카테고리 생성
     */
    @Transactional
    public ServiceCategoryDto createServiceCategory(ServiceCategoryDto ServiceCategoryDto) {
        // 중복 체크
        if (serviceCategoryRepository.existsById(ServiceCategoryDto.getServiceCategoryCode())) {
            throw new IllegalArgumentException("이미 존재하는 Service 카테고리 코드입니다: " + ServiceCategoryDto.getServiceCategoryCode());
        }

        // 상위 카테고리 존재 여부 확인 (있는 경우)
        if (ServiceCategoryDto.getUpServiceCategoryCode() != null && !ServiceCategoryDto.getUpServiceCategoryCode().isEmpty()) {
            serviceCategoryRepository.findById(ServiceCategoryDto.getUpServiceCategoryCode())
                    .orElseThrow(() -> new EntityNotFoundException("상위 Service 카테고리를 찾을 수 없습니다: " + ServiceCategoryDto.getUpServiceCategoryCode()));
        }

        // DTO -> 엔티티 변환
        ServiceCategory entity = serviceCategoryStruct.toEntity(ServiceCategoryDto);

        // 상위 카테고리 설정
        if (ServiceCategoryDto.getUpServiceCategoryCode() != null && !ServiceCategoryDto.getUpServiceCategoryCode().isEmpty()) {
            ServiceCategory parentEntity = serviceCategoryRepository.getReferenceById(ServiceCategoryDto.getUpServiceCategoryCode());
            entity.setUpServiceCategoryCode(parentEntity);
        }

        // 저장
        ServiceCategory savedEntity = serviceCategoryRepository.save(entity);
        // 엔티티 -> DTO 변환하여 반환
        return serviceCategoryStruct.toDto(savedEntity);
    }


    /**
     * Service 카테고리 삭제
     */
    @Transactional
    public void deleteServiceCategory(String ServiceCategoryCode) {
        // 카테고리 존재 여부 확인
        if (!serviceCategoryRepository.existsById(ServiceCategoryCode)) {
            throw new EntityNotFoundException("Service 카테고리를 찾을 수 없습니다: " + ServiceCategoryCode);
        }

        // 하위 카테고리가 있는지 확인
        if (serviceCategoryRepository.existsByUpServiceCategoryCode_ServiceCategoryCode(ServiceCategoryCode)) {
            throw new IllegalStateException("하위 카테고리가 존재하여 삭제할 수 없습니다: " + ServiceCategoryCode);
        }

        // 삭제 (또는 soft delete 처리)
        serviceCategoryRepository.deleteById(ServiceCategoryCode);
    }

    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getChildCategories(String parentCategoryCode) {
        List<ServiceCategory> childEntities = serviceCategoryRepository.findByUpServiceCategoryCode_ServiceCategoryCode(parentCategoryCode);
        return serviceCategoryStruct.toDtoList(childEntities);
    }
    
    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회 (openYn 조건 포함)
     * openYn이 'Y'인 경우: openYn이 'Y'인 카테고리만 조회
     * openYn이 'N'인 경우: 전체 카테고리 조회 (Y, N 모두)
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getChildCategories(String parentCategoryCode, Character openYn) {
        List<ServiceCategory> childEntities;
        
        if ('Y' == openYn) {
            // Y인 경우 Y인 것만 조회
            childEntities = serviceCategoryRepository.findByUpServiceCategoryCode_ServiceCategoryCodeAndOpenYn(parentCategoryCode, 'Y');
        } else {
            // N인 경우 전체 조회
            childEntities = serviceCategoryRepository.findByUpServiceCategoryCode_ServiceCategoryCode(parentCategoryCode);
        }
        
        return serviceCategoryStruct.toDtoList(childEntities);
    }

    /**
     * 최상위 카테고리 목록 조회 (상위 카테고리가 없고 openYn 조건을 만족하는 카테고리)
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getRootCategoriesByOpenYn(Character openYn) {
        List<ServiceCategory> rootEntities = serviceCategoryQueryRepository.findRootCategoriesByOpenYn(openYn);
        return serviceCategoryStruct.toDtoList(rootEntities);
    }

    /**
     * 엔티티를 직접 조회해야 하는 내부 메서드 (서비스 내부에서만 사용)
     */
    @Transactional(readOnly = true)
    protected ServiceCategory getServiceCategoryEntityById(String ServiceCategoryCode) {
        return serviceCategoryRepository.findById(ServiceCategoryCode)
                .orElseThrow(() -> new EntityNotFoundException("Service 카테고리를 찾을 수 없습니다: " + ServiceCategoryCode));
    }

    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     * @param categoryCode 카테고리 코드
     * @return 최상위 카테고리 DTO
     */
    @Transactional(readOnly = true)
    public ServiceCategoryDto findRootCategory(String categoryCode) {
        // 카테고리 코드 유효성 검사
        if (categoryCode == null || categoryCode.isEmpty()) {
            throw new IllegalArgumentException("카테고리 코드는 필수 입력값입니다.");
        }

        // 존재하는 카테고리인지 확인
        if (!serviceCategoryRepository.existsById(categoryCode)) {
            throw new EntityNotFoundException("카테고리를 찾을 수 없습니다: " + categoryCode);
        }

        // 최상위 카테고리 조회
        ServiceCategory rootCategory = serviceCategoryQueryRepository.findRootCategory(categoryCode);

        if (rootCategory == null) {
            throw new EntityNotFoundException("최상위 카테고리를 찾을 수 없습니다: " + categoryCode);
        }

        // 엔티티를 DTO로 변환하여 반환
        return serviceCategoryStruct.toDto(rootCategory);
    }

    /**
     * taskName으로 해당하는 2레벨 카테고리가 존재하는 1레벨 카테고리들을 조회
     * @param taskName 작업명 (예: "event")
     * @param openYn 공개 여부
     * @return 1레벨 카테고리 DTO 리스트
     */
    public List<ServiceCategoryDto> getRootCategoriesByTaskNameAndOpenYn(String taskName, Character openYn) {
        // taskName으로 TaskType enum에서 taskCode 찾기
        String taskCode = findTaskCodeByTaskName(taskName);
        if (taskCode == null) {
            throw new IllegalArgumentException("Invalid task name: " + taskName);
        }

        List<ServiceCategory> rootEntities = serviceCategoryQueryRepository
                .findRootCategoriesByTaskCodeAndOpenYn(taskCode, openYn);
        return serviceCategoryStruct.toDtoList(rootEntities);
    }

    /**
     * taskName으로 TaskType enum에서 taskCode를 찾는 헬퍼 메서드
     */
    private String findTaskCodeByTaskName(String taskName) {
        for (TaskType taskType : TaskType.values()) {
            if (taskType.getTaskName().equalsIgnoreCase(taskName)) {
                return taskType.getTaskCode();
            }
        }
        return null;
    }

    /**
     * 2레벨 카테고리 목록 조회 (distinct 적용)
     */
    /**
     * TaskType과 일치하는 2레벨 카테고리 조회 및 변환
     * @param openYn 공개 여부
     * @return TaskType 기준으로 매핑된 카테고리 목록
     */
    @Transactional(readOnly = true)
    public List<TaskCategoryResponseDto> getMatchingTaskCategories(Character openYn) {
        // 1. 2레벨 카테고리 데이터 가져오기
        List<ServiceCategoryDto> secondLevelCategories = serviceCategoryQueryRepository.findSecondLevelCategories(openYn);

        // 2. 중복 제거를 위한 맵 생성
        Map<String, TaskCategoryResponseDto> distinctCategories = new HashMap<>();

        // 3. 결과를 저장할 맵 (sortOrder를 키로 사용)
        Map<Integer, TaskCategoryResponseDto> sortedCategories = new TreeMap<>();

        // 4. 필터링 및 매핑
        for (ServiceCategoryDto category : secondLevelCategories) {
            String code = category.getServiceCategoryCode();
            String name = category.getServiceCategoryName();

            // '_' 기준으로 분리해서 뒷부분 확인
            if (code != null && code.contains("_")) {
                String[] parts = code.split("_");
                if (parts.length > 1) {
                    String suffix = parts[1];

                    // TaskType 열거형에서 일치하는 항목 찾기
                    for (TaskType taskType : TaskType.values()) {
                        // ServiceANSWER는 제외
                        if (taskType != TaskType.VOCANSWER && suffix.equals(taskType.getTaskCode())) {
                            TaskCategoryResponseDto dto = new TaskCategoryResponseDto(
                                    taskType.getTaskCode(),
                                    taskType.name().toLowerCase(),
                                    name
                            );

                            // ServiceCategoryName 기준으로 중복 제거하고, 최초 발견된 항목만 유지
                            if (!distinctCategories.containsKey(name)) {
                                distinctCategories.put(name, dto);
                                // 정렬을 위해 sortOrder를 키로 사용
                                sortedCategories.put(taskType.getSortOrder(), dto);
                            }
                            break;
                        }
                    }
                }
            }
        }

        // 5. 정렬된 결과 반환 (TreeMap은 키를 기준으로 자동 정렬)
        return new ArrayList<>(sortedCategories.values());
    }

    /**
     * 직원번호로 해당 직원이 담당하는 서비스 카테고리 목록 조회 (중복 제거)
     * @param employeeNumber 직원번호
     * @param category 카테고리 필터 (예: NTF)
     * @return 서비스 카테고리 DTO 리스트
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getServiceCategoriesByEmployeeNumber(String employeeNumber, String category) {
        // 직원번호 유효성 검사
        if (employeeNumber == null || employeeNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("직원번호는 필수 입력값입니다.");
        }

        // 직원번호로 서비스 카테고리 조회
        List<ServiceCategory> categories = serviceCategoryQueryRepository.findServiceCategoriesByEmployeeNumber(employeeNumber, category);

        // 조회 결과가 없는 경우
        if (categories.isEmpty()) {
            throw new EntityNotFoundException("직원번호 " + employeeNumber + "에 해당하는 서비스 카테고리가 없습니다.");
        }

        // 엔티티를 DTO로 변환하여 반환
        return serviceCategoryStruct.toDtoList(categories);
    }

    /**
     * 직원번호로 해당 직원이 담당하는 최상위 서비스 카테고리 목록 조회 (중복 제거)
     * @param employeeNumber 직원번호
     * @return 최상위 서비스 카테고리 DTO 리스트
     */
    @Transactional(readOnly = true)
    public List<ServiceCategoryDto> getTopLevelServiceCategoriesByEmployeeNumber(String employeeNumber, String category) {
        // 직원번호 유효성 검사
        if (employeeNumber == null || employeeNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("직원번호는 필수 입력값입니다.");
        }

        // 직원번호로 최상위 서비스 카테고리 조회
        List<ServiceCategory> topLevelCategories = serviceCategoryQueryRepository.findTopLevelServiceCategoriesByEmployeeNumber(employeeNumber, category);

        // 조회 결과가 없는 경우
        if (topLevelCategories.isEmpty()) {
            throw new EntityNotFoundException("직원번호 " + employeeNumber + "에 해당하는 최상위 서비스 카테고리가 없습니다.");
        }

        // 엔티티를 DTO로 변환하여 반환
        return serviceCategoryStruct.toDtoList(topLevelCategories);
    }
}
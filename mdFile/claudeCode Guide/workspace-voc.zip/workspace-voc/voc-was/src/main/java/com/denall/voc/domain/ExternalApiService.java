package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.Notice;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.mapper.NoticeStruct;
import com.denall.voc.model.common.ExternalApiDto;
import com.denall.voc.model.table.NoticeDto;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.repository.EventRepository;
import com.denall.voc.repository.FaqRepository;
import com.denall.voc.repository.NoticeRepository;
import com.denall.voc.repository.QnaAnswerDetailRepository;
import com.denall.voc.repository.QnaRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
@Service
@RequiredArgsConstructor
public class ExternalApiService {

    private final EventRepository eventRepository;
    private final NoticeRepository noticeRepository;
    private final FaqRepository faqRepository;
    private final QnaRepository qnaRepository;
    private final QnaAnswerDetailRepository qnaAnswerDetailRepository;
    private final NoticeStruct noticeStruct;
    private final TxmServiceClient txmServiceClient;

    // 🔒 링크 상수 정의
    private static final String BASE_URL = "http://10.210.0.146:7023";
    private static final String S_BASE_URL = "https://voc.denall.com";
    private static final String TV_CHANNEL_PARAM = "?channel=tv";
    private static final String MALL_CHANNEL_PARAM = "?channel=mall";

    /**
     * TV 공지사항 푸터 조회
     *
     * @return TV 공지사항 푸터 리스트
     */
    public List<ExternalApiDto> getTvNoticesFooter() {
        String tvCode = "D001";

        return noticeRepository
                .findTop3ByserviceCategoryCodeContainingOrderByNoticeRegistrationDatetimeDesc(tvCode)
                .stream()
                .map(n -> ExternalApiDto.builder()
                        .type("notice")
                        .id(n.getNoticeNumber())
                        .title(n.getNoticeTitle())
                        .createdAt(n.getNoticeRegistrationDatetime())
                        .link(BASE_URL + "/notice/detail/" + n.getNoticeNumber() + TV_CHANNEL_PARAM)
                        .build())
                .toList();
    }

    /**
     * Mall 공지사항 및 이벤트 통합 최근 5개 조회
     *
     * @return 공지사항 + 이벤트 통합 리스트
     */
    public List<ExternalApiDto> getMallNoticesAndEvent() {
        String mallCode = "D002";

        List<ExternalApiDto> notices = noticeRepository
                .findTop5ByServiceCategoryCodeContainingAndOpenYnOrderByNoticeRegistrationDatetimeDesc(mallCode, "Y")
                .stream()
                .map(n -> ExternalApiDto.builder()
                        .type("notice")
                        .id(n.getNoticeNumber())
                        .title(n.getNoticeTitle())
                        .createdAt(n.getNoticeRegistrationDatetime())
                        .link(BASE_URL + "/notice/detail/" + n.getNoticeNumber() + MALL_CHANNEL_PARAM)
                        .build())
                .toList();

        List<ExternalApiDto> events = eventRepository
                .findTop5RecentEvents(mallCode, "Y")
                .stream()
                .map(e -> ExternalApiDto.builder()
                        .type("event")
                        .id(e.getEventNumber())
                        .title(e.getEventTitle())
                        .createdAt(e.getEventRegistrationDatetime())
                        .link(BASE_URL + "/event/detail/" + e.getEventNumber() + MALL_CHANNEL_PARAM)
                        .build())
                .toList();

        return Stream.concat(notices.stream(), events.stream())
                .sorted(Comparator.comparing(ExternalApiDto::getCreatedAt).reversed())
                .limit(5)
                .toList();
    }

    /**
     * 게시판별 게시물 조회
     *
     * @param boardType 게시판 타입 (notice, faq, qna, event)
     * @param channel 채널명 (tv, mall, software, education, job)
     * @param count 조회할 개수
     * @return 게시물 리스트
     */
    public List<ExternalApiDto> getBoardPosts(String boardType, String channel, int count) {
        String channelCode = getChannelCode(channel);
        String channelParam = "?channel=" + channel;
        boolean isSoftware = "software".equalsIgnoreCase(channel);

        switch (boardType.toLowerCase()) {
            case "notice":
                return noticeRepository.findByChannelCodeAndOpenYnOrderByDateDesc(
                                channelCode, "Y", PageRequest.of(0, count))
                        .stream()
                        .map(n -> {
                            var builder = ExternalApiDto.builder()
                                    .type("notice")
                                    .id(n.getNoticeNumber())
                                    .title(n.getNoticeTitle())
                                    .createdAt(n.getNoticeRegistrationDatetime())
                                    .link(BASE_URL + "/notice/detail/" + n.getNoticeNumber() + channelParam);

                            if (isSoftware) {
                                var info = mapCategory(n.getServiceCategoryCode());
                                builder.categoryName(info.name)
                                        .categoryCss(info.css)
                                        .flagNew(isNewPost(n.getNoticeRegistrationDatetime()) ? "Y" : "N")
                                        .fileCnt(getFileCount(n.getFileId(), TaskType.NOTICE));
                            }

                            return builder.build();
                        })
                        .toList();

            case "faq":
                return faqRepository.findByChannelCodeAndUseYnOrderByDateDesc(
                                channelCode, "Y", PageRequest.of(0, count))
                        .stream()
                        .map(f -> {
                            var builder = ExternalApiDto.builder()
                                    .type("faq")
                                    .id(f.getFaqNumber())
                                    .title(f.getFaqTitle())
                                    .createdAt(f.getRgstProcDtm())
                                    .link(BASE_URL + "/faq/detail/" + f.getFaqNumber() + channelParam);

                            if (isSoftware) {
                                var info = mapCategory(f.getServiceCategoryCode());
                                builder.categoryName(info.name)
                                        .categoryCss(info.css)
                                        .flagNew(isNewPost(f.getRgstProcDtm()) ? "Y" : "N")
                                        .fileCnt(getFileCount(f.getFileId(), TaskType.FAQ));
                            }

                            return builder.build();
                        })
                        .toList();

            case "qna":
                return qnaRepository.findByChannelCodeOrderByDateDesc(
                                channelCode, PageRequest.of(0, count))
                        .stream()
                        .map(q -> {
                            var builder = ExternalApiDto.builder()
                                    .type("qna")
                                    .id(q.getQnaNumber())
                                    .title(q.getQnaTitle())
                                    .createdAt(q.getQnaRegistrationDatetime())
                                    .link(BASE_URL + "/qna/detail/" + q.getQnaNumber() + channelParam);

                            if (isSoftware) {
                                var info = mapCategory(q.getServiceCategoryCode());
                                // 담당자가 아닌 댓글 개수 조회
                                Long userCommentCount = qnaAnswerDetailRepository
                                        .countByQnaNumberAndAnswererEmployeeNumberIsNull(q.getQnaNumber());
                                
                                // 담당자 답변 여부 확인
                                boolean hasEmployeeAnswer = qnaAnswerDetailRepository
                                        .existsByIdQnaNumberAndAnswererEmployeeNumberIsNotNull(q.getQnaNumber());
                                
                                builder.categoryName(info.name)
                                        .categoryCss(info.css)
                                        .flagNew(isNewPost(q.getQnaRegistrationDatetime()) ? "Y" : "N")
                                        .fileCnt(getFileCount(q.getFileId(), TaskType.QNA))
                                        .memoCnt(String.valueOf(userCommentCount))
                                        .qnaYn(hasEmployeeAnswer ? "Y" : "N");
                            }

                            return builder.build();
                        })
                        .toList();

            case "event":
                return eventRepository.findByChannelCodeAndUseYnOrderByDateDesc(
                                channelCode, "Y", PageRequest.of(0, count))
                        .stream()
                        .map(e -> {
                            var builder = ExternalApiDto.builder()
                                    .type("event")
                                    .id(e.getEventNumber())
                                    .title(e.getEventTitle())
                                    .createdAt(e.getEventRegistrationDatetime())
                                    .link(BASE_URL + "/event/detail/" + e.getEventNumber() + channelParam);

                            if (isSoftware) {
                                var info = mapCategory(e.getServiceCategoryCode());
                                builder.categoryName(info.name)
                                        .categoryCss(info.css)
                                        .flagNew(isNewPost(e.getEventRegistrationDatetime()) ? "Y" : "N")
                                        .fileCnt(getFileCount(e.getFileId(), TaskType.EVENT));
                            }

                            return builder.build();
                        })
                        .toList();

            default:
                throw new IllegalArgumentException("지원하지 않는 게시판 타입입니다: " + boardType);
        }
    }

    /**
     * 특정 카테고리 코드의 공지사항 조회
     *
     * @param categoryCode 카테고리 코드
     * @param topFixedOnly 상단고정 여부 ("Y"인 경우 상단고정만, null인 경우 전체)
     * @param count 조회할 개수
     * @return 공지사항 리스트
     */
    public List<ExternalApiDto> getNoticesByCategoryCode(String categoryCode, String topFixedOnly, int count) {
        List<Notice> notices;

        if ("Y".equals(topFixedOnly)) {
            notices = noticeRepository.findByServiceCategoryCodeContainingAndTopFixedYnAndOpenYnOrderByNoticeRegistrationDatetimeDesc(
                    categoryCode, "Y", "Y", PageRequest.of(0, count));
        } else {
            notices = noticeRepository.findByServiceCategoryCodeContainingAndOpenYnOrderByNoticeRegistrationDatetimeDesc(
                    categoryCode, "Y", PageRequest.of(0, count));
        }

        return notices.stream()
                .map(n -> ExternalApiDto.builder()
                        .type("notice")
                        .id(n.getNoticeNumber())
                        .title(n.getNoticeTitle())
                        .createdAt(n.getNoticeRegistrationDatetime())
                        .link(BASE_URL + "/notice/detail/" + n.getNoticeNumber())
                        .build())
                .toList();
    }

    /**
     * 채널명을 채널 코드로 변환
     */
    private String getChannelCode(String channel) {
        switch (channel.toLowerCase()) {
            case "tv":
                return "D001";
            case "mall":
                return "D002";
            case "education":
                return "D003";
            case "job":
                return "D004";
            case "software":
                return "D005";
            default:
                throw new IllegalArgumentException("지원하지 않는 채널입니다: " + channel);
        }
    }


    /** serviceCategoryCode → categoryName, categoryCss 매핑 헬퍼 */
    private CategoryInfo mapCategory(String svcCtgCd) {
        if (svcCtgCd == null || svcCtgCd.length() < 3) {
            return new CategoryInfo("공통", "cate_d");
        }
        String suffix = svcCtgCd.substring(svcCtgCd.length() - 3);

        return switch (suffix) {
            case "001" -> new CategoryInfo("두번에",    "cate_d");
            case "002" -> new CategoryInfo("OneClick","cate_o");
            case "003" -> new CategoryInfo("보험정보",  "cate_b");
            case "004" -> new CategoryInfo("V-Ceph",   "cate_v");
            case "005" -> new CategoryInfo("One2",     "cate_one2");
            case "006" -> new CategoryInfo("One3",     "cate_one3");
            case "999" -> new CategoryInfo("공통",     "cate_e");
            default     -> new CategoryInfo("공통",     "cate_e");
        };
    }

    public List<ExternalApiDto> getTodayNotices(String categoryCode, int count) {
        return noticeRepository.findByCategoryCodeWithDefaultAndOpenYnOrderByDateDesc(
                        categoryCode, "Y", PageRequest.of(0, count))
                .stream()
                .map(n -> {
                    var builder = ExternalApiDto.builder()
                            .type("notice")
                            .id(n.getNoticeNumber())
                            .title(n.getNoticeTitle())
                            .createdAt(n.getNoticeRegistrationDatetime())
                            .link(BASE_URL + "/notice/detail/" + n.getNoticeNumber());

                    var info = mapCategory(n.getServiceCategoryCode());
                    builder.categoryName(info.name)
                            .categoryCss(info.css)
                            .flagNew(isNewPost(n.getNoticeRegistrationDatetime()) ? "Y" : "N")
                            .fileCnt(getFileCount(n.getFileId(), TaskType.NOTICE));
                    return builder.build();
                })
                .toList();
    }


    /** 간단한 DTO 매핑용 헬퍼 클래스 */
    private static class CategoryInfo {
        final String name, css;
        CategoryInfo(String name, String css) {
            this.name = name;
            this.css  = css;
        }
    }

    /**
     * 등록일자 기준 일주일 이내인지 확인
     */
    private boolean isNewPost(LocalDateTime createdAt) {
        if (createdAt == null) {
            return false;
        }
        return createdAt.isAfter(LocalDateTime.now().minusWeeks(1));
    }

    /**
     * 파일 개수 조회
     */
    private String getFileCount(String fileId, TaskType taskType) {
        if (StringUtils.isEmpty(fileId)) {
            return "0";
        }
        
        try {
            TxmFileListResponse fileResponse = txmServiceClient.getFileList(
                FileUtils.buildRequest(taskType, fileId)
            );
            
            if (fileResponse.getStatus() == 200 && fileResponse.getData() != null) {
                return String.valueOf(fileResponse.getData().size());
            }
            return "0";
        } catch (Exception e) {
            // 파일 조회 실패 시 0 반환
            return "0";
        }
    }

}

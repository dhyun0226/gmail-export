package com.denall.voc.mapper;

import com.denall.voc.entity.QnaAnswerDetail;
import com.denall.voc.entity.QnaAnswerDetailId;
import com.denall.voc.model.table.QnaAnswerDetailDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface QnaAnswerDetailStruct extends StructMapper<QnaAnswerDetail, QnaAnswerDetailDto> {

    @Mapping(target = "qnaNumber", source = "id.qnaNumber")
    @Mapping(target = "qnaAnswerDetailNumber", source = "id.qnaAnswerDetailNumber")
    QnaAnswerDetailDto toDto(QnaAnswerDetail entity);

    @Mapping(target = "id", expression = "java(createQnaAnswerDetailId(dto))")
    @Mapping(target = "qna", ignore = true)
    QnaAnswerDetail toEntity(QnaAnswerDetailDto dto);

    default QnaAnswerDetailId createQnaAnswerDetailId(QnaAnswerDetailDto dto) {
        if (dto.getQnaNumber() == null || dto.getQnaAnswerDetailNumber() == null) {
            return null;
        }

        return new QnaAnswerDetailId(dto.getQnaNumber(), dto.getQnaAnswerDetailNumber());
    }
}
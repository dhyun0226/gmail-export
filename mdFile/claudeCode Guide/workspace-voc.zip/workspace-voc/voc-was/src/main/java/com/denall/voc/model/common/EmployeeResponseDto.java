package com.denall.voc.model.common;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EmployeeResponseDto {
    private Integer status;
    private String code;
    private String message;
    private Employee data;

    @Data
    public static class Employee {
        private String corporationCode;
        private String employeeNumber;
        private String employeeName;
        private String departmentCode;
        private String departmentName;
        private String dutyCode;
        private String dutyName;
        private String positionCode;
        private String positionName;
    }
}

package com.denall.voc.constant;


public enum TaskType {
    INQUIRY("INQ", "TB_INDV_INQY_M",5,"inquiry"),
    NOTICE("NTF", "TB_NTFY_M",1,"notice"),
    FAQ("FAQ", "TB_FAQ_M",2,"faq"),
    QNA("QNA", "TB_QNA_M",4,"qna"),
    EVENT("EVT", "TB_EVT_M",3,"event"),
    VOC("VOC", "TB_VOC_M",6,"voc"),
    VOCANSWER("VAN", "TB_VOC_ANS_D",7,"vocAnswer");

    private final String taskCode;
    private final String tableName;
    private final int sortOrder;
    private final String taskName;

    TaskType(String taskCode, String tableName,int sortOrder, String taskName) {
        this.taskCode = taskCode;
        this.tableName = tableName;
        this.sortOrder = sortOrder;
        this.taskName = taskName;
    }

    public String getTaskCode() {
        return taskCode;
    }

    public String getTableName() {
        return tableName;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public String getTaskName() {
        return taskName;
    }
}
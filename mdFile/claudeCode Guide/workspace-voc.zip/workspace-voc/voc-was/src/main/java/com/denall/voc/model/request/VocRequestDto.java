package com.denall.voc.model.request;

import com.denall.voc.model.base.PagingDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VocRequestDto implements PagingDto {
    private String searchType;
    private String keyword;
    private String itemCode;

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @JsonIgnore
    public Pageable getPageable() {
        int pageIndex = getOffset() / getLimit();
        return PageRequest.of(pageIndex, getLimit());
    }
}

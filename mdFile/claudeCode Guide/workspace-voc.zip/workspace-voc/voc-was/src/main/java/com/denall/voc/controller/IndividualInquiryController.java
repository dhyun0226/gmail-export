package com.denall.voc.controller;

import com.denall.voc.domain.IndividualInquiryService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.IndividualInquiryRequestDto;
import com.denall.voc.model.response.IndividualInquiryResponseDto;
import com.denall.voc.model.table.IndividualInquiryDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/individual-inquiries")
@RequiredArgsConstructor
@Tag(name = "개인문의", description = "개인문의 API")
public class IndividualInquiryController {

    private final IndividualInquiryService individualInquiryService;

    @PostMapping
    @Operation(summary = "개인문의 등록", description = "개인문의를 등록합니다.")
    @ApiResponse(responseCode = "201", description = "등록 성공")
    public ResponseEntity<IndividualInquiryDto> create(
            @RequestHeader(name = "X-USER-ID") String userId,
            @RequestBody @Valid IndividualInquiryDto inquiryDto) {
        inquiryDto.setWriterMemberId(userId);
        IndividualInquiryDto createdInquiry = individualInquiryService.create(inquiryDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdInquiry);
    }

    @GetMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의 상세 조회", description = "개인문의 번호로 개인문의 상세 정보를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    @ApiResponse(responseCode = "404", description = "개인문의를 찾을 수 없음")
    public ResponseEntity<IndividualInquiryResponseDto> get(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber) {
        IndividualInquiryResponseDto inquiryDto = individualInquiryService.getInquiryWithAnswer(inquiryNumber);
        return ResponseEntity.ok(inquiryDto);
    }

    @GetMapping
    @Operation(summary = "개인문의 목록 조회", description = "개인문의 목록을 페이징 처리하여 조회합니다.")
    public ResponseEntity<ResultDto<IndividualInquiryResponseDto>> list(
            IndividualInquiryRequestDto requestDto,@RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode) {
        ResultDto<IndividualInquiryResponseDto> result = individualInquiryService.search(requestDto, userId, corporationCode);
        return ResponseEntity.ok(result);
    }

    @PutMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의 수정", description = "개인문의 번호로 개인문의 정보를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "수정 성공")
    @ApiResponse(responseCode = "404", description = "개인문의를 찾을 수 없음")
    public ResponseEntity<IndividualInquiryDto> update(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber,
            @RequestBody @Valid IndividualInquiryDto inquiryDto) {
        IndividualInquiryDto updatedInquiry = individualInquiryService.update(inquiryNumber, inquiryDto);
        return ResponseEntity.ok(updatedInquiry);
    }

    @DeleteMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의 삭제", description = "개인문의 번호로 개인문의를 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "삭제 성공")
    @ApiResponse(responseCode = "404", description = "개인문의를 찾을 수 없음")
    public ResponseEntity<Void> delete(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber) {
        individualInquiryService.delete(inquiryNumber);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    @Operation(summary = "전체 개인문의 조회", description = "모든 개인문의와 답변 데이터를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    public ResponseEntity<List<IndividualInquiryResponseDto>> getAllInquiriesWithAnswers(
            @RequestParam String channelCode,
            @RequestParam(required = false) String serviceCategoryCode,
            @RequestParam(required = false) String writerMemberId,
            @RequestParam(required = false) String keyword) {
        List<IndividualInquiryResponseDto> inquiries = individualInquiryService.getAllInquiriesWithAnswers(
                channelCode,
                serviceCategoryCode,
                writerMemberId,
                keyword);
        return ResponseEntity.ok(inquiries);
    }
}
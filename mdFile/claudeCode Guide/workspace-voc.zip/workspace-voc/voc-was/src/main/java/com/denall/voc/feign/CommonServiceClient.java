package com.denall.voc.feign;

import com.denall.voc.model.common.EmailRequestDto;
import com.denall.voc.model.common.MMSRequestDto;
import com.osstem.ow.api.feign.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "commonClient", url = "${occ.api.com.root.uri}", configuration = FeignClientConfig.class)
public interface CommonServiceClient {
    @PostMapping("/mms/mt/trans/add")
    void sendMMS(MMSRequestDto requests);

    @PostMapping("/mail/send")
    void sendEmail(EmailRequestDto requests);
}

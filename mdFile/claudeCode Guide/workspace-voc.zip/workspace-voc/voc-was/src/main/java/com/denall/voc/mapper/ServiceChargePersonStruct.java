package com.denall.voc.mapper;


import com.denall.voc.entity.ServiceChargePerson;
import com.denall.voc.model.response.ServiceChargePersonResponseDto;
import com.denall.voc.model.table.ServiceChargePersonDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ServiceChargePersonStruct extends StructMapper<ServiceChargePerson, ServiceChargePersonDto> {
    ServiceChargePersonResponseDto toResponseDto(ServiceChargePerson ServiceChargePerson);

    // 엔티티 리스트를 DTO 리스트로 변환
    List<ServiceChargePersonDto> toDtoList(List<ServiceChargePerson> ServiceChargePersonList);

    // 엔티티 리스트를 응답 DTO 리스트로 변환
    List<ServiceChargePersonResponseDto> toResponseDtoList(List<ServiceChargePerson> ServiceChargePersonList);

    // DTO 리스트를 엔티티 리스트로 변환
    List<ServiceChargePerson> toEntityList(List<ServiceChargePersonDto> ServiceChargePersonDtoList);
}
package com.denall.voc.feign;

import com.denall.voc.model.common.BusinessPartnerCodeResponseDto;
import com.denall.voc.model.common.CustomerInfoResponseDto;
import com.denall.voc.model.common.EmployeeResponseDto;
import com.denall.voc.model.dnc.DncMemberInfoResponse;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.osstem.ow.api.feign.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "dncClient", url = "${occ.api.dnc.root.uri}", configuration = FeignClientConfig.class)
public interface DncServiceClient {
    @GetMapping("/member/info/getMemberInfo")
    DncMemberInfoResponse getMemberInfo(@RequestParam("memberId") String memberId);

    @GetMapping("/member/info/get/businessmanCustomerCode")
    BusinessPartnerCodeResponseDto getBusinessPartnerCode(@RequestParam String memberId);

    @GetMapping("/sales-employee/getByBusinessCustomerCode")
    EmployeeResponseDto getBusinessPartnerSalesEmployeeDto(@RequestParam String businessmanCustomerCode);

    // 사업자거래처 정보 조회
    @GetMapping("/businessman-customer/getBusinessmanCustomerInfo")
    CustomerInfoResponseDto getBusinessmanCustomerInfo(@RequestParam String businessmanCustomerCode);

}

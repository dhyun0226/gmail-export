package com.denall.voc.model.response;

import com.denall.voc.model.txm.File;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "공지 응답 DTO")
public class NoticeResponseDto {

    @Schema(description = "공지 번호", example = "1")
    private Long noticeNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Schema(description = "공개 여부", example = "Y")
    private String openYn;

    @Schema(description = "상단 고정 여부", example = "N")
    private String topFixedYn;

    @Schema(description = "공지 제목", example = "시스템 점검 안내")
    private String noticeTitle;

    @Schema(description = "공지 내용", example = "안녕하세요. 시스템 점검이 예정되어 있습니다. 자세한 내용은...")
    private String noticeContent;

    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "공지 등록 일시", example = "2025-04-04T09:00:00")
    private LocalDateTime noticeRegistrationDatetime;

    @Schema(description = "파일 ID", example = "file789")
    private String fileId;

    @Schema(description = "조회 건수", example = "157")
    private Short inquiryCount;

    @Schema(description = "공지사항 앞 목록")
    private NoticeResponseDto previousNotices;

    @Schema(description = "공지사항 뒤 목록")
    private NoticeResponseDto nextNotices;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "수정자 사원 번호")
    private String updateEmployeeNumber;

    @Schema(description = "수정일시")
    private LocalDateTime updateDatetime;

    public void setFileList(TxmFileListResponse txmFileListResponse) {
        this.fileList = txmFileListResponse.getData();
    }

    public void setUpdateInfo(String updateEmployeeNumber, LocalDateTime updateDatetime) {
        this.updateEmployeeNumber = updateEmployeeNumber;
        this.updateDatetime = updateDatetime;
    }

}
package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.Notice;
import com.denall.voc.entity.NoticeContent;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.NoticeStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.NoticeRequestDto;
import com.denall.voc.model.response.NoticeResponseDto;
import com.denall.voc.model.table.NoticeDto;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.EventRepository;
import com.denall.voc.repository.NoticeContentRepository;
import com.denall.voc.repository.NoticeQueryRepository;
import com.denall.voc.repository.NoticeRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository noticeRepository;
    private final NoticeContentRepository noticeContentRepository;
    private final NoticeQueryRepository noticeQueryRepository;
    private final NoticeStruct noticeStruct;
    private final TxmServiceClient txmServiceClient;
    private final ServiceChargePersonService serviceChargePersonService;


    /**
     * 공지 생성
     *
     * @param noticeDto 공지 DTO
     * @return 생성된 공지 DTO
     */
    @Transactional
    public NoticeDto create(NoticeDto noticeDto) {
        noticeDto.setNoticeRegistrationDatetime(LocalDateTime.now());
        Notice notice = noticeStruct.toEntity(noticeDto);
        notice = noticeRepository.save(notice);
        
        // NoticeContent 생성 및 저장
        NoticeContent noticeContent = NoticeContent.builder()
                .noticeNo(notice.getNoticeNumber())
                .noticeContent(noticeDto.getNoticeContent())
                .build();
        noticeContentRepository.save(noticeContent);

        if (!noticeDto.getFileList().isEmpty() && notice.getNoticeNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareNoticeFiles(
                    noticeDto.getFileList(),
                    notice.getNoticeNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }

            notice.attachFile(notice.getNoticeNumber().toString());
            noticeRepository.save(notice);
        }

        NoticeDto result = noticeStruct.toDto(notice);
        // Content 별도 조회하여 설정
        noticeContent = noticeContentRepository.findById(notice.getNoticeNumber()).orElse(null);
        if (noticeContent != null) {
            result.setNoticeContent(noticeContent.getNoticeContent());
        }
        return result;
    }

    /**
     * 공지 조회
     *
     * @param noticeNumber 공지 번호
     * @return 공지 DTO
     */
    @Transactional
    public NoticeResponseDto get(Long noticeNumber, String channelCode, String serviceCategoryCode, String userRole ) {
        NoticeResponseDto noticeResponseDto = noticeQueryRepository.findByIdWithContent(noticeNumber);
        if (noticeResponseDto == null) {
            throw new BusinessException("notice.notFound", noticeNumber);
        }
        if (StringUtils.isNotEmpty(noticeResponseDto.getFileId())) {
            TxmFileListResponse vocFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.NOTICE, noticeResponseDto.getFileId()));
            if (vocFileResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            noticeResponseDto.setFileList(vocFileResponse);
        }

        Notice previousNotice = noticeQueryRepository.findPreviousNotice(noticeNumber, channelCode, serviceCategoryCode);
        Notice nextNotice = noticeQueryRepository.findNextNotice(noticeNumber, channelCode, serviceCategoryCode);

        noticeResponseDto.setPreviousNotices(noticeStruct.toResponseDto(previousNotice));
        noticeResponseDto.setNextNotices(noticeStruct.toResponseDto(nextNotice));

        // 조회수 증가
        if (userRole == null) {
            Notice notice = noticeRepository.findById(noticeNumber).orElse(null);
            if (notice != null) {
                notice.incrementInquiryCount();
                noticeRepository.save(notice);
            }
        }

        return noticeResponseDto;
    }

    /**
     * 공지 수정
     *
     * @param noticeNumber 공지 번호
     * @param noticeDto 공지 DTO
     * @return 수정된 공지 DTO
     */
    @Transactional
    public NoticeDto update(Long noticeNumber, NoticeDto noticeDto) {
        Notice notice = noticeRepository.findById(noticeNumber)
                .orElseThrow(() -> new BusinessException("notice.notFound", noticeNumber));

        notice.updateNotice(
                noticeDto.getNoticeTitle(),
                noticeDto.getServiceCategoryCode(),
                noticeDto.getOpenYn(),
                noticeDto.getTopFixedYn()
        );
        
        // NoticeContent 수정
        NoticeContent noticeContent = noticeContentRepository.findById(noticeNumber)
                .orElse(NoticeContent.builder()
                        .noticeNo(noticeNumber)
                        .noticeContent(noticeDto.getNoticeContent())
                        .build());
        
        if (noticeContent.getNoticeNo() != null) {
            noticeContent.setNoticeContent(noticeDto.getNoticeContent());
        }
        noticeContentRepository.save(noticeContent);

        // 파일 처리 - FileUtils 활용
        FileUtils.processFiles(
                noticeDto.getFileList(),
                TaskType.NOTICE,
                notice.getNoticeNumber().toString(),
                txmServiceClient,
                notice::attachFile,
                notice::detachFile // 모든 파일이 삭제된 경우 엔티티에서 파일 ID 제거
        );

        // 등록자 정보 업데이트
        if (noticeDto.getRegistererCorporationCode() != null
                && noticeDto.getRegistererDepartmentCode() != null
                && noticeDto.getRegistererEmployeeNumber() != null) {
            notice.updateRegisterer(
                    noticeDto.getRegistererCorporationCode(),
                    noticeDto.getRegistererDepartmentCode(),
                    noticeDto.getRegistererEmployeeNumber()
            );
        }

        notice = noticeRepository.save(notice);
        NoticeDto result = noticeStruct.toDto(notice);
        // Content 별도 조회하여 설정
        noticeContent = noticeContentRepository.findById(notice.getNoticeNumber()).orElse(null);
        if (noticeContent != null) {
            result.setNoticeContent(noticeContent.getNoticeContent());
        }
        return result;
    }

    /**
     * 공지 삭제
     *
     * @param noticeNumber 공지 번호
     */
    @Transactional
    public void delete(Long noticeNumber) {
        Notice notice = noticeRepository.findById(noticeNumber)
                .orElseThrow(() -> new BusinessException("notice.notFound", noticeNumber));

        // NoticeContent 삭제
        noticeContentRepository.deleteById(noticeNumber);

        noticeRepository.delete(notice);
    }

    /**
     * 공지 검색
     *
     * @param requestDto 공지 검색 조건
     * @return 검색 결과 및 총 건수
     */
    @Transactional(readOnly = true)
    public ResultDto<NoticeResponseDto> search(NoticeRequestDto requestDto) {

        // QueryRepository 호출
        List<NoticeResponseDto> noticeList =noticeQueryRepository.searchNotices(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getOpenYn(),
                requestDto.getTopFixedYn(),
                requestDto.getServiceCategoryCode());

        long totalCount = noticeQueryRepository.countINotices(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getOpenYn(),
                requestDto.getTopFixedYn(),
                requestDto.getServiceCategoryCode());

        return new ResultDto<>(noticeList, totalCount, requestDto.getServiceCategoryCode());
    }

    /**
     * 상단 고정 공지 목록 조회
     *
     * @return 상단 고정 공지 DTO 목록
     */
    @Transactional(readOnly = true)
    public List<NoticeDto> getTopFixedList() {
        List<Notice> noticeList = noticeRepository.findByopenYnAndTopFixedYn("Y", "Y");
        return noticeStruct.toDtoList(noticeList);
    }

}
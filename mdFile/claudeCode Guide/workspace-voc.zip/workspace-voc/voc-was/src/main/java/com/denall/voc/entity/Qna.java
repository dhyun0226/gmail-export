package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_QNA_M")
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class Qna extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "QNA_NO")
    private Long qnaNumber;

    @Column(name = "SVC_CTG_CD", length = 12, nullable = false)
    private String serviceCategoryCode;

    @Column(name = "WRTR_MEM_ID", nullable = false, length = 20)
    private String writerMemberId;

    @Column(name = "ITM_CD", length = 90)
    private String itemCode;

    @Column(name = "OPEN_YN", nullable = false, length = 1)
    private String openYn;

    @Column(name = "QNA_TTL", nullable = false, length = 100)
    private String qnaTitle;

    @Column(name = "QNA_RGST_DTM", nullable = false)
    private LocalDateTime qnaRegistrationDatetime;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    @Column(name = "ANS_CNT")
    private Short answerCount;

    @Column(name = "INQ_CNT")
    private Short inquiryCount;


    public void setFileId(String fileId) {
        this.fileId = fileId;
    }


    // 비즈니스 메소드
    public void updateQna(String qnaTitle, String openYn, String itemCode, String serviceCategoryCode) {
        this.qnaTitle = qnaTitle;
        this.openYn = openYn;
        this.itemCode = itemCode;
        this.serviceCategoryCode = serviceCategoryCode;
    }

    public void incrementAnswerCount() {
        this.answerCount = this.answerCount == null ? 1 : (short)(this.answerCount + 1);
    }

    public void decrementAnswerCount() {
        if (this.answerCount != null && this.answerCount > 0) {
            this.answerCount--;
        }
    }
    

}
package com.denall.voc.domain;

import com.denall.voc.entity.Event;
import com.denall.voc.entity.EventAnswer;
import com.denall.voc.entity.EventAnswerId;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.mapper.EventAnswerStruct;
import com.denall.voc.model.table.EventAnswerDto;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.EventAnswerRepository;
import com.denall.voc.repository.EventRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventAnswerService {

    private final EventRepository eventRepository;
    private final EventAnswerRepository eventAnswerRepository;
    private final EventAnswerStruct eventAnswerStruct;
    private final TxmServiceClient txmServiceClient;


    /**
     * 이벤트 답변 생성
     *
     * @param eventAnswerDto 이벤트 답변 DTO
     * @return 생성된 이벤트 답변 DTO
     */
    @Transactional
    public EventAnswerDto create(EventAnswerDto eventAnswerDto) {
        // Event 존재 여부 확인
        Event event = eventRepository.findById(eventAnswerDto.getEventNumber())
                .orElseThrow(() -> new BusinessException("event.notFound", eventAnswerDto.getEventNumber()));

        // 답변 일시 설정
        eventAnswerDto.setEventParticipationDatetime(LocalDateTime.now());

        //댓글 삭제 여부 설정
        eventAnswerDto.setDeleteYesOrNo("N");

        // 엔티티 변환
        EventAnswer eventAnswer = eventAnswerStruct.toEntity(eventAnswerDto);

        // Event 연관관계 설정
        eventAnswer.setEvent(event);


        // 파일 리스트 처리
        if (eventAnswerDto.getFileList() != null && !eventAnswerDto.getFileList().isEmpty() && eventAnswer.getId().getEventNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareEventFiles(
                    eventAnswerDto.getFileList(),
                    eventAnswer.getId().getEventNumber().toString() + '_' + eventAnswer.getId().getEventParticipationDatetime().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);
            eventAnswer.setFileId(eventAnswer.getId().getEventNumber().toString() + '_' + eventAnswer.getId().getEventParticipationDatetime().toString());

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }
        }

        // 엔티티 저장
        eventAnswer = eventAnswerRepository.save(eventAnswer);

        return eventAnswerStruct.toDto(eventAnswer);
    }

    /**
     * 이벤트 답변 삭제
     *
     * @param eventAnswerDto 이벤트 답변 DTO
     */
    @Transactional
    public void delete(EventAnswerDto eventAnswerDto) {
        // EventAnswerId 생성
        EventAnswerId eventAnswerId = new EventAnswerId(eventAnswerDto.getEventNumber(), eventAnswerDto.getEventParticipationDatetime());

        // EventAnswer 존재 여부 확인
        EventAnswer eventAnswer = eventAnswerRepository.findById(eventAnswerId)
                .orElseThrow(() -> new BusinessException("eventAnswer.notFound", eventAnswerDto.getEventNumber(), eventAnswerDto.getEventParticipationDatetime()));

        // EventAnswer 삭제
        eventAnswerRepository.delete(eventAnswer);
    }

    /**
     * 이벤트 답변 삭제
     *
     * @param eventAnswerDto 이벤트 답변 DTO
     */
    @Transactional
    public void updateDeleteYesOrNo(EventAnswerDto eventAnswerDto) {
        // EventAnswerId 생성
        EventAnswerId eventAnswerId = new EventAnswerId(eventAnswerDto.getEventNumber(), eventAnswerDto.getEventParticipationDatetime());

        // EventAnswer 존재 여부 확인
        EventAnswer eventAnswer = eventAnswerRepository.findById(eventAnswerId)
                .orElseThrow(() -> new BusinessException("eventAnswer.notFound", eventAnswerDto.getEventNumber(), eventAnswerDto.getEventParticipationDatetime()));

        // EventAnswer 삭제 여부 업데이트
        eventAnswer.setDeleteYesOrNo(eventAnswerDto.getDeleteYesOrNo());

        // 엔티티 저장
        eventAnswerRepository.save(eventAnswer);
    }

}
package com.denall.voc.model.request;

import com.denall.voc.model.base.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Schema(description = "QnA 답변 상세 요청 DTO")
public class QnaAnswerDetailRequestDto implements PagingDto {

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @NotNull
    @Schema(description = "QnA 번호", example = "1")
    private Long qnaNumber;

    @Size(max = 20)
    @Schema(description = "답변자 회원 ID", example = "admin123")
    private String answererMemberId;

    @Size(max = 3)
    @Schema(description = "답변자 법인 코드", example = "001")
    private String answererCorporationCode;

    @Size(max = 30)
    @Schema(description = "답변자 부서 코드", example = "DEP001")
    private String answererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "답변자 사원 번호", example = "EMP00123")
    private String answererEmployeeNumber;

    @Size(max = 100)
    @Schema(description = "검색어", example = "답변")
    private String keyword;

    @Size(max = 10)
    @Schema(description = "검색 타입 (title, content, both)", example = "content")
    private String searchType;

    @Schema(description = "시작일", example = "2025-01-01")
    private LocalDate fromDate;

    @Schema(description = "종료일", example = "2025-04-04")
    private LocalDate toDate;
}

package com.denall.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.denall.voc.model.txm.TxmFileListRequest;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@FeignClient(name = "txmClient", url = "${occ.api.txm.root.uri}", configuration = FeignClientConfig.class)
public interface TxmServiceClient {
    @PostMapping("/file/save")
    TxmFileSaveResponse saveFile(List<TxmFileSaveRequest> request);

    @PostMapping("/file/removeByReference")
    TxmFileSaveResponse deleteFile(TxmFileListRequest request);

    @GetMapping("/file/getList")
    TxmFileListResponse getFileList(@SpringQueryMap TxmFileListRequest requests);

    @PostMapping("/file/removeByReference")
    TxmFileSaveResponse removeByReference(List<TxmFileListRequest> request);

    @PostMapping("/file/removeByFileId")
    TxmFileSaveResponse removeByFileId(TxmFileListRequest request);
}

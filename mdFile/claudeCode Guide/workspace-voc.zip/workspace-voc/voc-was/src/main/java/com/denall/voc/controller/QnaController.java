package com.denall.voc.controller;

import com.denall.voc.domain.QnaService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.QnaRequestDto;
import com.denall.voc.model.response.QnaResponseDto;
import com.denall.voc.model.table.QnaDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/qnas")
@RequiredArgsConstructor
@Tag(name = "QnA", description = "QnA API")
public class QnaController {

    private final QnaService qnaService;

    @Operation(summary = "QnA 생성", description = "새로운 QnA를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "QnA 생성 성공",
            content = @Content(schema = @Schema(implementation = QnaDto.class)))
    @PostMapping
    public ResponseEntity<QnaDto> create(
            @RequestHeader(name = "X-USER-ID") String userId,
            @Parameter(description = "QnA 생성 정보", required = true)
            @Valid @RequestBody QnaDto qnaDto) {
        qnaDto.setWriterMemberId(userId);
        QnaDto createdQna = qnaService.create(qnaDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdQna);
    }

    @Operation(summary = "QnA 조회", description = "ID로 QnA를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 조회 성공",
            content = @Content(schema = @Schema(implementation = QnaDto.class)))
    @ApiResponse(responseCode = "404", description = "QnA 없음")
    @GetMapping("/{qnaNumber}")
    public ResponseEntity<QnaResponseDto> get(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber,
            @RequestParam(required = false)  String channelCode,
            @RequestParam(required = false) String serviceCategoryCode,
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
  @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode) {
        QnaResponseDto qnaResponseDto = qnaService.getQnaWithAnswers(qnaNumber, channelCode, serviceCategoryCode, userId, corporationCode);
        return ResponseEntity.ok(qnaResponseDto);
    }

    @Operation(summary = "QnA 수정", description = "ID로 QnA를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 수정 성공",
            content = @Content(schema = @Schema(implementation = QnaDto.class)))
    @ApiResponse(responseCode = "404", description = "QnA 없음")
    @PutMapping("/{qnaNumber}")
    public ResponseEntity<QnaDto> update(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber,
            @Parameter(description = "QnA 수정 정보", required = true)
            @Valid @RequestBody QnaDto qnaDto) {
        QnaDto updatedQna = qnaService.update(qnaNumber, qnaDto);
        return ResponseEntity.ok(updatedQna);
    }

    @Operation(summary = "QnA 삭제", description = "ID로 QnA를 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "QnA 삭제 성공")
    @ApiResponse(responseCode = "404", description = "QnA 없음")
    @DeleteMapping("/{qnaNumber}")
    public ResponseEntity<ResultDto<?>> delete(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber) {
        qnaService.delete(qnaNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }

    @Operation(summary = "회원별 QnA 목록 조회", description = "회원 ID로 QnA 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = QnaDto.class)))
    @GetMapping("/members/{memberId}")
    public ResponseEntity<List<QnaDto>> getListByMember(
            @Parameter(description = "회원 ID", required = true)
            @PathVariable String memberId) {
        List<QnaDto> qnaDtoList = qnaService.getListByMember(memberId);
        return ResponseEntity.ok(qnaDtoList);
    }

    @GetMapping
    @Operation(summary = "QnA 목록 조회", description = "QnA 목록을 페이징 처리하여 조회합니다.")
    public ResponseEntity<ResultDto<QnaResponseDto>> list(
            QnaRequestDto requestDto,
            @RequestParam(name = "processStatus", required = false, defaultValue = "") String processStatus) {
        ResultDto<QnaResponseDto> result = qnaService.search(requestDto, processStatus);
        return ResponseEntity.ok(result);
    }

    //openYn  확인해서 해당 작성자가 작성한 Qna인지 확인
    @GetMapping("/isWriter/{qnaNumber}")
    @Operation(summary = "QnA 작성자 확인", description = "QnA 작성자를 확인")
    public ResponseEntity<QnaResponseDto> isQnaWriter(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @PathVariable Long qnaNumber) {
        QnaResponseDto qnaResponseDto = qnaService.isQnaWriter(userId, qnaNumber);
        return ResponseEntity.ok(qnaResponseDto);
    }
}
// 1) MapStruct 매퍼 정의
package com.denall.voc.mapper;


import com.denall.voc.entity.VocAnswer;
import com.denall.voc.model.table.VocAnswerDto;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface VocAnswerStruct extends StructMapper<VocAnswer, VocAnswerDto> {
    VocAnswerDto toDto(VocAnswer entity);
    VocAnswer toEntity(VocAnswerDto dto);

    /** update 시, DTO 필드만 Entity에 덮어쓰기 */
    void updateEntityFromDto(VocAnswerDto dto, @MappingTarget VocAnswer entity);
}

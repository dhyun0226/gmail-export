package com.denall.voc.domain;

import com.denall.voc.entity.ServiceChargePerson;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.CommonServiceClient;
import com.denall.voc.mapper.ServiceChargePersonStruct;
import com.denall.voc.model.response.ServiceChargePersonResponseDto;
import com.denall.voc.model.table.ServiceChargePersonDto;
import com.denall.voc.repository.ServiceChargePersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ServiceChargePersonService {

    private final ServiceChargePersonRepository serviceChargePersonRepository;
    private final ServiceChargePersonStruct serviceChargePersonStruct;
    private final CommonServiceClient commonServiceClient;

    /**
     * Service 담당자 번호로 단건 조회합니다.
     *
     * @param ServiceChargePersonNumber Service 담당자 번호
     * @return Service 담당자 정보
     */
    @Transactional(readOnly = true)
    public ServiceChargePersonDto findById(Long ServiceChargePersonNumber) {
        ServiceChargePerson ServiceChargePerson = serviceChargePersonRepository.findById(ServiceChargePersonNumber)
                .orElseThrow(() -> new BusinessException("ServiceChargePerson.notFound"));
        return serviceChargePersonStruct.toDto(ServiceChargePerson);
    }

    @Transactional(readOnly = true)
    public List<String> findByEmployeeNumber(String employeeNumber) {
        List<ServiceChargePerson> serviceChargePersons = serviceChargePersonRepository.findByServiceChargePersonEmployeeNumber(employeeNumber);
        return serviceChargePersons.stream()
                .map(ServiceChargePerson::getServiceCategoryCode)
                .toList();
    }


    @Transactional(readOnly = true)
    public ServiceChargePersonDto findRepresentativePersonInCharge(String ServiceCategoryCode) {
        ServiceChargePerson ServiceChargePerson = serviceChargePersonRepository.findByServiceCategoryCodeAndServiceDesignationThePersonInChargeYn
                        (ServiceCategoryCode, "T")
                .orElseThrow(() -> new BusinessException("ServiceChargePerson.notFound"));
        return serviceChargePersonStruct.toDto(ServiceChargePerson);
    }

    /**
     * 신규 Service 담당자를 등록합니다.
     *
     * @param ServiceChargePersonDto Service 담당자 정보
     * @return 등록된 Service 담당자 정보
     */
    @Transactional
    public ServiceChargePersonDto create(ServiceChargePersonDto ServiceChargePersonDto) {
        // DTO를 Entity로 변환
        ServiceChargePerson ServiceChargePerson = serviceChargePersonStruct.toEntity(ServiceChargePersonDto);

        // Entity 저장
        ServiceChargePerson savedServiceChargePerson = serviceChargePersonRepository.save(ServiceChargePerson);

        // 저장된 Entity를 DTO로 변환하여 반환
        return serviceChargePersonStruct.toDto(savedServiceChargePerson);
    }

    /**
     * Service 담당자 정보를 수정합니다.
     *
     * @param ServiceChargePersonNumber Service 담당자 번호
     * @param ServiceChargePersonDto    수정할 Service 담당자 정보
     * @return 수정된 Service 담당자 정보
     */
    @Transactional
    public ServiceChargePersonDto update(Long ServiceChargePersonNumber, ServiceChargePersonDto ServiceChargePersonDto) {
        // 기존 Service 담당자 조회
        ServiceChargePerson existingServiceChargePerson = serviceChargePersonRepository.findById(ServiceChargePersonNumber)
                .orElseThrow(() -> new BusinessException("ServiceChargePerson.notFound"));

        // DTO를 Entity로 변환하여 업데이트
        ServiceChargePerson updatedServiceChargePerson = serviceChargePersonStruct.toEntity(ServiceChargePersonDto);

        // 중요 필드 검증 및 업데이트 처리
        if (!ServiceChargePersonNumber.equals(updatedServiceChargePerson.getServiceChargePersonNumber())) {
            throw new BusinessException("ServiceChargePerson.invalidServiceChargePersonNumber");
        }

        // Entity 저장
        ServiceChargePerson savedServiceChargePerson = serviceChargePersonRepository.save(updatedServiceChargePerson);

        // 저장된 Entity를 DTO로 변환하여 반환
        return serviceChargePersonStruct.toDto(savedServiceChargePerson);
    }

    @Transactional
    public void updateServiceChargePersons(List<ServiceChargePersonDto> ServiceChargePersonDtos) {
        for (ServiceChargePersonDto dto : ServiceChargePersonDtos) {
            // 기존 Service 담당자 조회
            ServiceChargePerson existingServiceChargePerson = serviceChargePersonRepository.findById(dto.getServiceChargePersonNumber())
                    .orElseThrow(() -> new BusinessException("ServiceChargePerson.notFound"));

            // Entity 업데이트
            existingServiceChargePerson.setServiceDesignationThePersonInChargeYn(dto.getServiceDesignationThePersonInChargeYn());

            // 변경된 Entity 저장
            serviceChargePersonRepository.save(existingServiceChargePerson);
        }
    }

    /**
     * Service 담당자를 삭제합니다.
     *
     * @param ServiceChargePersonNumber Service 담당자 번호
     */
    @Transactional
    public void delete(Long ServiceChargePersonNumber) {
        // 기존 Service 담당자 조회
        ServiceChargePerson ServiceChargePerson = serviceChargePersonRepository.findById(ServiceChargePersonNumber)
                .orElseThrow(() -> new BusinessException("ServiceChargePerson.notFound"));

        // Service 담당자 삭제
        serviceChargePersonRepository.delete(ServiceChargePerson);
    }


    @Transactional(readOnly = true)
    public List<ServiceChargePersonResponseDto> findByServiceCategoryCode(String serviceCategoryCode) {
        List<ServiceChargePerson> serviceChargePersons = serviceChargePersonRepository.findByServiceCategoryCode(serviceCategoryCode);
        return serviceChargePersonStruct.toResponseDtoList(serviceChargePersons);
    }
    
}
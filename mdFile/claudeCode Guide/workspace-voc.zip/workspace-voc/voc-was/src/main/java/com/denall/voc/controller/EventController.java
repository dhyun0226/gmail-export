package com.denall.voc.controller;

import com.denall.voc.domain.EventService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.EventRequestDto;
import com.denall.voc.model.response.EventResponseDto;
import com.denall.voc.model.table.EventDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
@RequiredArgsConstructor
@Tag(name = "이벤트", description = "이벤트 API")
public class EventController {

    private final EventService eventService;

    @Operation(summary = "이벤트 생성", description = "새로운 이벤트를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "이벤트 생성 성공",
            content = @Content(schema = @Schema(implementation = EventDto.class)))
    @PostMapping
    public ResponseEntity<EventDto> create(
            @Parameter(description = "이벤트 생성 정보", required = true)
            @Valid @RequestBody EventDto eventDto) {
        EventDto createdEvent = eventService.create(eventDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEvent);
    }

    @Operation(summary = "이벤트 조회", description = "ID로 이벤트를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 조회 성공",
            content = @Content(schema = @Schema(implementation = EventResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @GetMapping("/{eventNumber}")
    public ResponseEntity<EventResponseDto> get(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber,
            @RequestParam(required = false) String serviceCategoryCode,
            @RequestHeader(value = "X-User-Role", required = false) String userRole) {
        EventResponseDto eventResponseDto = eventService.getEventWithAnswers(eventNumber, serviceCategoryCode, userRole);
        return ResponseEntity.ok(eventResponseDto);
    }

    @Operation(summary = "이벤트 수정", description = "ID로 이벤트를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 수정 성공",
            content = @Content(schema = @Schema(implementation = EventDto.class)))
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @PutMapping("/{eventNumber}")
    public ResponseEntity<EventDto> update(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber,
            @Parameter(description = "이벤트 수정 정보", required = true)
            @Valid @RequestBody EventDto eventDto) {
        EventDto updatedEvent = eventService.update(eventNumber, eventDto);
        return ResponseEntity.ok(updatedEvent);
    }

    @Operation(summary = "이벤트 삭제", description = "ID로 이벤트를 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "이벤트 삭제 성공")
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @DeleteMapping("/{eventNumber}")
    public ResponseEntity<ResultDto<?>> delete(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber) {
        eventService.delete(eventNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }

    @Operation(summary = "이벤트 검색", description = "조건에 맞는 이벤트 목록을 검색합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/search")
    public ResponseEntity<ResultDto<EventResponseDto>> search(
            EventRequestDto requestDto) {
        ResultDto<EventResponseDto> result = eventService.search(requestDto);
        return ResponseEntity.ok(result);
    }
}
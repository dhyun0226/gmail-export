package com.denall.voc.mapper;

import com.denall.voc.entity.Faq;
import com.denall.voc.model.table.FaqDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface FaqStruct extends StructMapper<Faq, FaqDto> {
    @Override
    @Mapping(target = "faqContent", ignore = true)
    FaqDto toDto(Faq faq);
    
    @Override
    Faq toEntity(FaqDto dto);
}
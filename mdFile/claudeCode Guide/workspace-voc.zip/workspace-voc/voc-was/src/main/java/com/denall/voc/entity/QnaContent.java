package com.denall.voc.entity;


import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

@Entity
@Table(name = "TB_QNA_CN_D")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
public class QnaContent extends BaseEntity {

    @Id
    @Column(name = "QNA_NO", nullable = false)
    private Long qnaNo;

    @Column(name = "QNA_CN", nullable = false, columnDefinition = "MEDIUMTEXT")
    private String qnaContent;


}
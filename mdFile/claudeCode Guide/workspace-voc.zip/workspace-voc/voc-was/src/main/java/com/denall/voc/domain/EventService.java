package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.Event;
import com.denall.voc.entity.EventAnswer;
import com.denall.voc.entity.EventContent;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.EventStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.EventRequestDto;
import com.denall.voc.model.response.EventAnswerResponseDto;
import com.denall.voc.model.response.EventResponseDto;
import com.denall.voc.model.table.EventDto;
import com.denall.voc.model.txm.*;
import com.denall.voc.repository.EventAnswerRepository;
import com.denall.voc.repository.EventContentRepository;
import com.denall.voc.repository.EventQueryRepository;
import com.denall.voc.repository.EventRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;
    private final EventContentRepository eventContentRepository;
    private final EventQueryRepository eventQueryRepository;
    private final EventAnswerRepository eventAnswerRepository;
    private final EventStruct eventStruct;
    private final TxmServiceClient txmServiceClient;
    private final ServiceChargePersonService serviceChargePersonService;

    @Transactional
    public EventDto create(EventDto eventDto) {
        eventDto.setEventRegistrationDatetime(LocalDateTime.now());
        eventDto.incrementInquiryCount();
        Event event = eventStruct.toEntity(eventDto);
        Event savedEvent = eventRepository.save(event);
        
        // EventContent 생성 및 저장
        EventContent eventContent = EventContent.builder()
                .eventNo(savedEvent.getEventNumber())
                .eventContent(eventDto.getEventContent())
                .build();
        eventContentRepository.save(eventContent);

        if (eventDto.getFileList() != null && !eventDto.getFileList().isEmpty() && savedEvent.getEventNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareEventFiles(
                    eventDto.getFileList(),
                    savedEvent.getEventNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);
            savedEvent.setFileId(savedEvent.getEventNumber().toString());
            eventRepository.save(savedEvent);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }

        }

        // 썸네일 파일 처리 로직 추가
        if (eventDto.getThumbnailFile() != null && savedEvent.getEventNumber() != null) {
            List<TxmFileSaveRequest> thumbnailFile = FileUtils.prepareEventFiles(
                    eventDto.getThumbnailFile(),
                    "thumb_" + savedEvent.getEventNumber().toString()
            );

            TxmFileSaveResponse txmThumbnailFileSaveResponse = txmServiceClient.saveFile(thumbnailFile);

                savedEvent.setThumbnailFileId("thumb_" + savedEvent.getEventNumber().toString());
                eventRepository.save(savedEvent);

            if (txmThumbnailFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.thumbnail.save");
            }

        }

        EventDto result = eventStruct.toDto(savedEvent);
        // Content 별도 조회하여 설정
        eventContent = eventContentRepository.findById(savedEvent.getEventNumber()).orElse(null);
        if (eventContent != null) {
            result.setEventContent(eventContent.getEventContent());
        }
        return result;
    }

    @Transactional
    public EventResponseDto getEventWithAnswers(Long eventNumber, String serviceCategoryCode,String userRole) {

        Event event = eventRepository.findById(eventNumber)
                .orElseThrow(() -> new BusinessException("event.notFound", eventNumber));


        EventResponseDto eventResponseDto = eventQueryRepository.findEventWithAnswers(
                eventNumber,
                serviceCategoryCode
        );

        long eventAnswerTotalCount = eventQueryRepository.countEventAnswers(
                eventNumber,
                serviceCategoryCode
        );

        eventResponseDto.setEventAnswerTotalCount(eventAnswerTotalCount);

        if (StringUtils.isNotEmpty(eventResponseDto.getFileId())) {
            TxmFileListResponse vocFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.EVENT,eventResponseDto.getFileId()));
            if (vocFileResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            eventResponseDto.setFileList(vocFileResponse);
        }

        if (StringUtils.isNotEmpty(eventResponseDto.getThumbnailFileId())) {
            TxmFileListResponse thumbnailFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.EVENT, eventResponseDto.getThumbnailFileId()));
            if (thumbnailFileResponse.getStatus() != 200) {
                throw new BusinessException("error.thumbnail.found");
            }
            eventResponseDto.setthumbnailFile(thumbnailFileResponse);
        }

        Event previousEvent = eventQueryRepository.findPreviousEvent(eventNumber, serviceCategoryCode);
        Event nextEvent = eventQueryRepository.findNextEvent(eventNumber, serviceCategoryCode);
        eventResponseDto.setPreviousEvents(eventStruct.toResponseDto(previousEvent));
        eventResponseDto.setNextEvents(eventStruct.toResponseDto(nextEvent));

        //여기에 댓글 파일 리스트 가져오는 로직 만들어야 함
        eventResponseDto.getEventAnswers().forEach(answer -> {
            if (StringUtils.isNotEmpty(answer.getAnswerFileId())) {
                TxmFileListResponse answerFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.EVENT, answer.getAnswerFileId()));
                if (answerFileResponse.getStatus() != 200) {
                    throw new BusinessException("error.file.found");
                }
                answer.setFileList(answerFileResponse);
            }
        });



        if (userRole == null) {
            event.incrementInquiryCount();
        }

        eventRepository.save(event);


//        event.incrementInquiryCount();
//        eventRepository.save(event);

        return eventResponseDto;
    }

    @Transactional
    public EventDto update(Long eventNumber, EventDto eventDto) {

        //존재하는 이벤트인지 확인
        Event event = eventRepository.findById(eventNumber)
                .orElseThrow(() -> new BusinessException("event.notFound", eventNumber));

        //이벤트 수정
        event.updateEvent(eventStruct.toEntity(eventDto));
        
        // EventContent 수정
        EventContent eventContent = eventContentRepository.findById(eventNumber)
                .orElse(EventContent.builder()
                        .eventNo(eventNumber)
                        .eventContent(eventDto.getEventContent())
                        .build());
        
        if (eventContent.getEventNo() != null) {
            eventContent.setEventContent(eventDto.getEventContent());
        }
        eventContentRepository.save(eventContent);

        FileUtils.processFiles(
                eventDto.getFileList(),
                TaskType.EVENT,
                eventNumber.toString(),
                txmServiceClient,
                event::setFileId,
                event::detachFile
        );

        FileUtils.processThumbnailFile(
                eventDto.getThumbnailFile() != null && !eventDto.getThumbnailFile().isEmpty() ?
                        eventDto.getThumbnailFile().get(0) : null,
                TaskType.EVENT,
                eventNumber.toString(),
                txmServiceClient,
                event::setThumbnailFileId,
                event::detachThumbnailFile
        );

        //DB에 업데이트
        event = eventRepository.save(event);
        EventDto result = eventStruct.toDto(event);
        // Content 별도 조회하여 설정
        eventContent = eventContentRepository.findById(event.getEventNumber()).orElse(null);
        if (eventContent != null) {
            result.setEventContent(eventContent.getEventContent());
        }
        return result;
    }

    @Transactional
    public void delete(Long eventNumber) {
        Event event = eventRepository.findById(eventNumber)
                .orElseThrow(() -> new BusinessException("event.notFound", eventNumber));

        // 이벤트 댓글 먼저 삭제
        List<EventAnswer> eventAnswers = eventAnswerRepository.findByEvent_EventNumber(eventNumber);
        eventAnswerRepository.deleteAll(eventAnswers);

        // EventContent 삭제
        eventContentRepository.deleteById(eventNumber);

        eventRepository.delete(event);
    }

    @Transactional(readOnly = true)
    public ResultDto<EventResponseDto> search(EventRequestDto requestDto) {

        List<EventResponseDto> eventList = eventQueryRepository.searchEvents(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getUseYesOrNo(),
                requestDto.getTopFixedYesOrNo(),
                requestDto.getServiceCategoryCode()
        );

        for (EventResponseDto eventResponseDto : eventList) {
            if (StringUtils.isNotEmpty(eventResponseDto.getFileId())) {
                TxmFileListResponse vocFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.EVENT, eventResponseDto.getFileId()));
                if (vocFileResponse.getStatus() != 200) {
                    throw new BusinessException("error.file.found");
                }
                eventResponseDto.setFileList(vocFileResponse);
            }

            if (StringUtils.isNotEmpty(eventResponseDto.getThumbnailFileId())) {
                TxmFileListResponse thumbnailFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.EVENT, eventResponseDto.getThumbnailFileId()));
                if (thumbnailFileResponse.getStatus() != 200) {
                    throw new BusinessException("error.thumbnail.found");
                }
                eventResponseDto.setthumbnailFile(thumbnailFileResponse);
            }

            // 댓글 리스트 조회 및 세팅
            List<EventAnswer> answers = eventAnswerRepository.findByEvent_EventNumber(eventResponseDto.getEventNumber());
            List<EventAnswerResponseDto> answerDtos = answers.stream()
                    .map(eventStruct::toAnswerResponseDto)
                    .collect(java.util.stream.Collectors.toList());
            eventResponseDto.setEventAnswers(answerDtos);
        }

        long totalCount = eventQueryRepository.countEvents(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getUseYesOrNo(),
                requestDto.getTopFixedYesOrNo(),
                requestDto.getServiceCategoryCode()
        );

        return new ResultDto<>(eventList, totalCount, requestDto.getServiceCategoryCode());
    }
}
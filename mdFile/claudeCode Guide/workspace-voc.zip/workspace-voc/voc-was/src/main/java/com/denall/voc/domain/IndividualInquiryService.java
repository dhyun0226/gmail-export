package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.IndividualInquiry;
import com.denall.voc.entity.IndividualInquiryAnswer;
import com.denall.voc.entity.QnaAnswerDetail;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.IndividualInquiryStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.IndividualInquiryRequestDto;
import com.denall.voc.model.response.IndividualInquiryResponseDto;
import com.denall.voc.model.response.QnaResponseDto;
import com.denall.voc.model.table.IndividualInquiryDto;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.IndividualInquiryAnswerRepository;
import com.denall.voc.repository.IndividualInquiryQueryRepository;
import com.denall.voc.repository.IndividualInquiryRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class IndividualInquiryService {

    private final IndividualInquiryRepository individualInquiryRepository;
    private final IndividualInquiryQueryRepository individualInquiryQueryRepository;
    private final IndividualInquiryAnswerRepository individualInquiryAnswerRepository;
    private final IndividualInquiryStruct individualInquiryStruct;
    private final TxmServiceClient txmServiceClient;
    private final VocServiceClient vocServiceClient;


    /**
     * 개인문의 등록
     *
     * @param inquiryDto 개인문의 DTO
     * @return 등록된 개인문의 DTO
     */
    @Transactional
    public IndividualInquiryDto create(IndividualInquiryDto inquiryDto) {
        // 필수 필드 검증
        validateInquiryDto(inquiryDto);
        
        inquiryDto.setIndividualInquiryRegistrationDatetime(LocalDateTime.now());
        IndividualInquiry entity = individualInquiryStruct.toEntity(inquiryDto);
        IndividualInquiry savedEntity = individualInquiryRepository.save(entity);

        if (!inquiryDto.getFileList().isEmpty() && savedEntity.getIndividualInquiryNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareInquiryFiles(
                    inquiryDto.getFileList(),
                    savedEntity.getIndividualInquiryNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }

            savedEntity.setFileId(savedEntity.getIndividualInquiryNumber().toString());
            individualInquiryRepository.save(savedEntity);
        }

//        vocServiceClient.create(individualInquiryStruct.toVocDto(savedEntity));

//        if(transferDto.getWriterMemberId() != null) {
//            DncMemberInfoResponse dncMemberInfoResponse = dncServiceClient.getMemberInfo(inquiryDto.getWriterMemberId());
//
//            if(dncMemberInfoResponse.getStatus() != 200){
//                throw new BusinessException("error.dnc.member.not.found");
//            }
//
//            transferDto.setWriterInfoFromMemberResponse(dncMemberInfoResponse);
//        }

        return individualInquiryStruct.toDto(savedEntity);
    }

    /**
     * 전체 개인문의 및 답변 리스트 조회
     *
     * @return 개인문의 및 답변 리스트
     */
    @Transactional(readOnly = true)
    public List<IndividualInquiryResponseDto> getAllInquiriesWithAnswers(
            String channelCode,
            String serviceCategoryCode,
            String writerMemberId,
            String keyword) {
        return individualInquiryQueryRepository.findAllInquiriesWithAnswers(
                channelCode,
                serviceCategoryCode,
                writerMemberId,
                keyword);
    }

    /**
     * 개인문의 및 답변 상세 조회
     *
     * @param vocNumber 개인문의 번호
     * @return 개인문의 및 답변 상세 정보
     * @throws BusinessException 개인문의가 존재하지 않는 경우
     */
    public IndividualInquiryResponseDto getInquiryWithAnswer(Long vocNumber) {
        IndividualInquiryResponseDto responseDto = individualInquiryQueryRepository.findInquiryWithAnswer(vocNumber);

        if (responseDto == null) {
            throw new BusinessException("error.inquiry.not.found");
        }

        if (StringUtils.isNotEmpty(responseDto.getFileId())) {
            TxmFileListResponse vocFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.INQUIRY,responseDto.getFileId()));
            if (vocFileResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            responseDto.setFileList(vocFileResponse);

//            TxmFileListResponse answerFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.INQUIRY, responseDto.getAnswerFileId()));
//            if (answerFileResponse.getStatus() != 200) {
//                throw new BusinessException("error.file.found");
//            }
//            responseDto.setAnswerFileList(answerFileResponse);

        }



        return responseDto;
    }
    
    /**
     * 문의 DTO 유효성 검증
     * @param inquiryDto 검증할 DTO
     */
    private void validateInquiryDto(IndividualInquiryDto inquiryDto) {
        // 제목 검증
        if (inquiryDto.getIndividualInquiryTitle() == null || 
            inquiryDto.getIndividualInquiryTitle().trim().isEmpty()) {
            throw new BusinessException("문의 제목을 입력해주세요.");
        }
        
        // 내용 검증
        if (inquiryDto.getIndividualInquiryContent() == null || 
            inquiryDto.getIndividualInquiryContent().trim().isEmpty()) {
            throw new BusinessException("문의 내용을 입력해주세요.");
        }
        
        // 채널 코드 검증
        if (inquiryDto.getServiceCategoryCode() == null || 
            inquiryDto.getServiceCategoryCode().trim().isEmpty()) {
            throw new BusinessException("문의 유형을 선택해주세요.");
        }
    }

    @Transactional(readOnly = true)
    public ResultDto<IndividualInquiryResponseDto> search(IndividualInquiryRequestDto requestDto,String userId, String corporationCode) {
        List<String> serviceCategoryCodes = new ArrayList<>();
        boolean applyCorporationFilter = corporationCode != null && !corporationCode.isEmpty();

        if(applyCorporationFilter) {
            serviceCategoryCodes = vocServiceClient.getVocChargePersonChannels(userId);
            // corporationCode가 있는데 serviceCategoryCodes가 비어있으면, 빈 결과를 바로 반환
            if(serviceCategoryCodes.isEmpty()) {
                return new ResultDto<>(new ArrayList<>(), 0L); // 빈 결과 반환
            }
        }

        // QueryRepository 호출
        List<IndividualInquiryResponseDto> inquiryList = individualInquiryQueryRepository.searchInquiries(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getChannelCode(),
                requestDto.getServiceCategoryCode(),
                applyCorporationFilter ? null : userId,
                applyCorporationFilter ? serviceCategoryCodes : null);

        inquiryList.forEach(dto ->
                dto.setProcessStatus(
                        individualInquiryAnswerRepository
                                .existsByIndividualInquiryNumberAndAnswererEmployeeNumberIsNotNull(
                                        dto.getIndividualInquiryNumber()
                                )
                )
        );


        long totalCount = individualInquiryQueryRepository.countInquiries(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getChannelCode(),
                requestDto.getServiceCategoryCode(),
                applyCorporationFilter ? null : userId,
                applyCorporationFilter ? serviceCategoryCodes : null);

        return new ResultDto<>(inquiryList, totalCount);
    }


    /**
     * 개인문의 수정
     *
     * @param inquiryNumber 개인문의 번호
     * @param inquiryDto    개인문의 DTO
     * @return 수정된 개인문의 DTO
     */
    @Transactional
    public IndividualInquiryDto update(Long inquiryNumber, IndividualInquiryDto inquiryDto) {
        // 기존 개인문의 확인
        IndividualInquiry existingEntity = individualInquiryRepository.findById(inquiryNumber)
                .orElseThrow(() -> new BusinessException("individualInquiry.notFound", inquiryNumber));

        // DTO에 ID 설정 후 엔티티 변환
        inquiryDto.setIndividualInquiryNumber(inquiryNumber);
        inquiryDto.setIndividualInquiryChangeDatetime(LocalDateTime.now());

        IndividualInquiry updatedEntity = individualInquiryStruct.toEntity(inquiryDto);
        individualInquiryRepository.save(updatedEntity);

        return individualInquiryStruct.toDto(updatedEntity);
    }

    /**
     * 개인문의 삭제
     *
     * @param inquiryNumber 개인문의 번호
     */
    @Transactional
    public void delete(Long inquiryNumber) {
        // 기존 개인문의 확인
        if (!individualInquiryRepository.existsById(inquiryNumber)) {
            throw new BusinessException("individualInquiry.notFound", inquiryNumber);
        }

        individualInquiryRepository.deleteById(inquiryNumber);
    }


}
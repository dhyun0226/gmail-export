package com.denall.voc.mapper;

import com.denall.voc.entity.ServiceCategory;
import com.denall.voc.model.table.ServiceCategoryDto;
import com.denall.voc.repository.ServiceCategoryRepository;
import org.mapstruct.*;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,
        uses = {ServiceCategoryRepository.class})
public interface ServiceCategoryStruct extends StructMapper<ServiceCategory, ServiceCategoryDto> {

    @Override
    @Mapping(target = "upServiceCategoryCode", source = "upServiceCategoryCode.serviceCategoryCode")
    @Mapping(target = "upServiceCategoryName", source = "upServiceCategoryCode.serviceCategoryName")
    ServiceCategoryDto toDto(ServiceCategory entity);

    @Override
    @Mapping(target = "upServiceCategoryCode", ignore = true) // 엔티티로 변환 시 상위 카테고리는 별도 처리 필요
    ServiceCategory toEntity(ServiceCategoryDto dto);

    /**
     * dto에서 상위 카테고리 코드가 있는 경우, 해당 코드로 상위 카테고리 엔티티를 설정합니다.
     * 이 메서드는 toEntity 메서드 후에 호출되어야 합니다.
     */
    @AfterMapping
    default void setUpServiceCategoryCode(ServiceCategoryDto dto, @MappingTarget ServiceCategory entity,
                                      @Context ServiceCategoryRepository repository) {
        if (dto.getUpServiceCategoryCode() != null && !dto.getUpServiceCategoryCode().isEmpty()) {
            repository.findById(dto.getUpServiceCategoryCode())
                    .ifPresent(entity::setUpServiceCategoryCode);
        }
    }

    /**
     * 엔티티 목록을 DTO 목록으로 변환합니다.
     */
    @Override
    default List<ServiceCategoryDto> toDtoList(List<ServiceCategory> entityList) {
        if (entityList == null) {
            return null;
        }

        return entityList.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * DTO 목록을 엔티티 목록으로 변환합니다.
     */
    @Override
    default List<ServiceCategory> toEntityList(List<ServiceCategoryDto> dtoList) {
        if (dtoList == null) {
            return null;
        }

        return dtoList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }
}

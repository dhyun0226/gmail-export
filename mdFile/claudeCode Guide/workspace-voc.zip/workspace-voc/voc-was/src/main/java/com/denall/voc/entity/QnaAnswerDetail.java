package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_QNA_ANS_D")
@Getter
@Builder
@Setter
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class QnaAnswerDetail extends BaseEntity {

    @EmbeddedId
    private QnaAnswerDetailId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "QNA_NO", insertable = false, updatable = false)
    @MapsId("qnaNumber")
    private Qna qna;

    @Column(name = "UP_QNA_ANS_DTL_NO")
    private Long parentAnswerDetailNumber;

    @Column(name = "ANSR_MEM_ID", length = 20)
    private String answererMemberId;

    @Column(name = "ANSR_CPRN_CD", length = 3)
    private String answererCorporationCode;

    @Column(name = "ANSR_DEPT_CD", length = 30)
    private String answererDepartmentCode;

    @Column(name = "ANSR_EMP_NO", length = 60)
    private String answererEmployeeNumber;

    @Column(name = "QNA_ANS_CN", nullable = false, length = 1000)
    private String qnaAnswerContent;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    @Column(name = "QNA_ANS_DTM", nullable = false)
    private LocalDateTime qnaAnswerDatetime;

    @Column(name = "DEL_YN", nullable = false, length = 1)
    private String deleteYn = "N";

    @PrePersist
    private void prePersist() {
        if (this.qnaAnswerDatetime == null) {
            this.qnaAnswerDatetime = LocalDateTime.now();
        }
        if (this.deleteYn == null) {
            this.deleteYn = "N";
        }
    }

    // 비즈니스 메소드
    public void updateAnswer(String qnaAnswerContent) {
        this.qnaAnswerContent = qnaAnswerContent;
    }

    public void updateAnswerer(String answererMemberId, String answererCorporationCode,
                               String answererDepartmentCode, String answererEmployeeNumber) {
        this.answererMemberId = answererMemberId;
        this.answererCorporationCode = answererCorporationCode;
        this.answererDepartmentCode = answererDepartmentCode;
        this.answererEmployeeNumber = answererEmployeeNumber;
    }

    public void attachFile(String fileId) {
        this.fileId = fileId;
    }

    public void setQna(Qna qna) {
        this.qna = qna;
    }
}
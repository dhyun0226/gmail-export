package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_M")
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class Voc extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "VOC_NO")
    private Long vocNumber;

    @Column(name = "VOC_CTG_CD", length = 12, nullable = false)
    private String vocCategoryCode;

    @Column(name = "ITM_CD", length = 90)
    private String itemCode;

    @Column(name = "VOC_ITM_NM", length = 100)
    private String vocItemName;

    @Column(name = "MEM_YN", length = 1, nullable = false)
    private String memberYn;

    @Column(name = "WRTR_MEM_ID", length = 20)
    private String writerMemberId;

    @Column(name = "VOC_WRTR_NM", length = 50)
    private String vocWriterName;

    @Column(name = "WRTR_EML_ADDR", length = 50)
    private String writerEmailAddress;

    @Column(name = "WRTR_TLNO", length = 20)
    private String writerTelephoneNumber;

    @Column(name = "WRTR_HPNO", length = 20)
    private String writerHandPhoneNumber;

    @Column(name = "VOC_CN", length = 2000, nullable = false)
    private String vocContent;

    @Column(name = "VOC_RGST_DTM", nullable = false)
    private LocalDateTime vocRegistrationDateTime;

    @Column(name = "VOC_CHG_DTM")
    private LocalDateTime vocChangeDateTime;

    @Column(name = "INDV_INFO_CLCT_TOU_AGRE_YN", length = 1, nullable = false)
    private String individualInformationCollectionTermsOfUseAgreementYesOrNo;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    public void attachFile(String fileId) {
        this.fileId = fileId;
    }

}

package com.denall.voc.domain;

import com.denall.voc.entity.IndividualInquiryAnswer;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.CommonServiceClient;
import com.denall.voc.mapper.IndividualInquiryAnswerStruct;
import com.denall.voc.model.common.EmailRequestDto;
import com.denall.voc.model.common.MMSRequestDto;
import com.denall.voc.model.table.IndividualInquiryAnswerDto;
import com.denall.voc.repository.IndividualInquiryAnswerRepository;
import com.denall.voc.repository.IndividualInquiryRepository;
import com.denall.voc.util.NotificationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class IndividualInquiryAnswerService {

    private final IndividualInquiryRepository individualInquiryRepository;
    private final IndividualInquiryAnswerRepository individualInquiryAnswerRepository;
    private final IndividualInquiryAnswerStruct individualInquiryAnswerStruct;
    private final CommonServiceClient commonServiceClient;

    /**
     * 개인문의답변 등록
     *
     * @param answerDto 개인문의답변 DTO
     * @return 등록된 개인문의답변 DTO
     */
    @Transactional
    public IndividualInquiryAnswerDto create(IndividualInquiryAnswerDto answerDto) {
        // 개인문의 존재 여부 확인
        Long inquiryNumber = answerDto.getIndividualInquiryNumber();
        if (!individualInquiryRepository.existsById(inquiryNumber)) {
            throw new BusinessException("individualInquiry.notFound", inquiryNumber);
        }

        // 이미 답변이 존재하는지 확인
        if (individualInquiryAnswerRepository.existsById(inquiryNumber)) {
            throw new BusinessException("individualInquiryAnswer.alreadyExists", inquiryNumber);
        }

        // 현재 시간 설정
        answerDto.setIndividualInquiryAnswerDatetime(LocalDateTime.now());

        // Entity 변환 및 저장
        IndividualInquiryAnswer entity = individualInquiryAnswerStruct.toEntity(answerDto);
        IndividualInquiryAnswer savedEntity = individualInquiryAnswerRepository.save(entity);

        try {
            // MMS 전송 요청 생성
            MMSRequestDto mmsRequest = NotificationUtils.createMMSRequest(answerDto, "010-9957-1907");
            commonServiceClient.sendMMS(mmsRequest);

            // 필요시 이메일도 전송
            EmailRequestDto emailRequest = NotificationUtils.createEmailRequest(answerDto, "rlarkddbs3@osstem.com", "김강윤");
            commonServiceClient.sendEmail(emailRequest);

        } catch (Exception e) {
            // 예외 발생 시 트랜잭션 롤백을 위해 BusinessException으로 감싸서 던짐
            throw new BusinessException("notification.sendFailed", e.getMessage());
        }

        return individualInquiryAnswerStruct.toDto(savedEntity);
    }

    /**
     * 개인문의답변 상세 조회
     *
     * @param inquiryNumber 개인문의 번호
     * @return 개인문의답변 DTO
     */
    @Transactional(readOnly = true)
    public IndividualInquiryAnswerDto get(Long inquiryNumber) {
        IndividualInquiryAnswer entity = individualInquiryAnswerRepository.findById(inquiryNumber)
                .orElseThrow(() -> new BusinessException("individualInquiryAnswer.notFound", inquiryNumber));

        return individualInquiryAnswerStruct.toDto(entity);
    }

    /**
     * 개인문의답변 수정
     *
     * @param inquiryNumber 개인문의 번호
     * @param answerDto 개인문의답변 DTO
     * @return 수정된 개인문의답변 DTO
     */
    @Transactional
    public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
        // 기존 개인문의답변 확인
        IndividualInquiryAnswer existingEntity = individualInquiryAnswerRepository.findById(inquiryNumber)
                .orElseThrow(() -> new BusinessException("individualInquiryAnswer.notFound", inquiryNumber));

        // DTO에 ID 설정 후 엔티티 변환
        answerDto.setIndividualInquiryNumber(inquiryNumber);

        IndividualInquiryAnswer updatedEntity = individualInquiryAnswerStruct.toEntity(answerDto);
        individualInquiryAnswerRepository.save(updatedEntity);

        return individualInquiryAnswerStruct.toDto(updatedEntity);
    }

    /**
     * 개인문의답변 삭제
     *
     * @param inquiryNumber 개인문의 번호
     */
    @Transactional
    public void delete(Long inquiryNumber) {
        // 기존 개인문의답변 확인
        if (!individualInquiryAnswerRepository.existsById(inquiryNumber)) {
            throw new BusinessException("individualInquiryAnswer.notFound", inquiryNumber);
        }

        individualInquiryAnswerRepository.deleteById(inquiryNumber);
    }

    /**
     * 개인문의답변 목록 조회
     *
     * @param inquiryNumber 개인문의 번호
     * @return 개인문의답변 DTO
     */
    @Transactional(readOnly = true)
    public List<IndividualInquiryAnswerDto> getList(Long inquiryNumber) {
        List<IndividualInquiryAnswer> entities = individualInquiryAnswerRepository.findByIndividualInquiryNumber(inquiryNumber);

        return entities.stream()
                .map(individualInquiryAnswerStruct::toDto)
                .collect(Collectors.toList());
    }
}
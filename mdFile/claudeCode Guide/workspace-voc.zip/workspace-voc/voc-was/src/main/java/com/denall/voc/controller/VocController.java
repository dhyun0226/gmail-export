package com.denall.voc.controller;

import com.denall.voc.domain.VocService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.VocRequestDto;
import com.denall.voc.model.response.VocResponseDto;
import com.denall.voc.model.table.VocDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vocs")
@RequiredArgsConstructor
@Tag(name = "VOC", description = "VOC API")
public class VocController {

    private final VocService vocService;

    @PostMapping
    @Operation(summary = "VOC 등록", description = "VOC를 등록합니다.")
    @ApiResponse(responseCode = "201", description = "등록 성공")
    public ResponseEntity<VocDto> create(
            @RequestHeader(name = "X-USER-ID") String userId,
            @RequestBody @Valid VocDto vocDto) {
        vocDto.setWriterMemberId(userId);
        VocDto createdVoc = vocService.create(vocDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdVoc);
    }

    @GetMapping("/{vocNumber}")
    @Operation(summary = "VOC 상세 조회", description = "VOC 번호로 VOC 상세 정보를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    @ApiResponse(responseCode = "404", description = "VOC를 찾을 수 없음")
    public ResponseEntity<VocResponseDto> get(
            @Parameter(description = "VOC 번호", required = true)
            @PathVariable Long vocNumber) {
        VocResponseDto vocDto = vocService.getVocWithAnswer(vocNumber);
        return ResponseEntity.ok(vocDto);
    }

    @GetMapping
    @Operation(summary = "VOC 목록 조회", description = "VOC 목록을 페이징 처리하여 조회합니다.")
    public ResponseEntity<ResultDto<VocResponseDto>> list(
            @RequestHeader(name = "X-USER-ID") String userId,
            VocRequestDto requestDto) {
        ResultDto<VocResponseDto> result = vocService.search(userId, requestDto);
        return ResponseEntity.ok(result);
    }

    @PutMapping("/{vocNumber}")
    @Operation(summary = "VOC 수정", description = "VOC 번호로 VOC 정보를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "수정 성공")
    @ApiResponse(responseCode = "404", description = "VOC를 찾을 수 없음")
    public ResponseEntity<VocDto> update(
            @Parameter(description = "VOC 번호", required = true)
            @PathVariable Long vocNumber,
            @RequestBody @Valid VocDto vocDto) {
        VocDto updatedVoc = vocService.update(vocNumber, vocDto);
        return ResponseEntity.ok(updatedVoc);
    }

    @DeleteMapping("/{vocNumber}")
    @Operation(summary = "VOC 삭제", description = "VOC 번호로 VOC를 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "삭제 성공")
    @ApiResponse(responseCode = "404", description = "VOC를 찾을 수 없음")
    public ResponseEntity<Void> delete(
            @Parameter(description = "VOC 번호", required = true)
            @PathVariable Long vocNumber) {
        vocService.delete(vocNumber);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    @Operation(summary = "전체 VOC 조회", description = "모든 VOC와 답변 데이터를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    public ResponseEntity<List<VocResponseDto>> getAllVocsWithAnswers(
            @RequestParam(required = false) String itemCode,
            @RequestParam(required = false) String writerMemberId,
            @RequestParam(required = false) String keyword) {
        List<VocResponseDto> vocs = vocService.getAllVocsWithAnswers(
                itemCode,
                writerMemberId,
                keyword);
        return ResponseEntity.ok(vocs);
    }
}

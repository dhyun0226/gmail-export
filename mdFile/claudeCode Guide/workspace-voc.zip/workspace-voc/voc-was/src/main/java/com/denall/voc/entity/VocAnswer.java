// 1. Entity
package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_ANS_D")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VocAnswer extends BaseEntity {

    @Id
    @Column(name = "VOC_NO", nullable = false)
    private Long vocNumber;

    @Column(name = "ANSR_CPRN_CD", length = 50, nullable = false)
    private String answererCorporationCode;

    @Column(name = "ANSR_DEPT_CD", length = 50, nullable = false)
    private String answererDepartmentCode;

    @Column(name = "ANSR_EMP_NO", length = 50, nullable = false)
    private String answererEmployeeNumber;

    @Column(name = "VOC_ANS_CN", columnDefinition = "TEXT")
    private String vocAnswerContent;

    @Column(name = "VOC_ANS_DTM")
    private LocalDateTime vocAnswerDateTime;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    // fileList 는 별도 엔티티로 매핑하거나 JSON 형태로 저장하도록 추가 설계 필요
}

package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.Voc;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.DncServiceClient;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.VocStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.common.BusinessPartnerCodeResponseDto;
import com.denall.voc.model.common.CustomerInfoResponseDto;
import com.denall.voc.model.common.EmployeeResponseDto;
import com.denall.voc.model.event.VocClientDto;
import com.denall.voc.model.request.VocRequestDto;
import com.denall.voc.model.response.VocResponseDto;
import com.denall.voc.model.table.VocDto;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.VocQueryRepository;
import com.denall.voc.repository.VocRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class VocService {

    private final VocRepository vocRepository;
    private final VocQueryRepository vocQueryRepository;
    private final VocStruct vocStruct;
    private final TxmServiceClient txmServiceClient;
    private final VocServiceClient vocServiceClient;
    private final DncServiceClient dncServiceClient;

    /**
     * VOC 등록
     *
     * @param vocDto VOC DTO
     * @return 등록된 VOC DTO
     */
    @Transactional
    public VocDto create(VocDto vocDto) {
        vocDto.setVocRegistrationDateTime(LocalDateTime.now());
        Voc entity = vocStruct.toEntity(vocDto);
        Voc savedEntity = vocRepository.save(entity);

        if (!vocDto.getFileList().isEmpty() && savedEntity.getVocNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareVocFiles(
                    vocDto.getFileList(),
                    savedEntity.getVocNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }

            savedEntity.attachFile(savedEntity.getVocNumber().toString());
            vocRepository.save(savedEntity);
        }

        VocClientDto vocClientDto = vocStruct.toClientDto(savedEntity);


        //덴올 VOC 번호 설정
        vocClientDto.setDenallVocNumber(savedEntity.getVocNumber());

        //VOC 상태코드 접수로 설정
        vocClientDto.setVocStateCode("01");

        //VOC등록자구분코드 설정 -> 회원이면 02, 비회원이면 03
        vocClientDto.setVocRegistererDivisionCode("02");

        // VCO삭제여부
        vocClientDto.setDeleteYesOrNo("N");




        // 1. 접수하는 사람 회원 ID로 거래처코드 조회
        BusinessPartnerCodeResponseDto businessPartnerCodeResponseDto = dncServiceClient.getBusinessPartnerCode(vocClientDto.getRegistererMemberId());
        if (businessPartnerCodeResponseDto == null || StringUtils.isEmpty(businessPartnerCodeResponseDto.getData())) {
            throw new BusinessException("businessPartner.notFound");
        }

        // 2. 거래처코드로 영업사원번호 조회
        EmployeeResponseDto salesPersonNumber = dncServiceClient.getBusinessPartnerSalesEmployeeDto(businessPartnerCodeResponseDto.getData());
        if (salesPersonNumber == null || StringUtils.isEmpty(salesPersonNumber.getData().getEmployeeNumber())) {
            throw new BusinessException("salesPerson.notFound");
        }

        //  거래처코드로 거래처명 조회
        CustomerInfoResponseDto customerInfoResponseDto = dncServiceClient.getBusinessmanCustomerInfo(businessPartnerCodeResponseDto.getData());
        if (customerInfoResponseDto == null || StringUtils.isEmpty(customerInfoResponseDto.getData().getBusinessmanCustomerName())) {
            throw new BusinessException("customerInfo.notFound");
        }

        // VOC 영업 담당자 설정
        vocClientDto.setRegistererEmployeeNumber(salesPersonNumber.getData().getEmployeeNumber());

        // 거래처명 설정
        vocClientDto.setVocCustomerCustomerName(customerInfoResponseDto.getData().getBusinessmanCustomerName());


        try {
            // 개인문의 시스템으로 데이터 전송
            vocServiceClient.create(vocClientDto);
        } catch (Exception e) {
            throw new BusinessException("error.external.system");
        }

        return vocStruct.toDto(savedEntity);
    }

    /**
     * 전체 VOC 및 답변 리스트 조회
     *
     * @return VOC 및 답변 리스트
     */
    @Transactional(readOnly = true)
    public List<VocResponseDto> getAllVocsWithAnswers(
            String itemCode,
            String writerMemberId,
            String keyword) {
        return vocQueryRepository.findAllVocsWithAnswers(
                itemCode,
                writerMemberId,
                keyword);
    }

    /**
     * VOC 및 답변 상세 조회
     *
     * @param vocNumber VOC 번호
     * @return VOC 및 답변 상세 정보
     * @throws BusinessException VOC가 존재하지 않는 경우
     */
    public VocResponseDto getVocWithAnswer(Long vocNumber) {
        VocResponseDto responseDto = vocQueryRepository.findVocWithAnswer(vocNumber);

        if (responseDto == null) {
            throw new BusinessException("error.voc.not.found");
        }

        if (StringUtils.isNotEmpty(responseDto.getFileId())) {
            TxmFileListResponse vocFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.VOC, responseDto.getFileId()));
            if (vocFileResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            responseDto.attachFileList(vocFileResponse);
        }

        if (StringUtils.isNotEmpty(responseDto.getAnswerFileId())) {
            TxmFileListResponse answerFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.VOCANSWER, responseDto.getAnswerFileId()));
            if (answerFileResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            responseDto.attachAnswerFileList(answerFileResponse);
        }

        return responseDto;
    }

    @Transactional(readOnly = true)
    public ResultDto<VocResponseDto> search(String userId, VocRequestDto requestDto) {
        // QueryRepository 호출
        List<VocResponseDto> vocList = vocQueryRepository.searchVocs(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getItemCode(),
                userId);

        long totalCount = vocQueryRepository.countVocs(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getItemCode(),
                userId);

        return new ResultDto<>(vocList, totalCount);
    }

    /**
     * VOC 수정
     *
     * @param vocNumber VOC 번호
     * @param vocDto    VOC DTO
     * @return 수정된 VOC DTO
     */
    @Transactional
    public VocDto update(Long vocNumber, VocDto vocDto) {
        // 기존 VOC 확인
        Voc existingEntity = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound", vocNumber));

        // DTO에 ID 설정 후 엔티티 변환
        vocDto.setVocNumber(vocNumber);
        vocDto.setVocChangeDateTime(LocalDateTime.now());

        Voc updatedEntity = vocStruct.toEntity(vocDto);

//        vocDto를 vocClientDto로 변환
        VocClientDto vocClientDto = vocStruct.toClientDto(updatedEntity);

        //저장하기 전에 업데이트 치고 업데이트 실패하면 저장 안되게 하기
        VocClientDto response = vocServiceClient.put(vocDto.getVocNumber(), vocClientDto);
        if (response == null) {
            throw new BusinessException("error.voc.update");
        }

        vocRepository.save(updatedEntity);

        return vocStruct.toDto(updatedEntity);
    }

    /**
     * VOC 삭제
     *
     * @param vocNumber VOC 번호
     */
    @Transactional
    public void delete(Long vocNumber) {
        // 기존 VOC 확인
        if (!vocRepository.existsById(vocNumber)) {
            throw new BusinessException("voc.notFound", vocNumber);
        }

        vocRepository.deleteById(vocNumber);
    }
}


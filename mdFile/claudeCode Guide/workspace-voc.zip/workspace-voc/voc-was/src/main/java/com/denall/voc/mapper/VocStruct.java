package com.denall.voc.mapper;

import com.denall.voc.entity.Voc;
import com.denall.voc.model.event.VocClientDto;
import com.denall.voc.model.table.VocDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface VocStruct extends StructMapper<Voc, VocDto> {
    @Mapping(source = "vocNumber", target = "vocNumber")
    @Mapping(source = "itemCode", target = "itemCode")
    @Mapping(source = "memberYn", target = "memberYn")
    @Mapping(source = "writerMemberId", target = "writerMemberId")
    @Mapping(source = "vocWriterName", target = "vocWriterName")
    @Mapping(source = "writerEmailAddress", target = "writerEmailAddress")
    @Mapping(source = "writerTelephoneNumber", target = "writerTelephoneNumber")
    @Mapping(source = "writerHandPhoneNumber", target = "writerHandPhoneNumber")
    @Mapping(source = "vocContent", target = "vocContent")
    @Mapping(source = "vocRegistrationDateTime", target = "vocRegistrationDateTime")
    @Mapping(source = "vocChangeDateTime", target = "vocChangeDateTime")
    @Mapping(source = "individualInformationCollectionTermsOfUseAgreementYesOrNo", target = "individualInformationCollectionTermsOfUseAgreementYesOrNo")
    @Mapping(source = "fileId", target = "fileId")
    VocDto toDto(Voc voc);

    @Mapping(source = "vocNumber", target = "vocNumber")
    @Mapping(source = "itemCode", target = "itemCode")
    @Mapping(source = "memberYn", target = "memberYn")
    @Mapping(source = "writerMemberId", target = "writerMemberId")
    @Mapping(source = "vocWriterName", target = "vocWriterName")
    @Mapping(source = "writerEmailAddress", target = "writerEmailAddress")
    @Mapping(source = "writerTelephoneNumber", target = "writerTelephoneNumber")
    @Mapping(source = "writerHandPhoneNumber", target = "writerHandPhoneNumber")
    @Mapping(source = "vocContent", target = "vocContent")
    @Mapping(source = "vocRegistrationDateTime", target = "vocRegistrationDateTime")
    @Mapping(source = "vocChangeDateTime", target = "vocChangeDateTime")
    @Mapping(source = "individualInformationCollectionTermsOfUseAgreementYesOrNo", target = "individualInformationCollectionTermsOfUseAgreementYesOrNo")
    @Mapping(source = "fileId", target = "fileId")
    Voc toEntity(VocDto vocDto);

    @Mapping(source = "writerMemberId", target = "registererMemberId")
    @Mapping(source = "vocWriterName", target = "vocCustomerName")
    VocClientDto toClientDto(Voc voc);
}

package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "TB_SVC_CTG_C")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class ServiceCategory extends BaseEntity {

    @Id
    @Size(max = 12)
    @Column(name = "SVC_CTG_CD", nullable = false, length = 12)
    private String serviceCategoryCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UP_SVC_CTG_CD")
    private ServiceCategory upServiceCategoryCode;

    @Size(max = 100)
    @NotNull
    @Column(name = "SVC_CTG_NM", nullable = false, length = 100)
    private String serviceCategoryName;

    @NotNull
    @ColumnDefault("'Y'")
    @Column(name = "OPEN_YN", nullable = false)
    private Character openYn;

    @Size(max = 3)
    @NotNull
    @Column(name = "RGSTR_CPRN_CD", nullable = false, length = 3)
    private String registererCorporationCode;

    @Size(max = 30)
    @NotNull
    @Column(name = "RGSTR_DEPT_CD", nullable = false, length = 30)
    private String registererDepartmentCode;

    @Size(max = 60)
    @NotNull
    @Column(name = "RGSTR_EMP_NO", nullable = false, length = 60)
    private String registererEmployeeNumber;

    @NotNull
    @Column(name = "SVC_CTG_RGST_DTM", nullable = false)
    private Instant serviceCategoryRegistrationDatetime;

    @NotNull
    @Column(name = "DEL_YN", nullable = false)
    private Character deleteYn;

    @NotNull
    @Column(name = "SORT_ORD", nullable = false, precision = 10)
    private BigDecimal sortOrder;
}

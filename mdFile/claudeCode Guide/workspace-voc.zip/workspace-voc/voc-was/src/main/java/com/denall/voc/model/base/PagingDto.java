package com.denall.voc.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface PagingDto {
    public static final int DEFAULT_PAGE_NO = 1;
    public static final int DEFAULT_PAGE_SIZE = 10;
    public static final int MAX_PAGE_SIZE = 1000;

    Integer getPageNo();

    Integer getPageSize();

    @JsonIgnore
    default Integer getLimit() {
        return getPageSize() == null ? DEFAULT_PAGE_SIZE : Math.min(getPageSize(), MAX_PAGE_SIZE);
    }

    @JsonIgnore
    default Integer getOffset() {
        Integer adjustedPageNo = getPageNo() == null ? DEFAULT_PAGE_NO : getPageNo();
        Integer adjustedPageSize = getPageSize() == null ? DEFAULT_PAGE_SIZE : Math.min(getPageSize(), MAX_PAGE_SIZE);

        return (adjustedPageNo - 1) * adjustedPageSize;
    }
}
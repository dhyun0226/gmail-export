package com.denall.voc.mapper;

import com.denall.voc.entity.Notice;
import com.denall.voc.model.response.NoticeResponseDto;
import com.denall.voc.model.table.NoticeDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface NoticeStruct extends StructMapper<Notice, NoticeDto> {
    @Override
    @Mapping(target = "noticeContent", ignore = true)
    NoticeDto toDto(Notice notice);
    
    @Override
    Notice toEntity(NoticeDto dto);
    
    @Mapping(target = "noticeContent", ignore = true)
    NoticeResponseDto toResponseDto(Notice notice);
}
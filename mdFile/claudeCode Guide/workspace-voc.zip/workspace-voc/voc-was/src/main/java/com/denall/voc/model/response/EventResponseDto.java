package com.denall.voc.model.response;

import com.denall.voc.entity.Event;
import com.denall.voc.entity.EventAnswer;
import com.denall.voc.model.txm.File;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.aspectj.apache.bcel.classfile.Code;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "이벤트 응답 DTO")
public class EventResponseDto {

    @Schema(description = "이벤트 번호", example = "1")
    private Long eventNumber;

    @Size(max = 4)
    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Schema(description = "이벤트 제목", example = "프로모션 안내")
    private String eventTitle;

    @Schema(description = "이벤트 내용", example = "이벤트 내용입니다.")
    private String eventContent;

    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "파일 ID", example = "file123")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "조회 건수", example = "157")
    private Short inquiryCount;

    @Schema(description = "이벤트 등록 일시", example = "2024-01-01T12:00:00")
    private LocalDateTime eventRegistrationDatetime;

    @Schema(description = "썸네일 파일 ID", example = "THUMBNAIL123")
    private String thumbnailFileId;

    @Schema(description = "썸네일 파일")
    private List<File> thumbnailFile;

    @Schema(description = "상단 고정 여부", example = "Y")
    private String topFixedYesOrNo;


    @Schema(description = "이벤트 시작 일시", example = "2025-01-01T09:00:00")
    private LocalDateTime eventStartDatetime;

    @Schema(description = "이벤트 종료 일시", example = "2025-01-31T18:00:00")
    private LocalDateTime eventEndDatetime;

    @Schema(description = "사용 여부", example = "Y")
    private String useYesOrNo;

    @Schema(description = "이벤트 참여 구분 코드", example = "01")
    private String eventParticipationDivisionCode;

    @Schema(description = "이벤트 앞 목록")
    private EventResponseDto previousEvents;

    @Schema(description = "이벤트 뒤 목록")
    private EventResponseDto nextEvents;

    @Setter
    @Schema(description = "이벤트 답변 목록")
    private List<EventAnswerResponseDto> eventAnswers;

    @Schema(description = "이벤트 답변 총 건수", example = "100")
    private Long eventAnswerTotalCount;

    public void setFileList(TxmFileListResponse txmFileListResponse) {
        this.fileList = txmFileListResponse.getData();
    }

    public void setthumbnailFile(TxmFileListResponse txmFileListResponse) {
        this.thumbnailFile = txmFileListResponse.getData();
    }

}
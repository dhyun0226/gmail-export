package com.denall.voc.controller;

import com.denall.voc.domain.QnaAnswerDetailService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.QnaAnswerDetailRequestDto;
import com.denall.voc.model.table.QnaAnswerDetailDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/qna-answers")
@RequiredArgsConstructor
@Tag(name = "QnA 답변", description = "QnA 답변 API")
public class QnaAnswerDetailController {

    private final QnaAnswerDetailService qnaAnswerDetailService;

    @Operation(summary = "QnA 답변 생성", description = "새로운 QnA 답변을 생성합니다.")
    @ApiResponse(responseCode = "201", description = "QnA 답변 생성 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @PostMapping
    public ResponseEntity<QnaAnswerDetailDto> create(
            @Parameter(description = "QnA 답변 생성 정보", required = true)
            @Valid @RequestBody QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetailDto createdQnaAnswer = qnaAnswerDetailService.create(qnaAnswerDetailDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdQnaAnswer);
    }

    @Operation(summary = "QnA 답변 대댓글 생성", description = "QnA 답변에 대댓글을 생성합니다.")
    @ApiResponse(responseCode = "201", description = "QnA 답변 대댓글 생성 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @PostMapping("/{qnaNumber}/{parentAnswerDetailNumber}/replies")
    public ResponseEntity<QnaAnswerDetailDto> createReply(
            @PathVariable Long qnaNumber,
            @PathVariable Long parentAnswerDetailNumber,
            @RequestBody @Valid QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetailDto createdReply = qnaAnswerDetailService.createReply(qnaNumber, parentAnswerDetailNumber, qnaAnswerDetailDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReply);
    }

    @Operation(summary = "QnA 답변 조회", description = "QnA 번호와 답변 일시로 QnA 답변을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 답변 조회 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @ApiResponse(responseCode = "404", description = "QnA 답변 없음")
    @GetMapping("/{qnaNumber}/{qnaAnswerDetailNumber}")
    public ResponseEntity<QnaAnswerDetailDto> get(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber,
            @Parameter(description = "QnA 답변 일시", required = true)
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) long qnaAnswerDetailNumber) {
        QnaAnswerDetailDto qnaAnswerDetailDto = qnaAnswerDetailService.get(qnaNumber, qnaAnswerDetailNumber);
        return ResponseEntity.ok(qnaAnswerDetailDto);
    }

    @Operation(summary = "QnA 답변 수정", description = "QnA 번호와 답변 일시로 QnA 답변을 수정합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 답변 수정 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @ApiResponse(responseCode = "404", description = "QnA 답변 없음")
    @PutMapping("/{qnaNumber}/{qnaAnswerDetailNumber}")
    public ResponseEntity<QnaAnswerDetailDto> update(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber,
            @Parameter(description = "QnA 답변 번호", required = true)
            @PathVariable long qnaAnswerDetailNumber,
            @Parameter(description = "QnA 답변 수정 정보", required = true)
            @Valid @RequestBody QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetailDto updatedQnaAnswer = qnaAnswerDetailService.update(qnaNumber, qnaAnswerDetailNumber, qnaAnswerDetailDto);
        return ResponseEntity.ok(updatedQnaAnswer);
    }

    @Operation(summary = "QnA 답변 삭제", description = "QnA 번호와 답변 상세 번호로 QnA 답변을 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "QnA 답변 삭제 성공")
    @ApiResponse(responseCode = "404", description = "QnA 답변 없음")
    @DeleteMapping("/{qnaNumber}/{qnaAnswerDetailNumber}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber,
            @Parameter(description = "QnA 답변 상세 번호", required = true)
            @PathVariable Long qnaAnswerDetailNumber) {
        qnaAnswerDetailService.delete(qnaNumber, qnaAnswerDetailNumber);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "QnA별 답변 목록 조회", description = "QnA 번호로 답변 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 답변 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @GetMapping("/qnas/{qnaNumber}")
    public ResponseEntity<List<QnaAnswerDetailDto>> getListByQnaNumber(
            @Parameter(description = "QnA 번호", required = true)
            @PathVariable Long qnaNumber) {
        List<QnaAnswerDetailDto> qnaAnswerDetailDtoList = qnaAnswerDetailService.getListByQnaNumber(qnaNumber);
        return ResponseEntity.ok(qnaAnswerDetailDtoList);
    }

}
package com.denall.voc.controller;

import com.denall.voc.domain.ServiceChargePersonService;
import com.denall.voc.model.response.ServiceChargePersonResponseDto;
import com.denall.voc.model.table.ServiceChargePersonDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/service-charge-persons")
@RequiredArgsConstructor
@Tag(name = "서비스 담당자 관리", description = "서비스 담당자 관리 API")
public class ServiceChargePersonController {

    private final ServiceChargePersonService serviceChargePersonService;

    @GetMapping("/{serviceChargePersonNumber}")
    @Operation(summary = "서비스 담당자 조회", description = "서비스 담당자 번호로 서비스 담당자 정보를 조회합니다.")
    public ResponseEntity<ServiceChargePersonDto> findById(@PathVariable Long serviceChargePersonNumber) {
        ServiceChargePersonDto serviceChargePersonDto = serviceChargePersonService.findById(serviceChargePersonNumber);
        return ResponseEntity.ok(serviceChargePersonDto);
    }

    @PostMapping
    @Operation(summary = "서비스 담당자 등록", description = "새로운 서비스 담당자를 등록합니다.")
    public ResponseEntity<ServiceChargePersonDto> create(@Valid @RequestBody ServiceChargePersonDto serviceChargePersonDto) {
        ServiceChargePersonDto createdServiceChargePersonDto = serviceChargePersonService.create(serviceChargePersonDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdServiceChargePersonDto);
    }

    @GetMapping("/channels/{serviceChargePersonEmployeeNumber}")
    @Operation(summary = "서비스 담당자 채널 조회", description = "서비스 담당자의 담당 채널을 조회합니다.")
    public ResponseEntity<List<String>> getChannelsByEmployeeNumber(@PathVariable String serviceChargePersonEmployeeNumber) {
        return ResponseEntity.ok(serviceChargePersonService.findByEmployeeNumber(serviceChargePersonEmployeeNumber));
    }

    @PutMapping("/{serviceChargePersonNumber}")
    @Operation(summary = "서비스 담당자 수정", description = "기존 서비스 담당자 정보를 수정합니다.")
    public ResponseEntity<ServiceChargePersonDto> update(
            @PathVariable Long serviceChargePersonNumber,
            @Valid @RequestBody ServiceChargePersonDto serviceChargePersonDto) {
        ServiceChargePersonDto updatedServiceChargePersonDto = serviceChargePersonService.update(serviceChargePersonNumber, serviceChargePersonDto);
        return ResponseEntity.ok(updatedServiceChargePersonDto);
    }

    @PutMapping("/update")
    @Operation(summary = "서비스 담당자 일괄 업데이트", description = "서비스 담당자 데이터를 일괄 업데이트합니다.")
    public ResponseEntity<Void> updateServiceChargePersons(@RequestBody List<ServiceChargePersonDto> serviceChargePersonDtos) {
        serviceChargePersonService.updateServiceChargePersons(serviceChargePersonDtos);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{serviceChargePersonNumber}")
    @Operation(summary = "서비스 담당자 삭제", description = "서비스 담당자를 삭제합니다.")
    public ResponseEntity<Void> delete(@PathVariable Long serviceChargePersonNumber) {
        serviceChargePersonService.delete(serviceChargePersonNumber);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    @Operation(summary = "서비스 담당자 목록 조회", description = "serviceCategoryCode로 서비스 담당자 정보를 조회합니다.")
    public ResponseEntity<List<ServiceChargePersonResponseDto>> findByServiceCategoryCode(
            @RequestParam String serviceCategoryCode) {
        List<ServiceChargePersonResponseDto> serviceChargePersonResponseDto = serviceChargePersonService.findByServiceCategoryCode(serviceCategoryCode);
        return ResponseEntity.ok(serviceChargePersonResponseDto);
    }
    
}
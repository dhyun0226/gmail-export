package com.denall.voc.model.response;


import com.denall.voc.annotation.Masked;
import com.denall.voc.model.txm.File;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "이벤트 답변 응답 DTO")
public class EventAnswerResponseDto extends BaseDto {

    @Schema(description = "이벤트 번호", example = "1")
    private Long eventNumber;

    @Schema(description = "이벤트 참여 일시", example = "2024-01-01T10:00:00")
    private LocalDateTime eventParticipationDatetime;

    @Masked(type = Masked.MaskingType.ID)
    @Schema(description = "참여자 회원 ID", example = "user123")
    private String participantMemberId;

    @Schema(description = "이벤트 참여 내용", example = "이벤트에 참여합니다.")
    private String eventParticipationContent;

    @Schema(description = "파일 ID", example = "file123")
    private String answerFileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "삭제 여부", example = "Y")
    private String deleteYesOrNo;


    public void setFileList(TxmFileListResponse txmFileListResponse) {
        this.fileList = txmFileListResponse.getData();
    }

}
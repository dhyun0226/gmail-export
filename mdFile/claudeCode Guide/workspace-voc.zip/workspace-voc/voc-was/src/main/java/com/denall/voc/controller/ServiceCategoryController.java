package com.denall.voc.controller;

import com.denall.voc.domain.ServiceCategoryService;
import com.denall.voc.model.response.TaskCategoryResponseDto;
import com.denall.voc.model.table.ServiceCategoryDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/serviceCategories")
@RequiredArgsConstructor
@Tag(name = "서비스 카테고리", description = "VOC 서비스 카테고리 관리 API")
public class ServiceCategoryController {

    private final ServiceCategoryService serviceCategoryService;
    @GetMapping
    @Operation(summary = "전체 서비스 카테고리 조회", description = "모든 VOC 서비스 카테고리를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class)))
    public ResponseEntity<List<ServiceCategoryDto>> getAllServiceCategories() {
        List<ServiceCategoryDto> serviceCategoryCodes = serviceCategoryService.getAllServiceCategories();
        return ResponseEntity.ok(serviceCategoryCodes);
    }

    @GetMapping("/{serviceCategoryCode}")
    @Operation(summary = "특정 서비스 카테고리 조회", description = "서비스 카테고리 코드로 특정 카테고리를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공",
                    content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class))),
            @ApiResponse(responseCode = "404", description = "카테고리를 찾을 수 없음")
    })
    public ResponseEntity<ServiceCategoryDto> getServiceCategoryById(
            @Parameter(description = "서비스 카테고리 코드", required = true, example = "CAT001")
            @PathVariable String serviceCategoryCode) {
        ServiceCategoryDto serviceCategoryDto = serviceCategoryService.getServiceCategoryById(serviceCategoryCode);
        return ResponseEntity.ok(serviceCategoryDto);
    }

    @GetMapping("/root")
    @Operation(summary = "최상위 카테고리 목록 조회", description = "최상위(Root) 카테고리 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class)))
    public ResponseEntity<List<ServiceCategoryDto>> getRootCategoriesByOpenYn(
            @Parameter(description = "공개 여부 (Y/N)", required = false, example = "Y")
            @RequestParam(required = false, defaultValue = "Y") Character openYn) {
        List<ServiceCategoryDto> rootCategories = serviceCategoryService.getRootCategoriesByOpenYn(openYn);
        return ResponseEntity.ok(rootCategories);
    }

    @GetMapping("/root/by-task")
    @Operation(summary = "업무별 최상위 카테고리 목록 조회", description = "업무명으로 필터링된 최상위 카테고리 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class)))
    public ResponseEntity<List<ServiceCategoryDto>> getRootCategoriesByTaskNameAndOpenYn(
            @Parameter(description = "업무명", required = false, example = "고객지원")
            @RequestParam(required = false) String taskName,
            @Parameter(description = "공개 여부 (Y/N)", required = false, example = "Y")
            @RequestParam(required = false,defaultValue = "Y") Character openYn) {
        List<ServiceCategoryDto> rootCategories = serviceCategoryService.getRootCategoriesByTaskNameAndOpenYn(taskName, openYn);
        return ResponseEntity.ok(rootCategories);
    }

    @GetMapping("/{categoryCode}/root")
    @Operation(summary = "특정 카테고리의 최상위 카테고리 조회", 
            description = "특정 카테고리의 최상위(루트) 카테고리를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공",
                    content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class))),
            @ApiResponse(responseCode = "404", description = "최상위 카테고리를 찾을 수 없음")
    })
    public ResponseEntity<ServiceCategoryDto> getRootCategoryByCategoryCode(
            @Parameter(description = "카테고리 코드", required = true, example = "CAT003")
            @PathVariable String categoryCode) {
        ServiceCategoryDto rootCategory = serviceCategoryService.findRootCategory(categoryCode);
        if (rootCategory != null) {
            return ResponseEntity.ok(rootCategory);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{parentCategoryCode}/children")
    @Operation(summary = "하위 카테고리 목록 조회", description = "특정 상위 카테고리에 속한 하위 카테고리 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class)))
    public ResponseEntity<List<ServiceCategoryDto>> getChildCategories(
            @Parameter(description = "상위 카테고리 코드", required = true, example = "CAT001")
            @PathVariable String parentCategoryCode,
            @Parameter(description = "공개 여부 (Y/N)", required = false, example = "N")
            @RequestParam(required = false, defaultValue = "N") Character openYn) {
        List<ServiceCategoryDto> childCategories = serviceCategoryService.getChildCategories(parentCategoryCode, openYn);
        return ResponseEntity.ok(childCategories);
    }

    @GetMapping("/second-level")
    @Operation(summary = "2레벨 카테고리 목록 조회", 
            description = "2레벨 카테고리 목록을 중복 제거하여 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공",
            content = @Content(schema = @Schema(implementation = TaskCategoryResponseDto.class)))
    public ResponseEntity<List<TaskCategoryResponseDto>> getSecondLevelCategories(
            @Parameter(description = "공개 여부 (Y/N)", required = false, example = "Y")
            @RequestParam(required = false, defaultValue = "Y") Character openYn) {
        List<TaskCategoryResponseDto> categories = serviceCategoryService.getMatchingTaskCategories(openYn);
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/by-employee/{employeeNumber}")
    @Operation(summary = "직원별 서비스 카테고리 목록 조회", 
            description = "특정 직원이 담당하는 서비스 카테고리 목록을 중복 없이 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공",
                    content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class))),
            @ApiResponse(responseCode = "404", description = "해당 직원의 카테고리를 찾을 수 없음"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청 (직원번호 누락)")
    })
    public ResponseEntity<List<ServiceCategoryDto>> getServiceCategoriesByEmployeeNumber(
            @Parameter(description = "직원번호", required = true, example = "26082208")
            @PathVariable String employeeNumber,
            @Parameter(description = "카테고리 필터 (예: NTF)", required = false)
            @RequestParam(required = false) String category) {
        List<ServiceCategoryDto> categories = serviceCategoryService.getServiceCategoriesByEmployeeNumber(employeeNumber, category);
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/top-level/by-employee/{employeeNumber}")
    @Operation(summary = "직원별 최상위 서비스 카테고리 목록 조회", 
            description = "특정 직원이 담당하는 서비스 카테고리의 최상위 카테고리 목록을 중복 없이 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공",
                    content = @Content(schema = @Schema(implementation = ServiceCategoryDto.class))),
            @ApiResponse(responseCode = "404", description = "해당 직원의 최상위 카테고리를 찾을 수 없음"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청 (직원번호 누락)")
    })
    public ResponseEntity<List<ServiceCategoryDto>> getTopLevelServiceCategoriesByEmployeeNumber(
            @Parameter(description = "직원번호", required = true, example = "26082208")
            @PathVariable String employeeNumber,
            @Parameter(description = "카테고리 필터 (예: NTF)", required = false)
            @RequestParam(required = false) String category) {
        List<ServiceCategoryDto> topLevelCategories = serviceCategoryService.getTopLevelServiceCategoriesByEmployeeNumber(employeeNumber, category);
        return ResponseEntity.ok(topLevelCategories);
    }
}
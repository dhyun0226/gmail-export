package com.denall.voc.domain;

import com.denall.voc.entity.Qna;
import com.denall.voc.entity.QnaAnswerDetail;
import com.denall.voc.entity.QnaAnswerDetailId;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.mapper.QnaAnswerDetailStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.QnaAnswerDetailRequestDto;
import com.denall.voc.model.table.QnaAnswerDetailDto;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.QnaAnswerDetailRepository;
import com.denall.voc.repository.QnaRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class QnaAnswerDetailService {

    private final QnaRepository qnaRepository;
    private final QnaAnswerDetailRepository qnaAnswerDetailRepository;
    private final QnaAnswerDetailStruct qnaAnswerDetailStruct;
    private final TxmServiceClient txmServiceClient;

    /**
     * QnA 답변 생성
     *
     * @param qnaAnswerDetailDto QnA 답변 상세 DTO
     * @return 생성된 QnA 답변 상세 DTO
     */
    @Transactional
    public QnaAnswerDetailDto create(QnaAnswerDetailDto qnaAnswerDetailDto) {
        // QnA 존재 여부 확인
        Qna qna = qnaRepository.findById(qnaAnswerDetailDto.getQnaNumber())
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaAnswerDetailDto.getQnaNumber()));

        // 답변 일시 설정
        qnaAnswerDetailDto.setQnaAnswerDatetime(LocalDateTime.now());

        // QnA 답변 상세 번호 설정 (예: 최대값 + 1)
        Long maxDetailNumber = qnaAnswerDetailRepository.findMaxDetailNumberByQnaNumber(qnaAnswerDetailDto.getQnaNumber());
        qnaAnswerDetailDto.setQnaAnswerDetailNumber(maxDetailNumber != null ? maxDetailNumber + 1 : 1L);

        // 엔티티 변환
        QnaAnswerDetail qnaAnswerDetail = qnaAnswerDetailStruct.toEntity(qnaAnswerDetailDto);

        // QnA 연관관계 설정
        qnaAnswerDetail.setQna(qna);

        // 엔티티 저장
        qnaAnswerDetail = qnaAnswerDetailRepository.save(qnaAnswerDetail);

        // QnA 답변 건수 증가
        qna.incrementAnswerCount();

        // 파일 리스트 처리
        if (qnaAnswerDetailDto.getFileList() != null && !qnaAnswerDetailDto.getFileList().isEmpty() ) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareQnaFiles(
                    qnaAnswerDetailDto.getFileList(),
                    qnaAnswerDetail.getId().getQnaNumber().toString() + '_' + qnaAnswerDetail.getId().getQnaAnswerDetailNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);
            qnaAnswerDetail.setFileId(qnaAnswerDetail.getId().getQnaNumber().toString() + '_' + qnaAnswerDetail.getId().getQnaAnswerDetailNumber().toString());

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }
        }

        qnaRepository.save(qna);

        return qnaAnswerDetailStruct.toDto(qnaAnswerDetail);
    }

    @Transactional
    public QnaAnswerDetailDto createReply(Long qnaNumber, Long parentAnswerDetailNumber, QnaAnswerDetailDto qnaAnswerDetailDto) {
        // 부모 답변 확인
        QnaAnswerDetail parentAnswer = qnaAnswerDetailRepository
                .findByIdQnaNumberAndIdQnaAnswerDetailNumber(qnaNumber, parentAnswerDetailNumber)
                .orElseThrow(() -> new BusinessException("parentAnswer.notFound", qnaNumber, parentAnswerDetailNumber));

        // QnA 확인
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));

        // QnA 답변 상세 번호 설정
        Long maxDetailNumber = qnaAnswerDetailRepository.findMaxDetailNumberByQnaNumber(qnaNumber);
        Long newDetailNumber = (maxDetailNumber != null) ? maxDetailNumber + 1 : 1L;

        // 복합 키 설정
        QnaAnswerDetailId id = new QnaAnswerDetailId(qnaNumber, newDetailNumber);

        // 엔티티 생성 및 저장
        QnaAnswerDetail qnaAnswerDetail = QnaAnswerDetail.builder()
                .id(id)
                .qna(qna)
                .parentAnswerDetailNumber(parentAnswerDetailNumber)
                .qnaAnswerContent(qnaAnswerDetailDto.getQnaAnswerContent())
                .qnaAnswerDatetime(LocalDateTime.now())
                .answererMemberId(qnaAnswerDetailDto.getAnswererMemberId())
                .deleteYn("N")
                .build();

        qnaAnswerDetail = qnaAnswerDetailRepository.save(qnaAnswerDetail);

        // QnA 답변 건수 증가
        qna.incrementAnswerCount();
        qnaRepository.save(qna);

        return qnaAnswerDetailStruct.toDto(qnaAnswerDetail);
    }

    /**
     * QnA 답변 조회
     *
     * @param qnaNumber QnA 번호
     * @param qnaAnswerDetailNumber QnA 답변 일시
     * @return QnA 답변 상세 DTO
     */
    @Transactional(readOnly = true)
    public QnaAnswerDetailDto get(Long qnaNumber, Long qnaAnswerDetailNumber) {
        QnaAnswerDetail qnaAnswerDetail = qnaAnswerDetailRepository
                .findByIdQnaNumberAndIdQnaAnswerDetailNumber(qnaNumber, qnaAnswerDetailNumber)
                .orElseThrow(() -> new BusinessException("qnaAnswer.notFound", qnaNumber, qnaAnswerDetailNumber));

        return qnaAnswerDetailStruct.toDto(qnaAnswerDetail);
    }

    /**
     * QnA 답변 수정
     *
     * @param qnaNumber QnA 번호
     * @param qnaAnswerDetailNumber QnA 답변 일시
     * @param qnaAnswerDetailDto QnA 답변 상세 DTO
     * @return 수정된 QnA 답변 상세 DTO
     */
    @Transactional
    public QnaAnswerDetailDto update(Long qnaNumber, long qnaAnswerDetailNumber,
                                     QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetail qnaAnswerDetail = qnaAnswerDetailRepository
                .findByIdQnaNumberAndIdQnaAnswerDetailNumber(qnaNumber, qnaAnswerDetailNumber)
                .orElseThrow(() -> new BusinessException("qnaAnswer.notFound", qnaNumber, qnaAnswerDetailNumber));

        qnaAnswerDetail.updateAnswer(qnaAnswerDetailDto.getQnaAnswerContent());

        if (qnaAnswerDetailDto.getAnswererMemberId() != null
                && qnaAnswerDetailDto.getAnswererCorporationCode() != null
                && qnaAnswerDetailDto.getAnswererDepartmentCode() != null
                && qnaAnswerDetailDto.getAnswererEmployeeNumber() != null) {
            qnaAnswerDetail.updateAnswerer(
                    qnaAnswerDetailDto.getAnswererMemberId(),
                    qnaAnswerDetailDto.getAnswererCorporationCode(),
                    qnaAnswerDetailDto.getAnswererDepartmentCode(),
                    qnaAnswerDetailDto.getAnswererEmployeeNumber()
            );
        }
        if (qnaAnswerDetailDto.getDeleteYn() != null) {
            qnaAnswerDetail.setDeleteYn(qnaAnswerDetailDto.getDeleteYn());
        }

        // 파일 리스트 처리 추가
        if (qnaAnswerDetailDto.getFileList() != null && !qnaAnswerDetailDto.getFileList().isEmpty()) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareQnaFiles(
                    qnaAnswerDetailDto.getFileList(),
                    qnaAnswerDetail.getId().getQnaNumber().toString() + '_' + qnaAnswerDetail.getId().getQnaAnswerDetailNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);
            qnaAnswerDetail.setFileId(qnaAnswerDetail.getId().getQnaNumber().toString() + '_' + qnaAnswerDetail.getId().getQnaAnswerDetailNumber().toString());

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }
        }

        qnaAnswerDetail = qnaAnswerDetailRepository.save(qnaAnswerDetail);
        return qnaAnswerDetailStruct.toDto(qnaAnswerDetail);
    }
    /**
     * QnA 답변 삭제
     *
     * @param qnaNumber QnA 번호
     * @param qnaAnswerDetailNumber QnA 답변 일시
     */
    @Transactional
    public void delete(Long qnaNumber, Long qnaAnswerDetailNumber) {
        QnaAnswerDetailId id = new QnaAnswerDetailId(qnaNumber, qnaAnswerDetailNumber);

        QnaAnswerDetail qnaAnswerDetail = qnaAnswerDetailRepository.findById(id)
                .orElseThrow(() -> new BusinessException("qnaAnswer.notFound", qnaNumber, qnaAnswerDetailNumber));

        qnaAnswerDetailRepository.delete(qnaAnswerDetail);

        // QnA 답변 건수 감소
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));

        qna.decrementAnswerCount();
        qnaRepository.save(qna);
    }

    /**
     * QnA 번호별 답변 목록 조회
     *
     * @param qnaNumber QnA 번호
     * @return QnA 답변 상세 DTO 목록
     */
    @Transactional(readOnly = true)
    public List<QnaAnswerDetailDto> getListByQnaNumber(Long qnaNumber) {
        List<QnaAnswerDetail> qnaAnswerDetailList = qnaAnswerDetailRepository.findByIdQnaNumber(qnaNumber);
        return qnaAnswerDetailStruct.toDtoList(qnaAnswerDetailList);
    }


}
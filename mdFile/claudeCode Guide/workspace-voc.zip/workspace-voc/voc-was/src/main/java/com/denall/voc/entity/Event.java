package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_EVT_M")
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class Event extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EVT_NO")
    private Long eventNumber;

    @Column(name = "SVC_CTG_CD", length = 12, nullable = false)
    private String serviceCategoryCode;

    @Column(name = "EVT_TTL", nullable = false, length = 100)
    private String eventTitle;

    @Column(name = "RGSTR_CPRN_CD", nullable = false, length = 3)
    private String registererCorporationCode;

    @Column(name = "RGSTR_DEPT_CD", nullable = false, length = 30)
    private String registererDepartmentCode;

    @Column(name = "RGSTR_EMP_NO", nullable = false, length = 60)
    private String registererEmployeeNumber;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    @Column(name = "INQ_CNT")
    private Short inquiryCount;

    @Column(name = "EVT_RGST_DTM", nullable = false)
    private LocalDateTime eventRegistrationDatetime;

    @Column(name = "THNL_FILE_ID", length = 50)
    private String thumbnailFileId;

    @Column(name = "TOP_FXD_YN", length = 50)
    private String topFixedYesOrNo;

    @Column(name = "EVT_STRT_DTM", nullable = false)
    private LocalDateTime eventStartDatetime;

    @Column(name = "EVT_END_DTM", nullable = false)
    private LocalDateTime eventEndDatetime;

    @Column(name = "USE_YN", nullable = false, length = 1)
    private String useYesOrNo;

    @Column(name = "EVT_PRTC_DVCD", nullable = false, length = 2)
    private String eventParticipationDivisionCode;

    // 비즈니스 메소드
    public void updateEvent(Event event) {
        this.eventTitle = event.eventTitle;
        this.serviceCategoryCode = event.serviceCategoryCode;
        this.eventStartDatetime = event.eventStartDatetime;
        this.eventEndDatetime = event.eventEndDatetime;
        this.topFixedYesOrNo = event.topFixedYesOrNo;
        this.useYesOrNo = event.useYesOrNo;
        this.fileId = event.fileId;
        this.thumbnailFileId = event.thumbnailFileId;
        this.eventParticipationDivisionCode = event.eventParticipationDivisionCode;
        this.registererCorporationCode = event.registererCorporationCode;
        this.registererDepartmentCode = event.registererDepartmentCode;
        this.inquiryCount = event.inquiryCount;
        this.registererEmployeeNumber = event.registererEmployeeNumber;
    }

//    public void incrementInquiryCount() {
//        this.inquiryCount = this.inquiryCount == null ? 1 : (short)(this.inquiryCount + 1);
//    }

    public void updateRegisterer(String registererCorporationCode,
                                 String registererDepartmentCode,
                                 String registererEmployeeNumber) {
        this.registererCorporationCode = registererCorporationCode;
        this.registererDepartmentCode = registererDepartmentCode;
        this.registererEmployeeNumber = registererEmployeeNumber;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public void setThumbnailFileId(String thumbnailFileId) {
        this.thumbnailFileId = thumbnailFileId;
    };

    public void detachThumbnailFile() {
        this.thumbnailFileId = null;
    }

    public void detachFile() {
        this.fileId = null;
    }

    public void incrementInquiryCount() {
        this.inquiryCount = this.inquiryCount == null ? 1 : (short)(this.inquiryCount + 1);
    }
    

}
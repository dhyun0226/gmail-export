package com.denall.voc.controller;

import com.denall.voc.domain.FaqService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.FaqRequestDto;
import com.denall.voc.model.table.FaqDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/faqs")
@RequiredArgsConstructor
@Tag(name = "FAQ", description = "FAQ API")
public class FaqController {

    private final FaqService faqService;

    @Operation(summary = "FAQ 생성", description = "새로운 FAQ를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "FAQ 생성 성공",
            content = @Content(schema = @Schema(implementation = FaqDto.class)))
    @PostMapping
    public ResponseEntity<FaqDto> create(
            @Parameter(description = "FAQ 생성 정보", required = true)
            @Valid @RequestBody FaqDto faqDto) {
        FaqDto createdFaq = faqService.create(faqDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdFaq);
    }

    @Operation(summary = "FAQ 조회", description = "ID로 FAQ를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "FAQ 조회 성공",
            content = @Content(schema = @Schema(implementation = FaqDto.class)))
    @ApiResponse(responseCode = "404", description = "FAQ 없음")
    @GetMapping("/{faqNumber}")
    public ResponseEntity<FaqDto> get(
            @Parameter(description = "FAQ 번호", required = true)
            @PathVariable Long faqNumber) {
        FaqDto faqDto = faqService.get(faqNumber);
        return ResponseEntity.ok(faqDto);
    }

    @Operation(summary = "FAQ 수정", description = "ID로 FAQ를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "FAQ 수정 성공",
            content = @Content(schema = @Schema(implementation = FaqDto.class)))
    @ApiResponse(responseCode = "404", description = "FAQ 없음")
    @PutMapping("/{faqNumber}")
    public ResponseEntity<FaqDto> update(
            @Parameter(description = "FAQ 번호", required = true)
            @PathVariable Long faqNumber,
            @Parameter(description = "FAQ 수정 정보", required = true)
            @Valid @RequestBody FaqDto faqDto) {
        FaqDto updatedFaq = faqService.update(faqNumber, faqDto);
        return ResponseEntity.ok(updatedFaq);
    }

    @Operation(summary = "FAQ 삭제", description = "ID로 FAQ를 삭제합니다.")
    @ApiResponse(responseCode = "200", description = "공지 삭제 성공")
    @ApiResponse(responseCode = "404", description = "FAQ 없음")
    @DeleteMapping("/{faqNumber}")
    public ResponseEntity<ResultDto<?>> delete(
            @Parameter(description = "FAQ 번호", required = true)
            @PathVariable Long faqNumber) {
        faqService.delete(faqNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }

    @Operation(summary = "사용중인 FAQ 목록 조회", description = "사용중인 FAQ 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "사용중인 FAQ 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = FaqDto.class)))
    @GetMapping("/active")
    public ResponseEntity<List<FaqDto>> getActiveList() {
        List<FaqDto> faqDtoList = faqService.getActiveList();
        return ResponseEntity.ok(faqDtoList);
    }

    @Operation(summary = "정렬순서순 FAQ 목록 조회", description = "정렬순서순 FAQ 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "정렬순서순 FAQ 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = FaqDto.class)))
    @GetMapping("/ordered")
    public ResponseEntity<List<FaqDto>> getOrderedList() {
        List<FaqDto> faqDtoList = faqService.getOrderedList();
        return ResponseEntity.ok(faqDtoList);
    }

    @Operation(summary = "FAQ 검색", description = "조건에 맞는 FAQ 목록을 검색합니다.")
    @ApiResponse(responseCode = "200", description = "FAQ 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping
    public ResponseEntity<ResultDto<FaqDto>> search(FaqRequestDto requestDto) {
        ResultDto<FaqDto> result = faqService.search(requestDto);
        return ResponseEntity.ok(result);
    }


    @GetMapping("/{faqNumber}/position")
    @Operation(summary = "FAQ 위치 조회", description = "특정 FAQ의 목록 내 위치(순서)를 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "위치 조회 성공",
                    content = @Content(schema = @Schema(implementation = ResultDto.class))),
            @ApiResponse(responseCode = "404", description = "FAQ를 찾을 수 없음")
    })
    public ResultDto<Long> getFaqPosition(
            @Parameter(description = "FAQ 번호", required = true)
            @PathVariable long faqNumber,
            @Parameter(description = "FAQ 검색 조건")
            FaqRequestDto requestDto
    ) {
        long pos = faqService.getPosition(faqNumber, requestDto.getChannelCode());

        // position 이 1 이상이면 singleton 리스트, 아니면 빈 리스트
        List<Long> data = pos > 0
                ? Collections.singletonList(pos)
                : Collections.emptyList();

        // totalCount 는 data.size() 로 설정
        return new ResultDto<>(data, (long) data.size());
    }
}

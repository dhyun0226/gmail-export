package com.denall.voc.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Embeddable
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class EventAnswerId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "EVT_NO", nullable = false, updatable = false)
    private Long eventNumber;

    @Column(name = "EVT_PRTC_DTM", nullable = false, updatable = false)
    private LocalDateTime eventParticipationDatetime;

    public EventAnswerId(Long eventNumber, LocalDateTime eventParticipationDatetime) {
        this.eventNumber = eventNumber;
        this.eventParticipationDatetime = eventParticipationDatetime;
    }
}
package com.denall.voc.aop;

import com.denall.voc.annotation.Masked;
import com.denall.voc.util.MaskingUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.*;

@Aspect
@Component
public class MaskingAspect {

    /**
     * MapStruct 매퍼의 toDto 메서드 호출 시 마스킹 처리
     */
    @Around("execution(* com.denall.voc.mapper.*Struct.toDto*(..))")
    public Object applyMaskingToDto(ProceedingJoinPoint joinPoint) throws Throwable {
        // 원본 메서드 실행
        Object result = joinPoint.proceed();

        // 결과 마스킹 처리
        return maskResult(result);
    }

    /**
     * QueryDSL Repository의 마스킹 대상 메서드 호출 시 마스킹 처리
     */
    @Around("@annotation(com.denall.voc.annotation.MaskingQueryResult)")
    public Object applyMaskingToQueryResult(ProceedingJoinPoint joinPoint) throws Throwable {
        // 원본 메서드 실행
        Object result = joinPoint.proceed();

        // 결과 마스킹 처리
        return maskResult(result);
    }

    /**
     * 결과 객체 마스킹 처리
     */
    private Object maskResult(Object result) {
        if (result == null) {
            return null;
        }

        // 반환 결과가 컬렉션인 경우 각 항목마다 마스킹 처리
        if (result instanceof Collection) {
            ((Collection<?>) result).forEach(this::processObjectRecursively);
        } else {
            // 단일 객체 처리
            processObjectRecursively(result);
        }

        return result;
    }

    /**
     * 객체와 그 내부 객체들을 재귀적으로 처리
     */
    private void processObjectRecursively(Object obj) {
        if (obj == null || isProcessedObject(obj)) {
            return;
        }

        // 이미 처리된 객체로 표시
        markAsProcessed(obj);

        // 현재 객체가 DTO인 경우 마스킹 처리
        if (shouldMaskObject(obj)) {
            processMasking(obj);
        }

        // 객체의 필드들을 재귀적으로 처리
        processFields(obj);
    }

    /**
     * 이미 처리된 객체인지 확인 (순환 참조 방지)
     */
    private final Set<Integer> processedObjects = Collections.newSetFromMap(new WeakHashMap<>());

    private boolean isProcessedObject(Object obj) {
        return !processedObjects.add(System.identityHashCode(obj));
    }

    private void markAsProcessed(Object obj) {
        processedObjects.add(System.identityHashCode(obj));
    }

    /**
     * 객체의 필드들을 재귀적으로 처리
     */
    private void processFields(Object obj) {
        try {
            Class<?> clazz = obj.getClass();
            
            // Java 내장 클래스들은 처리하지 않음
            if (isJavaInternalClass(clazz)) {
                return;
            }
            
            Field[] fields = clazz.getDeclaredFields();

            for (Field field : fields) {
                field.setAccessible(true);
                Object fieldValue = field.get(obj);
                field.setAccessible(false);

                if (fieldValue == null) {
                    continue;
                }

                // 컬렉션인 경우
                if (fieldValue instanceof Collection) {
                    ((Collection<?>) fieldValue).forEach(this::processObjectRecursively);
                }
                // 배열인 경우
                else if (fieldValue.getClass().isArray()) {
                    int length = Array.getLength(fieldValue);
                    for (int i = 0; i < length; i++) {
                        processObjectRecursively(Array.get(fieldValue, i));
                    }
                }
                // Map인 경우
                else if (fieldValue instanceof Map) {
                    ((Map<?, ?>) fieldValue).values().forEach(this::processObjectRecursively);
                }
                // 일반 객체인 경우 (기본 타입, String, 래퍼 클래스 등은 제외)
                else if (!fieldValue.getClass().isPrimitive() &&
                        !isJavaInternalClass(fieldValue.getClass())) {
                    processObjectRecursively(fieldValue);
                }
            }
        } catch (Exception e) {
            // 로깅만 하고 계속 진행
            e.printStackTrace();
        }
    }
    
    /**
     * Java 내장 클래스인지 확인
     */
    private boolean isJavaInternalClass(Class<?> clazz) {
        String className = clazz.getName();
        return className.startsWith("java.") || 
               className.startsWith("javax.") || 
               className.startsWith("sun.") ||
               className.startsWith("com.sun.") ||
               className.startsWith("jdk.");
    }

    /**
     * 객체가 마스킹 대상인지 확인
     */
    private boolean shouldMaskObject(Object obj) {
        if (obj == null) {
            return false;
        }

        Class<?> clazz = obj.getClass();
        return clazz.getSimpleName().endsWith("Dto") ||
                clazz.getSimpleName().endsWith("DTO");
    }

    /**
     * 객체 내의 @Masked 어노테이션이 있는 필드에 마스킹 적용
     */
    private void processMasking(Object dto) {
        try {
            if (dto == null) {
                return;
            }

            Class<?> dtoClass = dto.getClass();
            Field[] fields = dtoClass.getDeclaredFields();

            for (Field field : fields) {
                if (field.isAnnotationPresent(Masked.class)) {
                    field.setAccessible(true);
                    Object value = field.get(dto);

                    if (value != null && value instanceof String) {
                        Masked.MaskingType maskingType = field.getAnnotation(Masked.class).type();
                        String maskedValue = MaskingUtils.applyMaskingByType((String) value, maskingType);
                        field.set(dto, maskedValue);
                    }

                    field.setAccessible(false);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("마스킹 처리 중 오류가 발생했습니다.", e);
        }
    }
}
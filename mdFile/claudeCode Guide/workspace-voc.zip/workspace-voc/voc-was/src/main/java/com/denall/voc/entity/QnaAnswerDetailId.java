package com.denall.voc.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class QnaAnswerDetailId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "QNA_NO", nullable = false, updatable = false)
    private Long qnaNumber;

    @Column(name = "QNA_ANS_DTL_NO", nullable = false, updatable = false)
    private Long qnaAnswerDetailNumber;

    public QnaAnswerDetailId(Long qnaNumber, Long qnaAnswerDetailNumber) {
        this.qnaNumber = qnaNumber;
        this.qnaAnswerDetailNumber = qnaAnswerDetailNumber;
    }
}
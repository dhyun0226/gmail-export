package com.denall.voc.feign;

import com.denall.voc.model.event.VocClientDto;
import com.denall.voc.model.response.TaskCategoryResponseDto;
import com.denall.voc.model.table.ServiceCategoryDto;
import com.osstem.ow.api.feign.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "vocClient", url = "${occ.api.voc.root.uri}", configuration = FeignClientConfig.class)
public interface VocServiceClient {
    @PostMapping("/vocs")
    VocClientDto create(VocClientDto request);

    @GetMapping("/voc-charge-persons/channels/{vocChargePersonEmployeeNumber}")
    List<String> getVocChargePersonChannels(@PathVariable String vocChargePersonEmployeeNumber);

    @PutMapping("/vocs/{vocNumber}/denall")
    VocClientDto put(@PathVariable Long vocNumber, VocClientDto request);

    @GetMapping("/vocCategories")
    List<ServiceCategoryDto> getAllVocCategoryCodes();

    @GetMapping("/vocCategories/{vocCategoryCode}")
    ServiceCategoryDto getVocCategoryById(@PathVariable String vocCategoryCode);

    @GetMapping("/vocCategories/root")
    List<ServiceCategoryDto> getRootCategories(@RequestParam(required = false) Character openYn);

    @GetMapping("/vocCategories/{categoryCode}/root")
    ServiceCategoryDto getRootCategoryByCategoryCode(@PathVariable String categoryCode);

    @GetMapping("/vocCategories/{parentCategoryCode}/children")
    List<ServiceCategoryDto> getChildCategoriesByCategoryCode(@PathVariable String parentCategoryCode);

    @GetMapping("/vocCategories/second-level")
    List<TaskCategoryResponseDto> getSecondLevelCategories(@RequestParam(required = false) Character openYn);

    @GetMapping("/vocCategories/root/by-task")
    List<ServiceCategoryDto> getRootCategoriesByTask(@RequestParam String taskName, @RequestParam(required = false) Character openYn);

}

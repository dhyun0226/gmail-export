// 2) Service 클래스 (인터페이스 없이 단일 클래스로)
package com.denall.voc.domain;

import com.denall.voc.entity.VocAnswer;
import com.denall.voc.mapper.VocAnswerStruct;
import com.denall.voc.model.table.VocAnswerDto;
import com.denall.voc.repository.VocAnswerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class VocAnswerService {

    private final VocAnswerRepository vocAnswerRepository;
    private final VocAnswerStruct vocAnswerStruct;

    public VocAnswerDto create(VocAnswerDto dto) {
        VocAnswer saved = vocAnswerRepository.save(vocAnswerStruct.toEntity(dto));
        return vocAnswerStruct.toDto(saved);
    }

    @Transactional(readOnly = true)
    public VocAnswerDto getById(Long id) {
        VocAnswer e = vocAnswerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 답변 id=" + id));
        return vocAnswerStruct.toDto(e);
    }

    @Transactional(readOnly = true)
    public List<VocAnswerDto> getAll() {
        return vocAnswerRepository.findAll()
                .stream()
                .map(vocAnswerStruct::toDto)
                .collect(Collectors.toList());
    }

    public VocAnswerDto update(Long id, VocAnswerDto dto) {
        VocAnswer existing = vocAnswerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 답변 id=" + id));
        vocAnswerStruct.updateEntityFromDto(dto, existing);
        // 영속성 컨텍스트에 의해 자동 반영됨
        return vocAnswerStruct.toDto(existing);
    }

    public void delete(Long id) {
        vocAnswerRepository.deleteById(id);
    }
}

package com.denall.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC DTO")
public class VocClientDto extends BaseDto {

    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @NotNull
    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Schema(description = "덴올 VOC 번호")
    private Long denallVocNumber;

    @Size(max = 90)
    @Schema(description = "품목 코드")
    private String itemCode;

    @NotBlank
    @Size(max = 2)
    @Schema(description = "VOC 등록자 구분 코드")
    private String vocRegistererDivisionCode;

    @Size(max = 3)
    @Schema(description = "등록자 법인 코드")
    private String registererCorporationCode;

    @Size(max = 30)
    @Schema(description = "등록자 부서 코드")
    private String registererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "등록자 사원 번호")
    private String registererEmployeeNumber;

    @Size(max = 20)
    @Schema(description = "등록자 회원 ID")
    private String registererMemberId;

    @Size(max = 50)
    @Schema(description = "VOC 고객명")
    private String vocCustomerName;

    @Size(max = 100)
    @Schema(description = "VOC 고객 거래처명")
    private String vocCustomerCustomerName;


    @Size(max = 50)
    @Schema(description = "VOC 고객 이메일 주소")
    private String vocCustomerEmailAddress;

    @Size(max = 20)
    @Schema(description = "VOC 고객 전화번호")
    private String vocCustomerTelephoneNumber;

    @Size(max = 20)
    @Schema(description = "VOC 고객 휴대전화번호")
    private String vocCustomerHandPhoneNumber;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "VOC 제목")
    private String vocTitle;

    @NotBlank
    @Size(max = 2000)
    @Schema(description = "VOC 내용")
    private String vocContent;

    @Size(max = 1)
    @Schema(description = "개인정보 수집 이용 약관 동의 여부")
    private String individualInformationCollectionTermsOfUseAgreementYesOrNo;

    @Size(max = 50)
    @Schema(description = "파일 ID")
    private String fileId;

    @Size(max = 2)
    @Schema(description = "VOC 완료 유형 코드")
    private String vocCompletionTypeCode;

    @Schema(description = "업무 요청 번호")
    private Long businessRequestNumber;

    @Schema(description = "과제 절차 번호")
    private Long assignmentProcedureNumber;

    @Size(max = 500)
    @Schema(description = "종료 사유 내용")
    private String endReasonContent;

    @NotBlank
    @Size(max = 2)
    @Schema(description = "VOC 상태 코드")
    private String vocStateCode;

    @NotBlank
    @Size(max = 1)
    @Schema(description = "삭제 여부")
    private String deleteYesOrNo;

    @Schema(description = "VOC 등록 일시")
    private LocalDateTime vocRegistrationDateTime;


}
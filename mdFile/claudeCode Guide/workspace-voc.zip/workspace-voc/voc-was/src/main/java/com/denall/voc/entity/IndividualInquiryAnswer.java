package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_INDV_INQY_ANS_D")
@Getter
@Builder
@DynamicInsert
@DynamicUpdate
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class IndividualInquiryAnswer extends BaseEntity {

    @Id
    @Column(name = "INDV_INQY_NO", nullable = false, updatable = false)
    private Long individualInquiryNumber;

    @Column(name = "ANSR_CPRN_CD", length = 3, nullable = false)
    private String answererCorporationCode;

    @Column(name = "ANSR_DEPT_CD", length = 30, nullable = false)
    private String answererDepartmentCode;

    @Column(name = "ANSR_EMP_NO", length = 60, nullable = false)
    private String answererEmployeeNumber;

    @Column(name = "INDV_INQY_ANS_CN", length = 1000, nullable = false)
    private String individualInquiryAnswerContent;

    @Column(name = "INDV_INQY_ANS_DTM", nullable = false)
    private LocalDateTime individualInquiryAnswerDatetime;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;
}
package com.denall.voc.mapper;

import com.denall.voc.entity.Event;
import com.denall.voc.entity.EventAnswer;
import com.denall.voc.model.response.EventAnswerResponseDto;
import com.denall.voc.model.response.EventResponseDto;
import com.denall.voc.model.table.EventDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EventStruct extends StructMapper<Event, EventDto> {
    @Override
    @Mapping(target = "eventContent", ignore = true)
    EventDto toDto(Event event);
    
    @Override
    Event toEntity(EventDto dto);
    
    @Mapping(target = "eventContent", ignore = true)
    EventResponseDto toResponseDto(Event event);
    EventAnswerResponseDto toAnswerResponseDto(EventAnswer eventAnswer); // 추가
}
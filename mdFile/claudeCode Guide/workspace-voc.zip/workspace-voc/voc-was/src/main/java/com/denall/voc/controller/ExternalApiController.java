package com.denall.voc.controller;

import com.denall.voc.domain.ExternalApiService;
import com.denall.voc.domain.NoticeService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.common.ExternalApiDto;
import com.denall.voc.model.table.NoticeDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/public")
@RequiredArgsConstructor
@Tag(name = "외부", description = "외부 API")
public class ExternalApiController {

    private final ExternalApiService externalApiService;

    @Operation(
            summary = "덴올 TV 공지사항 푸터",
            description = "TV 채널 하단에 노출될 최근 공지사항 3건을 조회합니다. 공지사항은 최신 등록일 기준으로 정렬됩니다."
    )
    @ApiResponse(responseCode = "200", description = "공지 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/tv/footer")

    public ResponseEntity<List<ExternalApiDto>> getTvNoticesFooter() {
        List<ExternalApiDto> result = externalApiService.getTvNoticesFooter();
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "덴올 Mall 메인 공지/이벤트", description = "메인 화면에 노출될 최근 공지사항 및 이벤트 5건을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "공지/이벤트 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/mall/main")
    public ResponseEntity<List<ExternalApiDto>> getMallNoticesAndEvent() {
        List<ExternalApiDto> result = externalApiService.getMallNoticesAndEvent();
        return ResponseEntity.ok(result);
    }

    @Operation(
            summary = "게시판별 게시물 조회",
            description = "특정 게시판(notice, faq, qna, event)과 채널(tv, mall, software, education, job)별 최신 게시물을 지정된 개수만큼 조회합니다."
    )
    @ApiResponse(responseCode = "200", description = "게시물 조회 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/boards/posts")
    public ResponseEntity<List<ExternalApiDto>> getBoardPosts(
            @RequestParam String boardType,
            @RequestParam String channel,
            @RequestParam(defaultValue = "5") int count
    ) {
        List<ExternalApiDto> result = externalApiService.getBoardPosts(boardType, channel, count);
        return ResponseEntity.ok(result);
    }
    
    @Operation(
            summary = "카테고리별 공지사항 조회",
            description = "특정 카테고리 코드의 공지사항을 조회합니다. 상단고정 여부와 조회 개수를 지정할 수 있습니다."
    )
    @ApiResponse(responseCode = "200", description = "공지사항 조회 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/notices/category")
    public ResponseEntity<List<ExternalApiDto>> getNoticesByCategory(
            @RequestParam(defaultValue = "D002_NTF_005") String categoryCode,
            @RequestParam(required = false) String topFixedOnly,
            @RequestParam(defaultValue = "10") int count
    ) {
        List<ExternalApiDto> result = externalApiService.getNoticesByCategoryCode(categoryCode, topFixedOnly, count);
        return ResponseEntity.ok(result);
    }

    @Operation(
            summary = "소프트웨어 공지사항 투데이 게시물 조회",
            description = "특정 게시판(notice, faq, qna, event)과 채널(tv, mall, software, education, job)별 최신 게시물을 지정된 개수만큼 조회합니다."
    )
    @ApiResponse(responseCode = "200", description = "게시물 조회 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/notices/today")
    public ResponseEntity<List<ExternalApiDto>> getTodayNotices(
            @RequestParam(defaultValue = "D002_NTF_005") String categoryCode,
            @RequestParam(defaultValue = "5") int count
    ) {
        List<ExternalApiDto> result = externalApiService.getTodayNotices(categoryCode, count);
        return ResponseEntity.ok(result);
    }

}


package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "TB_SVC_CHPR_M")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class ServiceChargePerson extends BaseEntity {

    @Id
    @Column(name = "SVC_CHPR_NO", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long serviceChargePersonNumber;

    @NotNull
    @Size(max = 12)
    @Column(name = "SVC_CTG_CD", length = 12, nullable = false)
    private String serviceCategoryCode;

    @Setter
    @NotNull
    @Size(max = 3)
    @Column(name = "SVC_CHPR_CPRN_CD", length = 3, nullable = false)
    private String serviceChargePersonCorporationCode;

    @Setter
    @NotNull
    @Size(max = 30)
    @Column(name = "SVC_CHPR_DEPT_CD", length = 30, nullable = false)
    private String serviceChargePersonDepartmentCode;

    @Setter
    @NotNull
    @Size(max = 60)
    @Column(name = "SVC_CHPR_EMP_NO", length = 60, nullable = false)
    private String serviceChargePersonEmployeeNumber;

    @Setter
    @NotNull
    @Size(max = 500)
    @Column(name = "SVC_CHPR_DEPT_NM", length = 500, nullable = false)
    private String serviceChargePersonDepartmentName;

    @Setter
    @NotNull
    @Size(max = 100)
    @Column(name = "SVC_CHPR_EMP_NM", length = 100, nullable = false)
    private String serviceChargePersonEmployeeName;

    @Setter
    @NotNull
    @Size(max = 1)
    @Column(name = "SVC_DSNT_CHPR_YN", length = 1, nullable = false)
    private String serviceDesignationThePersonInChargeYn;

    @Setter
    @NotNull
    @Size(max = 1)
    @Column(name = "DEL_YN", length = 1, nullable = false)
    private String deleteYn;

}
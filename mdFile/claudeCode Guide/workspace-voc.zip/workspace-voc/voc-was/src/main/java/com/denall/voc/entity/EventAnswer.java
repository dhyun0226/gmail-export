package com.denall.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "TB_EVT_PRTC_D")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class EventAnswer extends BaseEntity {

    @EmbeddedId
    private EventAnswerId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EVT_NO", insertable = false, updatable = false)
    @MapsId("eventNumber")
    private Event event;

    @Column(name = "PRTCR_MEM_ID")
    private String participantMemberId;

    @Column(name = "EVT_PRTC_CN")
    private String eventParticipationContent;

    @Column(name = "FILE_ID")
    private String fileId;

    @Column(name = "DEL_YN")
    private String deleteYesOrNo;

    public void setEvent(Event event) {
        this.event = event;
    }
}
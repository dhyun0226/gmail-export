package com.denall.voc.model.base;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class ResultDto<T> {
    private List<T> data;
    private long totalCount;
    private List<String> serviceCategoryCodes; // 추가

    public ResultDto(List<T> data, long totalCount) {
        this.data = data;
        this.totalCount = totalCount;
    }

    public ResultDto(List<T> data, long totalCount, List<String> serviceCategoryCodes) { // 추가
        this.data = data;
        this.totalCount = totalCount;
        this.serviceCategoryCodes = serviceCategoryCodes;
    }
}
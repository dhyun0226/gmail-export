package com.denall.voc.model.request;

import com.denall.voc.model.base.PagingDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Schema(description = "FAQ 요청 DTO")
public class FaqRequestDto implements PagingDto {

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;


    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private List<String> serviceCategoryCode;

    @Size(max = 3)
    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Size(max = 30)
    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Size(max = 1)
    @Schema(description = "사용 여부", example = "Y")
    private String useYn;

    @Schema(description = "검색 타입 (title:제목, content:내용, both:제목+내용)", example = "both")
    private String searchType;

    @Schema(description = "검색 키워드", example = "문의합니다")
    private String keyword;

    @Schema(description = "시작일", example = "2025-01-01")
    private LocalDateTime fromDate;

    @Schema(description = "종료일", example = "2025-04-04")
    private LocalDateTime toDate;


    @JsonIgnore
    public Pageable getPageable() {
        int pageIndex = getOffset() / getLimit();
        return PageRequest.of(pageIndex, getLimit());
    }
}
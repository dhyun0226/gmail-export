package com.denall.voc.model.common;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BusinessPartnerCodeResponseDto {
    private Integer status;
    private String code;
    private String message;
    private String data;
}


//{
//  "data": "905227",
//  "status": 200,
//  "code": "OK",
//  "message": "Success",
//  "timestamp": 1747204630383
//}
package com.denall.voc.model.dnc;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DncMemberInfoResponse {
    private int status;
    private String code;
    private String message;
    private long timestamp;
    private MemberInfo data;

    @Builder
    @Getter
    public static class MemberInfo {
        private String rowStatus;
        private String memberId;
        private String businessmanCustomerCode;
        private String cimsBusinessmanCustomerCode;
        private String memberDivisionCode;
        private String handPhoneNumber;
        private String email;
        private String memberName;
        private String birthday;
        private String solarLunarDivisionCode;
        private String sexDivisionCode;
        private String countryCode;
        private String memberJobClassCode;
        private String recommendationEmployeeCode;
        private long joinDateTime;
        private String memberStatusCode;
        private String memberPassword;
    }
}

package com.denall.voc.controller;

import com.denall.voc.domain.IndividualInquiryAnswerService;
import com.denall.voc.model.table.IndividualInquiryAnswerDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/individual-inquiry-answers")
@RequiredArgsConstructor
@Tag(name = "개인문의답변", description = "개인문의답변 API")
public class IndividualInquiryAnswerController {

    private final IndividualInquiryAnswerService individualInquiryAnswerService;

    @PostMapping
    @Operation(summary = "개인문의답변 등록", description = "개인문의에 대한 답변을 등록합니다.")
    @ApiResponse(responseCode = "201", description = "등록 성공")
    @ApiResponse(responseCode = "404", description = "개인문의를 찾을 수 없음")
    @ApiResponse(responseCode = "409", description = "이미 답변이 존재함")
    public ResponseEntity<IndividualInquiryAnswerDto> create(
            @RequestBody @Valid IndividualInquiryAnswerDto answerDto) {
        IndividualInquiryAnswerDto createdAnswer = individualInquiryAnswerService.create(answerDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdAnswer);
    }

    @GetMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의답변 상세 조회", description = "개인문의 번호로 개인문의답변 상세 정보를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    @ApiResponse(responseCode = "404", description = "개인문의답변을 찾을 수 없음")
    public ResponseEntity<IndividualInquiryAnswerDto> get(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber) {
        IndividualInquiryAnswerDto answerDto = individualInquiryAnswerService.get(inquiryNumber);
        return ResponseEntity.ok(answerDto);
    }

    @PutMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의답변 수정", description = "개인문의 번호로 개인문의답변 정보를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "수정 성공")
    @ApiResponse(responseCode = "404", description = "개인문의답변을 찾을 수 없음")
    public ResponseEntity<IndividualInquiryAnswerDto> update(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber,
            @RequestBody @Valid IndividualInquiryAnswerDto answerDto) {
        IndividualInquiryAnswerDto updatedAnswer = individualInquiryAnswerService.update(inquiryNumber, answerDto);
        return ResponseEntity.ok(updatedAnswer);
    }

    @DeleteMapping("/{inquiryNumber}")
    @Operation(summary = "개인문의답변 삭제", description = "개인문의 번호로 개인문의답변을 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "삭제 성공")
    @ApiResponse(responseCode = "404", description = "개인문의답변을 찾을 수 없음")
    public ResponseEntity<Void> delete(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber) {
        individualInquiryAnswerService.delete(inquiryNumber);
        return ResponseEntity.noContent().build();
    }
}
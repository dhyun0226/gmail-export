package com.denall.voc.mapper;

import com.denall.voc.entity.IndividualInquiryAnswer;
import com.denall.voc.model.table.IndividualInquiryAnswerDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IndividualInquiryAnswerStruct extends StructMapper<IndividualInquiryAnswer, IndividualInquiryAnswerDto> {
}
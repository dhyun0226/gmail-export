package com.denall.voc.entity;
import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_NTFY_M")
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@EntityListeners(AuditingEntityListener.class)
public class Notice extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "NTFY_NO")
    private Long noticeNumber;

    @Column(name = "SVC_CTG_CD", length = 12, nullable = false)
    private String serviceCategoryCode;

    @Column(name = "OPEN_YN", nullable = false, length = 1)
    private String openYn;

    @Column(name = "TOP_FXD_YN", nullable = false, length = 1)
    private String topFixedYn;

    @Column(name = "NTFY_TTL", nullable = false, length = 100)
    private String noticeTitle;

    @Column(name = "RGSTR_CPRN_CD", nullable = false, length = 3)
    private String registererCorporationCode;

    @Column(name = "RGSTR_DEPT_CD", nullable = false, length = 30)
    private String registererDepartmentCode;

    @Column(name = "RGSTR_EMP_NO", nullable = false, length = 60)
    private String registererEmployeeNumber;

    @Column(name = "NTFY_RGST_DTM", nullable = false)
    private LocalDateTime noticeRegistrationDatetime;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    @Column(name = "NTFY_INQ_CNT")
    private Short inquiryCount;


    // 비즈니스 메소드
    public void updateNotice(String noticeTitle, String serviceCategoryCode,
                             String openYn, String topFixedYn) {
        this.noticeTitle = noticeTitle;
        this.serviceCategoryCode = serviceCategoryCode;
        this.openYn = openYn;
        this.topFixedYn = topFixedYn;
    }

    public void incrementInquiryCount() {
        this.inquiryCount = this.inquiryCount == null ? 1 : (short)(this.inquiryCount + 1);
    }

    public void attachFile(String fileId) {
        this.fileId = fileId;
    }

    public void detachFile(){
        this.fileId = null;
    }

    public void updateRegisterer(String registererCorporationCode,
                                 String registererDepartmentCode,
                                 String registererEmployeeNumber) {
        this.registererCorporationCode = registererCorporationCode;
        this.registererDepartmentCode = registererDepartmentCode;
        this.registererEmployeeNumber = registererEmployeeNumber;
    }
    
}
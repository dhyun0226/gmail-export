package com.denall.voc.mapper;

import com.denall.voc.entity.Qna;
import com.denall.voc.model.event.VocClientDto;
import com.denall.voc.model.response.QnaResponseDto;
import com.denall.voc.model.table.QnaDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface QnaStruct extends StructMapper<Qna, QnaDto> {
    @Override
    @Mapping(target = "qnaContent", ignore = true)
    QnaDto toDto(Qna qna);
    
    @Override
    Qna toEntity(QnaDto dto);
    
    @Mapping(source = "qnaNumber", target = "denallVocNumber")
    @Mapping(source = "serviceCategoryCode", target = "serviceCategoryCode")
    @Mapping(source = "itemCode", target = "itemCode")
    @Mapping(source = "writerMemberId", target = "registererMemberId")
    @Mapping(source = "qnaTitle", target = "vocTitle")
    @Mapping(target = "vocContent", ignore = true)
    @Mapping(source = "fileId", target = "fileId")
    @Mapping(source = "qnaRegistrationDatetime", target = "vocRegistrationDateTime")
    @Mapping(target = "vocStateCode", constant = "01") // 기본값 설정
    @Mapping(target = "deleteYesOrNo", constant = "N") // 기본값 설정
    @Mapping(target = "vocRegistererDivisionCode", expression = "java(determineRegistererDivisionCode(qna))") // 기본값 설정 (QnA는 회원만 작성 가능하다고 가정)
    VocClientDto toVocDto(Qna qna);

    default String determineRegistererDivisionCode(Qna qna) {
        return "Y".equals(qna.getWriterMemberId()) ? "01" : "02";  // 예시: 01=회원, 02=비회원
    }

    @Mapping(target = "qnaContent", ignore = true)
    QnaResponseDto toResponseDto(Qna qna);

}
package com.denall.voc.config;

import com.denall.voc.exception.BusinessException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;
import feign.codec.Decoder;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;

public class CustomSuccessResponseDecoder implements Decoder {

    private final Decoder delegate;

    public CustomSuccessResponseDecoder(Decoder delegate) {
        this.delegate = delegate;
    }

    @Override
    public Object decode(Response response, Type type) throws IOException, DecodeException, FeignException {
        // 성공 응답이지만 에러 코드 확인이 필요한 경우
        if (response.status() >= 200 && response.status() < 300) {
            // 응답 본문이 비어있는 경우 체크 수정
            Response.Body body = response.body();
            if (body == null) {
                // body가 null인 경우 바로 delegate에 위임
                return delegate.decode(response, type);
            }

            // length()가 null을 반환할 수 있으므로 null 체크 추가
            Integer contentLength = body.length();
            if (contentLength != null && contentLength == 0) {
                // 빈 응답인 경우 바로 delegate에 위임
                return delegate.decode(response, type);
            }

            try {
                // 응답 본문 복사
                byte[] bodyData = Util.toByteArray(body.asInputStream());
                String responseBody = new String(bodyData, StandardCharsets.UTF_8);

                // 응답 본문이 비어있는 경우 체크
                if (responseBody == null || responseBody.trim().isEmpty()) {
                    // 본문 복원
                    Response newResponse = response.toBuilder()
                            .body(bodyData)
                            .build();
                    return delegate.decode(newResponse, type);
                }

                // 응답 본문이 JSON이고 에러 코드가 포함된 경우만 처리
                if (responseBody.trim().startsWith("{")) {
                    try {
                        ObjectMapper mapper = new ObjectMapper();
                        JsonNode rootNode = mapper.readTree(responseBody);

                        // 에러 코드 확인
                        if (rootNode.has("status") && rootNode.get("status").asInt() == 545) {
                            throw new BusinessException(rootNode.get("message").asText(), 545);
                        }
                    } catch (Exception e) {
                        // JSON 파싱 실패는 무시
                    }
                }

                // 본문 복원
                Response newResponse = response.toBuilder()
                        .body(bodyData)
                        .build();

                return delegate.decode(newResponse, type);
            } catch (IOException e) {
                throw new DecodeException(response.status(), "응답 본문 처리 중 오류 발생", response.request());
            }
        }

        return delegate.decode(response, type);
    }
}
package com.denall.voc.exception;

import lombok.Getter;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

@Getter
@SuppressWarnings("serial")
public class BusinessException extends RuntimeException {
    private final String messageCode;
    private final Object[] args;

    public BusinessException(String messageCode, Object... args) {
        this.messageCode = messageCode;
        this.args = args;
    }

    public String getLocalizedMessage(MessageSource messageSource) {
        return messageSource.getMessage(messageCode, args, LocaleContextHolder.getLocale());
    }
}
package com.denall.voc.model.response;

import com.denall.voc.annotation.Masked;
import com.denall.voc.model.txm.File;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "QnA 응답 DTO")
public class QnaResponseDto {

    @Schema(description = "QnA 번호", example = "1")
    private Long qnaNumber;


    @NotBlank
    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Masked(type = Masked.MaskingType.ID)
    @Schema(description = "작성자 회원 ID", example = "user123")
    private String writerMemberId;

    @Schema(description = "품목 코드", example = "ITM001")
    private String itemCode;

    @Schema(description = "공개 여부", example = "Y")
    private String openYn;

    @Schema(description = "QnA 제목", example = "제품 사용 문의드립니다")
    private String qnaTitle;

    @Schema(description = "QnA 내용", example = "제품을 사용하는 중 문제가 발생하였습니다. 어떻게 해결할 수 있을까요?")
    private String qnaContent;

    @Schema(description = "QnA 등록 일시", example = "2025-04-04T10:30:00")
    private LocalDateTime qnaRegistrationDatetime;

    @Schema(description = "파일 ID", example = "file123")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "답변 건수", example = "2")
    private Short answerCount;

    @Schema(description = "답변 목록")
    private List<QnaAnswerDetailResponseDto> answers;

    @Schema(description = "조회 건수", example = "157")
    private Short inquiryCount;

    @Schema(description = "처리 상태", example = "true")
    private Boolean processStatus;

    @Schema(description = "작성자확인", example = "true")
    private Boolean isWriter;


    public void setFileList(TxmFileListResponse txmFileListResponse) {
        this.fileList = txmFileListResponse.getData();
    }

}
package com.denall.voc.model.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ExternalApiDto {
    private String type;        // "notice" 또는 "event"
    private Long id;            // 게시글 번호
    private String title;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")// 제목
    private LocalDateTime createdAt; // 등록일시
    private String link;

    // software 채널일 때만 채워지는 추가 필드
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String categoryName;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String categoryCss;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String flagNew; // 등록일자 기준 일주일 이내인 경우 "Y" 또는 "N"

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String fileCnt; // 첨부파일 개수

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String memoCnt; // 담당자의 답변을 제외한 댓글 개수

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String qnaYn; // 답변여부 "Y" 또는 "N"
}
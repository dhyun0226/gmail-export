package com.denall.voc.controller;

import com.denall.voc.domain.NoticeService;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.NoticeRequestDto;
import com.denall.voc.model.response.NoticeResponseDto;
import com.denall.voc.model.table.NoticeDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notices")
@RequiredArgsConstructor
@Tag(name = "공지", description = "공지 API")
public class NoticeController {

    private final NoticeService noticeService;

    @Operation(summary = "공지 생성", description = "새로운 공지를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "공지 생성 성공",
            content = @Content(schema = @Schema(implementation = NoticeDto.class)))
    @PostMapping
    public ResponseEntity<NoticeDto> create(
            @Parameter(description = "공지 생성 정보", required = true)
            @Valid @RequestBody NoticeDto noticeDto) {
        NoticeDto createdNotice = noticeService.create(noticeDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdNotice);
    }

    @Operation(summary = "공지 조회", description = "ID로 공지를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "공지 조회 성공",
            content = @Content(schema = @Schema(implementation = NoticeDto.class)))
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @GetMapping("/{noticeNumber}")
    public ResponseEntity<NoticeResponseDto> get(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber,
            @RequestParam(required = false) String channelCode,
            @RequestParam(required = false) String serviceCategoryCode,
            @RequestHeader(value = "X-User-Role", required = false) String userRole) {
        NoticeResponseDto noticeResponseDto = noticeService.get(noticeNumber, channelCode, serviceCategoryCode, userRole);
        return ResponseEntity.ok(noticeResponseDto);
    }

    @Operation(summary = "공지 수정", description = "ID로 공지를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "공지 수정 성공",
            content = @Content(schema = @Schema(implementation = NoticeDto.class)))
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @PutMapping("/{noticeNumber}")
    public ResponseEntity<NoticeDto> update(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber,
            @Parameter(description = "공지 수정 정보", required = true)
            @Valid @RequestBody NoticeDto noticeDto) {
        NoticeDto updatedNotice = noticeService.update(noticeNumber, noticeDto);
        return ResponseEntity.ok(updatedNotice);
    }

    @Operation(summary = "공지 삭제", description = "ID로 공지를 삭제합니다.")
    @ApiResponse(responseCode = "200", description = "공지 삭제 성공")
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @DeleteMapping("/{noticeNumber}")
    public ResponseEntity<ResultDto<?>> delete(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber) {
        noticeService.delete(noticeNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }

    @Operation(summary = "상단 고정 공지 목록 조회", description = "상단 고정 공지 목록을 조회합니다.")
    @ApiResponse(responseCode = "200", description = "상단 고정 공지 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = NoticeDto.class)))
    @GetMapping("/top-fixed")
    public ResponseEntity<List<NoticeDto>> getTopFixedList() {
        List<NoticeDto> noticeDtoList = noticeService.getTopFixedList();
        return ResponseEntity.ok(noticeDtoList);
    }

    @Operation(summary = "공지 검색", description = "조건에 맞는 공지 목록을 검색합니다.")
    @ApiResponse(responseCode = "200", description = "공지 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping("/search")
    public ResponseEntity<ResultDto<NoticeResponseDto>> search(NoticeRequestDto requestDto) {
        ResultDto<NoticeResponseDto> result = noticeService.search(requestDto);
        return ResponseEntity.ok(result);
    }


}
package com.denall.voc.model.common;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CustomerInfoResponseDto {
    private Integer status;
    private String code;
    private String message;
    private Customer data;

    @Data
    public static class Customer {
        private String employeeNumber;
        private String    businessmanCustomerCode;
        private String    businessmanCustomerName;
        private String    customerHandPhoneNumber;
        private String    customerEmail;
        private String    customerRepresentativeName;
        private String    customerCategoryCode;
        private String    customerStatCode;
        private String    customerTelephoneNumber;
        private String    basicStreetAddress;
        private String    detailStreetAddress;
        private String    basicLotNumberAddress;
        private String    detailLotNumberAddress;
        private String    businessItemsName;
        private String    businessTypeName;
        private String    activeYesOrNo;
        private String    memberId;
    }

}


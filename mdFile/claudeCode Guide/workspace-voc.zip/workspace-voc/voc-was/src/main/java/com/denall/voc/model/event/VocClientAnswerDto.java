package com.denall.voc.model.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "개인문의 DTO")
public class VocClientAnswerDto extends BaseDto {

    @NotNull
    @Schema(description = "개인문의번호")
    private Long vocNumber;

    @NotNull
    @Schema(description = "VOC 답변 일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private LocalDateTime vocAnswerDateTime;

    @Size(max = 1000)
    @Schema(description = "VOC 답변 내용")
    private String vocAnswerContent;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "VOC 담당자 법인 코드")
    private String vocChargePersonCorporationCode;


    @NotBlank
    @Size(max = 30)
    @Schema(description = "VOC 담당자 부서 코드")
    private String vocChargePersonDepartmentCode;

    @Size(max = 60)
    @Schema(description = "VOC 담당자 사원 번호")
    private String vocChargePersonEmployeeNumber;

    @Size(max = 50)
    @Schema(description = "파일 ID")
    private String fileId;
}

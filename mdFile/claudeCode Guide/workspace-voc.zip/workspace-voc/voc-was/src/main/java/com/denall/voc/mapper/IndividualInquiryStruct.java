package com.denall.voc.mapper;

import com.denall.voc.entity.IndividualInquiry;
import com.denall.voc.model.event.VocClientDto;
import com.denall.voc.model.table.IndividualInquiryDto;
import org.mapstruct.*;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IndividualInquiryStruct extends StructMapper<IndividualInquiry, IndividualInquiryDto> {
    @Mapping(source = "individualInquiryNumber", target = "denallVocNumber")
    @Mapping(source = "serviceCategoryCode", target = "serviceCategoryCode")
    @Mapping(source = "itemCode", target = "itemCode")
    @Mapping(source = "writerMemberId", target = "registererMemberId")
    @Mapping(source = "vocWriterName", target = "vocCustomerName")
    @Mapping(source = "writerEmailAddress", target = "vocCustomerEmailAddress")
    @Mapping(source = "writerTelephoneNumber", target = "vocCustomerTelephoneNumber")
    @Mapping(source = "writerHandPhoneNumber", target = "vocCustomerHandPhoneNumber")
    @Mapping(source = "individualInquiryTitle", target = "vocTitle")
    @Mapping(source = "individualInquiryContent", target = "vocContent")
    @Mapping(source = "individualInformationCollectionTermsOfUseAgreementYesOrNo", target = "individualInformationCollectionTermsOfUseAgreementYesOrNo")
    @Mapping(source = "fileId", target = "fileId")
    @Mapping(source = "individualInquiryRegistrationDatetime", target = "vocRegistrationDateTime")
    @Mapping(target = "vocStateCode", constant = "01") // 기본값 설정
    @Mapping(target = "deleteYesOrNo", constant = "N") // 기본값 설정
    @Mapping(target = "vocRegistererDivisionCode", expression = "java(determineRegistererDivisionCode(individualInquiry))")
    VocClientDto toVocDto(IndividualInquiry individualInquiry);

    // 회원 여부에 따라 등록자 구분 코드 결정하는 default 메소드
    default String determineRegistererDivisionCode(IndividualInquiry individualInquiry) {
        return "Y".equals(individualInquiry.getMemberYn()) ? "01" : "02";  // 예시: 01=회원, 02=비회원
    }
}
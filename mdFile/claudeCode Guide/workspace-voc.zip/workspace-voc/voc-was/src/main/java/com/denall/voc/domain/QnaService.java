package com.denall.voc.domain;

import com.denall.voc.constant.TaskType;
import com.denall.voc.entity.Qna;
import com.denall.voc.entity.QnaContent;
import com.denall.voc.entity.QnaAnswerDetail;
import com.denall.voc.exception.BusinessException;
import com.denall.voc.feign.TxmServiceClient;
import com.denall.voc.feign.VocServiceClient;
import com.denall.voc.mapper.QnaStruct;
import com.denall.voc.model.base.ResultDto;
import com.denall.voc.model.request.QnaRequestDto;
import com.denall.voc.model.response.QnaAnswerDetailResponseDto;
import com.denall.voc.model.response.QnaResponseDto;
import com.denall.voc.model.table.QnaDto;
import com.denall.voc.model.txm.TxmFileListResponse;
import com.denall.voc.model.txm.TxmFileSaveRequest;
import com.denall.voc.model.txm.TxmFileSaveResponse;
import com.denall.voc.repository.QnaAnswerDetailRepository;
import com.denall.voc.repository.QnaContentRepository;
import com.denall.voc.repository.QnaQueryRepository;
import com.denall.voc.repository.QnaRepository;
import com.denall.voc.util.FileUtils;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QnaService {

    private final QnaRepository qnaRepository;
    private final QnaContentRepository qnaContentRepository;
    private final QnaQueryRepository qnaQueryRepository;
    private final QnaAnswerDetailRepository qnaAnswerDetailRepository;
    private final QnaStruct qnaStruct;
    private final TxmServiceClient txmServiceClient;
    private final ServiceChargePersonService serviceChargePersonService;

    /**
     * QnA 생성
     *
     * @param qnaDto QnA DTO
     * @return 생성된 QnA DTO
     */
    @Transactional
    public QnaDto create(QnaDto qnaDto) {
        // QnA 등록 일시 설정
        qnaDto.setQnaRegistrationDatetime(LocalDateTime.now());
        qnaDto.initInquiryCount();

        // DTO를 엔티티로 변환 후 저장
        Qna qnaEntity = qnaStruct.toEntity(qnaDto);
        Qna savedEntity = qnaRepository.save(qnaEntity);
        
        // QnaContent 생성 및 저장
        QnaContent qnaContent = QnaContent.builder()
                .qnaNo(savedEntity.getQnaNumber())
                .qnaContent(qnaDto.getQnaContent())
                .build();
        qnaContentRepository.save(qnaContent);

        // 파일 리스트 처리
        if (qnaDto.getFileList() != null && !qnaDto.getFileList().isEmpty() && savedEntity.getQnaNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtils.prepareQnaFiles(
                    qnaDto.getFileList(),
                    savedEntity.getQnaNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);
            savedEntity.setFileId(savedEntity.getQnaNumber().toString());
            qnaRepository.save(savedEntity);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }
        }

//        vocServiceClient.create(qnaStruct.toVocDto(savedEntity));

        // 저장된 엔티티를 DTO로 변환하여 반환
        QnaDto result = qnaStruct.toDto(savedEntity);
        // Content 별도 조회하여 설정
        qnaContent = qnaContentRepository.findById(savedEntity.getQnaNumber()).orElse(null);
        if (qnaContent != null) {
            result.setQnaContent(qnaContent.getQnaContent());
        }
        return result;
    }
    /**
     * QnA 조회
     *
     * @param qnaNumber QnA 번호
     * @return QnA DTO
     */
    @Transactional(readOnly = true)
    public QnaDto get(Long qnaNumber) {
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));
        QnaDto result = qnaStruct.toDto(qna);
        // Content 별도 조회하여 설정
        QnaContent qnaContent = qnaContentRepository.findById(qnaNumber).orElse(null);
        if (qnaContent != null) {
            result.setQnaContent(qnaContent.getQnaContent());
        }
        return result;
    }

    /**
     * QnA 및 답변 조회
     *
     * @param qnaNumber QnA 번호
     * @return QnA 및 답변 DTO
     */
    @Transactional(readOnly = true)
    public QnaResponseDto getQnaWithAnswers(Long qnaNumber, String channelCode, String serviceCategoryCode, String userId, String corporationCode) {
        QnaResponseDto responseDto = qnaQueryRepository.findQnaWithAnswers(qnaNumber, channelCode, serviceCategoryCode);

        if (responseDto == null) {
            throw new BusinessException("error.qna.not.found");
        }

        if(corporationCode == null) {
            qnaRepository.incrementInquiryCount(qnaNumber);
        }

        if (StringUtils.isNotEmpty(responseDto.getFileId())) {
            TxmFileListResponse txmFileListResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.QNA,responseDto.getQnaNumber().toString()));

            if (txmFileListResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            responseDto.setFileList(txmFileListResponse);
        }

        responseDto.getAnswers().forEach(answer -> {
            if (StringUtils.isNotEmpty(answer.getAnswerFileId())) {
                TxmFileListResponse answerFileResponse = txmServiceClient.getFileList(FileUtils.buildRequest(TaskType.QNA, answer.getAnswerFileId()));
                if (answerFileResponse.getStatus() != 200) {
                    throw new BusinessException("error.file.found");
                }
                answer.setFileList(answerFileResponse);
            }
        });


        // 글쓴이 확인 로직
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));
        String writerId = qna.getWriterMemberId();
        if (writerId == null) {
            throw new BusinessException("error.qna.not.writer");
        }
        responseDto.setIsWriter(writerId.equals(userId));

        return responseDto;
    }

    /**
     * QnA 수정
     *
     * @param qnaNumber QnA 번호
     * @param qnaDto QnA DTO
     * @return 수정된 QnA DTO
     */

    @Transactional
    public QnaDto update(Long qnaNumber, QnaDto qnaDto) {
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));

        qna.updateQna(
                qnaDto.getQnaTitle(),
                qnaDto.getOpenYn(),
                qnaDto.getItemCode(),
                qnaDto.getServiceCategoryCode()
        );
        
        // QnaContent 수정
        QnaContent qnaContent = qnaContentRepository.findById(qnaNumber)
                .orElse(QnaContent.builder()
                        .qnaNo(qnaNumber)
                        .qnaContent(qnaDto.getQnaContent())
                        .build());
        
        if (qnaContent.getQnaNo() != null) {
            qnaContent.setQnaContent(qnaDto.getQnaContent());
        }
        qnaContentRepository.save(qnaContent);

        Qna savedQna = qnaRepository.save(qna);

        // 파일 처리 - FileUtils의 processFiles 메서드 사용
        FileUtils.processFiles(
                qnaDto.getFileList(),
                TaskType.QNA,
                savedQna.getQnaNumber().toString(),
                txmServiceClient,
                fileId -> {
                    savedQna.setFileId(fileId);
                    qnaRepository.save(savedQna);
                }
        );

        QnaDto result = qnaStruct.toDto(savedQna);
        // Content 별도 조회하여 설정
        qnaContent = qnaContentRepository.findById(savedQna.getQnaNumber()).orElse(null);
        if (qnaContent != null) {
            result.setQnaContent(qnaContent.getQnaContent());
        }
        return result;
    }

    /**
     * QnA 삭제
     *
     * @param qnaNumber QnA 번호
     */
    @Transactional
    public void delete(Long qnaNumber) {
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));

        // QnA 답변 먼저 삭제
        List<QnaAnswerDetail> answers = qnaAnswerDetailRepository.findByIdQnaNumber(qnaNumber);
        qnaAnswerDetailRepository.deleteAll(answers);

        // QnaContent 삭제
        qnaContentRepository.deleteById(qnaNumber);

        qnaRepository.delete(qna);
    }

    /**
     * 회원별 QnA 목록 조회
     *
     * @param memberId 회원 ID
     * @return QnA DTO 목록
     */
    @Transactional(readOnly = true)
    public List<QnaDto> getListByMember(String memberId) {
        List<Qna> qnaList = qnaRepository.findByWriterMemberId(memberId);
        return qnaStruct.toDtoList(qnaList);
    }

    /**
     * QnA 목록 검색
     *
     * @param requestDto QnA 검색 조건
     * @return 검색 결과 및 총 건수
     */
    @Transactional(readOnly = true)
    public ResultDto<QnaResponseDto> search( QnaRequestDto requestDto,
                                            String processStatus) {
        // QueryRepository 호출
        List<QnaResponseDto> qnaList = qnaQueryRepository.searchQnas(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getPageable(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getOpenYn(),
                processStatus,
                requestDto.getServiceCategoryCode()
        );

        // 검색 결과가 없을 경우 예외 처리
//        if (qnaList.isEmpty()) {
//            throw new BusinessException("error.qna.not.found");
//        }

        qnaList.forEach(dto ->
                dto.setProcessStatus(
                        qnaAnswerDetailRepository
                                .existsByIdQnaNumberAndAnswererEmployeeNumberIsNotNull(
                                        dto.getQnaNumber()
                                )
                )
        );


        long totalCount = qnaQueryRepository.countQnas(
                requestDto.getSearchType(),
                requestDto.getKeyword(),
                requestDto.getChannelCode(),
                requestDto.getFromDate(),
                requestDto.getToDate(),
                requestDto.getOpenYn(),
                processStatus,
                requestDto.getServiceCategoryCode()
                );

        return new ResultDto<>(qnaList, totalCount);
    }

    public QnaResponseDto isQnaWriter(String userId, Long qnaNumber) {
        Qna qna = qnaRepository.findById(qnaNumber)
                .orElseThrow(() -> new BusinessException("qna.notFound", qnaNumber));

        String writerId = qna.getWriterMemberId();

        if (writerId == null) {
            throw new BusinessException("error.qna.not.writer");
        }

        QnaResponseDto qnsResponseDto = qnaStruct.toResponseDto(qna);
        qnsResponseDto.setIsWriter(writerId.equals(userId));

        return qnsResponseDto;
    }


    /**
     * QnA 검색
     *
     * @param requestDto QnA 검색 조건
     * @return 검색 결과 및 총 건수
     */
//    @Transactional(readOnly = true)
//    public ResultDto<QnaDto> search(QnaRequestDto requestDto) {
//        Pageable pageable = PageRequest.of(
//                requestDto.getPageNo() != null ? requestDto.getPageNo() - 1 : 0,
//                requestDto.getPageSize() != null ? requestDto.getPageSize() : 10);
//
//        Page<QnaDto> qnaPage = qnaMapper.search(requestDto, pageable);
//
//        return new ResultDto<>(qnaPage.getContent(), qnaPage.getTotalElements());
//    }
}
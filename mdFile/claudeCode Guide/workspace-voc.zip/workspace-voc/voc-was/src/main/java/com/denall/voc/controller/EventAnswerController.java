package com.denall.voc.controller;

import com.denall.voc.domain.EventAnswerService;
import com.denall.voc.model.table.EventAnswerDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/event-answers")
@RequiredArgsConstructor
@Tag(name = "이벤트 답변", description = "이벤트 답변(댓글) 관리 API")
public class EventAnswerController {

    private final EventAnswerService eventAnswerService;

    @PostMapping
    @Operation(summary = "이벤트 답변 생성", description = "이벤트에 새로운 답변(댓글)을 생성합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "이벤트 답변 생성 성공",
                    content = @Content(schema = @Schema(implementation = EventAnswerDto.class))),
            @ApiResponse(responseCode = "400", description = "잘못된 요청"),
            @ApiResponse(responseCode = "404", description = "해당 이벤트를 찾을 수 없음")
    })
    public ResponseEntity<EventAnswerDto> createEventAnswer(
            @Parameter(description = "사용자 ID", required = true, example = "user123")
            @RequestHeader(name = "X-USER-ID") String userId,
            @Parameter(description = "이벤트 답변 정보", required = true)
            @RequestBody EventAnswerDto eventAnswerDto) {
        eventAnswerDto.setParticipantMemberId(userId);
        EventAnswerDto createdEventAnswer = eventAnswerService.create(eventAnswerDto);
        return new ResponseEntity<>(createdEventAnswer, HttpStatus.CREATED);
    }

    @DeleteMapping
    @Operation(summary = "이벤트 답변 삭제", description = "이벤트 답변의 삭제 여부를 업데이트합니다. (소프트 삭제)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "이벤트 답변 삭제 성공"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청"),
            @ApiResponse(responseCode = "404", description = "해당 이벤트 답변을 찾을 수 없음")
    })
    public ResponseEntity<Void> deleteEventAnswer(
            @Parameter(description = "삭제할 이벤트 답변 정보", required = true)
            @RequestBody EventAnswerDto eventAnswerDto) {
        eventAnswerService.updateDeleteYesOrNo(eventAnswerDto);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
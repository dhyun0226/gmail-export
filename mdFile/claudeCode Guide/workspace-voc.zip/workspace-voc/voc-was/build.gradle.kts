plugins {
	id("java")
	id("java-library")
	id("jacoco")
	id("org.springframework.boot") version "3.3.6"
    id("io.spring.dependency-management") version "1.1.4"
}

group = "com.osstem"
version = "1.0.0"

java {
	sourceCompatibility = JavaVersion.VERSION_21
}

configurations {
	compileOnly {
		extendsFrom(configurations.annotationProcessor.get())
	}
}

repositories {
	mavenCentral()
	maven {
		isAllowInsecureProtocol = true
		credentials {
			username = "${property("nexusUser")}"
			password = "${property("nexusPass")}"
		}
		url = uri("${property("nexusPublicRepoURL")}")
	}
}

tasks.getByName("bootJar") {
	enabled = true
}

tasks.getByName("jar") {
	enabled = false
}

dependencies {
    implementation("com.osstem:core:2.0.9")
    implementation("com.osstem:storage-db:2.0.0")
    implementation("com.osstem:logging:2.0.0")

	implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("org.mybatis.spring.boot:mybatis-spring-boot-starter:${property("mybatisSpringVersion")}")
	implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:${property("swaggerVersion")}")
	compileOnly("org.projectlombok:lombok")
	runtimeOnly("org.mariadb.jdbc:mariadb-java-client")
	annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
	annotationProcessor("org.projectlombok:lombok")
	testImplementation("org.springframework.boot:spring-boot-starter-test")

	//JPA querydsl
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	implementation("com.querydsl:querydsl-jpa:5.0.0:jakarta")
	annotationProcessor("com.querydsl:querydsl-apt:5.0.0:jakarta")
	annotationProcessor("jakarta.annotation:jakarta.annotation-api")
	annotationProcessor("jakarta.persistence:jakarta.persistence-api")

	//Mapstruct
	implementation("org.mapstruct:mapstruct:1.6.2")
	annotationProcessor("org.mapstruct:mapstruct-processor:1.6.2")
	annotationProcessor("org.projectlombok:lombok-mapstruct-binding:0.2.0")

	//Feign
	implementation("org.springframework.cloud:spring-cloud-starter-openfeign")


}

dependencyManagement {
    imports {
        mavenBom("org.springframework.cloud:spring-cloud-dependencies:${property("springCloudVersion")}")
    }
}

tasks.withType<Test> {
    useJUnitPlatform()
}

with(extensions.getByType(JacocoPluginExtension::class.java)) {
    toolVersion = "0.8.11"
}
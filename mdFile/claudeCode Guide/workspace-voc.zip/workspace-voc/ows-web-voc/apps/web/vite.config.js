import path from 'node:path';
import ows from '@ows/vite-plugin-web';
import ssl from '@vitejs/plugin-basic-ssl';
import vue from '@vitejs/plugin-vue';
import { defineConfig } from 'vite';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    ssl(),
    ows(),
  ],
  resolve: {
    alias: [
      {
        find: '@',
        replacement: path.resolve(__dirname, '../../packages/main/src'),
      },
    ],
  },
  server: {
    proxy: {
      '/api/sal': {
        target: 'http://local.osstem.com:8150',
        rewrite: path => path.replace(/^\/api/, ''),
        changeOrigin: true,
      },

      '/api/voc': {
        target: 'http://local.osstem.com:8201',
        rewrite: path => path.replace(/^\/api/, ''),
        changeOrigin: true,
      },
      '/api/com': {
        target: 'http://dev-ow.osstem.com:7001',
         changeOrigin: true,
       },

      // '/api/auth': {
      //   target: 'http://dev-ow.osstem.com:7001',
      //   // rewrite: path => path.replace(/^\/api/, ''),
      //   changeOrigin: true,
      // },
    },
  },
});

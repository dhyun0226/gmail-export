/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** 앱 이름 */
  VITE_APP_NAME: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

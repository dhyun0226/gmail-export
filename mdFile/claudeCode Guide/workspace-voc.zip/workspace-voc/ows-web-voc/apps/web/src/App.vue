<script setup>
import { useMenu } from '@ows/core';
import { useOwAlert } from "@ows/ui";
// 개발 & 할 일 관리에서 메뉴 설정 후 삭제
const { setData } = useMenu();
const { close, isOpen, message, alterType, title, target } = useOwAlert();
setData([
  {
    text: '메인',
    meta: {
      color: '#34A853',
    },
    path: '/UI-TSK-RRR-101',
  },
  {
    text: '오늘',
    meta: {
      color: '#34A853',
    },
    path: '/UI-TSK-RRR-102',
  },
  {
    text: '실행계획',
    meta: {
      color: '#34A853',
    },
    path: '/UI-TSK-RRR-103',
  },
  {
    text: 'VOC',
    meta: {
      color: '#34A853',
    },
    children: [
      {
        text: '접수',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-002',
      },
      {
        text: '처리대상',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-003',
        // children: [
        //   {
        //     text: '전체',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-003',
        //   },
        //   {
        //     text: '진행현황',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-004',
        //   },
        // ],
      },
      {
        text: '처리실적',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-0012',
        // children: [
        //   {
        //     text: 'VOC전체',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-0012',
        //   },
        //   {
        //     text: '품목',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-004',
        //   },
        //   {
        //     text: '지역',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-004',
        //   },
        //   {
        //     text: '인원',
        //     meta: {
        //       color: '#F59A23',
        //     },
        //     path: '/UI-SAL-VOC-004',
        //   },
        // ],
      },
    ],
  },
  {
    text: '고객센터',
    meta: {
      color: '#34A853',
    },
    children: [
      {
        text: '공지사항',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-009',
      },
      {
        text: 'FAQ',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-010',
      },
      {
        text: '이벤트',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-011',
      },
      {
        text: '문의',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-013',
      },
      // {
      //   text: '1:1문의',
      //   meta: {
      //     color: '#F59A23',
      //   },
      //   path: '/UI-SAL-VOC-014',
      // },
    ],
  },
  {
    text: '일정',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-TSK-RQS-100',
  },
  {
    text: '업무요청',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-TSK-RQS-101',
  },
  {
    text: '받은요청',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-TSK-RCV-101',
  },
  {
    text: '회의',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-TSK-MET-401',
  },
  {
    text: '점검',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-TSK-SCH-401',
  },
  {
    text: '결재',
    meta: {
      color: '#F59A23',
    },
    path: '/UI-EAP-MBX-001',
  },
  {
    text: '할일관리',
    meta: {
      color: '#A56AC1',
    },
    path: '/UI-EAP-MBX-002',
  },
  {
    text: '기준정보',
    meta: {
      color: '#A56AC1',
    },
    children: [{
      text: '담당자배정기준',
      meta: {
        color: '#F59A23',
      },
      path: '/UI-SAL-VOC-005',
    },
      {
        text: 'VOC담당자배정기준',
        meta: {
          color: '#F59A23',
        },
        path: '/UI-SAL-VOC-006',
      },
    ]
  },
]);
</script>

<template>
  <OwApp />
  <OwAlert
      v-if="isOpen"
      :open="isOpen"
      :alert-type="alterType"
      :title="title"
      :message="message"
      :on-cancel="close"
      :on-ok="close"
      :target="target"
  />
</template>

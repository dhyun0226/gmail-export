/**
 * 주의: 이 패키지는 주로 개발 단계에서의 효율적인 개발을 위해 설계되었습니다.
 *
 * 프로덕션 환경에서의 사용은 불가합니다.
 *
 * 프로덕션 환경에서는 '/packages/main/dist'만 사용됩니다.
 */
import { createApp } from 'vue';
import './style.css';

import Core from '@ows/core';
import UI from '@ows/ui';
import EAP from '@ows/eap';
import TSK from '@ows/tsk';

import App from './App.vue';

import Main from '@/index';

createApp(App)
  .use(Core, {
    modules: [
      UI,
      EAP,
      TSK,
      Main,
    ],
  }).mount('#app');

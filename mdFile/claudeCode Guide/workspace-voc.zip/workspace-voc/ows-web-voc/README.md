# Ows Starter Templates

## 소개

이 프로젝트는 Vue 3를 사용하여 개발을 시작하기 위한 기본 템플릿입니다.

프로젝트 시작을 빠르게 할 수 있도록 구성되어 있으며, 주요 라이브러리 및 도구들을 포함하고 있습니다.

## 주요 기능

- **Vue 3:**
  - 최신 버전의 Vue.js를 사용하여 성능 향상 및 새로운 기능 활용

- **Vite 4:**
  - 빠른 개발 환경을 제공하는 Vite 빌드 도구를 사용하여 효율적인 개발 프로세스

- **Vue Router 4:**
  - 페이지 간 라우팅을 구현하는 Vue Router를 통한 깔끔한 네비게이션 관리

- **Pinia:**
  - 상태 관리를 위한 Pinia를 활용하여 애플리케이션의 전역 상태 효과적으로 관리

- **Bootstrap, Bootstrap Icons, BootstrapVueNext:**
  - 부트스트랩을 활용하여 반응형 및 PC, 모바일 디자인 구현

- **DevExtreme:**
  - 강력한 UI 컴포넌트 및 차트를 제공하는 DevExtreme 활용

- **@vueuse:**
  - 다양한 유틸리티 함수 및 훅을 제공하는 @vueuse 라이브러리 활용

- **SCSS:**
  - 스타일시트 작성을 위한 SCSS 사용

- **ESLint 및 Prettier:**
  - 정적 분석을 위한 ESLint와 코드 스타일 통일을 위한 Prettier를 도입하여 코드 품질 향상

## 시작하기

이 프로젝트를 사용하여 업무 프로젝트를 시작하기 위해서는 다음 단계를 따라주세요.

1. [starter](http://gitlab.osstem.com/ows-web/starter.git) 저장소를 자신의 업무 그룹으로 [fork](http://gitlab.osstem.com/ows-web/starter/forks/new) 합니다.

    ```text
    `포크`는 프로젝트의 복사본입니다.
    저장소를 `포크`하면 원래 프로젝트에 영향을 주지 않고 변경할 수 있습니다.
    ```

2. `포크`한 프로젝트의 설정을 변경합니다.

    1. **Settings > General > Advanced settings > Rename repository > Proejct name**을 `starter`에서 `ows-web-[업무코드]`로 변경합니다.

    2. **Settings > General > Advanced settings > Rename repository > Path**를 `starter`에서 `ows-web-[업무코드]`로 변경합니다.

3. `포크`한 프로젝트를 로컬 환경으로 `클론`합니다.

    ```pwsh
    git clone http://gitlab.osstem.com/ows-web-our-project/ows-web-our-project.git
    ```

4. 프로젝트 디렉토리로 이동합니다.

    ```pwsh
    cd ows-web-our-project
    ```

5. 원본 저장소를 `upstream remote로` 추가합니다. (이는 원본 프로젝트의 최신 변경 사항을 가져오기 위해 필요한 설정입니다.)

    ```pwsh
    git remote add upstream http://gitlab.osstem.com/ows-web/starter.git
    ```

6. 텍스트 편집기로 `package.json`을 엽니다.

    ```pwsh
    code packages/main/package.json
    ```

7. `name` 변경

    ```json
    {
      "name": "@ows/your-project"
      // 나머지 package.json 속성들...
    }
    ```

8. 의존성 패키지를 설치합니다.

    ```pwsh
    npm install
    ```

9. 로컬 서버를 실행합니다.

    ```pwsh
    npm run dev
    ```

## 원본 프로젝트 업데이트 가이드

1. 원본 프로젝트의 최신 변경 사항을 가져오려면 다음 명령어를 실행합니다.

    ```pwsh
    git fetch upstream
    ```

2. 가져온 최신 변경 사항을 현재 브랜치에 병합합니다.

    ```pwsh
    git merge upstream/master
    ```

3. 병합이 완료되면 변경 사항을 로컬 브랜치에서 작업하고, 이를 포크한 원격 저장소로 푸시할 수 있습니다.

    ```pwsh
    git push origin master
    ```

    이제 포크한 프로젝트를 사용하면서 필요한 변경 사항을 추가하고, 원본 프로젝트의 업데이트를 손쉽게 받아올 수 있습니다.

## 프로젝트 빌드 및 배포 가이드

이 프로젝트는 `Vite`를 사용하여 빌드되며, 아래는 프로젝트를 빌드하고 실행하는 방법에 대한 가이드입니다.

1. 프로젝트 루트 디렉토리로 이동합니다.

    ```pwsh
    cd ows-web-our-project
    ```

2. 의존성 패키지를 설치합니다.

    ```pwsh
    npm install
    ```

3. 프로젝트를 빌드하고 미리보기로 실행하여 테스트합니다.

    ```pwsh
    npm run build && npm run preview
    ```

4. 프로덕션 빌드를 위해 `packages/main` 디렉토리로 이동합니다.

    ```pwsh
    cd packages/main
    ```

5. 규칙에 따라 버전을 명시합니다.

    `SemVer(Semantic Versioning)`으로 세 가지로 나누어 정의합니다.

    1. `MAJOR`(주 버전)
        - 호환되지 않는 변경사항이 있을 때 증가합니다.
        - 기존 API의 변경, 큰 기능 추가, 호환되지 않는 변경사항 등이 해당됩니다.
        - **MAJOR** 버전이 변경되면 하위 버전의 **MINOR**, **PATCH**는 0으로 초기화됩니다.

    2. `MINOR`(부 버전)
        - 기존 기능에 대한 호환되는 새로운 기능이 추가되었을 때 증가합니다.
        - 기존 API와의 호환성을 유지하면서 기능이 추가되는 경우에 사용합니다.
        - **MINOR** 버전이 변경되면 **MAJOR**는 그대로 유지, **PATCH**는 0으로 초기화됩니다.

    3. `PATCH`(수정 버전)
        - 기존 기능에 대한 버그 수정이나 작은 개선이 이루어졌을 때 증가합니다.
        - 기존 기능의 작은 수정이나 개선사항을 반영합니다.
        - **PATCH** 버전이 변경되면 **MAJOR**, **MINOR**는 그대로 유지됩니다.

    ```pwsh
    npm version major

    또는

    npm version minor

    또는

    npm version patch
    ```

6. 프로덕션 빌드를 생성합니다.

    ```pwsh
    npm run build
    ```

    빌드된 파일은 `dist` 디렉토리에 생성됩니다.

7. `npm`에 패키지를 배포합니다.

    ```pwsh
    npm publish
    ```

## 프로젝트 디렉토리 구조

```txt
- apps/
    - docs/
    - web/
- packages/
    - main/
      - src/
        - assets/
        - components/
        - composables/
        - i18n/
        - pages/
        - scss/
        - utils/
```

### apps/docs

- `Vue.js` 기반의 정적 사이트 생성기인 `vitepress`로 사이트를 생성합니다.
- 마크다운을 사용하여 문서화를 간편하게 작성하고 호스팅합니다.
- 코드 블록의 라이브 데모 등을 제공하여 효과적으로 문서를 관리, 공유할 수 있습니다.

### apps/web

- `packages/main`에서 작성한 패키지를 Vite로 실행하여 웹 사이트를 확인할 수 있습니다.

### packages/main/src/assets/

- 정적 파일 및 이미지 자원들을 저장하는 디렉토리입니다.
- 이미지, 폰트 등의 정적인 자원을 보관하는 용도로 사용됩니다.
- 주로 **images/**, **fonts/** 등과 같은 하위 디렉토리를 포함할 수 있습니다.

### packages/main/src/components/

- Vue 컴포넌트들을 저장하는 디렉토리입니다.
- 프로젝트에서 사용되는 각각의 재사용 가능한 컴포넌트들을 여기에 위치시킵니다.
- 전역 컴포넌트로 등록한 컴포넌트들은 `./exports/index.js`에 등록합니다.

### packages/main/src/composables/

- `Composition API`를 사용하여 만든 로직들을 저장하는 디렉토리입니다.
- 상태 관리를 위한 `Pinia`도 포함할 수 있습니다.
- 로직이나 훅을 구성하는 파일들을 포함할 수 있습니다.

### packages/main/src/messages/

- `Vue-I18n`의 메시지를 저장하는 디렉토리입니다.

### packages/main/src/pages/

- `Vue Router`에서 사용되는 페이지 컴포넌트를 저장하는 디렉토리입니다.
- 각각의 페이지에 해당하는 `Vue` 파일들이 위치합니다.

### packages/main/src/scss/

- SCSS(Sass) 파일들을 저장하는 디렉토리입니다.
- 주로 스타일 관련 파일들이 위치하며, 프로젝트의 전반적인 스타일링이나 변수, 믹스인을 정의합니다.
- **`styles.module.scss`로 설정하여 `CSS Module`로 사용해야 합니다.**

### packages/main/src/utils/

- 프로젝트 내부에서 사용되는 유틸리티 함수들이나 헬퍼 함수들을 저장하는 디렉토리입니다.
- 재사용 가능한 함수들을 모아두어 코드의 중복을 방지하고 유지보수성을 높이는 데 사용됩니다.
- 보통 상태 관리를 하지 않는(비 상태 관리) 함수들을 `utils`로 생성합니다.

## 의존성 설치 가이드

### Core 설치 또는 업그레이드

```pwsh
# 특정 버전으로 업그레이드
npm install @ows/core@^1.8.5

# 최신 버전으로 업그레이드
npm install @ows/core@latest
```

### UI 설치 또는 업그레이드

```pwsh
# 특정 버전으로 업그레이드
npm install @ows/ui@^1.8.5

# 최신 버전으로 업그레이드
npm install @ows/ui@latest
```

### 기타 의존성 설치

```-D``` 키워드를 이용하여 ```devDependencies```로 설치합니다.

```pwsh
npm install -D <pkgname>
```

## 프로젝트 기여 및 문제 발생 가이드

이 프로젝트에 기여하거나 문제를 신고하는 방법에 대한 안내입니다.

### 기여

1. 이 저장소를 [Fork](http://gitlab.osstem.com/ows-web/starter/forks/new)합니다.
2. 새로운 브랜치를 생성합니다.

    ```pwsh
    git checkbout -b feature/new-feature
    ```

3. 변경 사항을 커밋합니다.

    ```pwsh
    git commit -m 'Add New Feature'
    ```

4. 변경 사항을 원격 저장소로 푸시합니다.

    ```pwsh
    git push origin feature/new-feature
    ```

5. `Merge Request`를 생성합니다.

### 문제 발생

이 프로젝트 사용 중 문제가 발생하면, 다음 단계를 따라 문제를 제출해주세요.

1. [Issues](http://gitlab.osstem.com/ows-web/starter/issues) 탭에서 [New Issue](http://gitlab.osstem.com/ows-web/starter/issues/new) 버튼을 클릭하여 새로운 문제를 작성해주세요.

2. 문제에 대한 제목과 설명을 명확하게 작성해주세요.

3. 발생한 문제를 재현할 수 있는 단계나 예제 코드를 포함해주세요.

4. 버그 리포트의 경우, 발생한 환경(node version, npm version 등)을 포함해주세요.

5. 관련 스크린샷이나 로그를 함께 첨부하면 도움이 됩니다.

## 참고

`npm` 정보는 프로젝트의 루트 디렉토리의 `.npmrc`를 사용합니다.

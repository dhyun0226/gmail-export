import { resolve } from 'node:path';
import { defineConfig } from 'vite';
import ows from '@ows/vite-plugin-lib';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
  plugins: [
    vue(),
    ows(),
  ],
  resolve: {
    alias: [
      {
        find: '@',
        replacement: resolve(__dirname, 'src'),
      },
    ],
  },
});

interface ImportMetaEnv {}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

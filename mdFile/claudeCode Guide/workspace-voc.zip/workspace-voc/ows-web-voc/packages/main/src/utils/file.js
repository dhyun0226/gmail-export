// Utility functions
export function isImageFile(file) {
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  return imageExtensions.includes(file.fileExtensionName.toLowerCase());
}

export function getFileIcon(file) {
  const fileType = file.type.split('/')[1];
  switch (fileType) {
    case 'pdf':
      return 'fas fa-file-pdf';
    case 'doc':
    case 'docx':
      return 'fas fa-file-word';
    case 'xls':
    case 'xlsx':
      return 'fas fa-file-excel';
    case 'mp4':
    case 'mov':
    case 'avi':
      return 'fas fa-file-video';
    default:
      return 'fas fa-file';
  }
}

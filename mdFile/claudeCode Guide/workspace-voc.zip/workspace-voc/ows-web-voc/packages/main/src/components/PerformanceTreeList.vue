<script lang="ts" setup>
import { ref, onMounted, watch, defineProps, defineEmits, computed } from "vue";
import "devextreme/dist/css/dx.light.css";
import TreeList from "devextreme-vue/tree-list";
import { DxColumn } from "devextreme-vue/tree-list";

const props = defineProps({
  dataSource: {
    type: Array,
    default: () => [],
  },
  columns: {
    type: Array,
    default: () => [],
  },
  keyExpr: {
    type: String,
    default: "id",
  },
  parentIdExpr: {
    type: String,
    default: "parentId",
  },
  rootValue: {
    type: [String, Number, null],
    default: null,
  },
  showBorders: {
    type: Boolean,
    default: true,
  },
  showRowLines: {
    type: Boolean,
    default: true,
  },
  columnAutoWidth: {
    type: Boolean,
    default: true,
  },
  wordWrapEnabled: {
    type: Boolean,
    default: true,
  },
  height: {
    type: [String, Number],
    default: "auto",
  },
  noDataText: {
    type: String,
    default: "데이터가 없습니다",
  },
  defaultColDef: {
    type: Object,
    default: () => ({ alignment: "center" }),
  },
  autoExpandAll: {
    type: Boolean,
    default: false,
  },
});

// Emitting events to parent component
const emit = defineEmits([
  "row-click",
  "content-ready",
  "node-expand", // New event for node expansion
  "node-collapse", // New event for node collapse
]);

const treeListRef = ref(null);

// Process columns with default settings
const processedColumns = computed(() => {
  return props.columns.length > 0
    ? props.columns.map((column: any) => ({
        ...props.defaultColDef,
        ...column,
      }))
    : [
        { dataField: "name", caption: "구분", width: 200, alignment: "left" },
        { dataField: "total", caption: "전체", alignment: "center" },
        { dataField: "h8", caption: "0시~8시", alignment: "center" },
        { dataField: "h9", caption: "9시", alignment: "center" },
      ];
});

// Handle row click event
const onRowClick = (e: any) => {
  emit("row-click", e);
};

// Handle content ready event
const onContentReady = (e: any) => {
  emit("content-ready", e);
};

// Custom handler for node expand
const onNodeExpanding = (e: any) => {
  // Prevent default expansion to handle it manually
  if (e.event) {
    // Get the key of the node being expanded
    const key = e.key;

    // Emit event to parent for API data fetching
    emit("node-expand", key);
  }
};

// Custom handler for node collapse
const onNodeCollapsing = (e: any) => {
  if (e.event) {
    const key = e.key;
    emit("node-collapse", key);
  }
};

// Methods to manually expand or collapse nodes
const expandNode = (key: any) => {
  if (treeListRef.value?.instance) {
    treeListRef.value.instance.expandRow(key);
  }
};

const collapseNode = (key: any) => {
  if (treeListRef.value?.instance) {
    treeListRef.value.instance.collapseRow(key);
  }
};

// Method to expand all rows (manual implementation)
const expandAllRows = () => {
  const instance = treeListRef.value?.instance;
  if (instance) {
    // Get all parent nodes
    const parentKeys = [];
    const dataSource = props.dataSource;

    // Find all unique parent IDs
    dataSource.forEach((item: any) => {
      if (
        item[props.parentIdExpr] === props.rootValue &&
        !parentKeys.includes(item[props.keyExpr])
      ) {
        parentKeys.push(item[props.keyExpr]);
      }
    });

    // Expand each parent node
    parentKeys.forEach((key: any) => {
      instance.expandRow(key);
      emit("node-expand", key);
    });
  }
};

// Method to collapse all rows
const collapseAllRows = () => {
  const instance = treeListRef.value?.instance;
  if (instance) {
    // Get all parent nodes
    const parentKeys = [];
    const dataSource = props.dataSource;

    // Find all unique parent IDs
    dataSource.forEach((item: any) => {
      if (
        item[props.parentIdExpr] === props.rootValue &&
        !parentKeys.includes(item[props.keyExpr])
      ) {
        parentKeys.push(item[props.keyExpr]);
      }
    });

    // Collapse each parent node
    parentKeys.forEach((key: any) => {
      instance.collapseRow(key);
      emit("node-collapse", key);
    });
  }
};

// Method to refresh the grid
const refresh = () => {
  treeListRef.value?.instance.refresh();
};

// Expose methods to parent components
defineExpose({
  expandNode,
  collapseNode,
  expandAllRows,
  collapseAllRows,
  refresh,
  treeListInstance: treeListRef,
});

onMounted(() => {
  console.log("TreeGrid component mounted");
});
</script>

<template>
  <TreeList
    ref="treeListRef"
    :data-source="dataSource"
    :key-expr="keyExpr"
    :parent-id-expr="parentIdExpr"
    :root-value="rootValue"
    :show-borders="showBorders"
    :show-row-lines="showRowLines"
    :column-auto-width="columnAutoWidth"
    :word-wrap-enabled="wordWrapEnabled"
    :height="height"
    :no-data-text="noDataText"
    @row-click="onRowClick"
    @content-ready="onContentReady"
    @node-expanding="onNodeExpanding"
    @node-collapsing="onNodeCollapsing"
  >
    <DxColumn
      v-for="(column, index) in processedColumns"
      :key="index"
      v-bind="column"
    />

    <template #headerRow>
      <slot name="headerRow"></slot>
    </template>

    <template #footer>
      <slot name="footer"></slot>
    </template>
  </TreeList>
</template>

<style>
/* Custom + and - icons for expand/collapse */
.dx-treelist-collapsed:before {
  content: "+";
  font-size: 16px;
  font-weight: bold;
  color: #333;
}

.dx-treelist-expanded:before {
  content: "-";
  font-size: 16px;
  font-weight: bold;
  color: #333;
}

/* Adjust position of the icons */
.dx-treelist-collapsed,
.dx-treelist-expanded {
  text-align: center;
  vertical-align: middle;
  line-height: 1;
  width: 16px;
  height: 16px;
  display: inline-block;
}

/* Remove default icon */
.dx-treelist-empty,
.dx-icon-spinright,
.dx-icon-spindown {
  display: none !important;
}
</style>

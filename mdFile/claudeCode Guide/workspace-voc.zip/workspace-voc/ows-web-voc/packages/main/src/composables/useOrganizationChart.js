import { useApi, useOverlay } from '@ows/core';
import { useOwAlert } from '@ows/ui';

export function useOrganizationChart() {
  const api = useApi();
  const { owAlert } = useOwAlert();
  const { show, hide } = useOverlay();

  async function getAncestorsList(params) {
    try {
      show();
      return await api.get('/tsk/org/getOrganizationAncestorChart', { params });
    }
    catch (e) {
      owAlert({ title: '경고창', message: e.message });
    }
    finally {
      hide();
    }
  }

  async function getSubOrganizationChart(params) {
    try {
      show();
      return await api.get('/tsk/org/getSubOrganizationChart', { params });
    }
    catch (e) {
      owAlert({ title: '경고창', message: e.message });
    }
    finally {
      hide();
    }
  }

  async function getOrganizationsWithEmployees(params) {
    try {
      show();
      return await api.get('/com/organization-chart-with-employees', { params });
    }
    catch (e) {
      owAlert({ title: '경고창', message: e.message });
    }
    finally {
      hide();
    }
  }

  return {
    getAncestorsList,
    getSubOrganizationChart,
    getOrganizationsWithEmployees,
  };
}

export default useOrganizationChart;

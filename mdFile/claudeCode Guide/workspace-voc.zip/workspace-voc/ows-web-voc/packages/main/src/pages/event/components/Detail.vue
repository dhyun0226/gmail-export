<script setup lang="ts">
import { defineExpose, ref, watch } from 'vue';
import { useApi } from '@ows/core';
import dayjs from 'dayjs';
import { useOwPopup } from '@ows/ui';

import DxListNGrid from '@/components/DxListNGrid.vue';
import EventDetailPopup from '@/components/EventDetailPopup.vue';
import EventDetailCommentPopup from '@/components/EventDetailCommentPopup.vue';

const props = defineProps({
  from: String,
  to: String,
  dateUnit: String,
  filterOptions: Object,
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  employeeGroupOptions: Array,
  searchType: String,
  keyword: String,
});

const {
  openPopup: openDetailPopup,
  closePopup: closeDetailPopup,
  isPopupOpen,
} = useOwPopup();

const api = useApi();

const eventNumber = ref(0);
const SelectedServiceCategoryCode = ref('');
const isCommentPopupOpen = ref(false);
const columns = ref([
  {
    caption: '채널',
    width: '100',
    dataField: 'channelCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '상세구분',
    width: '100',
    dataField: 'serviceCategoryCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize5',
    visible: true,
  },
  {
    caption: '이벤트제목',
    width: '*',
    dataField: 'eventTitle',
    allowMerge: false,
    alignment: 'left',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '시작일',
    width: '90',
    dataField: 'eventStartDatetime',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'ymd',
    visible: true,
  },
  {
    caption: '종료일',
    width: '100',
    dataField: 'eventEndDatetime',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'ymd',
    visible: true,
  },
  {
    caption: '상단고정',
    width: '70',
    dataField: 'topFixedYesOrNo',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
  {
    caption: '사용',
    width: '80',
    dataField: 'useYesOrNo',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize4',
    visible: true,
  },
  {
    caption: '조회건수',
    width: '80',
    dataField: 'inquiryCount',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '댓글수',
    width: '80',
    dataField: 'commentCount',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록자',
    width: '100',
    dataField: 'registererEmployeeNumber',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize6',
    visible: true,
  },
  {
    caption: '등록일자',
    width: '100',
    dataField: 'eventRegistrationDatetime',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize',
    visible: true,
  },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 1,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  // pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

// 카테고리 코드를 채널 이름으로 변환하는 함수 개선
function getChannelText(code) {
  const channel = props.channelGroupOptions?.find(item =>
    code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 카테고리 코드를 카테고리 이름으로 변환하는 함수 개선
function getCategoryText(code) {
  const channel = props.categoryGroupOptions?.find(item =>
      code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 등록자 사번을 이름으로 변환하는 함수 개선
function getEmployeeName(code) {
  const employee = props.employeeGroupOptions?.find(item =>
      code === item.employeeNumber,
  );
  return employee ? employee.employeeName : code; // 매핑된 값이 없으면 원래 코드를 반환
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY-MM-DD');
}

function getTimeFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('HH:mm');
}

function getColumnsByDate() {
  const date = props.dateUnit;
  if (date === 'day') {
    columns.value.forEach((col) => {
      if (col.caption === '등록일자') {
        col.caption = '등록시간';
      }
    });
  } else {
    columns.value.forEach((col) => {
      if (col.caption === '등록시간') {
        col.caption = '등록일자';
      }
    });
  }
}

function getColumnsByChannel() {
  if(props.filterOptions.channelGroup.value === '') {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = true;
      }
    });
  } else {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = false;
      }
    });
  }
}

function onCellPrepared(e) {

}

function onCellClick(e) {
  eventNumber.value = e.data.eventNumber;
  SelectedServiceCategoryCode.value = e.data.serviceCategoryCode;
  if (e.column?.dataField === 'commentCount') {
    // 댓글수 컬럼 클릭 시 댓글 팝업 오픈
    openCommentPopup();
  }
  else {
    // 그 외는 기존 팝업 오픈
    openDetailPopup();
  }
}

function openCommentPopup() {
  isCommentPopupOpen.value = true;
}

function closeCommentPopup() {
  isCommentPopupOpen.value = false;
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      fromDate: props.from,
      toDate: props.to,
      channelCode: props.filterOptions.channelGroup.value,
      serviceCategoryCode: props.filterOptions.categoryGroup.value,
      useYesOrNo: props.filterOptions.useYnGroup.value,
      topFixedYesOrNo: props.filterOptions.topFxdYnGroup.value,
      searchType: props.searchType,
      keyword: props.keyword,
    };

    // 이벤트 데이터를 가져옴
    const result = await api.get('/voc/events', { params });

    const eventData = result.data.data || [];
    
    // 댓글 갯수 추가
    const enrichedData = eventData.map((item) => {
      return {
        ...item,
        commentCount: Array.isArray(item.eventAnswers) ? item.eventAnswers.length : 0,
      };
    });
    
    gridOption.value.datas = enrichedData;
    gridOption.value.paging.totalItemCount = result.data.totalCount || 0;
  }
  catch (error) {
    console.error('Event load error:', error);
    gridOption.value.datas = [];
  }
}

function handleSaveSuccess() {
  load();
}

watch(
    [() => props.from, () => props.to],
    () => {
      getColumnsByDate();
      load();
    }
 );

watch(
  () => props.filterOptions,
  () => {
    getColumnsByChannel();
    load();
  },
  { deep: true },
);

defineExpose({
  load,
});
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <template v-if="props.dateUnit === 'day'">
        {{ getTimeFormat(cell.data.eventRegistrationDatetime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.eventRegistrationDatetime) }}
        </div>
      </template>
    </template>

    <template #customize2="{ data: cell }">
      <div>{{ getChannelText(cell.data.serviceCategoryCode) }}</div>
    </template>
    <template #customize3="{ data: cell }">
      <div>{{ cell.data.topFixedYesOrNo === "Y" ? "고정" : "해제" }}</div>
    </template>
    <template #customize4="{ data: cell }">
      <div>{{ cell.data.useYesOrNo === "Y" ? "사용" : "미사용" }}</div>
    </template>
    <template #customize5="{ data: cell }">
      <div>{{ getCategoryText(cell.data.serviceCategoryCode) }}</div>
    </template>
    <template #customize6="{ data: cell }">
      <div>{{ getEmployeeName(cell.data.registererEmployeeNumber) }}</div>
    </template>
    <template #ymd="{ data: cell }">
      <div>{{ getDateFormat(cell.value) }}</div>
    </template>
  </DxListNGrid>
  <EventDetailPopup
    v-if="isPopupOpen"
    :is-popup-open="isPopupOpen"
    :service-category-code="SelectedServiceCategoryCode"
    :channel-group-options="props.channelGroupOptions"
    :category-group-options="props.categoryGroupOptions"
    height="auto"
    title="이벤트 상세"
    :event-number="eventNumber"
    :disabled-select="true"
    :width="1700"
    :on-close="
      () => {
        closeDetailPopup();
      }
    "
    @edit-event="handleSaveSuccess"
  />
  <EventDetailCommentPopup
    v-if="isCommentPopupOpen"
    :is-popup-open="isCommentPopupOpen"
    height="auto"
    title="이벤트 댓글"
    :event-number="eventNumber"
    :disabled-select="true"
    :width="1700"
    :on-close="() => { closeCommentPopup(); }"
    @edit-event="handleSaveSuccess"
  />
</template>

<style></style>
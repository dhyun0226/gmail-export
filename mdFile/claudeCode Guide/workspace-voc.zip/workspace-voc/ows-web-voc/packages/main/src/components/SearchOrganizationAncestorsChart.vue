<script setup>
import { computed, nextTick, onMounted, ref } from 'vue';
import { unionBy } from 'lodash-es';
import { useId, useUserProfile } from '@ows/core';
import { useOrganizationChart } from '@/composables/useOrganizationChart';

const props = defineProps({
  width: { type: String, default: '100%' },
});

const emit = defineEmits(['loaded', 'change', 'prepared']);

const modelValue = defineModel({ type: Object, default: () => { return {}; } });

const radioId = useId();
const { currentUser } = useUserProfile();
const { getAncestorsList, getSubOrganizationChart } = useOrganizationChart();

const data = ref([]);
const root = ref({}); // 오스템 임플란트 하위 레벨인 '본부'
const nodes = ref([]);
const selectedKey = ref({});
const selectedData = ref({});
const filter = ref(null);
const customWidth = ref(`${props.width}px`);

const computedData = computed(() =>
  data.value.filter(item =>
    item.key === root.value.key
    || item.key === selectedKey.value
    || item.key === selectedData.value.parentKey
    || item.parentKey === selectedKey.value
    || selectedData.value.leaf && (item.parentKey === selectedData.value.parentKey),
  ).sort((a, b) => a.level - b.level));

function setWidth(value) {
  customWidth.value = value;
}

function prev() {
  setTimeout(() => filter.value.set(0, 'prev'), 100);
}

function prepared() {
  const element = document.querySelector(`#${radioId.value}`);
  emit('prepared', { element, setWidth, prev });
}

async function load(
  corpCode = props.corpCode || currentUser.corpCode,
  deptCode = props.deptCode || currentUser.deptCode,
  initialized = true,
) {
  const params = { corpCode, deptCode };
  const res = initialized ? await getAncestorsList(params) : await getSubOrganizationChart(params);
  if (initialized) {
    const rootItem = res.at(0);
    if (rootItem.internal) {
      root.value = rootItem;
      nodes.value = res;
    }
    const findSelected = res.find(item => item.data.deptCode === modelValue.value.deptCode);
    selectedKey.value = findSelected ? findSelected.key : root.value.key;
    selectedData.value = findSelected.data ?? root.value.data;
  }
  data.value = unionBy([...nodes.value, ...res], 'key');
  filter.value.set(0, 'prev');
  nextTick(() => {
    prepared();
    emit('loaded');
  });
}

async function change(value) {
  const findItem = data.value.find(item => item.key === value);
  modelValue.value = findItem.data;
  selectedKey.value = value;
  selectedData.value = findItem;
  emit('change', findItem.data);
  if (findItem.internal) {
    if (value !== root.value.key) {
      root.value.expanded = false;
    }
    await load(findItem.data.corpCode, findItem.data.deptCode, root.value.key === value);
  }
  prepared();
}

function init() {
  if (!modelValue.value) {
    modelValue.value = currentUser;
  }
  nextTick(() => load());
}

onMounted(() => init());
</script>

<template>
  <OwFormFilterGroup
    ref="filter"
    :width="customWidth"
  >
    <BFormRadioGroup
      :id="radioId"
      v-model="selectedKey"
      :class="$style.group"
      text-field="display"
      value-field="key"
      buttons
      @change="change"
    >
      <BFormRadio
        v-for="item of computedData"
        :key="item.key"
        :aria-selected="selectedKey === item.key"
        :aria-expanded="item.expanded"
        :class="[
          { [$style.root]: item.internal },
          { [$style.item]: item.leaf },
        ]"
        :value="item.key"
      >
        {{ item.display }}
      </BFormRadio>
    </BFormRadioGroup>
  </OwFormFilterGroup>
</template>

<style lang="scss" module>
.group {
  padding: 0 !important;
  gap: 0 !important;
}

.root + label {
  --bs-btn-color: #333;
  --bs-btn-bg: #fff !important;
  --bs-btn-border-color: #e1e6ea;
  --bs-btn-hover-color: #333;
  --bs-btn-hover-bg: #fff;
  --bs-btn-hover-border-color: #e1e6ea;
  --bs-btn-focus-shadow-rgb: 76, 107, 150;
  --bs-btn-active-color: #fff;
  --bs-btn-active-bg: #4e95f5;
  --bs-btn-active-border-color: #176de2;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-padding-x: 10px;
  --bs-btn-padding-y: 0;
  --bs-btn-font-size: 12px;
  --bs-btn-border-radius: 0;
  height: 24px;
  margin-right: 0px;
  letter-spacing: -0.5px;
  font-weight: bold;
  font-size: 12px;
  border-color: #e1e6ea;
  border-radius: 0;
}

.root[aria-expanded='true'] + label {
  --bs-btn-color: #fff;
  --bs-btn-bg: #677280 !important;
  --bs-btn-border-color: #677280;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #677280;
  --bs-btn-hover-border-color: #677280;
  --bs-btn-active-bg: #677280;
  --bs-btn-active-border-color: #677280;
  --bs-btn-border-radius: 0;
  margin-right: 5px;
  transition: none;
  border: 1px solid #677280;

  &::after {
    content: '';
    position: absolute;
    height: 7px;
    width: 7px;
    right: -4px;
    background-color: #677280;
    transform: translate(0%, 0%) rotate(135deg);
  }
}

.root[aria-selected='true'] + label {
  --bs-btn-color: #fff;
  --bs-btn-bg: #4e95f5;
  --bs-btn-border-color: #176de2;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #4e95f5;
  --bs-btn-hover-border-color: #176de2;
  --bs-btn-active-bg: #4e95f5;
  --bs-btn-active-border-color: #176de2;
  --bs-btn-border-radius: 0;
  margin-right: 5px;
  transition: none;

  &::after {
    content: '';
    position: absolute;
    height: 7px;
    width: 7px;
    right: -4px;
    background-color: #4e95f5;
    transform: translate(0%, 0%) rotate(135deg);
    border-left: 1px solid #176de2;
    border-top: 1px solid #176de2;
  }
}

.item + label {
  --bs-btn-color: #333;
  --bs-btn-bg: #e1e6ea;
  --bs-btn-border-color: #e1e6ea;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #4e95f5;
  --bs-btn-hover-border-color: #176de2;
  --bs-btn-focus-shadow-rgb: 76, 107, 150;
  --bs-btn-active-color: #fff;
  --bs-btn-active-bg: #4e95f5;
  --bs-btn-active-border-color: #176de2;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #fff;
  --bs-btn-disabled-bg: rgb(44, 81, 131);
  --bs-btn-disabled-border-color: rgb(44, 81, 131);
  --bs-btn-padding-x: 10px;
  --bs-btn-padding-y: 0;
  --bs-btn-font-size: 12px;
  height: 22px;
  margin-right: 2px;
  margin-right: 2px;
  letter-spacing: -0.5px;
  font-weight: bold;
  font-size: 12px;
}
</style>

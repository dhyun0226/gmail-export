// data.ts
import { computed, ref } from "vue";

export const channelGroupOptions = [
  { text: "Osstem Home", value: "D006" },
  { text: "TV", value: "D001" },
  { text: "Mall", value: "D002" },
  { text: "Education", value: "D003" },
  { text: "Job", value: "D004" },
  { text: "Software", value: "D005" },
];

export const openYNGroupOptions = [
  { text: "공개", value: "Y" },
  { text: "비공개", value: "N" },
];

export const topFxdYnGroupOptions = [
  { text: "상단고정", value: "Y" },
  { text: "해제", value: "N" },
];

export const searchGroupOptions = [
  { text: "제목", value: "title" },
  { text: "내용", value: "content" },
  { text: "등록자", value: "writer" },
];

export const useYNGroupOptions = [
  { text: "사용", value: "Y" },
  { text: "미사용", value: "N" },
];

export const processStatusGroupOptions = [
  { text: "답변완료", value: "Y" },
  { text: "문의접수", value: "N" },
];

export const useDeleteGroupOptions = [
  { text: '삭제', value: 'Y' },
  { text: '미삭제', value: 'N' },
];

export const listCategoryGroupOptions = [
  { text: '댓글참여', value: '01' },
  { text: '인증참여', value: '02' },
];
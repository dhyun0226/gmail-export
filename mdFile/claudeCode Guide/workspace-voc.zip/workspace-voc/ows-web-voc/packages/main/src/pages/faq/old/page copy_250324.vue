<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import { DxColumn, DxDataGrid } from 'devextreme-vue/data-grid';
import { useApi, useCommonCode } from '@ows/core';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';

import type {
  GridState,
  PagingState,
  SearchState,
  VocData,
  VocItem,
} from '@/type/VOCReceptionTypes';

import ReceptionDetails from '@/pages/VOC/ProgressStatus/ReceptionDetails.vue';

import OwFilterProduct from '@/components/OwFilterProduct.vue';
import OwFilterCountry from '@/components/OwFilterCountry.vue';
import OwFilterOrg from '@/components/OwFilterOrg.vue';

import NGrid from '@/components/NGrid.vue';
import { dateUtils } from '@/utils';

const api = useApi();
const {
  openPopup: openReceptionPopup,
  closePopup: closeReceptionPopup,
  isPopupOpen: isReceptionPopupOpen,
} = useOwPopup();

// 공통 코드 로드
const { VOC_ITM_CTG_CD } = await useCommonCode('VOC_ITM_CTG_CD');
const { VOC_DVCD } = await useCommonCode('VOC_DVCD');

const fromEx2 = ref(dayjs().format('YYYY-MM-DD'));
const toEx2 = ref(dayjs().format('YYYY-MM-DD'));

const doubleFlag = ref(false);
const today = ref(false);

const twice = ref(false);
const disabledTwice = ref(false);

const disabledDouble = ref(false);
const disabledPicker = ref(false);

const rangeUnit = ref('day');

function rangeUnitChage(unit) {
  rangeUnit.value = unit;
  today.value = false;
}

function twiceChange(newTwice) {
  twice.value = newTwice;
}

// 상태 관리
const paging = reactive<PagingState>({
  pageNo: 1,
  pageSize: 14,
  totalCount: 0,
});

const search = reactive<SearchState>({
  from: '2024-07-09',
  to: dateUtils.getToday(),
  itemFilter: 'all',
  selectedType: '',
});

const grid = reactive<GridState>({
  data: [],
  height: '100%',
  selectedItem: null,
});

// 품목 필터 옵션
const itemFilterOptions: VocItem[] = [
  { text: '전체', value: 'all' },
  { text: '미품목', value: 'noItem' },
];

// 품목 필터 옵션
const termOptions: VocItem[] = [
  { text: '품목기간', value: 'productTerm' },
  { text: '지역기간', value: 'countryTerm' },
  { text: '인원기간', value: 'personalTerm' },
];

const listGroupOptions: VocItem[] = [
  { text: '품목', value: 'product' },
  { text: '지역', value: 'country' },
  { text: '인원', value: 'personal' },
];

const term = ref('productTerm');
const listGroup = ref('');

const typeOptions = computed(() =>
  VOC_DVCD.map(type => ({
    text: type.text,
    value: type.value,
  })),
);

const fields = [
  { key: 'registrationDateTime', label: '접수일자' },
  { key: 'vocContent', label: '내용' },
  { key: 'registrationEmployeeNumber', label: '요청자' },
  { key: 'vocItemCategoryCode', label: '품목' },
  { key: 'requestDepartment', label: '요청부서' },
  { key: 'vocDivisionCode', label: '유형' },
];

function formatDateTime(dateTime: string): string {
  if (!dateTime) {
    return '';
  }
  const date = new Date(dateTime);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(
    2,
    '0',
  )}-${String(date.getDate()).padStart(2, '0')} ${String(
    date.getHours(),
  ).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function handleItemFilterChange(): void {
  load();
}

function handleTypeChange(): void {
  load();
}

async function load(): Promise<void> {
  try {
    const params = {
      pageNo: paging.pageNo,
      pageSize: paging.pageSize * 2,
      fromDate: dateUtils.toLocalDateTime(search.from),
      toDate: dateUtils.toLocalDateTime(search.to),
      vocDivisionCode: search.selectedType,
      itemFilter: search.itemFilter,
    };

    const result = await api.get<{ data: VocData[]; totalCount: number }>(
      '/voc/vocs',
      { params },
    );
    grid.data = result.data.data;
    paging.totalCount = result.data.totalCount;
  }
  catch (error) {
    console.error('Failed to load VOC data:', error);
  }
}

function handlePaging({
  pageNo,
  pageSize,
}: {
  pageNo: number;
  pageSize: number;
}): void {
  paging.pageNo = pageNo;
  paging.pageSize = pageSize;
  load();
}

function onCellClick(e: { rowType: string; data: VocData }): void {
  if (e.rowType === 'data') {
    grid.selectedItem = e.data;
    openReceptionPopup();
  }
}

function handleDateChange(): void {
  load();
}

function handleUnitChange(unit: string): void {
  console.log('Date unit changed:', unit);
}

function handleTwiceChange(twice: boolean): void {
  console.log('Twice changed:', twice);
}

function handlePrevNextChange(unit: string): void {
  console.log('Date unit changed:', unit);
}

function updateGridHeight(): void {
  grid.height = `${window.innerHeight - 165}px`;
}

function getItemText(code: string): string {
  const item = VOC_ITM_CTG_CD.find(item => item.value === code);
  return item ? item.text : code;
}

function getTypeText(code: string): string {
  const type = VOC_DVCD.find(type => type.value === code);
  return type ? type.text : code;
}

onMounted(() => {
  // updateGridHeight();
  window.addEventListener('resize', updateGridHeight);
  load();
});
</script>

<template>
  <div class="voc-inquiry">
    <div
      class="input-group gap-1 mb-2"
      role="group"
    >
      <OwBizDatePickerRangeExcluedPickVer2
        ref="element3"
        v-model:from="fromEx2"
        v-model:to="toEx2"
        v-model:is-double-selected="doubleFlag"
        :unit="rangeUnit"
        :disabled-twice="disabledTwice"
        :default-twice="false"
        :disabled-double="disabledDouble"
        :years="15"
        :today="today"
        :hidden-units="['6months']"
        :disabled-picker="disabledPicker"
        @unit-change="handleUnitChange"
        @prev-next-change="handlePrevNextChange"
        @twice-change="handleTwiceChange"
      />

      <BButton
        v-if="doubleFlag && !['5years', 'day'].includes(rangeUnit)"
        class="ow-bi ow-w24"
        variant="light"
        :style="today ? 'border: 2px solid #176de2;' : ''"
        @click="today = !today"
      >
        <i class="bi bi-box-arrow-left" />
        <span class="visually-hidden">기간/오늘 선택</span>
      </BButton>
      <!-- <OwDatePickerRange
        v-model:from="search.from"
        v-model:to="search.to"
        :hidden-units="['year', '5years', '6months', 'day', 'week', 'month']"
        @change="handleDateChange"
        @unit-change="handleUnitChange"
        @twice-change="handleTwiceChange"
      /> -->
      <OwFilterCountry />
      <OwFilterProduct />
      <OwFilterOrg />
      <OwFormRadio
        v-model="term"
        :options="termOptions"
        shape="round"
        @change="handleItemFilterChange"
      />

      <OwFormRadio
        v-model="listGroup"
        :options="listGroupOptions"
        type="all"
        shape="round"
        @change="handleItemFilterChange"
      />

      <BButton
        variant="state"
        @click="openItemSelection"
      >
        품목선택
      </BButton>
      <BButton
        variant="state"
        @click="openItemSelection"
      >
        컬럼추가
      </BButton>
      <OwFormRadio
        v-model="search.selectedType"
        :options="typeOptions"
        type="all"
        @change="handleTypeChange"
      />
    </div>

    <NGrid
      :data="grid.data"
      :total-count="paging.totalCount"
      :count="2"
      :fields="fields"
      :page-no="paging.pageNo"
      :page-size="paging.pageSize"
      :allowed-page-sizes="[14, 28, 56]"
      @paging="handlePaging"
    >
      <template #default="{ items }">
        <DxDataGrid
          :data-source="items"
          :show-borders="true"
          :show-column-lines="false"
          :show-row-lines="true"
          :height="grid.height"
          @cell-click="onCellClick"
        >
          <DxColumn
            data-field="registrationDateTime"
            caption="접수일자"
            data-type="date"
            :width="140"
            cell-template="dateTemplate"
          />
          <DxColumn
            data-field="vocContent"
            caption="내용"
            cell-template="contentTemplate"
            width="*"
          />
          <DxColumn
            data-field="registrationEmployeeNumber"
            caption="요청자"
            :width="100"
            alignment="center"
          />
          <DxColumn
            data-field="vocItemCategoryCode"
            caption="품목"
            :width="80"
            cell-template="itemTemplate"
          />
          <DxColumn
            data-field="requestDepartment"
            caption="요청부서"
            :width="80"
          />
          <DxColumn
            data-field="vocDivisionCode"
            caption="유형"
            :width="80"
            cell-template="typeTemplate"
          />

          <template #dateTemplate="{ data }">
            <div class="text-center">
              {{ formatDateTime(data.data.registrationDateTime) }}
            </div>
          </template>

          <template #contentTemplate="{ data }">
            <div class="content-cell">
              {{ data.data.vocContent }}
            </div>
          </template>

          <template #itemTemplate="{ data }">
            <div>
              {{ getItemText(data.data.vocItemCategoryCode) }}
            </div>
          </template>

          <template #typeTemplate="{ data }">
            <div class="text-center">
              {{ getTypeText(data.data.vocDivisionCode) }}
            </div>
          </template>
        </DxDataGrid>
      </template>
    </NGrid>
  </div>

  <OwPopup
    v-if="isReceptionPopupOpen"
    :is-popup-open="isReceptionPopupOpen"
    :on-close="closeReceptionPopup"
    title="VOC상세"
    :show-title="true"
    :show-close-button="true"
    :height="750"
    :width="850"
  >
    <ReceptionDetails
      :voc-number="grid.selectedItem?.vocNumber"
      :voc-item-category-code="VOC_ITM_CTG_CD"
      :voc-division-code="VOC_DVCD"
    />
  </OwPopup>
</template>

<style scoped>
.voc-inquiry {
  height: 100%;
  width: 100%;
  /* display: flex; */
  /* flex-direction: column; */
}

/* .search-area {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 10px;
} */

.content-cell {
  white-space: normal;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-height: 1.5em;
  max-height: 4.5em;
}

:deep(.dx-datagrid-rowsview .dx-row > td) {
  vertical-align: top;
}
</style>

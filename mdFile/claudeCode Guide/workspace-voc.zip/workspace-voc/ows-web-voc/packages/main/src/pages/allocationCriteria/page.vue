<script setup>
import { onMounted, ref } from 'vue';
import { useApi, useCommonCode } from '@ows/core';
import { DxDataGrid } from 'devextreme-vue/data-grid';
import DxTreeList from '@/components/DxTreeList.vue'; // 사용자 정의 컴포넌트
import OrgPopup from '@/components/OrgPopup.vue';

const { VOC_RGST_DVCD: vocRgstDvcd, VOC_RGST_DTL_DVCD: vocRgstDtlDvcd }
    = await useCommonCode('VOC_RGST_DVCD', 'VOC_RGST_DTL_DVCD');

const api = useApi();

// 조직도 팝업 open 및 close
const isOrgPopupOpen = ref(false);
const popupPosition = ref({ top: 0, left: 0 });

function openOrgPopup(event) {
  const buttonRect = event.target.getBoundingClientRect();
  popupPosition.value = {
    top: buttonRect.top + window.scrollY,
    left: buttonRect.right + 10,
  };
  isOrgPopupOpen.value = true;
}

function closeOrgPopup() {
  isOrgPopupOpen.value = false;
}

async function handleUpdateOrganization(value) {
  if (value) {
    const newData = {
      itemCode: null,
      serviceChargePersonCorporationCode: value.corpCode,
      serviceChargePersonDepartmentCode: value.deptCode,
      serviceChargePersonEmployeeNumber: value.empNo,
      serviceChargePersonDepartmentName: value.deptName,
      serviceChargePersonEmployeeName: value.empName,
      serviceChargePersonNumber: null,
      serviceDesignationThePersonInChargeYn: 'N',
      deleteYn: 'N',
      serviceCategoryCode: serviceCategoryCode.value,
    };

    try {
      await api.post('/voc/service-charge-persons', newData);
      const response = await api.get('/voc/service-charge-persons', {
        params: { serviceCategoryCode: serviceCategoryCode.value },
      });
      gridData.value = response.data;
    }
    catch (error) {
      console.error('데이터 저장 또는 조회 실패:', error);
    }
  }
  closeOrgPopup();
}

const treeData = ref([]);
const gridData = ref([]);

/**
 * 카테고리 트리 데이터를 처리하고 재구성하는 함수
 * 특정 노드(DVOC_VOC)를 제거하고 그 자식들의 부모를 조정함
 * @param {Array} data - 원본 카테고리 데이터 배열
 * @returns {Array} - 처리된 트리 데이터
 */
function processTreeData(data) {
  // 삭제할 노드의 ID
  const nodeToRemove = 'DVOC_VOC';

  // 삭제할 노드의 부모 ID 찾기
  const parentOfNodeToRemove
      = data.find(item => item.serviceCategoryCode === nodeToRemove)
        ?.upServiceCategoryCode || null;

  // 결과 배열 준비
  const processedData = [];
  const childMap = new Map();

  // 1. 각 노드의 자식 여부를 미리 계산
  data.forEach((node) => {
    // 이 노드가 삭제 대상이 아닌 경우에만 처리
    if (node.serivceCategoryCode !== nodeToRemove) {
      const parentId = node.upServiceCategoryCode
        ? typeof node.upServiceCategoryCode === 'object'
          ? node.upServiceCategoryCode.serviceCategoryCode
          : node.upServiceCategoryCode
        : null;

      // 삭제 대상 노드가 부모인 경우, 삭제 대상 노드의 부모를 이 노드의 부모로 설정
      if (parentId === nodeToRemove) {
        childMap.set(parentOfNodeToRemove, true);
      }
      else if (parentId) {
        childMap.set(parentId, true);
      }
    }
  });

  // 2. 데이터 변환
  data.forEach((node) => {
    // 삭제 대상 노드는 건너뜀
    if (node.serviceCategoryCode === nodeToRemove) {
      return;
    }

    let parentId = node.upServiceCategoryCode
      ? typeof node.upServiceCategoryCode === 'object'
        ? node.upServiceCategoryCode.serviceCategoryCode
        : node.upServiceCategoryCode
      : null;

    // 삭제 대상 노드가 부모인 경우, 삭제 대상 노드의 부모를 이 노드의 부모로ㅈ 설정
    if (parentId === nodeToRemove) {
      parentId = parentOfNodeToRemove;
    }

    processedData.push({
      id: node.serviceCategoryCode, // 데이터의 고유 ID
      parentId, // 부모 ID (조정된)
      name: node.serviceCategoryName, // 표시할 이름
      hasChildren: childMap.has(node.serviceCategoryCode), // 자식 여부 확인
      rawData: node, // 원본 데이터 유지 (필요시)
    });
  });

  return processedData;
}

async function load() {
  try {
    const response = await api.get('/voc/serviceCategories');
    treeData.value = processTreeData(response.data);
  }
  catch (error) {
  }
}

const serviceCategoryCode = ref('');
const previousRowElement = ref(null);

async function onSelectionChanged(e) {
  serviceCategoryCode.value = e.data.id;
  if (e.data.id.length > 4) {
    try {
      const response = await api.get('/voc/service-charge-persons', {
        params: { serviceCategoryCode: serviceCategoryCode.value },
      });
      gridData.value = response.data;
      // 이전에 클릭된 행의 스타일 초기화
      if (previousRowElement.value) {
        previousRowElement.value.style.color = '';
        previousRowElement.value.style.fontWeight = '';
      }

      // 현재 클릭된 행의 스타일 변경
      e.rowElement.style.color = 'blue';
      e.rowElement.style.fontWeight = 'bold';

      // 현재 행을 이전 행으로 저장
      previousRowElement.value = e.rowElement;
    }
    catch (error) {
      console.error('데이터 조회 실패:', error);
      gridData.value = [];
    }
  }
}

async function onRowClick(e) {
  console.log(e);
  const clickedRow = e.data;

  if (clickedRow.serviceDesignationThePersonInChargeYn === 'N') {
    if (confirm('대표담당자로 지정하시겠습니까?')) {
      gridData.value = gridData.value.map(row => ({
        ...row,
        serviceDesignationThePersonInChargeYn: row === clickedRow ? 'Y' : 'N',
      }));
      try {
        await api.put('/voc/service-charge-persons/update', gridData.value);
      }
      catch (error) {
        console.error('데이터 업데이트 실패:', error);
      }
    }
  }
}

function onRowPrepared(e) {
  if (
    e.rowType === 'data'
    && e.data.serviceDesignationThePersonInChargeYn === 'Y'
  ) {
    e.rowElement.style.color = 'blue';
    e.rowElement.style.fontWeight = 'bold';
  }
}

onMounted(() => {
  load();
});
</script>

<template>
  <div class="content">
    <div class="left-panel">
      <DxTreeList
        :data-source="treeData"
        key-expr="id"
        parent-id-expr="parentId"
        has-items-expr="hasChildren"
        :auto-expand-top="true"
        :root-value="null"
        :columns="[{ dataField: 'name', caption: 'VOC 구분' }]"
        :exo
        :show-borders="true"
        @row-click="onSelectionChanged"
      />
    </div>

    <div class="right-panel">
      <div class="panel-header">
        <button
          class="top-button"
          @click="openOrgPopup"
        >
          담당자 등록
        </button>
        <Teleport to="body">
          <OrgPopup
            v-if="isOrgPopupOpen"
            :is-popup-open="isOrgPopupOpen"
            :on-close="closeOrgPopup"
            :height="800"
            :style="{
              position: 'absolute',
              top: `${popupPosition.top}px`,
              left: `${popupPosition.left}px`,
            }"
            @update-organization="handleUpdateOrganization"
          />
        </Teleport>
      </div>
      <DxDataGrid
        :data-source="gridData"
        :columns="[
          { dataField: 'serviceChargePersonEmployeeName', caption: '담당자' },
          { dataField: 'serviceChargePersonDepartmentName', caption: '담당부서' },
          {
            dataField: 'serviceDesignationThePersonInChargeYn',
            caption: '대표담당자',
          },
        ]"
        :show-borders="true"
        @row-click="onRowClick"
        @row-prepared="onRowPrepared"
      />
    </div>
  </div>
</template>

<style scoped>
.content {
  display: flex;
  height: 100vh;
}

.left-panel,
.right-panel {
  flex: 1;
  padding: 16px;
  box-sizing: border-box;
  border-right: 1px solid #ccc;
}

.right-panel {
  border-right: none;
}

.panel-header {
  margin-bottom: 8px;
}

.top-button {
  font-weight: bold;
  padding: 6px 12px;
  background-color: #eee;
  border: 1px solid #999;
  cursor: pointer;
}

:deep(.dx-treelist-rowsview .dx-selection.dx-row td) {
  background-color: #e3f2fd !important;
  color: #1976d2 !important;
  font-weight: bold !important;
}
</style>

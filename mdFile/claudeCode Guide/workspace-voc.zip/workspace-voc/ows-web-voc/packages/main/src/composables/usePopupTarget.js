import { ref } from 'vue';
import { defineStore } from 'pinia';
import { useOwPopupPosition } from '@/composables/useOwPopupPosition';

export const usePopupTarget = defineStore('popup-target', () => {
  const { getPosition } = useOwPopupPosition();

  const target = ref(null);

  function get() {
    return target.value;
  }

  function set(targetId) {
    target.value = targetId;
  }

  function clear() {
    target.value = null;
  }

  function getTargetPosition(width, height) {
    if (target.value) {
      return getPosition(target.value, width, height);
    }
  }

  return {
    get,
    set,
    clear,
    getTargetPosition,
  };
});

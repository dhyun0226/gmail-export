// data.js
import { computed } from "vue";

// 데이터 타입 정의
export interface TreeGridItem {
  id: number | string;
  name: string;
  total: number;
  h0_8: number;
  h9: number;
  h10: number;
  h11: number;
  h12: number;
  h13: number;
  h14: number;
  h15: number;
  h16: number;
  h17: number;
  h18: number;
  h19: number;
  h20: number;
  h21: number;
  h22: number;
  h23: number;
  parentId: number | string | null;
  hasChildren?: boolean;
}

// 오늘 날짜 포맷 함수
export const getTodayFormatted = () => {
  const now = new Date();
  return `${now.getFullYear()}년 ${String(now.getMonth() + 1).padStart(
    2,
    "0"
  )}월 ${String(now.getDate()).padStart(2, "0")}일`;
};

// 컬럼 정의 생성 함수
export const getColumns = () => {
  const todayFormatted = getTodayFormatted();

  return [
    {
      dataField: "name",
      caption: "구분",
      width: 150,
      alignment: "left",
    },
    {
      caption: todayFormatted,
      alignment: "center",
      columns: [
        { dataField: "total", caption: "전체", alignment: "center", width: 80 },
        {
          dataField: "h0_8",
          caption: "0시~8시",
          alignment: "center",
          width: "*",
        },
        { dataField: "h9", caption: "9시", alignment: "center", width: "*" },
        { dataField: "h10", caption: "10시", alignment: "center", width: "*" },
        { dataField: "h11", caption: "11시", alignment: "center", width: "*" },
        { dataField: "h12", caption: "12시", alignment: "center", width: "*" },
        { dataField: "h13", caption: "13시", alignment: "center", width: "*" },
        { dataField: "h14", caption: "14시", alignment: "center", width: "*" },
        { dataField: "h15", caption: "15시", alignment: "center", width: "*" },
        { dataField: "h16", caption: "16시", alignment: "center", width: "*" },
        { dataField: "h17", caption: "17시", alignment: "center", width: "*" },
        { dataField: "h18", caption: "18시", alignment: "center", width: "*" },
        { dataField: "h19", caption: "19시", alignment: "center", width: "*" },
        { dataField: "h20", caption: "20시", alignment: "center", width: "*" },
        { dataField: "h21", caption: "21시", alignment: "center", width: "*" },
        { dataField: "h22", caption: "22시", alignment: "center", width: "*" },
        { dataField: "h23", caption: "23시", alignment: "center", width: "*" },
      ],
    },
  ];
};

// 임시 데이터 생성 함수
export const fetchMockData = async (parentId = null) => {

  if (parentId === null) {
    // 1레벨 항목들 (전체 없음, 바로 카테고리들 표시)
    return [
      {
        id: "implant",
        name: "임플란트",
        total: 45,
        h0_8: 2,
        h9: 4,
        h10: 5,
        h11: 4,
        h12: 3,
        h13: 5,
        h14: 4,
        h15: 3,
        h16: 2,
        h17: 3,
        h18: 4,
        h19: 5,
        h20: 3,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: true,
      },
      {
        id: "tools",
        name: "기구",
        total: 6,
        h0_8: 0,
        h9: 0,
        h10: 1,
        h11: 0,
        h12: 0,
        h13: 1,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 1,
        h18: 1,
        h19: 1,
        h20: 1,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "booster",
        name: "보철/교정",
        total: 1,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 1,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "surgery",
        name: "수술/임팩",
        total: 4,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 1,
        h12: 0,
        h13: 1,
        h14: 0,
        h15: 1,
        h16: 0,
        h17: 0,
        h18: 1,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "healing",
        name: "인상/보철",
        total: 5,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 1,
        h13: 0,
        h14: 1,
        h15: 0,
        h16: 0,
        h17: 1,
        h18: 1,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "prosthetics",
        name: "보철/임팩",
        total: 3,
        h0_8: 1,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "gbr",
        name: "GBR",
        total: 1,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "healing_abutment",
        name: "치유용품",
        total: 2,
        h0_8: 1,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 1,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "equipment",
        name: "장비",
        total: 22,
        h0_8: 0,
        h9: 1,
        h10: 1,
        h11: 1,
        h12: 1,
        h13: 2,
        h14: 5,
        h15: 2,
        h16: 5,
        h17: 2,
        h18: 5,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "orthodontic",
        name: "교정용기구",
        total: 4,
        h0_8: 0,
        h9: 1,
        h10: 0,
        h11: 1,
        h12: 0,
        h13: 1,
        h14: 0,
        h15: 0,
        h16: 1,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "membrane",
        name: "멤브레인/수장",
        total: 0,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "guidebones",
        name: "가이드용품",
        total: 0,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "medicine",
        name: "의약품",
        total: 0,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
      {
        id: "livingmaterials",
        name: "생활재료",
        total: 0,
        h0_8: 0,
        h9: 0,
        h10: 0,
        h11: 0,
        h12: 0,
        h13: 0,
        h14: 0,
        h15: 0,
        h16: 0,
        h17: 0,
        h18: 0,
        h19: 0,
        h20: 0,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: null,
        hasChildren: false,
      },
    ];
  } else if (parentId === "implant") {
    // 임플란트 하위 항목
    return [
      {
        id: "implant_a",
        name: "임플란트 A",
        total: 20,
        h0_8: 1,
        h9: 2,
        h10: 3,
        h11: 2,
        h12: 1,
        h13: 2,
        h14: 2,
        h15: 1,
        h16: 1,
        h17: 1,
        h18: 2,
        h19: 2,
        h20: 1,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: "implant",
        hasChildren: false,
      },
      {
        id: "implant_b",
        name: "임플란트 B",
        total: 15,
        h0_8: 1,
        h9: 1,
        h10: 1,
        h11: 1,
        h12: 1,
        h13: 2,
        h14: 2,
        h15: 1,
        h16: 1,
        h17: 1,
        h18: 1,
        h19: 2,
        h20: 1,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: "implant",
        hasChildren: false,
      },
      {
        id: "implant_c",
        name: "임플란트 C",
        total: 10,
        h0_8: 0,
        h9: 1,
        h10: 1,
        h11: 1,
        h12: 1,
        h13: 1,
        h14: 0,
        h15: 1,
        h16: 0,
        h17: 1,
        h18: 1,
        h19: 1,
        h20: 1,
        h21: 0,
        h22: 0,
        h23: 0,
        parentId: "implant",
        hasChildren: false,
      },
    ];
  }

  return [];
};

// 셀 렌더링 스타일 함수
export const cellStyleHandlers = {
  // 0인 셀을 회색으로 표시
  applyZeroValueStyle: (cell) => {
    if (
      cell.rowType === "data" &&
      cell.column.dataField !== "name" &&
      cell.value === 0
    ) {
      cell.cellElement.style.color = "#999";
    }
  },

  // 부모 항목 텍스트 굵게 표시
  applyParentStyle: (cell) => {
    if (
      cell.rowType === "data" &&
      cell.column.dataField === "name" &&
      cell.data.hasChildren
    ) {
      cell.cellElement.style.fontWeight = "bold";
    }
  },
};

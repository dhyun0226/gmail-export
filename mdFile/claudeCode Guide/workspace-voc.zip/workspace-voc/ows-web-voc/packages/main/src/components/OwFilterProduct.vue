<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue';

const props = defineProps({
  propsId: {
    type: String,
    default: 'itemSelectionsFilter',
  },
  label: {
    type: String,
    default: null,
  },
  propsListItem: {
    type: Array,
    default: () => [
      {
        name: '전체',
        value: null,
        itemList: [
          {
            name: '임플란트',
            value: '임플란트',
            itemList: [
              {
                name: 'KS System',
                value: 'KS System',
                itemList: [],
              },
              {
                name: 'TS System',
                value: 'TS System',
                itemList: [],
              },
              {
                name: 'SS System',
                value: 'SS System',
                itemList: [],
              },
              {
                name: 'US System',
                value: 'US System',
                itemList: [],
              },
              {
                name: 'ET System',
                value: 'ET System',
                itemList: [],
              },
              {
                name: 'MS System',
                value: 'MS System',
                itemList: [],
              },
              {
                name: 'OS System',
                value: 'OS System',
                itemList: [],
              },
              {
                name: 'OneDigital',
                value: 'OneDigital',
                itemList: [],
              },
              {
                name: 'KIT&Tools',
                value: 'KIT&Tools',
                itemList: [],
              },
              {
                name: 'GBR',
                value: 'GBR',
                itemList: [],
              },
              {
                name: 'CAD/CAM',
                value: 'CAD/CAM',
                itemList: [],
              },
              {
                name: 'Instruments',
                value: 'Instruments',
                itemList: [],
              },
            ],
          },
          { name: '기구', value: '기구', itemList: [] },
          { name: '보존/근관', value: '보존/근관', itemList: [] },
          { name: '수복/접착', value: '수복/접착', itemList: [] },
          {
            name: '인상/보철',
            value: '인상/보철',
            itemList: [
              {
                name: 'Unit chair',
                value: 'Unit chair',
                itemList: [
                  {
                    name: 'K5',
                    value: 'K5',
                    itemList: [],
                  },
                  { name: 'K3', value: 'K3', itemList: [] },
                  { name: 'K2', value: 'K2', itemList: [] },
                  {
                    name: 'Osstem Unit Chair',
                    value: 'Osstem Unit Chair',
                    itemList: [],
                  },
                ],
              },
              { name: 'Engine', value: 'Engine', itemList: [] },
              { name: 'Handpiece', value: 'Handpiece', itemList: [] },
              {
                name: 'Implant stability tester',
                value: 'Implant stability tester',
                itemList: [],
              },
              {
                name: 'Caries detection system',
                value: 'Caries detection system',
                itemList: [],
              },
              {
                name: 'Sterilization System',
                value: 'Sterilization Syste',
                itemList: [],
              },
              {
                name: 'Disinfection/Oiling',
                value: 'Disinfection/Oiling',
                itemList: [],
              },
              {
                name: 'Equipment(체어기타)',
                value: 'Equipment(체어기타)',
                itemList: [],
              },
            ],
          },

          { name: '절삭/연마', value: '절삭/연마', itemList: [] },
          { name: 'GBR', value: 'GBR', itemList: [] },
          { name: '위생용품', value: '위생용품', itemList: [] },
          {
            name: '장비',
            value: '장비',
            itemList: [
              { name: '진료장비', value: '진료장비', itemList: [] },
              { name: '임플란트장비', value: '임플란트장비', itemList: [] },
              { name: '멸균/소독장비', value: '멸균/소독장비', itemList: [] },
              { name: '영상장비', value: '영상장비', itemList: [] },
              {
                name: '체어/기계실장비',
                value: '체어/기계실장비',
                itemList: [
                  {
                    name: 'K5',
                    value: 'K5',
                    itemList: [],
                  },
                  { name: 'K3', value: 'K3', itemList: [] },
                  { name: 'K2', value: 'K2', itemList: [] },
                  {
                    name: 'Osstem Unit Chair',
                    value: 'Osstem Unit Chair',
                    itemList: [],
                  },
                ],
              },
              {
                name: 'PRF/AED/PMS장비',
                value: 'PRF/AED/PMS장비',
                itemList: [],
              },
              { name: '기타장비', value: '기타장비', itemList: [] },
            ],
          },
          { name: '교정', value: '교정', itemList: [] },
          { name: '예방/구강', value: '예방/구강', itemList: [] },
          { name: '기공', value: '기공', itemList: [] },
          { name: '의약품', value: '의약품', itemList: [] },
          { name: '생활가전', value: '생활가전', itemList: [] },
          { name: '미선택', value: '미선택', itemList: [] },
        ],
      },
    ],
  },
  propsSelectItem1: {
    type: String,
    default: '전체',
  },
  propsSelectItem2: {
    type: String,
    default: null,
  },
  propsSelectItem: {
    type: Array,
    default: () => ['전체', null, null, null],
  },
  viewDepth: {
    type: Number,
    default: null,
  },
  propsWidth: {
    type: String,
    default: 'auto',
  },
});

const emit = defineEmits(['selectItem']);

const root = ref(null);
const filter = ref(null);
const index = ref(0);

const state = reactive({
  item2_select: props.propsSelectItem2,
  item_list: [...props.propsListItem],
  original_list: [...props.propsListItem],
  item1_select: props.propsSelectItem1,
  overflow: false,
  item_select: [...props.propsSelectItem],
});

const filteredItems = computed(() => {
  // 전체 선택이거나 아무것도 선택되지 않은 경우 모든 항목 표시
  if (!state.item_select[0]) {
    return state.original_list;
  }

  // 현재 선택된 가장 깊은 레벨과 선택된 항목들의 경로를 찾음
  let currentLevel = -1;
  const selectedPath = [];

  for (let i = 0; i < state.item_select.length; i++) {
    if (state.item_select[i]) {
      currentLevel = i;
      selectedPath.push(state.item_select[i]);
    }
  }

  // 선택된 항목을 찾아 그 항목과 하위 구조만 반환
  function findSelectedItem(items, level = 0) {
    if (level >= selectedPath.length) { return null; }

    const selectedItem = items.find(
      item => item.name === selectedPath[level],
    );
    if (!selectedItem) { return null; }

    // 선택된 항목의 복사본 생성
    const result = { ...selectedItem };

    // 마지막 선택 레벨이 아니고 하위 항목이 있으면 재귀적으로 처리
    if (level < currentLevel && result.itemList?.length > 0) {
      const nextLevel = findSelectedItem(result.itemList, level + 1);
      if (nextLevel) {
        result.itemList = [nextLevel];
      }
    }

    return result;
  }

  const selectedItem = findSelectedItem(state.original_list);
  return selectedItem ? [selectedItem] : [];
});

watch(
  () => props.viewDepth,
  (newDepth) => {
    if (newDepth != null) {
      4;
      switch (newDepth) {
        case 2:
          state.item_select = state.item_select.map((_, i) =>
            i === 0 ? 'Implant' : null,
          );
          break;
        case 3:
          state.item_select = state.item_select.map((_, i) => {
            if (i === 1) { return 'Fixture'; }
            return i < 1 ? state.item_select[i] : null;
          });
          break;
        default:
          state.item_select = state.item_select.map((_, i) =>
            i === 0 ? '전체' : null,
          );
      }
    }
  },
);

watch(
  () => props.propsListItem,
  (newValue) => {
    state.item_list = [...newValue];
    state.original_list = [...newValue];
  },
);

watch(
  () => props.propsSelectItem,
  (newValue) => {
    state.item_select = newValue;
  },
);

function itemSelectAction(depth, name, item, grp) {
  if (depth === 0 && name === '전체') {
    state.item_select = state.item_select.map(() => null);
    state.item_select[0] = '전체';
  }
  else {
    const newSelect = state.item_select.map(() => null);

    for (let i = 0; i <= depth; i++) {
      if (i === depth) {
        newSelect[i] = name;
      }
      else {
        newSelect[i] = state.item_select[i];
      }
    }

    state.item_select = newSelect;
  }

  emit('selectItem', name, depth, grp);
}

function getContentRect(dom) {
  if (!dom) { return DOMRectReadOnly.fromRect(); }
  return dom.getBoundingClientRect();
}

// const listSlide = _.throttle((direction) => {
//   const outerEl = root.value;
//   const innerEl = filter.value;

//   if (!outerEl || !innerEl) { return; }

//   const { left: outerLeft, right: outerRight } = getContentRect(outerEl);
//   const {
//     left: innerLeft,
//     right: innerRight,
//     width: innerWidth,
//   } = getContentRect(innerEl);

//   let tx;
//   switch (direction) {
//     case 'prev':
//       if (outerLeft > innerLeft) {
//         tx = innerWidth * (index.value += 1) * (1 / 3);
//       }
//       break;
//     case 'next':
//       if (outerRight < innerRight) {
//         tx = innerWidth * (index.value -= 1) * (1 / 3);
//       }
//       break;
//   }

//   if (typeof tx === 'number') {
//     innerEl.style.transform = `translateX(${tx}px)`;
//   }
// }, 300);

const observer = new ResizeObserver((entries) => {
  for (const entry of entries) {
    const { width: outerWidth } = entry.contentRect;
    const { width: innerWidth } = getContentRect(filter.value);
    if (entry.target === root.value) {
      state.overflow = outerWidth < innerWidth;
    }
  }
});

onMounted(() => {
  if (root.value) {
    observer.observe(root.value);
  }
});

onUnmounted(() => {
  observer.disconnect();
});
</script>

<template>
      <div
        ref="root"
        class="ow-filter"
      >
        <!-- <button
          v-if="state.overflow"
          type="button"
          class="ow-filter-btn-move prev"
          @click="listSlide('prev')"
        >
          &lt;
        </button> -->
        <div
          ref="filter"
          class="ow-filter-cont"
        >
          <ul class="log_style_towdepth_radio">
            <li
              v-for="item in filteredItems"
              :key="item.name"
              :class="[
                state.item_select[0] == item.name ? 'active' : '',
                { 'has-arrow': item.itemList?.length > 0 },
              ]"
            >
              <button @click="itemSelectAction(0, item.name, item, item.grp)">
                {{ item.name }}
              </button>
              <ul v-if="item.itemList?.length > 0">
                <li
                  v-for="item2 in item.itemList"
                  :key="item2.name"
                  :class="[
                    state.item_select[1] == item2.name ? 'active' : '',
                    { 'has-arrow': item2.itemList?.length > 0 },
                  ]"
                >
                  <button
                    @click="itemSelectAction(1, item2.name, item2, item2.grp)"
                  >
                    {{ item2.name }}
                  </button>
                  <ul v-if="item2.itemList?.length > 0">
                    <li
                      v-for="item3 in item2.itemList"
                      :key="item3.name"
                      :class="[
                        state.item_select[2] == item3.name ? 'active' : '',
                        { 'has-arrow': item3.itemList?.length > 0 },
                      ]"
                    >
                      <button
                        @click="
                          itemSelectAction(2, item3.name, item3, item3.grp)
                        "
                      >
                        {{ item3.name }}
                      </button>
                      <ul v-if="item3.itemList?.length > 0">
                        <li
                          v-for="item4 in item3.itemList"
                          :key="item4.name"
                          :class="[
                            state.item_select[3] == item4.name ? 'active' : '',
                            { 'has-arrow': item4.itemList?.length > 0 },
                          ]"
                        >
                          <button
                            @click="
                              itemSelectAction(3, item4.name, item4, item4.grp)
                            "
                          >
                            {{ item4.name }}
                          </button>
                          <ul v-if="item4.itemList?.length > 0">
                            <li
                              v-for="item5 in item4.itemList"
                              :key="item5.name"
                              :class="[
                                state.item_select[4] == item5.name
                                  ? 'active'
                                  : '',
                                { 'has-arrow': item5.itemList?.length > 0 },
                              ]"
                            >
                              <button
                                @click="
                                  itemSelectAction(
                                    4,
                                    item5.name,
                                    item5,
                                    item5.grp,
                                  )
                                "
                              >
                                {{ item5.name }}
                              </button>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- <button
          v-if="state.overflow"
          type="button"
          class="ow-filter-btn-move next"
          @click="listSlide('next')"
        >
          &gt;
        </button> -->
      </div>
</template>

<style lang="scss" scoped>
.itemSelectAreaWrap {
  &.ow-flex-wrap {
    height: 100%;
    .ow-table-type-info {
      width: 180px;
    }
    th {
      background: #e7ecf2;
      box-shadow: 0 2px 4px 0 rgb(0 0 0 / 12%);
    }
    td {
      vertical-align: top;
    }
  }
  .allItemsGroupList {
    height: 100%;
    overflow-y: auto;
    li > Button {
      display: block;
      width: 100%;
      padding: 14px 8px;
      border-bottom: 1px solid #d7dce3;
      line-height: 18px;
      text-align: left;
      font-size: 13px;
      .subTxt {
        color: #999;
        font-size: 11px;
        display: inline-block;
      }
    }
    .active {
      background: #d4ecff;
    }
  }
}
.ow-filter {
  padding: 0;
  max-width: var(--maxWidth, 100%);
  .ow-filter-cont {
    white-space: nowrap;
  }
}

.log_style_towdepth_radio {
  align-items: center;
  display: flex;
  overflow: hidden;
  padding-left: 1px;
  background: #fff;
  margin-bottom: 0px;
}

.log_style_towdepth_radio li {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -1px;
  color: #333;
  background: #e1e6ea;
}

.log_style_towdepth_radio li a,
.log_style_towdepth_radio li button {
  float: left;
  display: block;
  border: 1px solid #e1e6ea;
  padding: 0 5px;
  font-weight: 700;
  letter-spacing: 0px;
  color: #333;
  line-height: 22px;
  margin-left: -1px;
  background: #e1e6ea;
}

.log_style_towdepth_radio li ul {
  display: none;
  overflow: hidden;
  padding: 0px 6px;
}

.log_style_towdepth_radio li ul a,
.log_style_towdepth_radio li ul button {
  line-height: 18px;
  border-radius: 2px;
}

.log_style_towdepth_radio li.active > a,
.log_style_towdepth_radio li.active > button {
  border-color: #176de2;
  background-color: #4e95f5;
  color: #fff;
  position: relative;
}

.log_style_towdepth_radio li.active:has(li) > a:after,
.log_style_towdepth_radio li.active:has(li) > button:after {
  content: "";
  position: absolute;
  height: 7px;
  width: 7px;
  right: -4px;
  background-color: #4e95f5;
  transform: translateY(100%) rotate(135deg);
  border-left: 1px solid #176de2;
  border-top: 1px solid #176de2;
}

.log_style_towdepth_radio li.active:hover > a,
.log_style_towdepth_radio li.active:hover > button {
  border-color: #176de2;
  background-color: #4e95f5;
}

.log_style_towdepth_radio li.active > ul:has(li) {
  display: inline-block;
}

.log_style_towdepth_radio li.active > ul:has(li) a:after,
.log_style_towdepth_radio li.active > ul:has(li) button:after {
  margin-top: -2px;
}

.log_style_towdepth_radio li.active:has(.active) > a,
.log_style_towdepth_radio li.active:has(.active) > button {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active:has(.active) > a:after,
.log_style_towdepth_radio li.active:has(.active) > button:after {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active + li a,
.log_style_towdepth_radio li.active + li button {
  margin-left: 0;
}

// .log_style_towdepth_radio li:hover > a,
// .log_style_towdepth_radio li:hover > button {
//   background-color: #fff;
// }

// .log_style_towdepth_radio > li > ul > li > ul {
//   background: #cad1da;
// }

// .log_style_towdepth_radio > li > ul > li > ul a,
// .log_style_towdepth_radio > li > ul > li > ul button {
//   background-color: #cad1da;
//   border-color: #cad1da;
// }

// .log_style_towdepth_radio > li > ul > li > ul > li > ul {
//   background: #bcc1c9;
// }

// .log_style_towdepth_radio > li > ul > li > ul > li > ul a,
// .log_style_towdepth_radio > li > ul > li > ul > li > ul button {
//   background-color: #bcc1c9;
//   border-color: #bcc1c9;
// }

// .log_style_towdepth_radio > li > ul > li > ul > li > ul > li > ul {
//   background: #b1bbc9;
// }

// .log_style_towdepth_radio > li > ul > li > ul > li > ul > li > ul a,
// .log_style_towdepth_radio > li > ul > li > ul > li > ul > li > ul button {
//   background-color: #b1bbc9;
//   border-color: #b1bbc9;
// }
</style>

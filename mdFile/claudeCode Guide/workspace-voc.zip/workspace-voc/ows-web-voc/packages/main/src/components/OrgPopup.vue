<script setup lang="ts">
import { ref } from 'vue';

// import { useFetch } from '@/composables/useFetch';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '조직도' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 400 },
  height: { type: Number, default: 200 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
});

const emit = defineEmits(['updateOrganization']);

const orgChart = ref(null);

const user = ref({
  corpCode: 'KR1',
  deptCode: 'O000000913',
  empNo: '',
  deptName: '',
  empName: '',
});

async function clickSave() {
  console.log(user.value);
  emit('updateOrganization', user.value);
}
</script>

<template>
  <OwPopup v-bind="props">
    <div>
      <BTableSimple
        responsive
        bordered="false"
        small
        class="ow-table-read"
      >
        <caption class="visually-hidden">
          TABLE TITLE
        </caption>
        <OwOrganizationChart
          v-model="user"
        />
      </BTableSimple>
      <div class="ow-popup-bottom fixed-bottom">
        <BButton
          size="md"
          variant="base base-gray"
          @click="props.onClose"
        >
          취소
        </BButton>
        <BButton
          id="btnOk"
          size="md"
          variant="base base-dark"
          @click="clickSave()"
        >
          확인
        </BButton>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
/* .b-table tbody>tr td {
    font-size: 14px
}

.b-table tbody>tr th {
    font-size: 14px
} */
.button-with-text {
  margin-right: 10px;
}

.image-section {
  display: flex;
  margin-bottom: 20px;
  gap: 15px;
}

.image-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: none;
}

.image-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  font-size: 48px;
  color: #6c757d;
}

.fixed-bottom {
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: white; /* Optional: to match the background */
  padding: 10px; /* Optional: to add some padding */
  box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1); /* Optional: to add a shadow */
}
</style>

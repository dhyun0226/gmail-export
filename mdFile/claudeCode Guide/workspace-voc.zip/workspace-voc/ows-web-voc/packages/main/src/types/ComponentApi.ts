import type { ChannelKey } from '@dns/core';
import type { TableItem } from 'bootstrap-vue-next';
import type { CategoryKey } from './Category';
import type { SearchText, SearchType } from './Search';

export interface Pageable {
/**
 * 페이지 번호
 */
  page?: number;
  /**
   * 페이지 번호
   *
   * @alias page
   */
  pageNo?: number;
  /**
   * 페이지 사이즈
   */
  size?: number;
  /**
   * 페이지 사이즈
   *
   * @alias size
   */
  pageSize?: number;
}

export interface Searchable {
/**
 * 검색 타입
 */
  searchType?: SearchType;
  /**
   * 검색어
   */
  query?: SearchText;
}

export interface Params extends Pageable, Searchable {
  /**
   * 채널 코드
   */
  channelDivisionCode?: ChannelKey;
  /**
   * 카테고리 코드
   */
  customerCenterCategoryCode?: CategoryKey;
}

export interface Data {
  /**
   * 채널 코드
   */
  channelDivisionCode: ChannelKey;
  /**
   * 카테고리 코드
   */
  customerCenterCategoryCode: CategoryKey;
}

export interface AttachFile {
  /**
   * 파일 ID
   */
  fileId: string;
  /**
   * 파일명
   */
  fileOriginalName: string;
  /**
   * 파일 확장자
   */
  fileExtensionName: string;
  /**
   * 파일 크기
   */
  fileSize: number;
}

export interface DenallTVVideoData {
  /**
   * 덴올TV동영상번호
   */
  denallTVVideoNumber: number;
  /**
   * 덴올TV동영상파일경로
   */
  denallTVVideoFilePath: string;
  /**
   * 덴올TV동영상섬네일파일경로
   */
  denallTVVideoThumbnailFilePath: string;
  /**
   * 덴올TV동영상이름
   */
  denallTVVideoName: string;
  /**
   * 덴올TV동영상설명
   */
  denallTVVideoDescription: string;
}

/****************
 * 공지사항
 ***************/
export interface NotifyParams extends Params {

}

export interface NotifyData extends Data {
  /**
   * 공지사항 순번
   */
  rownum: number;
  /**
   * 공지사항 번호
   */
  notifyNumber: number;
  /**
   * 공지사항 제목
   */
  notifyTitle: string;
  /**
   * 공지사항 내용
   */
  notifyContent?: string;
  /**
   * 상단 고정 여부
   */
  topFixedYesOrNo: 'Y' | 'N';
  /**
   * 파일 첨부 여부
   */
  fileAttachYn?: 'Y' | 'N';
  /**
   * 첨부 파일 목록
   */
  fileId?: AttachFile[];
  /**
   * 덴올TV동영상목록
   */
  denallTVVideoList?: DenallTVVideoData[];
  /**
   * 조회수
   */
  inquiryCount: number;
  /**
   * 등록일
   */
  notifyRegistrationDatetime: Array<number>;
  // /**
  //  * 이전 공지사항
  //  */
  // previous?: Pick<NoticeData, 'noticeSequenceNumber' | 'noticeTitle' | 'date'>;
  // /**
  //  * 다음 공지사항
  //  */
  // next?: Pick<NoticeData, 'noticeSequenceNumber' | 'noticeTitle' | 'date'>;
}

export interface NoticeContentParams extends Pick<NotifyData, 'notifyNumber'> {

}

/**
 * NoticeData 정규화
 */
export interface NotifyNormalizedData {
  /**
   * 공지사항 ID
   */
  id: number;
  /**
   * 공지사항 제목
   */
  title: string;
  /**
   * 공지사항 내용
   */
  content?: string;
  /**
   * 공지사항 첨부 파일 목록
   */
  files?: AttachFile[];
  /**
   * 덴올TV동영상목록
   */
  denallTVVideoList?: DenallTVVideoData[];
  /**
   * 공지사항 등록일
   */
  date?: string;
  /**
   * 공지사항 고정 여부
   */
  isPinned?: boolean;
  // /**
  //  * 이전 공지사항
  //  */
  // prev?: Pick<NoticeNormalizedData, 'id' | 'title' | 'date'>;
  // /**
  //  * 이전 공지사항
  //  */
  // next?: Pick<NoticeNormalizedData, 'id' | 'title' | 'date'>;
}

/****************
 * FAQ
 ***************/
export interface FrequentlyAskedQuestionsParams extends Params {

}

export interface FrequentlyAskedQuestionsData extends Data {
  /**
   * FAQ 번호
   */
  faqSequenceNumber: number;
  /**
   * FAQ 제목
   */
  faqTitle: string;
  /**
   * FAQ 내용
   */
  faqContent?: string;
  /**
   * FAQ 파일 첨부 여부
   */
  fileAttachYn: 'Y' | 'N';
  /**
   * FAQ 첨부 파일 목록
   */
  attachedFiles?: AttachFile[];
  /**
   * 조회수
   */
  hit: number;
  /**
   * 등록일
   */
  date: string;
}

export interface FrequentlyAskedQuestionsContentParams extends Pick<FrequentlyAskedQuestionsData, 'faqSequenceNumber'> {

}

/**
 * FrequentlyAskedQuestionsData를 정규화
 */
export interface FrequentlyAskedQuestionsNormalizedData {
  /**
   * FAQ ID
   */
  id: number;
  /**
   * FAQ 제목
   */
  title: string;
  /**
   * FAQ 내용
   */
  content?: string;
  /**
   * FAQ 첨부 파일 목록
   */
  files?: AttachFile[];
}

export type FrequentlyAskedQuestionsNormalizedTableItem = TableItem<FrequentlyAskedQuestionsNormalizedData>;

/****************
 * 문의
 ***************/
export interface QuestionAnswerParams extends Params {

}

export interface QuestionAnswerData extends Omit<Data, 'customerCenterCategoryCode'> {
  /**
   * 문의 번호
   */
  qnaSequenceNumber: number;
  /**
   * 문의 카테고리 코드
   */
  customerCenterCategorizationCode: string;
  /**
   * 문의 카테고리 코드명
   */
  customerCenterCategorizationCodeName: string;
  /**
   * 문의 답변 여부(Y: 답변완료, N: 문의접수)
   */
  answerStatusCode: 'Y' | 'N';
  /**
   * 문의 질문 제목
   */
  questionTitle: string;
  /**
   * 문의 질문 내용
   */
  questionContent?: string;
  /**
   * 문의 답변 내용
   */
  answerContent?: string;
  /**
   * 문의 파일 첨부 여부
   */
  fileAttachYn?: 'Y' | 'N';
  /**
   * 문의 첨부 파일 목록
   */
  fileList?: AttachFile[];
  /**
   * 문의 공개 여부
   */
  openYn: 'Y' | 'N';
  /**
   * 문의 작성일
   */
  writeDtm: string;
  /**
   * 문의 작성자
   */
  writerId: string;
  /**
   * 문의 답변일
   */
  finalAnswerDtm?: string;
  /**
   * 문의 조회수
   */
  hit: number;
}

export interface QuestionAnswerNewData {
  /**
   * 문의 카테고리 코드
   */
  customerCenterCategorizationCode: string;
  /**
   * 문의 질문 제목
   */
  questionTitle: string;
  /**
   * 문의 질문 내용
   */
  questionContent: string;
  /**
   * 문의 파일 첨부 여부
   */
  fileAttachYn: 'Y' | 'N';
  /**
   * 문의 첨부 파일 목록
   */
  fileList?: AttachFile[];
  /**
   * 문의 공개 여부
   */
  openYn: 'Y' | 'N';
}

export interface QuestionAnswerContentParams extends Pick<QuestionAnswerData, 'qnaSequenceNumber'> {

}

/**
 * QuestionAnswerData 정규화
 */
export interface QuestionAnswerNormalizedData {
  /**
   * 문의 ID
   */
  id: number;
  /**
   * 문의 유형
   */
  type: string;
  /**
   * 문의 제목
   */
  title: string;
  /**
   * 문의 내용
   */
  content?: string;
  /**
   * 문의 첨부 파일 목록
   */
  files?: AttachFile[];
  /**
   * 문의 등록일
   */
  date: string;
  /**
   * 문의 등록자
   */
  writer: string;
  /**
   * 문의 비밀글 여부
   */
  isPrivate?: boolean;
  /**
   * 문의 답변 여부
   */
  isAnswered?: boolean;
  /**
   * 문의 답변
   */
  answer?: Pick<QuestionAnswerNormalizedData, 'content' | 'date'>;
}

export interface QuestionAnswerNormalizedNewData {
  /**
   * 문의 유형
   */
  type: string;
  /**
   * 문의 제목
   */
  title: string;
  /**
   * 문의 내용
   */
  content: string;
  /**
   * 문의 첨부 파일 목록
   */
  files: AttachFile[];
  /**
   * 문의 공개 여부
   */
  isOpen: boolean;
}

/****************
 * 1:1문의
 ***************/
export interface InquiryNewData {
  /**
   * 1:1문의 채널 코드
   */
  channelDivisionCode?: string;
  /**
   * 1:1문의 카테고리 코드
   */
  customerCenterCategorizationCode: string;
  /**
   * 1:1문의 로그인 여부
   */
  loginYn: 'Y' | 'N';
  /**
   * 1:1문의 작성자명
   */
  writerName: string;
  /**
   * 1:1문의 작성자 이메일
   */
  writerEmail: string;
  /**
   * 1:1문의 전화번호
   */
  telephoneNo?: string;
  /**
   * 1:1문의 휴대전화번호
   */
  handphoneNo: string;
  /**
   * 1:1문의 질문 제목
   */
  questionTitle: string;
  /**
   * 1:1문의 질문 내용
   */
  questionContent: string;
  /**
   * 1:1문의 파일 첨부 여부
   */
  fileAttachYn: 'Y' | 'N';
  /**
   * 1:1문의 첨부 파일 목록
   */
  fileList?: AttachFile[];
  /**
   * 1:1문의 약관 ID
   */
  termsId?: string;
  /**
   * 1:1문의 약관 동의
   */
  termsAgreement: 'Y' | 'N';
}

export interface InquiryNormalizedNewData {
  /**
   * 1:1문의 유형
   */
  type: string;
  /**
   * 1:1문의 이름
   */
  name: string;
  /**
   * 1:1문의 이메일
   */
  email: string;
  /**
   * 1:1문의 전화번호
   */
  phone?: string;
  /**
   * 1:1문의 휴대전화번호
   */
  mobile: string;
  /**
   * 1:1문의 제목
   */
  title: string;
  /**
   * 1:1문의 내용
   */
  content: string;
  /**
   * 1:1문의 첨부 파일 목록
   */
  files: AttachFile[];
  /**
   * 1:1문의 선택 약관 동의 여부
   */
  isTermsAgreed: boolean;
}

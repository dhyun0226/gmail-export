<script setup>
import { BButton } from 'bootstrap-vue-next';
import { computed, ref } from 'vue';
import { useColumnPopup } from '@/composables/useColumnPopupStore';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '컬럼 추가' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
});

const columnPopupStore = useColumnPopup();
const columns = ref(columnPopupStore.columns);

const transformedColumns = computed(() => {
  return columns.value.map(col => ({
    text: col.caption,
    value: col.caption,
  }));
});

function change(value) {
  console.log('change', value);
  columnPopupStore.setSelectedColumns(value);
}

// const options = ref([
//   { text: '과제', value: 'ASGN' },
//   { text: '회의', value: 'MEET' },
//   { text: '업무', value: 'OWAY' },
//   { text: '휴가', value: 'VCTN' },
//   { text: '교육', value: 'EDUC' },
//   { text: '출장', value: 'BSTR' },
// ]);
</script>

<template>
  <OwPopup >
<!--  <OwPopup v-bind="props">-->
    <div class="popup-content">
      <div>
        <OwFormCheckbox
          v-model="columnPopupStore.selectedColumns"
          :options="transformedColumns"
          shape="text"
          action-type="input"
          class="line"
          type="normal"
          @change="change"
        />
      </div>
      <div class="button-container">
        <BButton
          style="margin-top: 10px"
          size="md"
          variant="base base-gray"
          @click="props.onClose"
        >
          닫기
        </BButton>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
.button-container {
  display: flex; /* Flexbox 사용 */
  justify-content: center; /* 수평 중앙 */
  align-items: center; /* 수직 중앙 */
  margin-top: 10px; /* 버튼와 checkbox 간의 간격 */
}
</style>

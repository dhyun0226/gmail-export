<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { onMounted, ref } from 'vue';
import { useApi, useCommonCode, useFileDownload, useUserProfile } from '@ows/core';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import OrgPopup from '@/components/OrgPopup.vue';
import type { VocFile } from '@/types/voc';
import type { EventResponse, PaginatedResponse } from '@/types';
import { getFileIcon, isImageFile } from '@/types/inquiry';
import FilePopupInput from '@/components/FilePopupInput.vue'; // 파일 첨부 컴포넌트 import
import { dateUtils } from '@/utils';
import DxListNGrid from '@/components/DxListNGrid.vue';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '문의 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  qnaNumber: { type: Number },
  eventItemCategoryCode: { type: Object },
  vocCategoryCode: { type: Object },
  vocCategoryName: { type: String },
  disabledSelect: { type: Boolean, default: false },
});

const emit = defineEmits(['save-event', 'edit-event']); // edit-event 이벤트 추가
const { currentUser } = useUserProfile();

// 공통 코드 로드
const { VOC_STACD: vocStatuses, VOC_CMPL_TYCD: vocTypes, VOC_RGST_DTL_DVCD: vocRegistrationDetailDivisionCodeGroup } = await useCommonCode(
  'VOC_STACD',
  'VOC_CMPL_TYCD',
  'VOC_RGST_DTL_DVCD',
);

const api = useApi();
const { image } = useFileDownload();
const user = ref('');

const selectedProcessType = ref('01');
const reasonText = ref('');

const editable = ref(true);
const content = ref('');

const listServiceGroup = ref('');
const listServiceGroupOptions = [
  { text: 'TV', value: 'D001_QNA' },
  { text: 'Mall', value: 'D002_QNA' },
  { text: 'Education', value: 'D003_QNA' },
  { text: 'Job', value: 'D004_QNA' },
  { text: 'Software', value: 'D005_QNA' },
  { text: 'Platform', value: 'D006_QNA' },
];
const detailedDivisionCode = ref('');
const detailedDivisionCodeOptions = [
  // { text: '문의', value: 'D004_QNA' },
  // { text: '구직', value: 'D004_QNA_001' },
  // { text: '구인', value: 'D004_QNA_002' },
  // { text: '이벤트', value: 'D004_QNA_003' },
  // { text: '장애/오류신고', value: 'D004_QNA_004' },
  // { text: '불량정보신고', value: 'D004_QNA_005' },
  // { text: '건의/불만사항', value: 'D004_QNA_006' },
  // { text: '기타', value: 'D004_QNA_999' },
  // { text: '문의', value: 'D005_QNA' },
  // { text: '두번에/하나로', value: 'D005_QNA_001' },
  // { text: 'OneClick', value: 'D005_QNA_002' },
  // { text: '보험정보', value: 'D005_QNA_003' },
  // { text: 'V-Ceph', value: 'D005_QNA_004' },
  // { text: 'One2', value: 'D005_QNA_005' },
  // { text: 'One3', value: 'D005_QNA_006' },
];

const useSettingGroup = ref('Y');
const useSettingGroupOptions = [
  { text: '공개', value: 'Y' },
  { text: '비공개', value: 'N' },
];

const topFixedSettingGroup = ref('N');
const topFixedSettingGroupOptions = [
  { text: '고정', value: 'Y' },
  { text: '해제', value: 'N' },
];

const dateFormRangeFrom = ref(dayjs().format('YYYY-MM-DD'));
const dateFormRangeTo = ref(dayjs().format('YYYY-MM-DD'));

// 값 변경 핸들러
function handleChange(value) {
  // console.log('값 변경:', value);
}

function change(value) {
  // console.log('라디오 버튼 변경:', value);

}

// 날짜 포맷 함수
function formatDate(dateString: string): string {
  return dateUtils.formatDateWithSeparator(dateString, '.', false);
}

// qna 응답 데이터
const responseData = ref<Partial<EventResponse>>({});
const qnaTitle = ref('');
const qnaContent = ref('');
const qnaAnswers = ref('');
const fileList = ref<VocFile[]>([]);
const files = ref([]);
const thumbnailFile = ref<VocFile[]>([]);

// qna 답변 데이터 불러오기
async function fetchQnaData() {
  try {
    const { data } = await api.get<PaginatedResponse>(
      `/voc/qnas/${props.qnaNumber}`,
      {
        params: {
          vocCategoryCode: props.vocCategoryCode,
          channelCode: null,
        },
      },
    );

    responseData.value = data;
    qnaTitle.value = data.qnaTitle || '';
    qnaContent.value = data.qnaContent || '';
    fileList.value = data.fileList || [];

    gridOption.value.datas = data.answers || [];
    dateFormRangeFrom.value = data.eventStartDatetime || '';
    dateFormRangeTo.value = data.eventEndDatetime || '';
    files.value = data.fileList || [];
    thumbnailFile.value = data.thumbnailFile || [];
    gridOption.value.paging.totalItemCount = data.eventAnswerTotalCount || 0;
    topFixedSettingGroup.value = data.topFixedYesOrNo || 'N';
    // console.log('이벤트 데이터:', data);
  }
  catch (error) {
    responseData.value = {};
  }
}

// 조직 팝업 관련
const {
  openPopup: openOrgPopup,
  closePopup: closeOrgPopup,
  isPopupOpen: isOrgPopupOpen,
} = useOwPopup();

// 사용자 선택 처리
function handleUpdateOrganization(item) {
  user.value = item;
  closeOrgPopup();
}

// 저장 처리
async function clickSave() {
  // 필수 입력 검증
  if (!qnaTitle.value?.trim()) {
    alert('문의 제목을 입력해주세요.');
    return;
  }

  if (!qnaContent.value?.trim()) {
    alert('이벤트 내용을 입력해주세요.');
    return;
  }

  if (!detailedDivisionCode.value) {
    alert('상세구분을 선택해주세요.');
    return;
  }

  const params = {
    vocCategoryCode: listServiceGroup.value,
    qnaTitle: qnaTitle.value,
    qnaContent: qnaContent.value,
    eventStartDatetime: dateUtils.toLocalDateTime(dateFormRangeFrom.value),
    eventEndDatetime: dateUtils.toLocalDateTime(dayjs(dateFormRangeTo.value).hour(23).minute(59).second(59)),
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    useYesOrNo: useSettingGroup.value,
    topFixedYesOrNo: topFixedSettingGroup.value,
    fileList: files.value?.length > 0 ? files.value : null,
    thumbnailFile: thumbnailFile.value ? thumbnailFile.value : null,
  };

  try {
    const { data } = await api.post('/voc/events', params);
    emit('save-event', data);
    // console.log('저장 성공:', data);
    alert('이벤트가 등록되었습니다.');
    if (props.onClose) { props.onClose(); }
  }
  catch (error) {
    console.error('event 저장 오류:', error);
    alert('이벤트 저장 중 오류가 발생했습니다.');
  }
}

// 수정 처리
async function clickEdit() {
  // 필수 입력 검증
  if (!qnaTitle.value?.trim()) {
    alert('문의 제목을 입력해주세요.');
    return;
  }

  if (!qnaContent.value?.trim()) {
    alert('이벤트 내용을 입력해주세요.');
    return;
  }

  if (!detailedDivisionCode.value) {
    alert('상세구분을 선택해주세요.');
    return;
  }

  const params = {
    vocCategoryCode: listServiceGroup.value,
    eventRegistrationDatetime: responseData.value.eventRegistrationDatetime,
    qnaTitle: qnaTitle.value,
    qnaContent: qnaContent.value,
    eventStartDatetime: dateUtils.toLocalDateTime(dateFormRangeFrom.value),
    eventEndDatetime: dateUtils.toLocalDateTime(dayjs(dateFormRangeTo.value).hour(23).minute(59).second(59)),
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    useYesOrNo: useSettingGroup.value,
    topFixedYesOrNo: topFixedSettingGroup.value,
    eventParticipationDivisionCode: listCategoryGroup.value,
    inquiryCount: responseData.value.inquiryCount,
    fileList: files.value?.length > 0 ? files.value : null,
    thumbnailFile: thumbnailFile.value ? thumbnailFile.value : null,
  };

  // console.log(params, 'params');

  try {
    const { data } = await api.put(`/voc/events/${props.qnaNumber}`, params);
    emit('edit-event', data);
    // console.log('수정 성공:', data);
    alert('이벤트가 수정되었습니다.');
    if (props.onClose) { props.onClose(); }
  }
  catch (error) {
    console.error('event 저장 오류:', error);
    alert('이벤트 수정 중 오류가 발생했습니다.');
  }
}

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 1,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const columns = ref([
  {
    caption: '댓글 내용',
    width: '*',
    dataField: 'qnaAnswerContent',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '작성자',
    width: '100',
    dataField: 'answererMemberId',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록일시',
    width: '100',
    dataField: 'qnaAnswerDatetime',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '삭제',
    width: '60',
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
]);

async function deleteAnswer(eventAnswer) {
  if (confirm('정말 삭제하시겠습니까?')) {
    const params = {
      qnaNumber: responseData.value.qnaNumber,
      eventParticipationDatetime: eventAnswer.eventParticipationDatetime,
    };
    try {
      const { data } = await api.delete('/voc/event-answers', { data: params });
      // console.log('답변 삭제 성공:', data);
    }
    catch (error) {
      console.error('답변 삭제 오류:', error);
    }
    fetchQnaData();
  }
}

onMounted(async () => {
  try {
    // vocCtg 데이터 가져오기
    const vocCtgResponse = await api.get('/voc/serviceCategories');
    const vocCtgs = vocCtgResponse.data;

    // 채널 설정
    const matchedChannel = listServiceGroupOptions.find(option =>
      props.vocCategoryCode.includes(option.value),
    );
    if (matchedChannel) {
      listServiceGroup.value = matchedChannel.value;
    }

    // 상세구분 데이터 가공
    if (listServiceGroup.value) {
      const filteredCtgs = vocCtgs.filter(ctg =>
        ctg.vocCategoryCode.includes(listServiceGroup.value),
      );

      detailedDivisionCodeOptions.length = 0; // 기존 옵션 초기화
      filteredCtgs.forEach((ctg) => {
        detailedDivisionCodeOptions.push({
          text: ctg.vocCategoryName,
          value: ctg.vocCategoryCode,
        });
      });

      // console.log('detailedDivisionCodeOptions:', detailedDivisionCodeOptions);
    }

    // 상세구분 설정 (옵션이 설정된 후 값 설정)
    if (props.vocCategoryCode) {
      detailedDivisionCode.value = props.vocCategoryCode;
    }
    else {
      console.warn('vocCategoryCode 값이 비어 있습니다.');
      detailedDivisionCode.value = ''; // 기본값 설정
    }

    if (props.disabledSelect) {
      fetchQnaData();
    }

    // console.log('detailedDivisionCode:', detailedDivisionCode.value);
  }
  catch (error) {
    console.error('vocCtg 데이터 가져오기 실패:', error);
  }
});
</script>

<template>
  <OwPopup v-bind="props">
    <div class="d-flex">
      <div
        class="voc-detail-container"
        style="flex: 3;"
      >
        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            event 상세 정보
          </caption>
          <colgroup>
            <col width="130px">
            <col>
            <col width="130px">
            <col>
          </colgroup>
          <BTbody>
            <BTr>
              <BTh>채널</BTh>
              <BTd>
                <div>
                  <BFormSelect
                    v-model="listServiceGroup"
                    :options="listServiceGroupOptions"

                    :disabled="disabledSelect"
                    class="ow-select"
                    @change="handleChange"
                  />
                </div>
              </BTd>
              <BTh>상세구분</BTh>
              <BTd>
                <div>
                  <BFormSelect
                    v-model="detailedDivisionCode"
                    :options="detailedDivisionCodeOptions"
                    :key="detailedDivisionCodeOptions.length"
                    class="ow-select detail-select"
                    :disabled="disabledSelect"
                    placeholder="등록구분 선택 후 선택 가능"
                    @change="handleChange"
                  />
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh class="required">
                공개여부 설정
              </BTh>
              <BTd>
                <OwFormRadio
                  id="rdo02"
                  v-model="useSettingGroup"
                  :options="useSettingGroupOptions"
                  @change="change"
                />
              </BTd>
              <BTh class="required">
                파일 첨부
              </BTh>
              <BTd colspan="3">
                <div
                  class="input-group"
                  role="group"
                >
                  <!-- 파일 첨부 컴포넌트 적용 - 썸네일 -->
                  <FilePopupInput
                    v-model="thumbnailFile"
                    :max-files="1"
                    :max-file-size="5"
                    help-text="썸네일"
                  />
                </div>
              </BTd>
            </BTr>

            <BTr />
            <BTr>
              <BTh class="required">
                문의 제목
              </BTh>
              <BTd colspan="3">
                <div
                  class="input-group"
                  role="group"
                >
                  <input
                    id="form02"
                    v-model="qnaTitle"
                    class="form-control ow-form-control noline"
                    type="text"
                    placeholder="제목을 입력해주세요."
                  >
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh class="required">
                문의 내용
              </BTh>
              <BTd colspan="3">
                <div
                  class="input-group"
                  role="group"
                >
                  <input
                    id="form02"
                    v-model="qnaContent"
                    class="form-control ow-form-control noline"
                    type="text"
                    placeholder="제목을 입력해주세요."
                  >
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div style="height: 40vh">
          <OwTinyEditor
            v-model="qnaAnswers"
            :editable="editable"
            :enable-insert-image="true"
            :enable-insert-media="false"
            placeholder="내용을 입력해주세요."
          />
        </div>

        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            이벤트 상세 정보
          </caption>
          <colgroup>
            <col width="130px">
            <col>
          </colgroup>
          <BTbody>
            <BTr>
              <BTh>파일 첨부</BTh>
              <BTd colspan="4">
                <div
                  class="input-group"
                  role="group"
                >
                  <!-- 파일 첨부 컴포넌트 적용 - 일반 파일 -->
                  <FilePopupInput
                    v-model="files"
                    :max-files="3"
                    :max-file-size="5"
                    help-text="파일"
                  />
                </div>
              </BTd>
            </BTr>

            <BTr
              v-if="props.disabledSelect && fileList && fileList.length > 0"
              style="height: 90px"
            >
              <BTh>첨부된 파일</BTh>
              <BTd colspan="4">
                <div class="voc-file-container">
                  <div class="file-list">
                    <div
                      v-for="file in fileList"
                      :key="file.fileId"
                      class="file-item"
                    >
                      <template v-if="isImageFile(file.fileExtensionName)">
                        <img
                          :src="image(file.fileId, 90, 90)"
                          class="file-image"
                          :alt="file.fileOriginalName"
                        >
                      </template>
                      <div
                        v-else
                        class="file-icon"
                      >
                        <i :class="getFileIcon(file.fileExtensionName)" />
                        <span class="file-name">{{ file.fileOriginalName }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div class="ow-popup-bottom">
          <BButton
            size="md"
            variant="base base-gray"
            @click="props.onClose"
          >
            취소
          </BButton>
          <BButton
            v-if="!props.disabledSelect"
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickSave"
          >
            확인
          </BButton>
          <BButton
            v-if="props.disabledSelect"
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickEdit"
          >
            답변
          </BButton>
        </div>
      </div>

      <!-- 댓글 테이블 -->
      <div
        v-if="props.disabledSelect"
        class="voc-detail-container"
        style="flex: 1;"
      >
        <DxListNGrid
          :n-grid-count="gridOption.nGridCount"
          :show-gap="false"
          :all-datas="gridOption.datas"
          :columns="columns"
          :paging="gridOption.paging"
          :height="gridOption.height"
          :selection="gridOption.selection"
          :is-show-pagination="true"
        >
          <template #customize="{ data: cell }">
            <div>
              {{ formatDate(cell.data.vocRegistrationDateTime) }}
            </div>
          </template>

          <template #customize2="{ data: cell }">
            <div>
              {{ formatDate(cell.data.eventParticipationDatetime) }}
            </div>
          </template>

          <template #customize3="{ data: cell }">
            <div>
              <BButton
                variant="box-delete"
                @click.stop="deleteAnswer(cell.data)"
              />
            </div>
          </template>
        </DxListNGrid>
      </div>
    </div>

    <!-- 조직 선택 팝업 -->
    <Teleport to="body">
      <OrgPopup
        v-if="isOrgPopupOpen"
        :is-popup-open="isOrgPopupOpen"
        :on-close="closeOrgPopup"
        :height="700"
        @update-organization="handleUpdateOrganization"
      />
    </Teleport>
  </OwPopup>
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  vertical-align: middle;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}

.detail-select {
  min-width: 180px;
}
</style>

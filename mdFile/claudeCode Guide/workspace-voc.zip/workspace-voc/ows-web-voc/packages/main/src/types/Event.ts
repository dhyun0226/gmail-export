/**
 * 이벤트 응답 데이터를 나타내는 인터페이스
 */
export interface EventResponse {
  /** 이벤트 번호 */
  eventNumber: number;
  /** 이벤트 등록 구분 코드 */
  eventRegistrationDivisionCode: string;
  /** 이벤트 등록 상세 구분 코드 */
  eventRegistrationDetailDivisionCode: string;
  /** 이벤트 제목 */
  eventTitle: string;
  /** 이벤트 내용 */
  eventContent: string;
  /** 등록자 회사 코드 */
  registererCorporationCode: string;
  /** 등록자 부서 코드 */
  registererDepartmentCode: string;
  /** 등록자 사번 */
  registererEmployeeNumber: string;
  /** 이벤트 시작 일시 */
  eventStartDatetime: string;
  /** 이벤트 종료 일시 */
  eventEndDatetime: string;
  /** 사용 여부 */
  useYn: string;
  /** 이벤트 참여 구분 코드 */
  eventParticipationDivisionCode: string;
  /** 파일 ID */
  fileId: string;
  /** 파일 목록 */
  fileList: FileInfo[];

  eventAnswer: EventAnswer[];

}

// 백엔드 파일 정보 인터페이스
export interface FileInfo {
  fileId: string;
  filePath?: string;
  referenceOwTaskCode?: string | null;
  referenceTableName?: string | null;
  referenceDistinguishColumnValueContent?: string | null;
  fileOriginalName: string;
  fileExtensionName: string;
  fileSize: string | number;
  fileUrl?: string;
}

export interface EventAnswer {

  eventParticipationDatetime: string;
  participantMemberId: string;
  eventParticipationContent: string;

}

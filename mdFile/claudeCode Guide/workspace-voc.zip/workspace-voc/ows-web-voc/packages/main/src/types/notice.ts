export interface NoticeItem {
  noticeNumber: number;
  noticeRegistrationDivisionCode: string;
  noticeRegistrationDetailDivisionCode: string;
  openYn: string;
  topFixedYn: string;
  noticeTitle: string;
  noticeContent: string;
  registererCorporationCode: string;
  registererDepartmentCode: string;
  registererEmployeeNumber: string;
  noticeRegistrationDatetime: string;
  inquiryCount: number;
  previousNotices: NoticeItem;
  nextNotices: NoticeItem;
}

export interface NoticeAttachment {
  id: number;
  name: string;
  url: string;
  fileSize: number;
}

export interface NoticeDetail extends NoticeItem {
  content: string;
  attachments?: NoticeAttachment[];
}

export interface Pagination {
  currentPage: number;
  totalPages: number;
  totalItems: number;
}

export interface NoticeState {
  noticeItems: NoticeItem[];
  pagination: Pagination;
  isLoading: boolean;
  error: string | null;
};

// 페이징 정보를 포함한 응답 타입
export interface PaginatedResponse {
  data: NoticeItem[];
  totalCount: number;
}

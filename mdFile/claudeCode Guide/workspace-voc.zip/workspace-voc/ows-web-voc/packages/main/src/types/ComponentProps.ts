import type { AttachFile } from './ComponentApi';

// Button

// ButtonGroup
export interface CategoryButtonGroupProps {

}

export interface ChannelButtonGroupProps {
  action?: boolean;
  replace?: boolean;
}

export interface ServiceButtonGroupProps {

}

export interface SubCategoryButtonGroupProps {

}

export interface FileInputGroupProps {
  count?: number | string;
  modelValue?: AttachFile | AttachFile[];
  multiple?: boolean;
  size?: number | string;
}

// Card
export interface AgreementCardProps {
  /**
   * 수집 항목
   */
  collectionItems: string | string[];
  /**
   * 수집 및 이용 목적
   */
  collectionPurpose: string;
  /**
   * 보유 및 이용 기간
   */
  retentionPeriod: string;
  /**
   * 추가 내용
   */
  additionalInfos?: string[];
}

export interface OptionalAgreementCardProps {
  modelValue?: boolean;
}

export interface RequiredAgreementCardProps {
  modelValue?: boolean;
}

// InputGroup
export interface PhoneNumberInputGroupProps {
  modelValue?: string;
}

export interface SearchInputGroupProps {

}

export interface FileListGroupProps {
  files?: AttachFile[];
}

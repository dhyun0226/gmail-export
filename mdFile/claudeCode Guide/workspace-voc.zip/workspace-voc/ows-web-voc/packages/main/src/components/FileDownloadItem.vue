<script setup lang="ts">
import { useDialog, useFileDownload, useOverlay } from '@ows/core';
import type { FileInfo } from '@/types/inquiry.ts';

const props = defineProps<{
  file: FileInfo;
  index: number;
}>();

const { show, hide } = useOverlay();
const { alert } = useDialog();
const { link } = useFileDownload();

function decodeFileName(fileName: string): string {
  try {
    return decodeURIComponent(fileName);
  }
  catch {
    return fileName;
  }
}

/**
 * 파일 확장자에 따른 Bootstrap Icon 클래스를 반환
 * @param extension 파일 확장자 (소문자)
 */
function getFileIconByExtension(extension: string): string {
  const ext = extension.toLowerCase();

  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)) {
    return 'bi-file-earmark-image';
  }
  if (['xlsx', 'xls', 'csv'].includes(ext)) {
    return 'bi-file-earmark-excel';
  }
  if (['pdf'].includes(ext)) {
    return 'bi-file-earmark-pdf';
  }
  if (['txt', 'md', 'json', 'log'].includes(ext)) {
    return 'bi-file-earmark-text';
  }
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
    return 'bi-file-earmark-zip';
  }
  if (['doc', 'docx'].includes(ext)) {
    return 'bi-file-earmark-word';
  }
  if (['ppt', 'pptx'].includes(ext)) {
    return 'bi-file-earmark-slides';
  }
  if (['mp4', 'avi', 'mov', 'mkv'].includes(ext)) {
    return 'bi-file-earmark-play';
  }
  return 'bi-file-earmark'; // 기본 파일 아이콘
}

function extractFileNameFromHeader(contentDisposition: string): string | null {
  const utf8Match = contentDisposition.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match) {
    return decodeURIComponent(utf8Match[1]);
  }
  const normalMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
  if (normalMatch) {
    return decodeFileName(normalMatch[1].replace(/['"]/g, ''));
  }
  return null;
}

async function downloadFile() {
  try {
    show();
    const response = await fetch(link(props.file.fileId,'DEN'), { credentials: 'include' });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const blob = await response.blob();

    let fileName = props.file.fileOriginalName || `file_${props.file.fileId}`;
    const contentDisposition = response.headers.get('content-disposition');
    if (contentDisposition) {
      const extractedName = extractFileNameFromHeader(contentDisposition);
      if (extractedName) {
        fileName = extractedName;
      }
    }
    else {
      fileName = decodeFileName(fileName);
    }
    if (!fileName.includes('.') && props.file.fileExtensionName) {
      fileName += `.${props.file.fileExtensionName}`;
    }

    const url = window.URL.createObjectURL(blob);
    const linkEl = document.createElement('a');
    linkEl.href = url;
    linkEl.download = fileName;
    document.body.appendChild(linkEl);
    linkEl.click();
    document.body.removeChild(linkEl);
    window.URL.revokeObjectURL(url);
  }
  catch (error) {
    console.error('파일 다운로드 실패:', error);
    alert('파일 다운로드 중 오류가 발생했습니다.');
  }
  finally {
    hide();
  }
}
</script>

<template>
  <div
      class="file-download-item clickable"
      @click="downloadFile"
  >
    <i :class="`${getFileIconByExtension(file.fileExtensionName)} me-1`" />
    <span class="file-name">{{ decodeFileName(file.fileOriginalName) }}.{{ file.fileExtensionName }}</span>
  </div>
</template>

<style scoped>
.file-download-item {
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.file-download-item:hover {
  background-color: #f1f3f5;
}
.file-name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
  max-width: 120px; /* 필요시 조정 */
}
</style>

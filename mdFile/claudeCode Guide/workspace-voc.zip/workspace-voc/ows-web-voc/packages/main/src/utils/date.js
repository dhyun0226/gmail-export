import { toWeekObject } from '@ows/ui';
import dayjs from 'dayjs';
import 'dayjs/locale/ko';
import quarterOfYear from 'dayjs/plugin/quarterOfYear';
import weekOfYear from 'dayjs/plugin/weekOfYear';

dayjs.locale('ko');
dayjs.extend(quarterOfYear);
dayjs.extend(weekOfYear);
// day	d	낮
// week	w	올해의 주
// quarter	Q	4분의 1
// month	M	월(1월은 0, 12월은 11)
// quarter Q
// half
// year	y	년도
// hour	h	시간
// minute	m	분
// second	s	두번째
// millisecond	ms	밀리초\
const YEAR_MONTH_DAY_LONG_TIME = 'YYYY-MM-DD HH:mm:ss';
const YEAR_MONTH_DAY_TIME = 'YYYY-MM-DD HH:mm';
const YEAR_MONTH_DAY = 'YYYY-MM-DD';
const YEAR_MONTH_DAY_PERIOD = 'YYYY.MM.DD';
const YEAR_MONTH = 'YYYY-MM';
const SHORT_YEAR_MONTH = 'YY-MM';
const SHORT_YEAR_MONTH_DAY = 'YY-MM-DD';
const SHORT_YEAR_MONTH_DAY_TIME = 'YY-MM-DD HH:mm';
const MONTH_DAY = 'MM-DD';
const MONTH_DAY_TIME = 'MM-DD HH:mm';
const MONTH_DAY_D = 'MM-DD(ddd)';
const DAY_TIME = 'DD HH:mm';
const TIME_ONLY = 'HH:MM';
const LONG_TIME = 'HH:mm:ss';
const D_MONTH_DAY = 'MM.DD';
const S_MONTH_DAY = 'MM/DD';
const S_YEAR_MONTH_DAT = 'YYYY/MM/DD';
const SS_MONTH_DAY = 'MMDD';
const SS_YEAR_MONTH = 'YYYYMM';
const SS_YEAR_MONTH_DAY = 'YYYYMMDD';
const SSS_YEAR_MONTH_DAY = 'YYYY.MM.DD';
const YEAR = 'YYYY';
const MONTH = 'MM';
const DAY = 'DD';
const SSS_MONTH_DAY = 'M/D';


export const FORMAT = {
  ymdts: YEAR_MONTH_DAY_LONG_TIME,
  ymdt: YEAR_MONTH_DAY_TIME,
  ymd: YEAR_MONTH_DAY,
  ymd_p: YEAR_MONTH_DAY_PERIOD,
  ym: YEAR_MONTH,
  y: YEAR,
  sym: SHORT_YEAR_MONTH,
  symd: SHORT_YEAR_MONTH_DAY,
  symdt: SHORT_YEAR_MONTH_DAY_TIME,
  md: MONTH_DAY,
  mdt: MONTH_DAY_TIME,
  mdd: MONTH_DAY_D,
  m: MONTH,
  d: DAY,
  dt: DAY_TIME,
  time: TIME_ONLY,
  l_time: LONG_TIME,
  d_md: D_MONTH_DAY,
  s_md: S_MONTH_DAY,
  s_ymd: S_YEAR_MONTH_DAT,
  ss_md: SS_MONTH_DAY,
  ss_ym: SS_YEAR_MONTH,
  ss_ymd: SS_YEAR_MONTH_DAY,
  sss_ymd: SSS_YEAR_MONTH_DAY,
  sss_md: SSS_MONTH_DAY,

};

// getTodayDate() : 오늘의 날짜
export function getTodayDate() {
  return dayjs();
}

export const today = dayjs();

// 날짜 계산.
// calculate('2023-02-03', 3)
// return :  new Date(2023-02-06)
export function calculate(n, type = 'day', val = getTodayDate()) {
  if (type == 'half') {
    n = n * 6;
    type = 'month';
  }

  if (n) {
    return dayjs(val).add(n, type);
  }
  else { return dayjs(val).subtract(0 - n, type); }
}

export function getFirstDate(type = 'week', val = getTodayDate()) {
  if (type == 'half') {
    const month = get('month', val);
    if (month < 6) {
      type = 'year';
    }
    else {
      type = 'month';
      val = set(6, type, val);
    }
  }

  return dayjs(val).startOf(type);
}

export function getLastDate(type = 'week', val = getTodayDate()) {
  if (type == 'half') {
    const month = get('month', val);
    if (month >= 6) { // 7월~
      type = 'year';
    }
    else {
      type = 'month';
      val = set(5, type, val);
    }
  }

  return dayjs(val).endOf(type);
}

export function getWorkDay(date = dayjs().format('YYYY-MM-DD'), type = true) {
  while (!checkWorkDay(date)) {
    date = getDateFormat('ymd', calculate(type ? 1 : -1, 'day', date));
  }
  return date;
};

export function getMonday(val = getTodayDate(), n = 0) {
  const mon = calculate(1, 'day', getFirstDate('week', val));
  return calculate(n, 'week', mon);
}

export function getFriday(val = getTodayDate(), n = 0) {
  const fri = calculate(-1, 'day', getLastDate('week', val));
  return calculate(n, 'week', fri);
}

export function getSunday(val = getTodayDate(), n = 0) {
  const sun = calculate(1, 'day', getLastDate('week', val));
  return calculate(n, 'week', sun);
}

export function getFullWeek(val = getTodayDate()) {
  let week = get('week', val);
  if (week === 1 && get('month', val) === 11) {
    week = get('week', getMonday(val, -1)) + week;
  }
  return week;
}
export function getMonthWeek(val = getTodayDate()) {
  let firstWorkDay = getFirstDate('month', val);
  while (!checkWorkDay(firstWorkDay)) {
    firstWorkDay = calculate(1, 'day', firstWorkDay);
  }
  const week = getFullWeek(val);
  return week - get('week', firstWorkDay) + 1;
}

export function getWeekObject(val = getTodayDate()) {
  let firstWorkDay = getFirstDate('month', val);
  while (!checkWorkDay(firstWorkDay)) {
    firstWorkDay = calculate(1, 'day', firstWorkDay);
  }

  return {
    firstWorkDay: getDateFormat('ymd', firstWorkDay),
    date: getDateFormat('ymd', val),
    ssDate: getDateFormat('ss_ymd', val),
    monday: getMonday(val).format(FORMAT.ymd),
    ssMon: getMonday(val).format(FORMAT.ss_ymd),
    friday: getFriday(val).format(FORMAT.ymd),
    ssFri: getFriday(val).format(FORMAT.ss_ymd),
    sunday: getSunday(val).format(FORMAT.ymd),
    ssSun: getSunday(val).format(FORMAT.ss_ymd),
    year: get('year', val),
    month: get('month', val) + 1,
    week: getFullWeek(val),
    yearMonth: getDateFormat('ym', val),
    ssYm: getDateFormat('ss_ym', val),
    yearMonthKR: getDateFormatKor('ym', val),
    monthWeek: getMonthWeek(val),
    yearWeek: getDateFormat('yu', val),
    year0Week: getDateFormat('y0u', val),
  };
}

export function getWeekByYearWeek(year = get('year'), week = 1) {
  const firstDate = `${year}-01-01`;
  console.log('firstDate', firstDate);
  const monday = getMonday(firstDate, week - 1);
  console.log('monday', monday, get('week', monday), week);
  if (get('week', monday) === week) {
    return getWeekObject(monday);
  }
}

export function checkWorkDay(val = getTodayDate()) {
  const sun = getSame(getFirstDate('week', val), val);
  const sat = getSame(getLastDate('week', val), val);
  return !(sun || sat);
}

export function get(type = 'day', val = getTodayDate()) {
  if (type == 'week') {
    return dayjs(val).isoWeek();
  }
  else {
    return dayjs(val).get(type);
  }
}

export function set(n = 0, type = 'day', val = getTodayDate()) {
  return dayjs(val).set(type, n);
}

export function getDateFormat(type = 'ymdt', val = getTodayDate()) {
  if (type === 'yu') {
    return `${get('year', val)}/${getFullWeek(val)}`;
  }
  else if (type === 'y0u') {
    return `${get('year', val)}/${String(getFullWeek(val)).padStart(2, '0')}`;
  }

  return dayjs(val).format(FORMAT[type]);
}

export function getDateFormatKor(type = 'ymd', val = getTodayDate()) {
  if (type == 'ymd') {
    return `${dayjs(val).get('year')}년 ${dayjs(val).get('month') + 1}월 ${dayjs(val).get('date')}일`;
  }
  else if (type == 'ym') {
    return `${dayjs(val).get('year')}년 ${dayjs(val).get('month') + 1}월`;
  }
  else if (type == 'md') {
    return `${dayjs(val).get('month') + 1}월 ${dayjs(val).get('date')}일`;
  }
  else if (type == 'y') {
    return `${dayjs(val).get('year')}년`;
  }
  else if (type == 'm') {
    return `${dayjs(val).get('month') + 1}월`;
  }
  else if (type == 'd') {
    return `${dayjs(val).get('date')}일`;
  }
  else if (type === 'yu') {
    return `${get('year', val)}년 ${getMonthWeek(val)}주`;
  }
  else if (type === 'ymu') {
    return `${get('year', val)}년 ${get('month', val) + 1}월 ${getMonthWeek(val)}주`;
  }
  else {
    return `${dayjs(val).get('year')}년 ${dayjs(val).get('month') + 1}월 ${dayjs(val).get('date')}일`;
  }
}

export function getDateDayFormatKor(type = 'ymd', val = getTodayDate()) {
  if (type == 'ymd') {
    return `${dayjs(val).get('year')}년 ${dayjs(val).get('month') + 1}월 ${dayjs(val).get('date')}일 (${dayjs(
      val,
    ).format('ddd')})`;
  }
  else if (type == 'md') {
    return `${dayjs(val).get('month') + 1}월 ${dayjs(val).get('date')}일 (${dayjs(val).format('ddd')})`;
  }
  else if (type === 'ym') {
    return `${dayjs(val).get('year')}년 ${dayjs(val).get('month') + 1}월`;
  }
}

export function getTimeFormmat(val = getTodayDate()) {
  return dayjs(val).format('HH:mm');
}

export function getDiff(val1, val2 = getTodayDate(), type = 'day') {
  const date1 = dayjs(val1);
  const date2 = dayjs(val2);
  return date1.diff(date2, type);
}

export function getBefore(val1, val2 = getTodayDate(), type = 'minute') {
  const date1 = dayjs(val1);
  const date2 = dayjs(val2);
  return date1.isBefore(date2, type);
}

export function getAfter(val1, val2 = getTodayDate(), type = 'minute') {
  const date1 = dayjs(val1);
  const date2 = dayjs(val2);
  return date1.isAfter(date2);
}

export function getSame(val1, val2 = getTodayDate(), type = 'day') {
  const date1 = dayjs(val1);
  const date2 = dayjs(val2);
  return date1.isSame(date2, type);
}

export function getBetween(val1, val2, val3 = getTodayDate(), type = false) {
  const date1 = dayjs(val1);
  const date2 = dayjs(val2);
  const date3 = dayjs(val3);
  if (type) { return (getAfter(date3, date1) || getSame(date3, date1)) && (getBefore(date3, date2) || getSame(date3, date2)); }
  else { return getAfter(date3, date1) && getBefore(date3, date2); }
}

export function getDateGroup(val1, val2 = getTodayDate(), type = false) {
  if (typeof val1 === 'undefined') { val1 = getTodayDate(); }
  if (typeof val2 === 'undefined') { val2 = getTodayDate(); }

  let temp_time = dayjs(val1);
  const dateList = [];
  if (checkWorkDay(temp_time) || type) {
    dateList.push(getDateFormat('ymd', temp_time));
  }
  while (!getSame(temp_time, val2)) {
    temp_time = calculate(1, 'day', temp_time);
    if (checkWorkDay(temp_time) || type) { dateList.push(getDateFormat('ymd', temp_time)); }
  }
  return dateList;
}

// 월요일부터 일요일까지 - OW 표준
export function getWeekDateGroup(val = getTodayDate(), type = true) {
  if (typeof val === 'undefined') { val = getTodayDate(); }

  const monday = getDateFormat('ymd', getMonday(val));
  const sunday = getDateFormat('ymd', getSunday(val));

  console.log(monday, sunday);
  return getDateGroup(monday, sunday, type);
}

// 일요일부터 월요일까지
export function getWeekDateGroup2(val = getTodayDate(), type = true) {
  if (typeof val === 'undefined') { val = getTodayDate(); }

  const monday = getDateFormat('ymd', getMonday(val));
  const sunday = getDateFormat('ymd', getSunday(val, -1));
  return getDateGroup(sunday, monday, type);
}

/**
 *
 * @param {dayjs} val1
 * @param {dayjs} val2
 * @returns
 * working week list : 1/1~1/5, 1/8~1/12 ...
 */
export function getWeekList(val1, val2 = getTodayDate(), type = false) {
  if (typeof val1 === 'undefined') { val1 = getTodayDate(); }
  if (typeof val2 === 'undefined') { val2 = getTodayDate(); }
  val1 = dayjs(val1);
  val2 = dayjs(val2);

  const dateList = [];
  let start = dayjs(val1);
  let week = 1;

  while (!checkWorkDay(start)) {
    start = calculate(1, 'day', start);
  }

  while (!getAfter(start, val2)) {
    const startYear = getMonday(start).get('year');
    let startMonth = getMonday(start).get('month');
    let startDay = getMonday(start).get('date');

    const endYear = type ? getSunday(start).get('year') : getFriday(start).get('year');
    let endMonth = type ? getSunday(start).get('month') : getFriday(start).get('month');
    let endDay = type ? getSunday(start).get('date') : getFriday(start).get('date');

    if (getBefore(getMonday(start), val1)) {
      startMonth = val1.get('month');
      startDay = val1.get('date');
    }

    if (getAfter(type ? getSunday(start) : getFriday(start), val2)) {
      endMonth = val2.get('month');
      endDay = val2.get('date');
    }

    let startText = getDateFormat('ymd', getMonday(start));
    if (startText < getDateFormat('ymd', val1)) { startText = getDateFormat('ymd', val1); }

    dateList.push({
      start: startText,
      end: getDateFormat('ymd', type ? getSunday(start) : getFriday(start)),
      text: `${startMonth + 1}/${startDay}~${endMonth + 1}/${endDay}`,
      text2: `${getDateFormat('d_md', `${startYear}-${startMonth + 1}-${startDay}`)}~${getDateFormat('d_md', `${endYear}-${endMonth + 1}-${endDay}`)}`,
      week,
    });
    start = calculate(1, 'week', start);
    week += 1;
  }

  return dateList;
}

export function getMonthList(val = getTodayDate()) {
  if (typeof val === 'undefined') {
    val = getTodayDate();
  }

  const dateList = [];
  let start = getFirstDate('year', val);
  const lastMonth = getLastDate('year', val);
  while (!getAfter(start, lastMonth)) {
    dateList.push({
      year: get('year', start),
      month: get('month', start) + 1,
      startDate: getDateFormat('ymd', start),
      endDate: getDateFormat('ymd', getLastDate('month', start)),
    });
    start = calculate(1, 'month', start);
  }
  return dateList;
}

// 현재일의 주차 구하기
export function getWeek(date = getTodayDate()) {
  const currentDate = date.getDate();
  const firstDay = new Date(date.setDate(1)).getDay();

  return Math.ceil((currentDate + firstDay) / 7);
}

export function getMaxWeek(date = getTodayDate()) {
  if (typeof date === 'undefined') { date = getTodayDate(); };
  let stdate = getFirstDate('month', date);
  let lsdate = getLastDate('month', date);

  while (!checkWorkDay(stdate)) {
    stdate = calculate(1, 'day', stdate);
  }
  while (!checkWorkDay(lsdate)) {
    lsdate = calculate(-1, 'day', lsdate);
  }

  const startWeek = get('week', stdate);
  let lastWeek = get('week', lsdate);

  if (lastWeek === 1 && get('month', lsdate) === 11) { // 12월 계산
    lastWeek = get('week', calculate(-1, 'week', lastWeek)) + 1;
  }

  const weekMax = lastWeek - startWeek + 1;
  return weekMax;
}

export function searchPeriodCalculation(cYear, cMonth) {
  // 날짜형으로 데이트 포맷
  const date = new Date(cYear, cMonth);

  // 월요일을 중심으로한 주차 구하기( JS기준 : 일요일 0 월요일 1 ~ 토요일 6 )
  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

  let weekObj = null;
  const weekObjArray = [];
  const weekStand = 8; // 월요일 고정
  let firstWeekEndDate = true;
  const thisMonthFirstWeek = firstDay.getDay();

  for (let num = 1; num <= 6; num++) {
    // 마지막월과 첫번째월이 다른경우 빠져나온다.
    if (lastDay.getMonth() != firstDay.getMonth()) {
      break;
    }
    weekObj = new Object();

    // 한주의 시작일은 월의 첫번째 월요일로 설정
    if (firstDay.getDay() <= 1) {
      // 한주의 시작일이 일요일이라면 날짜값을 하루 더해준다.
      if (firstDay.getDay() == 0) {
        firstDay.setDate(firstDay.getDate() + 1);
      }
      weekObj.weekStartDate
        = `${firstDay.getFullYear().toString()
        }-${
          numberPad((firstDay.getMonth() + 1).toString(), 2)
        }-${
          numberPad(firstDay.getDate().toString(), 2)}`;
    }

    if (weekStand > thisMonthFirstWeek) {
      if (firstWeekEndDate) {
        if (weekStand - firstDay.getDay() == 1) {
          firstDay.setDate(firstDay.getDate() + (weekStand - firstDay.getDay()) - 1);
        }
        if (weekStand - firstDay.getDay() > 1) {
          firstDay.setDate(firstDay.getDate() + (weekStand - firstDay.getDay()) - 1);
        }
        firstWeekEndDate = false;
      }
      else {
        firstDay.setDate(firstDay.getDate() + 6);
      }
    }
    else {
      firstDay.setDate(firstDay.getDate() + (6 - firstDay.getDay()) + weekStand);
    }

    // 월요일로 지정한 데이터가 존재하는 경우에만 마지막 일의 데이터를 담는다.
    if (typeof weekObj.weekStartDate !== 'undefined') {
      weekObj.weekEndDate
        = `${firstDay.getFullYear().toString()
        }-${
          numberPad((firstDay.getMonth() + 1).toString(), 2)
        }-${
          numberPad(firstDay.getDate().toString(), 2)}`;

      weekObjArray.push(weekObj);
    }

    firstDay.setDate(firstDay.getDate() + 1);
  }

  const firstDate = weekObjArray[0].weekStartDate.substring(
    weekObjArray[0].weekStartDate.length - 1,
    weekObjArray[0].weekStartDate.length,
  );
  const tempDate = getFriday().get('month') - 1;

  // 1주차 데이터가 월요일부터 시작이 아닐 때
  if (tempDate < firstDate) {
    weekObjArray.unshift({
      weekEndDate: `${cYear}-0${cMonth + 1}-01`,
      weekStartDate: `${cYear}-0${cMonth + 1}-0${tempDate}`,
    });
  }

  // 5주차 데이터가 중간에 끊길 때
  if (weekObjArray[4].weekEndDate.substr(5, 2) != weekObjArray[4].weekStartDate.substr(5, 2)) {
    weekObjArray[4].weekEndDate = `${weekObjArray[4].weekStartDate.substr(0, 7)}-${new Date(
      cYear,
      cMonth + 1,
      0,
    ).getDate()}`;
  }
  // weekObjArray[4].weekEndDate = new Date(cYear, cMonth + 1, 0).getDate();

  return weekObjArray;
}

// 월, 일 날짜값 두자리( 00 )로 변경
function numberPad(num, width) {
  num = String(num);
  return num.length >= width ? num : Array.from({ length: width - num.length + 1 }).join('0') + num;
}

// 랜덤 데이트
export function getRandomDate(startDate, endDate) {
  const start = dayjs(startDate);
  const end = dayjs(endDate);
  const diff = getDiff(end, start);
  const random = Math.round(Math.random() * diff);
  return start.add(random, 'day');
}

/**
 * 일/주/월/연 화면의 날짜 타이틀 구하기
 * getDateTitleFormat( 'day' | 'week' | 'workWeek' | 'month' | 'year',  new Date() )
 * - 일(day) : 2024년 5월 28일
 * - 주(week, workWeek) : 2024년 5월 5주차
 * - 월(month) : 2024년 5월
 * - 연(year) : 2024년
 */
export function getDateTitleFormat(v = 'day', d = new Date()) {
  let str = '';

  if (v == 'day') {
    str = dayjs(d).format('YYYY년 M월 D일');
  }
  else if (v.toLocaleLowerCase().includes('week')) {
    const { year, month, weekOfMonth } = toWeekObject(dayjs(d));
    str = `${year}년 ${month + 1}월 ${weekOfMonth}주차`;
  }
  else if (v == 'month') {
    str = dayjs(d).format('YYYY년 M월');
  }
  else if (v == 'year') {
    str = dayjs(d).format('YYYY년');
  }
  return str;
}

<script setup>
import { computed, onMounted, ref, watch } from 'vue';
import dayjs from 'dayjs';
import {
  DxColumn,
  DxColumnFixing,
  DxDataGrid,
  DxEditing,
  DxLoadPanel,
  DxPaging,
  DxSorting,
} from 'devextreme-vue/data-grid';
import { orderBy, uniqueId } from 'lodash-es';
import { get, setNumberFormat, useMergeCells } from '../utils';
import Pagination from '@/components/Pagination.vue';

const props = defineProps({
  id: {
    type: String,
    default: '',
  },
  class: { type: String, default: '' },
  showGap: {
    type: Boolean,
    default: false,
  },
  allDatas: {
    type: Array,
    default() {
      return [];
    },
  },
  columns: {
    type: Array,
    default() {
      return [];
    },
  },
  mergeCellIndexs: {
    type: Array,
    default() {
      return [];
    },
  },
  loading: { type: Boolean, default: false },
  sort: { type: Boolean, default: true },
  editing: { type: Boolean, default: false },
  edit: { type: Boolean, default: false },
  nGridCount: {
    type: Number,
    default: 1,
  },
  showPagination: {
    type: Boolean,
    default: true,
  },
  paging: {
    type: Object,
    default() {
      return { totalItemCount: 0, pageSize: 20, pageNo: 1 };
    },
  },
  selection: {
    type: Object,
    default() {
      return { mode: 'none', showCheckBoxesMode: 'none' };
    },
  },
  selectionFilter: {
    type: Array,
    default() {
      return [];
    },
  },
  selectedRowKeys: {
    type: Array,
    default() {
      return [];
    },
  },
  keyExpr: {
    type: String,
    default: '',
  },
  width: {
    type: String,
    default: '',
  },
  height: {
    type: String,
    default: '77vh',
  },
  columnFixing: {
    type: Boolean,
    default: true,
  },
  rowAlternationEnabled: {
    type: Boolean,
    default: false,
  },
  hoverRowEnabled: {
    type: Boolean,
    default: false,
  },
  rowTemplateYn: {
    type: Boolean,
    default: false,
  },
  showColumnHeaders: {
    type: Boolean,
    default: true,
  },
  showColumnLines: {
    type: Boolean,
    default: false,
  },
  showRowLines: {
    type: Boolean,
    default: false,
  },
  showBorders: {
    type: Boolean,
    default: true,
  },
  showGridDividingLine: {
    type: Boolean,
    default: false,
  },
  showIndicator: {
    type: Boolean,
    default: false,
  },
  indicatorSize: {
    type: Object,
    default() {
      return { startPosition: '16%', monthWidth: '7%', monthCount: 1 };
    },
  },
});

const emit = defineEmits([
  'onRowPrepared',
  'onCellPrepared',
  'onClickCell',
  'onClickCellText',
  'onClickCellButton',
  'onClickCellSelectbox',
  'onClickCellMultiSelectbox',
  'onMovePage',
  'onSave',
  'onSelectionChanged',
  'onCellHoverChanged',
  'onInitialized',
]);

const startPosition = computed(() => props.indicatorSize.startPosition);
const monthWidth = computed(() => props.indicatorSize.monthWidth);
const monthCount = get('month');
const allDatas = computed(() => props.allDatas);
const columns = computed(() => props.columns);
const mergeCellIndexs = computed(() => props.mergeCellIndexs);
// const paging = computed(() => props.paging);
const paging = ref(props.paging);
const pageNo = ref(paging.value.pageNo);
const isShowPagination = computed(() => props.showPagination);
const showGridDividingLine = computed(() => props.showGridDividingLine);

const gridInstance = ref();
function onInitialized(e) {
  gridInstance.value = e.component;
  emit('onInitialized', e);
}
const height = computed(() => {
  return props.height;
});
const width = computed(() => {
  return props.width;
});

// grid cell click event
function onClickCell(obj, gridId) {
  // console.log(obj);
  emit('onClickCell', { ...obj, gridId });
}

function onClickCellTemplate(fnName, data) {
  emit(fnName, data);
}

// paging
function onMovePage(clickedPage) {
  pageNo.value = clickedPage;
  paging.value.pageNo = clickedPage;
  setNGridData();
  emit('onMovePage', clickedPage);
}

/* SORT */
const sortDataField = ref('');
const sortAsc = ref(true);
const sortedData = ref(null);
function setSortHeader(dataField) {
  // 방향만 바꾸기
  if (dataField === sortDataField.value) {
    sortAsc.value = !sortAsc.value;
  }
  // 새로운 sort
  else {
    sortDataField.value = dataField;
    sortAsc.value = true;
  }
  sortData();
}

function sortData() {
  sortedData.value = orderBy(
    allDatas.value,
    sortDataField.value,
    sortAsc.value ? 'asc' : 'desc',
  );
  setNGridData();
}

// n-grid 컨트롤
const valuesList = ref([]);
const paginationComp = ref(null);

// n-grid 데이터 생성
async function setNGridData() {
  valuesList.value = [];
  // 데이터 전체 리스트를 받아오는 경우, n-grid 데이터 생성함수 사용
  const nData = getNGridData(sortedData.value || allDatas.value);
  nData.map((e, idx) => {
    valuesList.value.push({ id: `grid${idx}`, data: e });
  });
}

function getNGridData(
  data = [],
  size = paging.value.pageSize,
  cnt = props.nGridCount,
) {
  const arr = [];
  // case 1. 페이징 처리 하지 않는 경우
  // if (!isShowPagination.value) size = data.length;

  // case 2. 데이터를 페이징처리해서 가져오는 경우 리스트 인덱스 0부터 시작
  let startIdx = 0;

  // case 3. 데이터를 페이징처리하지 않고 전부 가져오는 경우 페이지마다 시작인덱스 계산
  if (data != null) {
    if (data.length > size * cnt) {
      startIdx = (paging.value.pageNo - 1) * size * cnt;
      // startIdx = (pageNo.value - 1) * size * cnt;
    }

    // n개 그리드에 각각 넣어줄 데이터 - 그리드당 목록 갯수(size)만큼 데이터 자르기
    for (let i = 1; i <= cnt; i++) {
      arr.push(data.slice(startIdx, startIdx + size));
      startIdx += size;
    }
  }

  return arr;
}

function getCellTemplate(col) {
  const cellTypeList = [
    'hover',
    'number',
    'ymd',
    'button',
    'selectbox',
    'multi-line',
    'customize',
    'customize2',
    'customize3',
    'customize4',
    'customize5',
    'customize6',
  ];
  const cellTemplate = ref('');

  if (!!col.cellType & cellTypeList.includes(col.cellType)) {
    cellTemplate.value = `${col.cellType}-cell-template`;
  }
  return cellTemplate.value;
}

function getHeaderCellTemplate(col) {
  if (!!col.headerType && col.headerType != '') {
    return `${col.headerType}-header-cell-template`;
  }
}

function onCellPrepare(e) {
  if (mergeCellIndexs.value.length != 0) {
    useMergeCells(e, mergeCellIndexs.value);
  }
  emit('onCellPrepared', e);
}

// onRowPrepared 함수 수정
function onRowPrepared(e) {
  if (e.rowType === 'data') {
    if (e.data?.deleteYn === 'Y') {
      e.rowElement.classList.add('deleted-row');
    }
    if (e.data?.mergedRow) {
      e.rowElement.classList.add('sal-merge-row');
    }
  }
  emit('onRowPrepared', e);
}

function onSave(e) {
  emit('onSave', e);
}

function onSelectionChanged(e) {
  // console.log(e);
  emit('onSelectionChanged', e);
}

function onCellHoverChanged(e) {
  // console.log(e);
  emit('onCellHoverChanged', e);
}

onMounted(() => {
  pageNo.value = props.paging.pageNo;
  paging.value = props.paging;
  setNGridData();
});

watch(
  () => allDatas.value,
  () => {
    pageNo.value = props.paging.pageNo;
    paging.value = props.paging;
    sortedData.value = null;
    setNGridData();
  },
  { immediate: true },
);

watch(
  () => props.paging,
  () => {
    paging.value = props.paging;
  },
);

watch(
  () => props.nGridCount,
  () => {
    setNGridData();
  },
);
</script>

<template>
  <div class="sal-grid-area">
    <!-- 그리드 -->
    <!-- <div>
      loading  : {{ props.loading }}
    </div> -->
    <div class="d-flex multi-grid">
      <template
        v-for="(values, idx) in valuesList"
        :key="idx"
      >
        <div
          class="grid-box"
          style="position: relative"
          :style="{
            'margin-right':
              showGap && nGridCount % 2 === 0 && idx === nGridCount / 2 - 1
                ? '23px'
                : '0px',
            'margin-left':
              showGap && nGridCount % 2 === 0 && idx === nGridCount / 2
                ? '20px'
                : '3px',
          }"
        >
          <DxDataGrid
            :id="props.id === '' ? values.id : props.id"
            class="ow-datagrid"
            :class="props.class"
            :width="width"
            :height="height"
            :data-source="values.data"
            :on-cell-click="(...args) => onClickCell(...args, values.id)"
            :repaint-changes-only="false"
            :allow-column-resizing="true"
            :allow-column-reordering="true"
            :column-auto-width="true"
            :focused-row-enabled="false"
            :focused-row-index="-1"
            :focused-row-key="undefined"
            :show-column-headers="props.showColumnHeaders"
            :show-column-lines="props.showColumnLines"
            :show-row-lines="props.showRowLines"
            :show-borders="props.showBorders"
            :row-alternation-enabled="props.rowAlternationEnabled"
            :hover-state-enabled="props.hoverRowEnabled"
            :selection-filter="props.selectionFilter"
            :selection="props.selection"
            :selected-row-keys="props.selectedRowKeys"
            :key-expr="props.keyExpr"
            @initialized="onInitialized"
            @row-prepared="onRowPrepared"
            @cell-prepared="(...args) => onCellPrepare(...args)"
            @saving="onSave"
            @selection-changed="onSelectionChanged"
            @cell-hover-changed="onCellHoverChanged"
          >
            <template v-if="!sort">
              <DxSorting mode="none" />
            </template>
            <template v-if="loading">
              <DxLoadPanel :enabled="loading" />
            </template>
            <DxColumnFixing :enabled="columnFixing" />
            <DxPaging :enabled="false" />
            <!-- {{ props.editing }} -->
            <template v-if="props.editing">
              <DxEditing
                refresh-mode="reshape"
                :allow-adding="false"
                :allow-updating="true"
                :allow-deleting="false"
                mode="batch"
              />
            </template>
            <template v-if="props.edit">
              <DxEditing
                refresh-mode="reshape"
                :allow-adding="false"
                :allow-updating="true"
                :allow-deleting="false"
                mode="cell"
              />
            </template>
            <template
              v-for="(col_lv1, idx1) in columns"
              :key="uniqueId()"
            >
              <DxColumn
                :data-field="col_lv1.dataField"
                :caption="col_lv1.caption"
                :fixed="col_lv1.fixed"
                :fixed-position="col_lv1.fixedPosition"
                :width="col_lv1.width"
                :format="col_lv1.format"
                :alignment="col_lv1.alignment"
                :allow-merge="col_lv1.allowMerge"
                :allow-sorting="col_lv1.allowSorting"
                :allow-editing="col_lv1.allowUpdating"
                :cell-template="getCellTemplate(col_lv1)"
                :header-cell-template="getHeaderCellTemplate(col_lv1)"
                :sort-order="col_lv1.sortOrder"
                :css-class="col_lv1.cssClass"
                :visible="col_lv1?.visible"
              >
                <template v-if="!!col_lv1.children">
                  <template
                    v-for="(col_lv2, idx2) in col_lv1.children"
                    :key="uniqueId()"
                  >
                    <DxColumn
                      :data-field="col_lv2.dataField"
                      :lv1-caption="col_lv1.caption"
                      :lv1-data-field="col_lv1.dataField"
                      :caption="col_lv2.caption"
                      :fixed="col_lv2.fixed"
                      :fixed-position="col_lv2.fixedPosition"
                      :width="col_lv2.width"
                      :format="col_lv2.format"
                      :alignment="col_lv2.alignment"
                      :allow-merge="col_lv2.allowMerge"
                      :allow-editing="col_lv2.allowUpdating"
                      :cell-template="getCellTemplate(col_lv2)"
                      :header-cell-template="getHeaderCellTemplate(col_lv2)"
                      :sort-order="col_lv2.sortOrder"
                      :css-class="col_lv2.cssClass"
                    >
                      <template v-if="!!col_lv2.children">
                        <template
                          v-for="(col_lv3, idx3) in col_lv2.children"
                          :key="uniqueId()"
                        >
                          <DxColumn
                            :data-field="col_lv3.dataField"
                            :lv1-caption="col_lv1.caption"
                            :lv1-data-field="col_lv1.dataField"
                            :lv2-caption="col_lv2.caption"
                            :lv2-data-field="col_lv2.dataField"
                            :caption="col_lv3.caption"
                            :fixed="col_lv3.fixed"
                            :fixed-position="col_lv3.fixedPosition"
                            :width="col_lv3.width"
                            :format="col_lv3.format"
                            :alignment="col_lv3.alignment"
                            :allow-merge="col_lv3.allowMerge"
                            :allow-editing="col_lv3.allowUpdating"
                            :sort-order="col_lv3.sortOrder"
                            :css-class="col_lv3.cssClass"
                            :cell-template="getCellTemplate(col_lv3)"
                            :header-cell-template="
                              getHeaderCellTemplate(col_lv3)
                            "
                          />
                        </template>
                      </template>
                    </DxColumn>
                  </template>
                </template>
              </DxColumn>
            </template>

            <!-- # hover & click (주용도 : 치과명 클릭) -->
            <template #hover-cell-template="{ data: cellData }">
              <span
                class="name"
                @click.stop="onClickCellTemplate('onClickCellText', cellData)"
              >
                {{ cellData.text }}
              </span>
            </template>

            <!-- 숫자 3자리 콤마 -->
            <template #number-cell-template="{ data: cellData }">
              <span>
                {{ setNumberFormat(cellData.text * 1) }}
              </span>
            </template>

            <!-- 날짜 포맷 -->
            <template #ymd-cell-template="{ data: cellData }">
              <span>
                {{
                  cellData.text === "00000000"
                    ? cellData.text
                    : dayjs(cellData.text).format("YY.MM.DD")
                }}
              </span>
            </template>

            <!-- # 셀 내부 버튼 -->
            <template #button-cell-template="{ data: cellData }">
              <BButton
                variant="state"
                @click="onClickCellTemplate('onClickCellButton', cellData)"
              >
                {{ cellData.text }}
              </BButton>
            </template>

            <!-- # 셀 내부 여러 줄 : 행 높이 자동 조절됨 -->
            <template #multi-line-cell-template="{ data: cellData }">
              <div style="white-space: pre-line !important">
                {{ cellData.text }}
              </div>
            </template>

            <!-- # 셀 custom -->
            <!-- 컬럼마다 커스텀이 필요한 경우, slot 안에서 column 속성을 이용해 분기처리하여 사용할 것을 권장합니다 -->
            <template #customize-cell-template="{ data: data }">
              <slot
                name="customize"
                :data="data"
              />
            </template>
            <template #customize1-cell-template="{ data: data }">
              <slot
                  name="customize1"
                  :data="data"
              />
            </template>
            <template #customize2-cell-template="{ data: data }">
              <slot
                name="customize2"
                :data="data"
              />
            </template>
            <template #customize3-cell-template="{ data: data }">
              <slot
                name="customize3"
                :data="data"
              />
            </template>
            <template #customize4-cell-template="{ data: data }">
              <slot
                name="customize4"
                :data="data"
              />
            </template>
            <template #customize5-cell-template="{ data: data }">
              <slot
                name="customize5"
                :data="data"
              />
            </template>
            <template #customize6-cell-template="{ data: data }">
              <slot
                name="customize6"
                :data="data"
              />
            </template>

            <!-- # 행 custom -->
            <template
              v-if="props.rowTemplateYn"
              #dataRowTemplate="{ data: rowInfo }"
            >
              <slot
                name="row"
                :data="rowInfo.data"
              />
            </template>

            <!-- #헤더 custom -->
            <template #customize-header-cell-template="{ data }">
              <slot
                name="customize-header"
                :data="data.column"
              />
            </template>
            <template #customize2-header-cell-template="{ data }">
              <slot
                name="customize2-header"
                :data="data.column"
              />
            </template>
            <template #sort-header-cell-template="{ data }">
              <span
                class="cursor-pointer"
                @click="setSortHeader(data.column.dataField)"
              >{{ data.column.caption }}</span><span v-if="data.column.dataField === sortDataField"><span v-if="sortAsc">↑</span><span v-else>↓</span></span>
            </template>
          </DxDataGrid>
          <div
            v-if="props.showIndicator"
            class="line-box bg-gray"
          />
          <div
            v-if="props.showIndicator"
            class="line-box bd-blue"
          />
        </div>

        <!-- 그리드 구분선 -->
        <div
          v-if="showGridDividingLine && idx < valuesList.length - 1"
          class="grid-dividing-line"
        />
      </template>
    </div>

    <!-- 페이징 -->
    <!-- <template v-if="isShowPagination && paging.totalItemCount != 0"> -->
    <!-- <template v-if="isShowPagination && paging.pageSize * nGridCount < paging.totalItemCount"> -->
    <template v-if="isShowPagination">
      <!-- <div class="ow-pagination">
        <OwPagination
          :page-no="paging.pageNo"
          :page-size="paging.pageSize * props.nGridCount"
          :total-count="paging.totalItemCount"
          :on-change="onMovePage"
        />
      </div> -->
      <div
        class="ow-pagination"
        style="margin-top: 8px; max-width: "
      >
        <Pagination
          ref="paginationComp"
          :n-grid-count="props.nGridCount"
          :paging="paging"
          @on-move-page="onMovePage"
        />
      </div>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.ow-pagination {
  max-width: 1920px;
}
.grid-dividing-line {
  border-left: 1px solid rgb(225, 233, 235);
  margin-left: 4px;
}
:deep() {
  .deleted-row > td {
    text-decoration: line-through;
    color: #aaa;
  }
  .sal-merge-row > td {
    // border : unset!important;
    // border-top: 1px solid rgba($color: #000000, $alpha: 0.2);
    border-top: 1px solid #e1e9eb;
    // outline: 0px 1px 0px 0px solid black;
  }
  .dx-scrollable-scrollbar {
    display: none !important;
  }
  .dx-row.dx-freespace-row {
    display: none !important;
  }

  .dx-datagrid-nodata {
    display: none;
    &:first {
      display: block;
    }
  }

  #grid0 {
    .dx-datagrid-nodata {
      display: block;
    }
  }
  .ow-thin {
    .dx-datagrid .dx-row > td,
    .dx-datagrid .dx-row > tr > td {
      padding: 2.5px 6px;
    }
  }
}
</style>

<script setup>
import { ref, onMounted, defineProps, defineEmits } from "vue";

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: "과제" },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: "md" },
  width: { type: Number, default: 400 },
  height: { type: Number, default: 200 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
});

const emit = defineEmits(["updateOrganization"]);

// 정적 데이터로 대체 (이미지에 맞게 구성)
const organizationList = ref([
  {
    id: "kg",
    name: "K3 교체, K5 보상 프로모션",
    isExpanded: true,
    isSelected: false,
    employees: [],
  },
  {
    id: "ks",
    name: "K5 만족도조사",
    isExpanded: true,
    isSelected: false,
    employees: [],
  },
  {
    id: "k5",
    name: "장비 짧은영상 K5",
    isExpanded: true,
    isSelected: false,
    employees: [],
  },
  {
    id: "sns3",
    name: "K5 SNS 3차",
    isExpanded: true,
    isSelected: false,
    employees: [],
  },
  {
    id: "sns-review",
    name: "K5 SNS 리뉴얼",
    isExpanded: true,
    isSelected: false,
    employees: [],
  },
]);

const selectedItem = ref(null);

// 항목 선택
const selectItem = (item) => {
  // 기존 선택 모두 해제
  organizationList.value.forEach((org) => {
    org.isSelected = false;
  });

  // 새 항목 선택
  item.isSelected = true;
  selectedItem.value = item;
};

// 확인 버튼 클릭
const clickSave = () => {
  if (selectedItem.value) {
    emit("updateOrganization", selectedItem.value);
    if (props.onClose) {
      props.onClose();
    }
  } else {
    alert("항목을 선택해주세요.");
  }
};

// 취소 버튼 클릭
const clickCancel = () => {
  if (props.onClose) {
    props.onClose();
  }
};

// 검색 기능
const searchText = ref("");
const filteredList = ref([]);

const handleSearch = () => {
  if (!searchText.value.trim()) {
    filteredList.value = organizationList.value;
    return;
  }

  filteredList.value = organizationList.value.filter((item) =>
    item.name.toLowerCase().includes(searchText.value.toLowerCase())
  );
};

// 초기화
onMounted(() => {
  filteredList.value = organizationList.value;
});
</script>

<template>
  <OwPopup v-bind="props">
    <div class="popup-container">
      <div class="search-container">
        <input
          type="text"
          v-model="searchText"
          @input="handleSearch"
          placeholder="검색어를 입력하세요"
          class="search-input"
        />
        <BButton variant="search" style="margin-top:7px; margin-left: 5px;" />
      </div>

      <div class="task-list">
        <div
          v-for="(item, index) in filteredList"
          :key="item.id"
          class="task-item"
          @click="selectItem(item)"
          :class="{ selected: item.isSelected }"
        >
          <div class="circle-icon">○</div>
          <span class="task-name">{{ item.name }}</span>
        </div>
      </div>

      <div class="button-container">
        <BButton           size="md"
          variant="base base-gray" @click="clickCancel">취소</BButton>
        <BButton           size="md"
          variant="base base-dark" @click="clickSave">확인</BButton>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
.popup-container {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif;
  width: 100%;
  max-width: 400px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  background-color: #fff;
}

.popup-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  border-bottom: 1px solid #e0e0e0;
}

.title {
  font-size: 18px;
  font-weight: 500;
}



.search-container {
  display: flex;
  padding: 10px;
  border-bottom: 1px solid #e0e0e0;
}

.search-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.search-btn {
  background: none;
  border: none;
  cursor: pointer;
  margin-left: -30px;
}

.search-icon {
  font-size: 16px;
  color: #666;
}

.task-list {
  overflow-y: auto;
  max-height: 300px;
}

.task-item {
  display: flex;
  align-items: center;
  padding: 12px 15px;
  cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
}

.task-item:hover {
  background-color: #f9f9f9;
}

.task-item.selected {
  background-color: #f0f7ff;
}

.circle-icon {
  color: #6c9fff;
  margin-right: 12px;
  font-size: 16px;
}

.task-name {
  font-size: 14px;
  color: #333;
}

.divider {
  height: 10px;
  background-color: #f5f5f5;
  border-top: 1px solid #e0e0e0;
  border-bottom: 1px solid #e0e0e0;
}

.button-container {
  display: flex;
  justify-content: center;
  padding: 10px;
  background-color: #fff;
}
</style>

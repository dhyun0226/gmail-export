<script setup>
import { computed, onMounted, ref, watch } from "vue";
import { useApi, useCommonCode, useUserProfile } from "@ows/core";
import dayjs from "dayjs";
import { useOwPopup } from "@ows/ui";
import { useColumnPopup } from "@/composables/useColumnPopupStore";
import DxListNGrid from "@/components/DxListNGrid.vue";
import { dateUtils } from "@/utils";
import VocDetailPopup from "@/components/VocDetailPopup.vue";
import EmployeePopup from "@/components/EmployeePopup.vue";
import VocDetailPopup2 from "@/components/VocDetailPopup2.vue";

const props = defineProps({
  dateOptions: Object,
  filterOptions: Object,
  listGroup: String,
  selectedProduct: String,
});

const { VOC_STACD: vocStatuses } = await useCommonCode("VOC_STACD");
const vocItemName = ref("");
const { currentUser } = useUserProfile();

const {
  openPopup: openVocDetailPopup,
  closePopup,
  isPopupOpen: isVocDetailPopupOpen,
  getVh,
} = useOwPopup();

// 조직 팝업 관련
const {
  openPopup: openEmployeePopup,
  closePopup: closeEmployeePopup,
  isPopupOpen: isEmployeePopupOpen,
} = useOwPopup();

const popupHeight = 100;
const popupPosition = ref({
  my: "center",
  at: "center",
  of: "body",
  offset: "0 10",
});
const employeePopupPosition = ref({
  my: "center",
  at: "center",
  of: "body",
  offset: "0 10",
});

const columnPopupStore = useColumnPopup();

const api = useApi();
const { VOC_ITM_CTG_CD } = await useCommonCode("VOC_ITM_CTG_CD");
const { VOC_DVCD } = await useCommonCode("VOC_DVCD");

const vocNumber = ref(0);
// 현재 선택된 행의 데이터를 저장하기 위한 변수
const selectedRowData = ref(null);

const columns = ref([
  {
    caption: "접수시간",
    width: "100",
    dataField: "vocRegistrationDateTime",
    allowMerge: true,
    alignment: "center",
    allowSorting: false,
    cellType: "customize",
    visible: true,
  },
  {
    caption: "품목",
    width: "80",
    dataField: "itemCode",
    allowMerge: true,
    alignment: "center",
    allowSorting: false,
    cellType: "customize2",
    visible: true,
  },
  {
    caption: "접수내용",
    width: "*",
    dataField: "vocContent",
    allowMerge: false,
    alignment: "left",
    allowSorting: false,
    visible: true,
    cellType: "customize4",
  },
  {
    caption: "요청자",
    width: "120",
    dataField: "vocCustomerName",
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    visible: true,
  },
  {
    caption: "영업담당",
    width: "120",
    dataField: "salName",
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    visible: true,
  },
  {
    caption: "처리담당자",
    width: "120",
    dataField: "vocProcessorName", // 담당자 이름 필드
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    visible: true,
    cellType: "customize3", // 커스텀 셀 타입 추가
  },
]);

// Add this computed property to filter visible columns
const visibleColumns = computed(() => {
  return columns.value.filter((column) => column.visible === true);
});

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 14,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: "725px",
  selection: { mode: "none", showCheckBoxesMode: "none" },
  pagination: true,
});

// rowTemplate 표시 여부 결정
const showRowTemplate = computed(() => {
  return columns.value && columns.value.length > 0;
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

// 코드-텍스트 매핑 객체
const itemCodeToNameMap = {
  implant: "임플란트",
  instrument: "기구",
  endodontic: "보존/근관",
  restorative: "수복/접착",
  impression: "인상/보철",
  cutting: "절삭/연마",
  gbr: "GBR",
  hygiene: "위생용품",
  equipment: "장비",
  orthodontic: "교정용기구",
  prevention: "예방/구강",
  dentalLab: "기공용품",
  medicine: "의약품",
  appliance: "생활가전",
};

// 코드를 텍스트로 변환하는 함수
function getItemText(code) {
  // 매핑 객체에서 코드에 해당하는 텍스트 반환, 없으면, 코드 그대로 반환
  return itemCodeToNameMap[code] || code;
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format("YY-MM-DD");
}

function getTimeFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format("HH:mm");
}

function getNGridCountByColumns() {
  if (columnPopupStore.selectedColumns.length === 2) {
    gridOption.value.nGridCount = 6;
  } else if (columnPopupStore.selectedColumns.length === 3) {
    gridOption.value.nGridCount = 4;
  } else {
    gridOption.value.nGridCount = 2;
  }
}

function getColumnsByDate() {
  const date = props.dateOptions.rangeUnit;
  if (date === "day") {
    columns.value.forEach((col) => {
      if (col.caption === "접수일자") {
        col.caption = "접수시간";
      }
      col.visible = true;
    });
  } else if (date === "week") {
    columns.value.forEach((col) => {
      if (col.caption === "접수시간") {
        col.caption = "접수일자";
      }
      col.visible = true;
    });
  } else {
    columns.value.forEach((col) => {
      if (col.caption === "접수시간" || col.caption === "접수일자") {
        col.caption = "접수일자";
        col.visible = false;
      }
      if (col.caption === "요청자" || col.caption === "영업담당") {
        col.visible = false;
      }
    });
  }

  columnPopupStore.setSelectedColumns(
    columns.value.filter((col) => col.visible).map((col) => col.caption)
  );
}

function getColumnsByGroup() {
  if (props.listGroup === "product") {
    columns.value.forEach((col) => {
      if (col.caption === "품목") {
        col.visible = false;
      }
    });
  } else {
    columns.value.forEach((col) => {
      if (col.caption === "품목") {
        col.visible = true;
      }
    });
  }

  columnPopupStore.setSelectedColumns(
    columns.value.filter((col) => col.visible).map((col) => col.caption)
  );
}

// 셀병합할 컬럼
const mergeColumns = computed(() => {
  const arr = [];
  columns.value.forEach((e, idx) => {
    if (e.allowMerge) {
      arr.push({ idx, field: e.dataField });
    }
  });
  return arr;
});

const mergeCellIndexs = mergeColumns.value.map((e) => [e.idx]);

function onCellClick(event, info) {
  // 헤더 행인 경우 다른 처리
  if (info.data?.header === true) {
    return;
  }

  // 화면 세로 중간 X 좌표
  const half = window.innerWidth / 2;
  // 클릭이 왼쪽이면 true, 오른쪽이면 false
  const isLeft = event.clientX < half;

  // 팝업 포지션 설정
  const pos = isLeft
    ? {
        my: "left center",
        at: "left center",
        of: window,
        offset: `${half} 50`,
      }
    : {
        my: "left center",
        at: "left center",
        of: window,
        offset: `15 50`,
      };

  // 일반 행 처리 (기존 코드 유지)
  vocNumber.value = info.data.vocNumber;
  vocItemName.value = info.data.vocItemName;
  if (info.column && info.column.caption === "처리담당자") {
    // 현재 행 데이터 저장
    selectedRowData.value = info.data;
    // 담당자 검색 팝업 열기
    openEmployeePopup();
  } else {
    // 다른 컬럼 클릭 시 VOC 상세 팝업 열기
    popupPosition.value = pos;
    openVocDetailPopup();
  }
}

async function handleUpdateOrganization(item) {
  // 팝업 닫기
  closeEmployeePopup();
  selectedRowData.value = null;
  load();
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      startDate: dateUtils.toLocalDateTime(props.dateOptions.from),
      endDate: dateUtils.toLocalDateTimeEnd(props.dateOptions.to),
      itemCode:
        props.filterOptions.product == "all"
          ? null
          : props.filterOptions.product,
      vocChargePersonDepartmentCode: props.filterOptions.org,
      vocRegistererDepartmentCode: props.filterOptions.country,
      vocStateCode: vocStatuses
        .filter((stat) => stat.text == "처리중")
        .map((item) => item.value),
    };

    // Determine the API endpoint based on listGroup value
    let apiPath = "/voc/vocs"; // Default path

    if (props.listGroup === "product") {
      apiPath = "/voc/vocs/grouped-by-item";
    } else if (["country", "personal"].includes(props.listGroup)) {
      apiPath = "/voc/vocs/grouped-by-dept";

      // Add groupByType parameter based on listGroup
      if (props.listGroup === "country") {
        params.groupByType = "REGISTERER"; // 등록자 부서 기준
      } else if (props.listGroup === "personal") {
        params.groupByType = "CHARGE_PERSON"; // 담당자 부서 기준
      }
    }

    const result = await api.get(apiPath, { params });
    gridOption.value.datas = result.data.data;
    gridOption.value.paging.totalItemCount = result.data.totalCount;
  } catch (error) {
    gridOption.value.datas = [];
  }
}

function closeVocDetailPopup() {
  load();
  closePopup();
}

watch(
  () => props.dateOptions,
  (newVal) => {
    if(props.dateOptions.to == props.dateOptions.from) {
      return;
    }
    getColumnsByDate();
    getNGridCountByColumns();
    load();
  },
  { deep: true }
);

watch(
  () => props.filterOptions,
  (newVal) => {
    load();
  },
  { deep: true }
);

watch(
  () => props.listGroup,
  (newVal) => {
    getColumnsByGroup();
    getNGridCountByColumns();
    load(); // listGroup이 변경되면 데이터 다시 로드
  }
);

watch(
  () => columnPopupStore.selectedColumns,
  (newVal) => {
    columns.value.forEach((col) => {
      col.visible = newVal.includes(col.caption);
    });
    getNGridCountByColumns();
  },
  { deep: true }
);

onMounted(() => {
  getColumnsByDate();
  getNGridCountByColumns();
  columnPopupStore.setColumns(columns.value);
  columnPopupStore.setSelectedColumns(
    columns.value.filter((col) => col.visible).map((col) => col.caption)
  );
  load();
});
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :merge-cell-indexs="mergeCellIndexs"
    :is-show-pagination="true"
    :row-template-yn="showRowTemplate"
    @on-click-cell="onCellClick"
    @on-move-page="handlePaging"
  >
    <!-- 일반 셀 커스텀 템플릿 - rowTemplate 미사용 시에만 활성화 -->
    <template v-if="!showRowTemplate" #customize="{ data: cell }">
      <template v-if="props.dateOptions.rangeUnit === 'day'">
        {{ getTimeFormat(cell.data.vocRegistrationDateTime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.vocRegistrationDateTime) }}
        </div>
      </template>
    </template>

    <template v-if="!showRowTemplate" #customize2="{ data: cell }">
      <div>{{ getItemText(cell.data.itemCode) }}</div>
    </template>

    <template v-if="!showRowTemplate" #customize3="{ data: cell }">
      <div class="customize3">
        {{ cell.data.vocChargePersonName || "미지정" }}
        <span class="edit-icon">
          <i class="dx-icon-edit" />
        </span>
      </div>
    </template>

    <template v-if="!showRowTemplate" #customize4="{ data: cell }">
      <div>{{ cell.data.vocContent }}</div>
    </template>

    <!-- 행 템플릿 - columns가 존재할 때만 활성화 -->
    <template v-if="showRowTemplate" #row="{ data }">
      <!-- 헤더 행인 경우 -->
      <tr v-if="data.header" class="header-row">
        <td :colspan="visibleColumns.length" class="header-row-cell">
          <div class="header-row-content">
            {{ `${data.itemName} ${data.itemCount}건` || "품목 그룹" }}
          </div>
        </td>
      </tr>

      <!-- 일반 행인 경우 -->
      <tr v-else class="normal-row">
        <!-- 각 컬럼별 처리 -->
        <td
          v-for="(column, index) in visibleColumns"
          :key="index"
          :class="column.cssClass"
          :style="{
            'text-align': column.alignment,
            width: column.width !== '*' ? `${column.width}px` : 'auto',
          }"
          @click="onCellClick($event, { data, column })"
        >
          <!-- 접수시간 컬럼 -->
          <template v-if="column.dataField === 'vocRegistrationDateTime'">
            <template v-if="props.dateOptions.rangeUnit === 'day'">
              {{ getTimeFormat(data.vocRegistrationDateTime) }}
            </template>
            <template v-else>
              <div class="sal-custom">
                {{ getDateFormat(data.vocRegistrationDateTime) }}
              </div>
            </template>
          </template>

          <!-- 품목 컬럼 -->
          <template v-else-if="column.dataField === 'itemCode'">
            <div>{{ getItemText(data.itemCode) }}</div>
            <div>{{ data.itemCode }}</div>
          </template>

          <!-- 접수내용 컬럼 -->
          <template v-else-if="column.dataField === 'vocContent'">
            <div class="content-text">
              {{ data.vocContent }}
            </div>
          </template>

          <!-- 요청자 컬럼 -->
          <template v-else-if="column.dataField === 'vocCustomerName'">
            <div>
              <div>{{ data.vocItemName }}</div>
              <div
                :class="{
                  'text-color': data.vocRegistererDivisionCode === '01',
                }"
              >
                {{ data.vocCustomerName }}
              </div>
            </div>
          </template>
          <!-- 영업담당 컬럼 -->
           <template v-else-if="column.dataField === 'salName'">
            <div>
              <!--              <div>{{ data.vocItemName }}</div>-->
              <div
                :class="{
                  'text-color': data.vocRegistererDivisionCode === '01',
                }"
              >
                {{ data.vocSaleChargeEmployeeName }}
              </div>
              <span>{{ data.vocSaleChargeDepartmentName }}</span>
            </div>
          </template>
          <!-- 처리담당자 컬럼 -->
          <template v-else-if="column.dataField === 'vocProcessorName'">
            <div class="customize3">
              <span
                :class="{
                  'match-text':
                    currentUser.empNo === data.vocChargePersonEmployeeNumber &&
                    currentUser.empName == '민봉기',
                }"
              >
                {{ data.vocChargePersonName || "미지정" }}
              </span>
            </div>
          </template>

          <!-- 기타 컬럼 -->
          <template v-else>
            {{ data[column.dataField] }}
          </template>
        </td>
      </tr>
    </template>
  </DxListNGrid>

  <!-- VOC 상세 팝업 -->
  <VocDetailPopup
    v-if="isVocDetailPopupOpen"
    :is-popup-open="isVocDetailPopupOpen"
    :popup-position="popupPosition"
    height="800px"
    :voc-number="vocNumber"
    :voc-item-name="vocItemName"
    :voc-item-category-code="VOC_ITM_CTG_CD"
    :voc-division-code="VOC_DVCD"
    :width="950"
    :on-close="
      () => {
        closeVocDetailPopup();
      }
    "
  />

  <!-- 사용자 검색 팝업 -->
  <EmployeePopup
    v-if="isEmployeePopupOpen"
    :is-popup-open="isEmployeePopupOpen"
    :voc-category-code="selectedRowData?.vocCategoryCode"
    :popup-position="employeePopupPosition"
    :on-close="closeEmployeePopup"
    :height="600"
    :voc-number="vocNumber"
    @update-organization="handleUpdateOrganization"
  />
</template>

<style>
.customize3 {
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  position: relative;
}

.customize3 .edit-icon {
  margin-left: 5px;
  opacity: 0.5;
  font-size: 12px;
}

.customize3:hover {
  background-color: #f5f5f5;
}

.customize3:hover .edit-icon {
  opacity: 1;
}

/* 헤더 행 스타일 */
.header-row-cell {
  background-color: #c0d0f9;
}

.header-row-hidden {
  display: none !important;
}

.header-row-content {
  font-weight: bold;
  font-size: 15px;
  color: #485f8d;
  text-align: left;
}


/* CSS (scoped or global) */
.match-text {
  color: #485f8d;
}

.text-color {
  /* 요청자가 직원일경우 */
  color: #4e95f5;
}
.content-text {
  display: -webkit-box; /* 중요: 클램프와 함께 사용 */
  -webkit-line-clamp: 2; /* 중요: 최대 줄 수 설정 */
  -webkit-box-orient: vertical; /* 중요: 텍스트 방향 지정 */
  overflow: hidden; /* 중요: 초과 내용 숨기기 */
  text-overflow: ellipsis; /* 초과된 텍스트 생략(...) */
  word-break: break-word; /* 긴 단어 줄바꿈 */
  white-space: normal; /* 기본 텍스트 단어 줄바꿈 (검토 필요) */
}
</style>

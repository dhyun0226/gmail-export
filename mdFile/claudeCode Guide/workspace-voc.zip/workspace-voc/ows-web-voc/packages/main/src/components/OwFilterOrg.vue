<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue";
import { useApi, useCommonCode } from "@ows/core";

const api = useApi();

const props = defineProps({
  propsId: {
    type: String,
    default: "itemSelectionsFilter",
  },
  label: {
    type: String,
    default: null,
  },
  propsListItem: {
    type: Array,
    default: () => [],
  },
  propsSelectItem1: {
    type: String,
    default: null,
  },
  propsSelectItem2: {
    type: String,
    default: null,
  },
  propsSelectItem: {
    type: Array,
    default: () => [null, null, null, null],
  },
  viewDepth: {
    type: Number,
    default: null,
  },
  propsWidth: {
    type: String,
    default: "auto",
  },
  corporationCode: {
    type: String,
    default: "KR1",
  },
  departmentCode: {
    type: String,
  },
});

const emit = defineEmits(["selectItem"]);

const root = ref(null);
const filter = ref(null);
const index = ref(0);

const state = reactive({
  item2_select: props.propsSelectItem2,
  item_list: [],
  original_list: [],
  item1_select: props.propsSelectItem1,
  overflow: false,
  item_select: [...props.propsSelectItem],
  loading: false,
  error: null,
  selectedValues: [null, null, null, null, null],
});

// 계층형 데이터로 변환하는 함수
function transformToHierarchical(flatData) {
  // 부서 데이터와 사원 데이터 분리
  const deptData = flatData.filter((item) => !item.data.empNo);
  const empData = flatData.filter((item) => item.data.empNo);

  // 결과 객체를 저장할 맵 생성
  const deptMap = new Map();
  
  // 최상위 부서들을 담을 배열
  const result = [];

  // 부서 데이터를 맵에 저장
  deptData.forEach((dept) => {
    deptMap.set(dept.key, {
      name: dept.data.deptName,
      value: dept.data.deptCode,
      itemList: [],
      data: dept.data,
    });
  });

  // 부서 계층 구조 구성
  deptData.forEach((dept) => {
    const deptObj = deptMap.get(dept.key);

    if (dept.parentId && deptMap.has(dept.parentId)) {
      // 부모 부서가 있는 경우 부모의 itemList에 추가
      const parentDept = deptMap.get(dept.parentId);
      parentDept.itemList.push(deptObj);
    } else if (dept.parentId === null || !deptMap.has(dept.parentId)) {
      // 최상위 부서인 경우 결과 배열에 직접 추가
      result.push(deptObj);
    }
  });

  // 사원 데이터를 해당 부서의 itemList에 추가
  empData.forEach((emp) => {
    if (emp.parentId && deptMap.has(emp.parentId)) {
      const parentDept = deptMap.get(emp.parentId);
      parentDept.itemList.push({
        name: `${emp.data.dutyName ? `(${emp.data.dutyName}) ` : ""}${
          emp.data.empName
        }${emp.data.gradeName ? ` ${emp.data.gradeName}` : ""}`,
        value: emp.data.empNo,
        itemList: [],
        data: emp.data,
      });
    }
  });

  return result;
}

// API에서 조직 데이터 가져오기
async function fetchOrganizationData() {
  state.loading = true;
  state.error = null;

  try {
    const response = await api.get("/com/v2/department", {
      params: {
        corporationCode: props.corporationCode,
        departmentCode: props.departmentCode,
      },
    });

    // API 응답 데이터 변환
    const hierarchicalData = transformToHierarchical(response || []);

    state.item_list = hierarchicalData;
    state.original_list = hierarchicalData;
    
    // API 데이터 로드 후에 첫 번째 항목 자동 선택
    selectFirstItem();
  } catch (error) {
    console.error("Failed to fetch organization data:", error);
    state.error = "조직 데이터를 가져오는 데 실패했습니다.";
  } finally {
    state.loading = false;
  }
}

// 첫 번째 항목을 자동으로 선택하는 함수
function selectFirstItem() {
  if (state.original_list && state.original_list.length > 0) {
    const firstItem = state.original_list[0];
    
    // 첫 번째 항목 선택 상태로 설정
    state.item_select[0] = firstItem.name;
    state.selectedValues[0] = firstItem.value;
    
    // 부모 컴포넌트에 선택 이벤트 발생 (root 플래그 추가)
    emit("selectItem", {
      name: firstItem.name,
      value: firstItem.value,
      depth: 0,
      grp: firstItem.grp,
      data: firstItem.data,
      root: true // 최상위 항목임을 표시
    });
  }
}

const filteredItems = computed(() => {
  // 아무것도 선택되지 않은 경우 모든 항목 표시
  if (!state.item_select[0]) {
    return state.original_list;
  }

  // 현재 선택된 가장 깊은 레벨과 선택된 항목들의 경로를 찾음
  let currentLevel = -1;
  const selectedPath = [];

  for (let i = 0; i < state.item_select.length; i++) {
    if (state.item_select[i]) {
      currentLevel = i;
      selectedPath.push(state.item_select[i]);
    }
  }

  // 선택된 항목을 찾아 그 항목과 하위 구조만 반환
  function findSelectedItem(items, level = 0) {
    if (level >= selectedPath.length) {
      return null;
    }

    const selectedItem = items.find(
      (item) => item.name === selectedPath[level]
    );
    if (!selectedItem) {
      return null;
    }

    // 선택된 항목의 복사본 생성
    const result = { ...selectedItem };

    // 마지막 선택 레벨이 아니고 하위 항목이 있으면 재귀적으로 처리
    if (level < currentLevel && result.itemList?.length > 0) {
      const nextLevel = findSelectedItem(result.itemList, level + 1);
      if (nextLevel) {
        result.itemList = [nextLevel];
      }
    }

    return result;
  }

  const selectedItem = findSelectedItem(state.original_list);
  return selectedItem ? [selectedItem] : [];
});

watch(
  () => props.viewDepth,
  (newDepth) => {
    if (newDepth != null) {
      switch (newDepth) {
        case 2:
          state.item_select = state.item_select.map((_, i) =>
            i === 0 ? "Implant" : null
          );
          break;
        case 3:
          state.item_select = state.item_select.map((_, i) => {
            if (i === 1) {
              return "Fixture";
            }
            return i < 1 ? state.item_select[i] : null;
          });
          break;
        default:
          // 기본값을 빈 값으로 설정하고, 이후에 첫 번째 항목 선택
          state.item_select = state.item_select.map(() => null);
          selectFirstItem();
      }
    }
  }
);

watch(
  () => props.propsListItem,
  (newValue) => {
    if (newValue && newValue.length > 0) {
      state.item_list = [...newValue];
      state.original_list = [...newValue];
      
      // 리스트 아이템이 변경될 때도 첫 번째 항목 자동 선택
      selectFirstItem();
    }
  }
);

watch(
  () => props.propsSelectItem,
  (newValue) => {
    state.item_select = newValue;
    
    // 만약 모든 값이 null이면 첫 번째 항목 선택
    if (newValue.every(val => val === null)) {
      selectFirstItem();
    }
  }
);

watch(
  () => props.corporationCode,
  (newValue) => {
    if (newValue) {
      fetchOrganizationData();
    }
  }
);

// 항목 선택 핸들러
function itemSelectAction(depth, name, item, grp) {
  // 특정 항목 선택 시
  const newSelect = state.item_select.map(() => null);
  const newValues = state.selectedValues.map(() => null);

  for (let i = 0; i <= depth; i++) {
    if (i === depth) {
      newSelect[i] = name;
      newValues[i] = item.value;
    } else {
      newSelect[i] = state.item_select[i];
      newValues[i] = state.selectedValues[i];
    }
  }

  state.item_select = newSelect;
  state.selectedValues = newValues;

  // 선택된 항목의 정보를 emit으로 전달 (root 플래그 추가)
  // depth가 0이면 최상위 항목이므로 root = true
  emit("selectItem", {
    name,
    value: item.value,
    depth,
    grp,
    data: item.data,
    root: depth === 0 // depth가 0인 경우 최상위 항목
  });
}

function getContentRect(dom) {
  if (!dom) {
    return DOMRectReadOnly.fromRect();
  }
  return dom.getBoundingClientRect();
}

const observer = new ResizeObserver((entries) => {
  for (const entry of entries) {
    const { width: outerWidth } = entry.contentRect;
    const { width: innerWidth } = getContentRect(filter.value);
    if (entry.target === root.value) {
      state.overflow = outerWidth < innerWidth;
    }
  }
});

onMounted(() => {
  if (root.value) {
    observer.observe(root.value);
  }

  // 컴포넌트 마운트 시 조직 데이터 가져오기
  fetchOrganizationData();
});

onUnmounted(() => {
  observer.disconnect();
});
</script>

<template>
      <div class="ow-filter">
        <div ref="filter" class="ow-filter-cont">
          <ul class="log_style_towdepth_radio">
            <li
              v-for="item in state.original_list"
              :key="item.name"
              :class="[
                state.item_select[0] == item.name ? 'active' : '',
                { 'has-arrow': item.itemList?.length > 0 },
              ]"
            >
              <button @click="itemSelectAction(0, item.name, item, item.grp)">
                {{ item.name }}
              </button>
              <ul v-if="item.itemList?.length > 0">
                <li
                  v-for="item2 in item.itemList"
                  :key="item2.name"
                  :class="[
                    state.item_select[1] == item2.name ? 'active' : '',
                    { 'has-arrow': item2.itemList?.length > 0 },
                  ]"
                >
                  <button
                    @click="itemSelectAction(1, item2.name, item2, item2.grp)"
                  >
                    {{ item2.name }}
                  </button>
                  <ul v-if="item2.itemList?.length > 0">
                    <li
                      v-for="item3 in item2.itemList"
                      :key="item3.name"
                      :class="[
                        state.item_select[2] == item3.name ? 'active' : '',
                        { 'has-arrow': item3.itemList?.length > 0 },
                      ]"
                    >
                      <button
                        @click="
                          itemSelectAction(2, item3.name, item3, item3.grp)
                        "
                      >
                        {{ item3.name }}
                      </button>
                      <ul v-if="item3.itemList?.length > 0">
                        <li
                          v-for="item4 in item3.itemList"
                          :key="item4.name"
                          :class="[
                            state.item_select[3] == item4.name ? 'active' : '',
                            { 'has-arrow': item4.itemList?.length > 0 },
                          ]"
                        >
                          <button
                            @click="
                              itemSelectAction(3, item4.name, item4, item4.grp)
                            "
                          >
                            {{ item4.name }}
                          </button>
                          <ul v-if="item4.itemList?.length > 0">
                            <li
                              v-for="item5 in item4.itemList"
                              :key="item5.name"
                              :class="[
                                state.item_select[4] == item5.name
                                  ? 'active'
                                  : '',
                                { 'has-arrow': item5.itemList?.length > 0 },
                              ]"
                            >
                              <button
                                @click="
                                  itemSelectAction(
                                    4,
                                    item5.name,
                                    item5,
                                    item5.grp
                                  )
                                "
                              >
                                {{ item5.name }}
                              </button>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
</template>

<style lang="scss" scoped>
.loading-indicator,
.error-message,
.empty-message {
  padding: 10px;
  text-align: center;
  font-size: 14px;
}

.error-message {
  color: #e74c3c;
}

.empty-message {
  color: #7f8c8d;
}

.ow-filter {
  padding: 0;
  max-width: var(--maxWidth, 100%);
  .ow-filter-cont {
    white-space: nowrap;
  }
}

.log_style_towdepth_radio {
  align-items: center;
  display: flex;
  overflow: hidden;
  padding-left: 1px;
  background: #fff;
  margin-bottom: 0px;
}

.log_style_towdepth_radio li {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -1px;
  color: #333;
  background: #e1e6ea;
}

.log_style_towdepth_radio li a,
.log_style_towdepth_radio li button {
  float: left;
  display: block;
  border: 1px solid #e1e6ea;
  padding: 0 5px;
  font-weight: 700;
  letter-spacing: 0px;
  color: #333;
  line-height: 22px;
  margin-left: -1px;
  background: #e1e6ea;
}

.log_style_towdepth_radio li ul {
  display: none;
  overflow: hidden;
  padding: 0px 6px;
}

.log_style_towdepth_radio li ul a,
.log_style_towdepth_radio li ul button {
  line-height: 18px;
  border-radius: 2px;
}

.log_style_towdepth_radio li.active > a,
.log_style_towdepth_radio li.active > button {
  border-color: #176de2;
  background-color: #4e95f5;
  color: #fff;
  position: relative;
}

.log_style_towdepth_radio li.active:has(li) > a:after,
.log_style_towdepth_radio li.active:has(li) > button:after {
  content: "";
  position: absolute;
  height: 7px;
  width: 7px;
  right: -4px;
  background-color: #4e95f5;
  transform: translateY(100%) rotate(135deg);
  border-left: 1px solid #176de2;
  border-top: 1px solid #176de2;
}

.log_style_towdepth_radio li.active:hover > a,
.log_style_towdepth_radio li.active:hover > button {
  border-color: #176de2;
  background-color: #4e95f5;
}

.log_style_towdepth_radio li.active > ul:has(li) {
  display: inline-block;
}

.log_style_towdepth_radio li.active > ul:has(li) a:after,
.log_style_towdepth_radio li.active > ul:has(li) button:after {
  margin-top: -2px;
}

.log_style_towdepth_radio li.active:has(.active) > a,
.log_style_towdepth_radio li.active:has(.active) > button {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active:has(.active) > a:after,
.log_style_towdepth_radio li.active:has(.active) > button:after {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active + li a,
.log_style_towdepth_radio li.active + li button {
  margin-left: 0;
}
</style>
<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { computed, onMounted, ref, watch } from 'vue';
import { useApi, useUserProfile } from '@ows/core';
import { uniqueId } from 'lodash-es';
import type { FileItem } from '@/types/inquiry';
import type { FAQItem } from '@/types/FAQItem';
import FilePopupInput from '@/components/FilePopupInput.vue';
import { useOwAlert } from '@ows/ui';
import BasicEditor from '@/components/BasicEditor.vue';
import {
  useYNGroupOptions,
} from '@/types/data.ts';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: 'FAQ' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: [String, Number], default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  faqNumber: { type: Number },
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
});

const { owAlert, owConfirm } = useOwAlert();
const emit = defineEmits(['save-success']);
const { currentUser } = useUserProfile();
const fileList = ref<FileItem[]>([]);
const editable = ref(true);
const api = useApi();
const saving = ref(false);
const useYnGroup = ref('Y');

const isCreateMode = computed(() => !props.faqNumber);

const popupTitle = computed(() =>
    isCreateMode.value ? 'FAQ 등록' : 'FAQ 수정',
);

const responseData = ref<Partial<FAQItem>>({
  channelCode: '',
  serviceCategoryCode: '',
  useYn: 'Y',
  faqTitle: '',
  faqContent: '',
});

// ✅ 전체 카테고리 옵션 저장
const allCategoryGroupOptions = ref(props.categoryGroupOptions ?? []);

// ✅ 채널 코드 기준 필터링된 카테고리 옵션
const filteredCategoryGroupOptions = computed(() => {
  const prefix = responseData.value.channelCode;
  if (!prefix) return allCategoryGroupOptions.value;
  return allCategoryGroupOptions.value.filter(opt =>
      opt.value.startsWith(`${prefix}_FAQ`)
  );
});



async function fetchFAQData() {
  try {
    const { data } = await api.get(`/voc/faqs/${props.faqNumber}`);
    responseData.value = {
      ...data,
      useYn: data.useYn || 'Y',
    };
    useYnGroup.value = responseData.value.useYn;
    editable.value = true;

    if (data.fileList && data.fileList.length > 0) {
      fileList.value = data.fileList;
    }

    // ✅ 채널코드 추출 (앞 4자리)
    responseData.value.channelCode = responseData.value.serviceCategoryCode?.substring(0, 4) || '';
  } catch (error) {
    console.error('Error loading FAQ data:', error);
  }
}

async function clickSave() {
  if (saving.value) return;
  saving.value = true;

  if (!responseData.value.faqTitle?.trim()) {
    owAlert({ title: '제목 필수입력 확인', message: 'FAQ 제목을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.faqContent?.trim()) {
    owAlert({ title: '내용 필수입력 확인', message: 'FAQ 내용을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.channelCode) {
    owAlert({ title: '채널 필수입력 확인', message: '채널을 선택해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.serviceCategoryCode) {
    owAlert({ title: '상세구분 필수입력 확인', message: '상세구분을 선택해주세요.' });
    saving.value = false;
    return;
  }

  const faqData = {
    faqTitle: responseData.value.faqTitle,
    faqContent: responseData.value.faqContent,
    channelCode: responseData.value.channelCode,
    serviceCategoryCode: responseData.value.serviceCategoryCode,
    useYn: useYnGroup.value || 'Y',
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    fileList: fileList.value,
  };

  if (!isCreateMode.value && props.faqNumber) {
    faqData.faqNumber = props.faqNumber;
  }

  try {
    if (isCreateMode.value) {
      if (await owConfirm({ title: '등록', message: 'FAQ를 등록하시겠습니까?', target: '#frm' })) {
        await api.post('voc/faqs', faqData);
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    } else {
      if (await owConfirm({ title: '수정', message: 'FAQ를 수정하시겠습니까?', target: '#frm' })) {
        await api.put(`voc/faqs/${props.faqNumber}`, faqData);
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    }
  } catch (error) {
    console.error('FAQ 저장 오류:', error);
  } finally {
    saving.value = false;
  }
}

async function deleteRow(faqNumber: number) {
  if (await owConfirm({ title: '삭제', message: 'FAQ를 삭제하시겠습니까?', target: '#frm' })) {
    try {
      const result = await api.delete(`/voc/faqs/${faqNumber}`);
      if (result.status === 200) {
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    } catch (error) {
      console.error('Error deleting FAQ:', error);
    }
  }
}

const isInitializing = ref(true);

onMounted(async () => {
  try {
    isInitializing.value = true;
    responseData.value.channelCode = props.channelGroupOptions?.[0]?.value || '';
    responseData.value.serviceCategoryCode = '';
    if (!isCreateMode.value && props.faqNumber) {
      await fetchFAQData();
    }
  } catch (error) {
    console.error('카테고리 초기화 실패:', error);
  } finally {
    isInitializing.value = false;
  }
});

watch(() => responseData.value.channelCode, () => {
  if (isInitializing.value) return;
  const firstMatch = filteredCategoryGroupOptions.value[0];
  if (firstMatch) {
    responseData.value.serviceCategoryCode = firstMatch.value;
  } else {
    responseData.value.serviceCategoryCode = '';
  }
});
</script>

<template>
  <OwPopup v-bind="{ ...props, title: popupTitle }">
    <div class="faq-detail-container">
      <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
      >
        <caption class="visually-hidden">
          FAQ
          {{
            isCreateMode ? "등록" : "상세"
          }}
          정보
        </caption>
        <colgroup>
          <col width="130px">
          <col>
        </colgroup>
        <BTbody>
          <BTr>
            <BTd colspan="2">
              <div class="settings-row">
                <div class="setting-group" style="width: 160px">
                  <span class="setting-label compact-label">채널</span>
                  <BFormSelect
                      v-model="responseData.channelCode"
                      :options="props.channelGroupOptions"
                      class="ow-select"
                  />
                </div>
                <div class="setting-group" style="width: 185px">
                  <span class="setting-label compact-label">상세구분</span>
                  <BFormSelect
                      v-model="responseData.serviceCategoryCode"
                      :options="filteredCategoryGroupOptions"
                      class="ow-select detail-select"
                  />
                </div>
                <div class="setting-group">
                  <span class="setting-label compact-label">사용여부</span>
                  <OwFormRadio
                      :id="uniqueId('use-chk-')"
                      v-model="useYnGroup"
                      :options="useYNGroupOptions"
                      class="ow-filter-more compact-radio"
                  />
                </div>
                <div
                    v-if="!isCreateMode"
                    class="setting-group"
                >
                  <span class="setting-label compact-label">삭제</span>
                  <BButton
                      variant="box-delete"
                      size="sm"
                      @click.stop="deleteRow(props.faqNumber)"
                  />
                </div>
              </div>
            </BTd>
          </BTr>
          <BTr>
            <BTh class="require">
              FAQ 제목
            </BTh>
            <BTd>
              <div
                  class="input-group"
                  role="group"
              >
                <input
                    id="faq-title"
                    v-model="responseData.faqTitle"
                    class="form-control ow-form-control noline"
                    type="text"
                    placeholder="제목을 입력해주세요."
                >
              </div>
            </BTd>
          </BTr>
          <BTr>
            <BTd colspan="2">
              <div style="height: 45vh">
                <BasicEditor
                    v-model="responseData.faqContent"
                />
              </div>
            </BTd>
          </BTr>
<!--          <BTr>-->
<!--            <BTh>파일 첨부</BTh>-->
<!--            <BTd>-->
<!--              <FilePopupInput-->
<!--                  v-model="fileList"-->
<!--                  :max-files="3"-->
<!--                  :max-file-size="5"-->
<!--                  help-text="파일"-->
<!--              />-->
<!--            </BTd>-->
<!--          </BTr>-->
        </BTbody>
      </BTableSimple>
      <div class="ow-popup-bottom">
        <BButton
            size="md"
            variant="base base-gray"
            @click="props.onClose"
        >
          취소
        </BButton>
        <BButton
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickSave"
        >
          {{ isCreateMode ? "확인" : "수정" }}
        </BButton>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
.faq-detail-container {
  max-width: 950px;
  margin: 0 auto;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.checkbox-container {
  display: flex;
  gap: 1.5rem;
  align-items: center;
}

.detail-select {
  min-width: 90px;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 1rem;
  vertical-align: middle;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 2rem;
  padding-top: 1.5rem;
  border-top: 1px solid #dee2e6;
}

.voc-content {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.voc-text {
  margin-bottom: 1rem;
  line-height: 1.5;
}

/* 새로 추가된 스타일 */
.settings-row {
  display: flex;
  flex-wrap: nowrap;
  gap: 20px;
  align-items: center;
  width: 100%;
}

.setting-group {
  display: flex;
  align-items: center;
  gap: 15px;
  white-space: nowrap;
}

.setting-label {
  font-weight: 600;
  min-width: auto;
}

.compact-label {
  font-size: 0.775rem;
}

.compact-radio :deep(.ow-radio) {
  margin-right: 8px;
}

/* 반응형 레이아웃을 위한 미디어 쿼리 */
@media (max-width: 768px) {
  .settings-row {
    flex-direction: column;
    align-items: flex-start;
  }

  .setting-group {
    margin-bottom: 8px;
    width: 100%;
  }
}
</style>
import type { OwsPlugin } from '@ows/core';

declare module '@vue/runtime-core' {
  interface GlobalComponents {}
  interface ComponentCustomProperties {}
}

declare const plugin: OwsPlugin;

export default plugin;

export * from './components/exports';

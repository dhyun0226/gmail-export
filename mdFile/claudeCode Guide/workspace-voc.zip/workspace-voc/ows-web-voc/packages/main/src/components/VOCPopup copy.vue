<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue';
import { useApi, useFileDownload } from '@ows/core';
import type {
  PopupState,
  SelectionState,
  VocFile,
  VocFormState,
  VocProps,
  VocResponse,
} from '../type/VOCReceptionDetailTypes';

const props = defineProps<VocProps>();
const emit = defineEmits<{
  (e: 'save'): void;
  (e: 'cancel'): void;
}>();
console.log(props);
const api = useApi();
const { image: getImageUrl } = useFileDownload();

// 상태 관리
const form = reactive<VocFormState>({
  registrationDateTime: '',
  registrationEmployeeNumber: '',
  customerName: '',
  vocContent: '',
  requestDepartment: '',
});

const selection = reactive<SelectionState>({
  selectedItem: '',
  selectedType: '',
  selectedDetailItem: '',
  detailProduct: '',
});

const popup = reactive<PopupState>({
  isMorePopupOpen: false,
});

const uploadedFiles = ref<VocFile[]>([]);

// 처리 유형 옵션
const processTypeOptions = [
  { text: '즉시처리', value: '즉시처리' },
  { text: '이관', value: '이관' },
  { text: '통합', value: '통합' },
  { text: '종결', value: '종결' },
];

const selectedProcessType = ref('즉시처리');
const targetDepartment = ref('');
const reasonText = ref('');

// 처리 유형 변경 감지
watch(selectedProcessType, (newValue) => {
  console.log(`처리 유형이 ${newValue}로 변경됨`);
  handleProcessTypeChange();
});

// Computed properties
const selectedItemText = computed(() => {
  const selected = props.vocItemCategoryCode.find(
    item => item.value === selection.selectedItem,
  );
  return selected?.text ?? '';
});

const moreItems = computed(() => props.vocItemCategoryCode.slice(7));

const typeOptions = computed(() => props.vocDivisionCode);

const morePopupProps = computed(() => ({
  'is-popup-open': popup.isMorePopupOpen,
  'target-id': 'btnMoreLeft',
  'width': 500,
  'height': 250,
  'target-position': 'left bottom',
  'my-position': 'left top',
}));

// Utility functions
function isImageFile(file: VocFile): boolean {
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  return imageExtensions.includes(file.fileExtensionName.toLowerCase());
}

function getFileIcon(file: VocFile): string {
  const fileType = file.type.split('/')[1];
  switch (fileType) {
    case 'pdf':
      return 'fas fa-file-pdf';
    case 'doc':
    case 'docx':
      return 'fas fa-file-word';
    case 'xls':
    case 'xlsx':
      return 'fas fa-file-excel';
    case 'mp4':
    case 'mov':
    case 'avi':
      return 'fas fa-file-video';
    default:
      return 'fas fa-file';
  }
}

// Event handlers
function handleProcessTypeChange(): void {
  // 처리 유형 변경 시 필요한 필드 초기화
  if (selectedProcessType.value === '이관') {
    targetDepartment.value = '';
  }
  else if (selectedProcessType.value === '통합') {
    // 통합 관련 초기화
  }
  else if (selectedProcessType.value === '종결') {
    reasonText.value = '';
  }
}

function handleTypeChange(): void {
  selection.selectedDetailItem = '';
}

function handleItemSelection(): void {
  popup.isMorePopupOpen = true;
}

function handleDepartmentSelection(): void {
  // 부서 선택 팝업 로직
}

function closeMorePopup(): void {
  popup.isMorePopupOpen = false;
}

function handleCancel(): void {
  emit('cancel');
}

function handleSave(): void {
  emit('save');
}

// Data fetching
async function fetchVocData(): Promise<void> {
  try {
    const { data } = await api.get<VocResponse>(`/voc/vocs/${props.vocNumber.vocNumber}`);

    if (data) {
      // Form data
      form.vocContent = data.vocContent ?? '';
      form.registrationEmployeeNumber = data.registrationEmployeeNumber ?? '';
      form.customerName = data.customerName ?? '';
      form.registrationDateTime = data.registrationDateTime ?? '';
      form.requestDepartment = data.requestDepartment ?? '';

      // Selection data
      selection.selectedItem = data.vocItemCategoryCode ?? '';
      selection.selectedType = data.vocDivisionCode ?? '';
      selection.selectedDetailItem = data.vocDetailItemCode ?? '';

      // Files
      if (data.fileList?.length) {
        uploadedFiles.value = data.fileList;
      }
    }
  }
  catch (error) {
    console.error('Error loading VOC data:', error);
  }
}

// Initialize
fetchVocData();
</script>

<template>
  <div class="voc-detail-container">
    <div class="section-container">
      <!-- 처리유형 -->
      <div class="section-row process-type">
        <div class="section-label">
          처리유형
        </div>
        <div class="section-content">
          <OwFormRadio
            v-model="selectedProcessType"
            :options="processTypeOptions"
            @change="handleProcessTypeChange"
          />
        </div>
      </div>

      <div class="divider" />

      <!-- 처리유형별 추가 필드 -->
      <div
        v-if="selectedProcessType === '이관'"
        class="section-row"
      >
        <div class="section-label">
          처리담당
        </div>
        <div class="section-content">
          <div class="input-container">
            <input
              v-model="targetDepartment"
              type="text"
              class="input-field"
              placeholder="담당자를 입력하세요"
              readonly
            >
            <button class="btn-department">
              업무요청서
            </button>
          </div>
        </div>
      </div>

      <div
        v-if="selectedProcessType === '통합'"
        class="section-row"
      >
        <div class="section-label">
          통합대상
        </div>
        <div class="section-content">
          <div class="input-container">
            <input
              v-model="targetDepartment"
              type="text"
              class="input-field"
              readonly
            >
            <button class="btn-department">
              과제
            </button>
          </div>
        </div>
      </div>

      <div
        v-if="selectedProcessType === '종결'"
        class="section-row"
      >
        <div class="section-label">
          사유
        </div>
        <div class="section-content">
          <textarea
            v-model="reasonText"
            class="textarea-field"
            placeholder="종결 사유를 입력하세요"
            rows="2"
          />
        </div>
      </div>

      <div
        v-if="selectedProcessType !== '즉시처리'"
        class="divider"
      />

      <!-- 답변 -->
      <div class="section-row">
        <div class="section-label">
          답변
        </div>
        <div class="section-content">
          답변을 입력해주세요.
        </div>
      </div>

      <div class="divider" />

      <!-- 품목 -->
      <div class="section-row">
        <div class="section-label">
          품목
        </div>
        <div class="section-content product-section">
          <span>{{ selectedItemText || "장비 > K3" }}</span>
          <button
            class="btn-product-select"
            @click="handleItemSelection"
          >
            품목 선택
          </button>
        </div>
      </div>

      <div class="divider" />

      <!-- 접수 내용 -->
      <div class="section-row">
        <div class="section-label">
          접수 내용
        </div>
        <div class="section-content">
          {{ form.vocContent || "" }}
        </div>
      </div>

      <!-- 이미지 섹션 -->
      <div
        v-if="uploadedFiles.length"
        class="image-section"
      >
        <div
          v-for="file in uploadedFiles"
          :key="file.fileId"
          class="image-item"
        >
          <img
            v-if="isImageFile(file)"
            :src="getImageUrl(file.fileId)"
            alt="VOC 이미지"
          >
          <i
            v-else
            :class="getFileIcon(file)"
            class="file-icon"
          />
        </div>
      </div>

      <div class="divider" />

      <!-- 요청자 -->
      <div class="section-row">
        <div class="section-label">
          요청자
        </div>
        <div class="section-content">
          {{ form.customerName || "아름다운치과 (박현성)" }}
        </div>
      </div>

      <div class="divider" />

      <!-- 유형 -->
      <div class="section-row">
        <div class="section-label">
          유형
        </div>
        <div class="section-content">
          <OwFormRadio
            v-model="selection.selectedType"
            :options="typeOptions"
            @change="handleTypeChange"
          />
        </div>
      </div>
    </div>

    <!-- 버튼 영역 -->
    <div class="button-container">
      <BButton
        variant="base base-gray"
        @click="handleCancel"
      >
        취소
      </BButton>
      <BButton
        variant="base base-dark"
        @click="handleSave"
      >
        확인
      </BButton>
    </div>

    <!-- 팝업 -->
    <OwMorePopup
      v-bind="morePopupProps"
      :on-close="closeMorePopup"
    >
      <OwFormRadio
        v-model="selection.selectedItem"
        :options="moreItems"
        class="ow-filter-more"
        @change="closeMorePopup"
      />
    </OwMorePopup>
  </div>
</template>

<style scoped>
.voc-detail-container {
  font-family: "Spoqa Han Sans Neo", sans-serif;
  max-width: 800px;
  margin: 0 auto;
  background-color: #fff;
  box-shadow: none;
  font-size: 16px;
}

.section-container {
  padding: 0;
}

.section-row {
  display: flex;
  padding: 20px 0;
}

.process-type {
  margin-top: 15px;
}

.section-label {
  flex: 0 0 130px;
  font-weight: 500;
  color: #333;
  font-size: 16px;
}

.section-content {
  flex: 1;
  color: #555;
  line-height: 1.6;
}

.product-section {
  display: flex;
  align-items: center;
  gap: 15px;
}

.btn-product-select {
  background-color: #f5f5f5;
  border: none;
  border-radius: 4px;
  padding: 6px 12px;
  font-size: 14px;
  cursor: pointer;
}

.image-section {
  display: flex;
  margin-left: 130px;
  margin-bottom: 20px;
  gap: 15px;
}

.image-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: none;
}

.image-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  font-size: 48px;
  color: #6c757d;
}

.button-container {
  display: flex;
  justify-content: center;
  gap: 15px;
  padding: 25px 0;
  margin-top: 25px;
}

/* 처리 유형별 추가 스타일 */
.input-container {
  display: flex;
  align-items: center;
  gap: 10px;
}

.input-field {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  width: 300px;
  font-size: 14px;
  background-color: #f9f9f9;
}

.textarea-field {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  width: 100%;
  max-width: 500px;
  font-size: 14px;
  resize: vertical;
}

.btn-department {
  padding: 8px 16px;
  background-color: #f5f5f5;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}
</style>

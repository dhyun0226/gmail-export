import type { I18nOptions } from 'vue-i18n';

declare const messages: I18nOptions['messages'];

export default messages;

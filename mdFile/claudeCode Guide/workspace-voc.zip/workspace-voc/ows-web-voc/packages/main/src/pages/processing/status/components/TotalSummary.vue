<!-- ReservationStatTreeGrid.vue -->
<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue';
import CustomStore from 'devextreme/data/custom_store';
import { cellStyleHandlers, fetchMockData, getColumns } from '../data';
import DxTreeList from '@/components/DxTreeList.vue';

// 트리 그리드 컴포넌트 참조
const treeListRef = ref(null);

// 컬럼 정의 불러오기
const columns = ref(getColumns());

// 서버에서 데이터를 가져오는 함수 (실제 API 호출로 대체 필요)
async function fetchTreeData(parentId: number | string | null = null) {
  console.log(`서버에서 데이터 가져오는 중... parentId: ${parentId}`);

  // 목 데이터 가져오기 (실제 구현에서는 API 호출로 대체)
  return await fetchMockData(parentId);
}

// CustomStore 설정
const customDataSource = new CustomStore({
  key: 'id',
  load: async (loadOptions) => {
    // 부모 ID 가져오기
    const parentId = loadOptions.parentIds && loadOptions.parentIds.length > 0
      ? loadOptions.parentIds[0]
      : null;

    // 서버에서 데이터 가져오기
    const data = await fetchTreeData(parentId);
    return data;
  },
  // TreeList가 자식 노드 여부를 확인하는데 사용
  hasChildrenExpr: 'hasChildren',
});

// React를 사용하여 데이터소스를 반응형으로 설정
const dataSource = reactive({
  store: customDataSource,
});

// 행 클릭 이벤트
function handleRowClick(e: any) {
  console.log('행 클릭:', e);
}

// 노드 확장 이벤트
function handleNodeExpand(key: number | string) {
  console.log(`노드 ${key} 확장`);
}

// 노드 접기 이벤트
function handleNodeCollapse(key: number | string) {
  console.log(`노드 ${key} 접기`);
}

// 셀 준비 이벤트
function onCellPrepared(e: any) {
  // 셀 스타일 핸들러 호출
  cellStyleHandlers.applyZeroValueStyle(e);
  cellStyleHandlers.applyParentStyle(e);
}

// 컴포넌트 초기화
onMounted(() => {
  console.log('예약 통계 트리 그리드 컴포넌트 마운트됨');
});
</script>

<template>
  <div>
    <DxTreeList
      ref="treeListRef"
      :data-source="dataSource"
      :columns="columns"
      :show-borders="true"
      :show-row-lines="true"
      :column-auto-width="true"
      :word-wrap-enabled="true"
      :remote-operations="true"
      has-items-expr="hasChildren"
      :on-cell-prepared="onCellPrepared"
      @node-expand="handleNodeExpand"
      @node-collapse="handleNodeCollapse"
      @row-click="handleRowClick"
    />
  </div>
</template>

<style scoped>
/* 스타일은 DxTreeList 컴포넌트에 정의됨 */
</style>

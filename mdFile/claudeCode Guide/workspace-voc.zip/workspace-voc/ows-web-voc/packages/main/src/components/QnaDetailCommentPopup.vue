<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import { useApi, useFileDownload, useUserProfile } from '@ows/core';
import dayjs from 'dayjs';
import FileDownloadList from './FileDownloadList.vue';
import useServiceCategoryCode from '@/composables/useServiceCategoryCode';
import type { PaginatedResponse } from '@/types/inquiry';
import DxListNGrid from '@/components/DxListNGrid.vue';
import type { VocFile } from '@/types/voc';
import { dateUtils } from '@/utils';

const props = defineProps({
  isCommentPopupOpen: { type: Boolean, default: false },
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '문의 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: [String, Number], default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  qnaNumber: { type: Number },
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  serviceCategoryCode: { type: [String, Object] },
});

const emit = defineEmits(['save-qna-answers', 'edit-event', 'save-success']);
const { currentUser } = useUserProfile();
const api = useApi();
const { image } = useFileDownload();

const responseData = ref({
  channelCode: '',
  serviceCategoryCode: '',
  openYn: 'Y',
  topFixedYn: 'Y',
  qnaTitle: '',
  qnaContent: '',
  writerMemberId: '',
  qnaRegistrationDatetime: '',
});

const qnaTitle = ref('');
const qnaContent = ref('');
const writerMemberId = ref('');
const qnaAnswers = ref('');
const fileList = ref<VocFile[]>([]);
const answerFiles = ref<VocFile[]>([]);
const answerFileList = ref<VocFile[]>([]);

// 문자 수 제한 관련
const MAX_CHAR_LENGTH = 1000;
const currentCharLength = ref(0);
const isOverLimit = ref(false);
const editableControl = ref(true);

function extractTextFromHtml(html: string): string {
  const temp = document.createElement('div');
  temp.innerHTML = html;
  return temp.textContent || '';
}

function getTextLength(html: string): number {
  const text = extractTextFromHtml(html);
  return text.length;
}

const actualEditable = computed(() => {
  return editable.value && editableControl.value && !isOverLimit.value;
});

watch(qnaAnswers, (newValue) => {
  const textLength = getTextLength(newValue);
  currentCharLength.value = textLength;
  if (textLength > MAX_CHAR_LENGTH) {
    isOverLimit.value = true;
    editableControl.value = false;
  }
});

function resetContent() {
  qnaAnswers.value = '';
  currentCharLength.value = 0;
  isOverLimit.value = false;
  editableControl.value = true;
}

function getDateFormat(dateString: string) {
  if (!dateString) { return ''; }
  return dayjs(dateString).format('YY.MM.DD HH:mm');
}

function formatDate(dateString: string): string {
  return dateUtils.formatDateWithSeparator(dateString, '.', false);
}
// 카테고리/셀렉트 관련
const topFxdYnGroup = ref('Y');
const topFxdYnGroupSetting = [
  { text: '상단고정', value: 'Y' },
  { text: '고정해제', value: 'N' },
];
const openYNGroup = ref('Y');
const openYNGroupSetting = [
  { text: '공개', value: 'Y' },
  { text: '비공개', value: 'N' },
];

const isCreateMode = computed(() => !props.qnaNumber);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 1,
  height: '668px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const columns = computed(() => [
  {
    caption: '댓글 내용',
    width: '*',
    dataField: 'qnaAnswerContent',
    allowMerge: true,
    alignment: 'left',
    cellType: 'customize',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '작성자',
    width: '100',
    dataField: 'answererMemberId',
    allowMerge: true,
    alignment: 'center',
    cellType: 'customize1',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록일시',
    width: '100',
    dataField: 'qnaAnswerDatetime',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '첨부파일',
    width: gridOption.value.datas.some(row => row.fileList && row.fileList.length > 0) ? '*' : 80,
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
  {
    caption: '삭제',
    width: '60',
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize4',
    visible: true,
  },
]);

async function deleteAnswer(qnaAnswer) {
  if (confirm('정말 삭제하시겠습니까?')) {
    const qnaNumber = props.qnaNumber;
    const qnaAnswerDetailNumber = qnaAnswer.qnaAnswerDetailNumber;
    try {
      await api.put(`/voc/qna-answers/${qnaNumber}/${qnaAnswerDetailNumber}`, {
        ...qnaAnswer,
        deleteYn: 'Y',
      });
      fetchQnaData();
    }
    catch (error) {
      console.error('답변 삭제 오류:', error);
    }
  }
}

async function fetchQnaData() {
  try {
    const { data } = await api.get<PaginatedResponse>(
      `/voc/qnas/${props.qnaNumber}`,
      {
        params: {
          serviceCategoryCode: props.serviceCategoryCode,
          channelCode: null,
        },
      },
    );
    responseData.value = data;
    qnaTitle.value = data.qnaTitle || '';
    qnaContent.value = data.qnaContent || '';
    writerMemberId.value = data.writerMemberId || '';
    fileList.value = data.fileList || [];
    answerFileList.value = data.answerFileList || [];
    gridOption.value.datas = data.answers || [];
    gridOption.value.paging.totalItemCount = (data.answers || []).length;
  }

  catch (error) {
    responseData.value = {};
  }
}

async function clickSave() {
  if (!qnaAnswers.value?.trim()) {
    window.alert('답변 내용을 입력해주세요.');
    return;
  }
  const answerContent = qnaAnswers.value
    .replace(/<p>/gi, '')
    .replace(/<\/p>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n');
  const params = {
    qnaNumber: props.qnaNumber,
    qnaAnswerDatetime: dayjs().format('YYYY-MM-DDTHH:mm:ss'),
    answererMemberId: '담당자',
    answererCorporationCode: currentUser.corpCode,
    answererDepartmentCode: currentUser.deptCode,
    answererEmployeeNumber: currentUser.empNo,
    qnaAnswerContent: answerContent,
    fileList: answerFiles.value,
  };
  try {
    const { data } = await api.post('/voc/qna-answers', params);
    emit('save-qna-answers', data);
    window.alert('문의 답변이 등록되었습니다.');
    if (props.onClose) { props.onClose(); }
  }
  catch (error) {
    console.error('저장 오류:', error);
    window.alert('답변 저장 중 오류가 발생했습니다.');
  }
}

onMounted(async () => {
  try {
    if (!isCreateMode.value && props.qnaNumber) {
      await fetchQnaData();
    }
    // 초기 문자 수 설정
    currentCharLength.value = getTextLength(qnaAnswers.value);
  }
  catch (error) {
    console.error('카테고리 초기화 실패:', error);
  }
});
</script>

<template>
  <OwPopup
    :is-popup-open="props.isPopupOpen"
    v-bind="props"
    :height="726"
    class="ow-popup-scrollable"
  >
    <div
      class="voc-detail-container"
      style="flex: 1;"
    >
      <DxListNGrid
        :n-grid-count="gridOption.nGridCount"
        :show-gap="false"
        :all-datas="gridOption.datas"
        :columns="columns"
        :paging="gridOption.paging"
        :height="gridOption.height"
        :selection="gridOption.selection"
        :row-class="row => row.deleteYn === 'Y' ? 'deleted-row' : ''"
        :is-show-pagination="true"
      >
        <!-- 댓글 내용 -->
        <template #customize="{ data: cell }">
          <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
            {{ cell.data.qnaAnswerContent }}
          </div>
        </template>

        <!-- 작성자 -->
        <template #customize1="{ data: cell }">
          <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
            {{ cell.data.answererMemberId }}
          </div>
        </template>

        <!-- 등록일시 -->
        <template #customize2="{ data: cell }">
          <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
            {{ formatDate(cell.data.qnaAnswerDatetime) }}
          </div>
        </template>

        <!-- 첨부파일 -->
        <template #customize3="{ data: cell }">
          <div
            class="file-list"
            :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''"
            style="display: flex; gap: 8px; flex-wrap: nowrap; overflow-x: auto;"
          >
            <FileDownloadList
              v-if="cell.data.fileList && cell.data.fileList.length > 0"
              :file-list="cell.data.fileList"
            />
            <span
              v-else
              style="color: #aaa;"
            >-</span>
          </div>
        </template>

        <!-- 삭제 버튼 -->
        <template #customize4="{ data: cell }">
          <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
            <BButton
              variant="box-delete"
              @click.stop="deleteAnswer(cell.data)"
            />
          </div>
        </template>
      </DxListNGrid>
    </div>
    <div class="ow-popup-bottom-fixed">
      <BButton
        size="md"
        variant="base base-gray"
        @click="props.onClose"
      >
        취소
      </BButton>
      <BButton
        id="btnOk"
        size="md"
        variant="base base-dark"
        @click="clickSave"
      >
        확인
      </BButton>
    </div>
  </OwPopup>
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}
.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}
.deleted-row {
  text-decoration: line-through;
  color: #aaa;
}
</style>

<script setup>
import { ref, onMounted, defineProps, defineEmits, watch } from "vue";
import { useApi, useCommonCode } from "@ows/core";

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: "담당자 목록" },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: "md" },
  width: { type: Number, default: 400 },
  height: { type: Number, default: 200 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  vocCategoryCode: {
    type: String,
    required: true,
  },
  vocNumber: { tpye: Number },
});

const emit = defineEmits(["updateOrganization"]);

const api = useApi();
const organizationList = ref([]);
const selectedEmployee = ref(null);

// 부서 토글
const toggleDepartment = (index) => {
  organizationList.value[index].isExpanded =
    !organizationList.value[index].isExpanded;
};

// 직원 선택
const selectEmployee = (employee) => {
  // 기존 선택 모두 해제
  organizationList.value.forEach((org) => {
    org.isSelected = false;
    org.employees.forEach((emp) => {
      emp.isSelected = false;
    });
  });

  // 새 직원 선택
  employee.isSelected = true;
  selectedEmployee.value = employee;
};

// 확인 버튼 클릭
const clickSave = async () => {
  if (selectedEmployee.value) {
    try {
      console.log(selectedEmployee.value);
      console.log(selectedEmployee.value.vocChargePersonNumber);
      
      // const response = await api.put(
      //   `/voc/vocs/${props.vocNumber}/chargePerson`,
      //   {
      //     vocChargePersonNumber: selectedEmployee.value.vocChargePersonNumber,
      //   }
      // );
      
      emit("updateOrganization", selectedEmployee.value);
      
      if (props.onClose) {
        props.onClose();
      }
    } catch (error) {
      console.error("직원 정보 업데이트 중 오류가 발생했습니다:", error);
      alert("직원 정보 업데이트에 실패했습니다. 다시 시도해주세요.");
    }
  } else {
    alert("직원을 선택해주세요.");
  }
};

// API에서 조직 및 직원 데이터 가져오기
const fetchOrganizationData = async () => {
  try {
    // 응답 데이터 구조에 맞게 API 엔드포인트 수정
    const response = await api.get("/voc/voc-charge-persons", {
      params: {
        vocCategoryCode:
          props.vocCategoryCode,
      },
    });

    // API 응답 데이터가 리스트 형태로 온다고 가정
    let vocChargePersonList = response.data;

    vocChargePersonList = vocChargePersonList.filter(item => item.vocChargePersonDepartmentName != 'OWCRM개발팀');

    console.log(vocChargePersonList);

    // 부서별로 그룹화
    const departmentMap = new Map();

    vocChargePersonList.forEach((person) => {
      const deptCode = person.vocChargePersonDepartmentName;

      if (!departmentMap.has(deptCode)) {
        departmentMap.set(deptCode, {
          id: deptCode,
          name: deptCode, // 부서명이 없으면 코드로 대체
          isExpanded: true,
          isSelected: false,
          employees: [],
        });
      }

      // 해당 부서에 직원 추가
      departmentMap.get(deptCode).employees.push({
        id: person.vocChargePersonEmployeeNumber,
        name: person.vocChargePersonEmployeeName, // 이름이 없으면 사번으로 대체
        position: person.itemCode || "직급 없음",
        isSelected: false,
        corporationCode: person.vocChargePersonCorporationCode,
        employeeNumber: person.vocChargePersonEmployeeNumber,
        departmentCode: person.vocChargePersonDepartmentCode,
        vocChargePersonNumber: person.vocChargePersonNumber,
      });
    });

    // Map을 배열로 변환
    const formattedData = Array.from(departmentMap.values());

    // 기본적으로 모두 펼쳐진 상태로 설정
    formattedData.forEach((dept) => {
      dept.isExpanded = true;
    });

    organizationList.value = formattedData;
  } catch (error) {
    console.error("Failed to fetch organization data:", error);
  }
};

// props.vocCategoryCode가 변경될 때마다 데이터 새로 가져오기
watch(
  () => props.vocCategoryCode,
  (newCode) => {
    if (newCode) {
      fetchOrganizationData();
    }
  }
);

// 컴포넌트가 마운트될 때 데이터 가져오기
onMounted(() => {
  if (props.vocCategoryCode) {
    console.log(props.vocCategoryCode);
    console.log(props.vocNumber);
    fetchOrganizationData();
  }

});
</script>

<template>
  <OwPopup v-bind="props">
    <div>
      <BTableSimple responsive bordered="false" small class="ow-table-read">
        <div class="employee-list">
          <div
            v-for="(org, index) in organizationList"
            :key="org.id"
            class="organization-item"
          >
            <div
              class="org-header"
              @click="toggleDepartment(index)"
              :class="{ selected: org.isSelected }"
            >
              <div class="toggle-icon">
                {{ org.isExpanded ? "−" : "+" }}
              </div>
              <span>{{ org.name }}</span>
            </div>

            <!-- 직원 목록 (부서가 확장되었을 때만 표시) -->
            <div v-if="org.isExpanded" class="employee-sublist">
              <div
                v-for="employee in org.employees"
                :key="employee.id"
                class="employee-item"
                @click="selectEmployee(employee)"
                :class="{ selected: employee.isSelected }"
              >
                <div class="indent">
                  <span>{{ employee.name }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </BTableSimple>
      <div class="ow-popup-bottom">
        <BButton size="md" variant="base base-gray" @click="props.onClose">
          취소
        </BButton>
        <BButton
          id="btnOk"
          size="md"
          variant="base base-dark"
          @click="clickSave()"
        >
          확인
        </BButton>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
.employee-list {
  width: 100%;
}

.organization-item {
  border-bottom: 1px solid #f0f0f0;
}

.org-header {
  padding: 12px 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  font-weight: 500;
}

.org-header.selected,
.employee-item.selected {
  color: #4a90e2;
}

.toggle-icon {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 18px;
  height: 18px;
  margin-right: 8px;
  font-size: 12px;
  font-weight: bold;
  color: white;
  background-color: #e0e0e0;
  border-radius: 50%;
}

.employee-sublist {
  background-color: #f9f9f9;
}

.employee-item {
  padding: 10px 16px;
  cursor: pointer;
  border-top: 1px solid #f0f0f0;
}

.employee-item:hover {
  background-color: #f0f0f0;
}

.indent {
  margin-left: 26px;
  display: flex;
  align-items: center;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}

</style>

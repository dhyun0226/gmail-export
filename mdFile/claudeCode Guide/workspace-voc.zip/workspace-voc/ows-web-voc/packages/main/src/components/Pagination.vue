<script setup>
import { computed, ref, watch, watchEffect } from 'vue';

const props = defineProps({
  paging: {
    type: Object,
    default() {
      return { totalItemCount: 0, pageSize: 20, pageNo: 1 };
    },
  },
  nGridCount: {
    type: Number,
    default: 1,
  },
});

const emit = defineEmits(['onMovePage']);
const paging = computed(() => props.paging);
const pageNo = computed({
  get() {
    return paging.value.pageNo;
  },
  // setter
  set(newValue) {
    paging.value.pageNo = newValue;
  },
});
// const pageNo = ref(paging.value.pageNo);

watch(
  () => pageNo.value,
  (newVlaue, oldValue) => {
    emit('onMovePage', newVlaue);
  },
);

// watchEffect(() => {
//   pageNo.value = paging.value.pageNo;
// });
</script>

<template>
  <div>
    <BPagination
      v-model="pageNo"
      :total-rows="paging.totalItemCount"
      :per-page="paging.pageSize * props.nGridCount"
    />
  </div>
</template>

<style lang="scss" scoped></style>

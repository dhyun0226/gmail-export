<!-- DxTreeList.vue -->
<script lang="ts" setup>
import { computed, defineEmits, defineProps, ref, watch } from "vue";
import DxTreeList, { DxColumn } from "devextreme-vue/tree-list";

// 부모 컴포넌트의 props 정의
const props = defineProps({
  dataSource: {
    type: Object,
    required: true,
  },
  columns: {
    type: Array,
    default: () => [],
  },
  keyExpr: {
    type: String,
    default: "key",
  },
  parentIdExpr: {
    type: String,
    default: "parentId",
  },
  rootValue: {
    type: [String, Number, null],
    default: null,
  },
  showBorders: {
    type: Boolean,
    default: true,
  },
  showRowLines: {
    type: Boolean,
    default: true,
  },
  columnAutoWidth: {
    type: Boolean,
    default: true,
  },
  wordWrapEnabled: {
    type: Boolean,
    default: true,
  },
  height: {
    type: [String, Number],
    default: "auto",
  },
  noDataText: {
    type: String,
    default: "데이터가 없습니다",
  },
  defaultColDef: {
    type: Object,
    default: () => ({ alignment: "center" }),
  },
  hasItemsExpr: {
    type: String,
    default: "hasChildren",
  },
  onCellPrepared: {
    type: Function,
  },
  // 최상위 노드 자동 확장 옵션 추가
  autoExpandTop: {
    type: Boolean,
    default: false,
  },
  // 모든 노드 자동 확장 옵션 추가
  autoExpandAll: {
    type: Boolean,
    default: false,
  },
  // 자동 확장을 적용할 레벨 (0: 최상위만, 1: 최상위 + 그 아래 레벨, -1: 모든 레벨)
  autoExpandLevel: {
    type: Number,
    default: 0,
  },
});

// 최초 확장 여부를 추적하는 플래그 추가
const initialExpansionDone = ref(false);
// 데이터 로드 완료 여부
const dataLoaded = ref(false);

// 부모 컴포넌트로 이벤트 전달
const emit = defineEmits([
  "row-click",
  "content-ready",
  "node-expand", 
  "node-collapse",
  "expansion-complete", // 노드 확장 완료 이벤트 추가
]);

const treeListRef = ref(null);

// 기본 설정이 적용된 컬럼 처리
const processedColumns = computed(() => {
  if (!props.columns || props.columns.length === 0) {
    return []; // columns가 없으면 빈 배열 반환
  }

  // columns가 있을 경우 defaultColDef 적용
  return props.columns.map((column: any) => ({
    ...props.defaultColDef,
    ...column,
  }));
});

// 행 클릭 이벤트 처리
function onRowClick(e: any) {
  emit("row-click", e);
}

// 컨텐츠 준비 이벤트 처리
function onContentReady(e: any) {
  dataLoaded.value = true;
  
  // 초기화 로직
  if (!initialExpansionDone.value) {
    // 자동 확장 옵션에 따라 처리
    if (props.autoExpandAll) {
      expandAllRows();
      initialExpansionDone.value = true;
    } else if (props.autoExpandTop && e.component.getTopVisibleRowData()) {
      handleAutoExpand();
      initialExpansionDone.value = true;
    }
  }
  
  emit("content-ready", e);
}

// 자동 확장 처리 함수
async function handleAutoExpand() {
  if (!treeListRef.value?.instance) return;
  
  const instance = treeListRef.value.instance;
  const visibleRows = instance.getVisibleRows();
  
  if (visibleRows.length === 0) return;
  
  if (props.autoExpandLevel === 0) {
    // 최상위 노드만 확장
    expandTopNodes();
  } else if (props.autoExpandLevel > 0) {
    // 지정된 레벨까지 확장
    await expandToLevel(props.autoExpandLevel);
  } else if (props.autoExpandLevel === -1) {
    // 모든 레벨 확장
    await expandAllRowsRecursively();
  }
  
  // 확장 완료 이벤트 발생
  emit("expansion-complete");
}

// 노드 확장 이벤트 처리
function onNodeExpanding(e: any) {
  // 확장 중인 노드의 키 가져오기
  const key = e.key;
  emit("node-expand", key);
}

// 노드 접기 이벤트 처리
function onNodeCollapsing(e: any) {
  const key = e.key;
  emit("node-collapse", key);
}

// 노드 수동 확장 메서드
function expandNode(key: any) {
  if (treeListRef.value?.instance) {
    treeListRef.value.instance.expandRow(key);
  }
}

// 최상위 노드들 확장 메서드
function expandTopNodes() {
  if (treeListRef.value?.instance) {
    const instance = treeListRef.value.instance;
    const visibleRows = instance.getVisibleRows();
    const topNodes = visibleRows.filter(row => row.level === 0);
    
    topNodes.forEach(node => {
      if (node.node.hasChildren) {
        instance.expandRow(node.key);
      }
    });
  }
}

// 특정 레벨까지 노드 확장 메서드
async function expandToLevel(level: number) {
  if (!treeListRef.value?.instance) return;
  
  const instance = treeListRef.value.instance;
  
  // 레벨별 확장을 위한 재귀 함수
  async function expandLevelRecursively(currentLevel: number) {
    if (currentLevel > level) return;
    
    const visibleRows = instance.getVisibleRows();
    const levelNodes = visibleRows.filter(row => row.level === currentLevel - 1);
    
    if (levelNodes.length === 0) return;
    
    // 현재 레벨의 노드들 확장
    let hasExpandedAny = false;
    for (const node of levelNodes) {
      if (!instance.isRowExpanded(node.key) && node.node.hasChildren) {
        instance.expandRow(node.key);
        hasExpandedAny = true;
      }
    }
    
    // UI 업데이트를 위한 짧은 지연
    if (hasExpandedAny) {
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    
    // 다음 레벨로 진행
    await expandLevelRecursively(currentLevel + 1);
  }
  
  // 레벨 0부터 시작
  await expandLevelRecursively(1);
}

// 노드 수동 접기 메서드
function collapseNode(key: any) {
  if (treeListRef.value?.instance) {
    treeListRef.value.instance.collapseRow(key);
  }
}

// 모든 행 접기 메서드
function collapseAllRows() {
  if (treeListRef.value?.instance) {
    // 확장된 모든 행 가져오기
    const rows = treeListRef.value.instance.getVisibleRows();
    for (const row of rows) {
      if (treeListRef.value.instance.isRowExpanded(row.key)) {
        treeListRef.value.instance.collapseRow(row.key);
      }
    }
  }
}

// 모든 행 펼치기 메서드 (단순 버전)
function expandAllRows() {
  if (treeListRef.value?.instance) {
    // 모든 행 가져오기
    const rows = treeListRef.value.instance.getVisibleRows();
    for (const row of rows) {
      // 접힌 상태인 노드만 펼치기
      if (!treeListRef.value.instance.isRowExpanded(row.key) && row.node.hasChildren) {
        treeListRef.value.instance.expandRow(row.key);
      }
    }
  }
}

// 모든 행 펼치기 메서드 (재귀적으로 처리)
async function expandAllRowsRecursively() {
  if (!treeListRef.value?.instance) return;
  
  const instance = treeListRef.value.instance;
  
  // 재귀적으로 노드 확장하는 함수
  async function expandNodesRecursively() {
    // 현재 보이는 모든 행 가져오기
    const visibleRows = instance.getVisibleRows();
    
    // 접힌 상태인 노드 찾기
    const collapsedNodes = visibleRows.filter(row => 
      !instance.isRowExpanded(row.key) && 
      row.node.hasChildren
    );

    // 더 이상 접힌 노드가 없으면 종료
    if (collapsedNodes.length === 0) {
      return;
    }
    
    // 접힌 노드들 펼치기
    for (const node of collapsedNodes) {
      instance.expandRow(node.key);
    }
    
    // UI 업데이트를 위해 짧은 지연 시간 부여
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // 다음 레벨의 노드 확장을 위해 재귀 호출
    await expandNodesRecursively();
  }
  
  // 노드 확장 시작
  await expandNodesRecursively();
}

// 그리드 새로고침 메서드
function refresh() {
  initialExpansionDone.value = false; // 플래그 리셋
  dataLoaded.value = false; // 데이터 로드 상태 리셋
  treeListRef.value?.instance?.refresh();
}

// props 변경에 대한 감시
watch(() => props.autoExpandTop, (newValue) => {
  if (newValue && dataLoaded.value && !initialExpansionDone.value) {
    expandTopNodes();
    initialExpansionDone.value = true;
  }
});

watch(() => props.autoExpandAll, (newValue) => {
  if (newValue && dataLoaded.value && !initialExpansionDone.value) {
    expandAllRows();
    initialExpansionDone.value = true;
  }
});

watch(() => props.autoExpandLevel, (newValue, oldValue) => {
  if (dataLoaded.value && newValue !== oldValue) {
    initialExpansionDone.value = false;
    handleAutoExpand();
  }
});

// 부모 컴포넌트에 메서드 노출
defineExpose({
  expandNode,
  collapseNode,
  collapseAllRows,
  expandAllRows,
  expandAllRowsRecursively,
  expandTopNodes,
  expandToLevel,
  refresh,
  getTreeListInstance: () => treeListRef.value?.instance,
});

</script>

<template>
  <DxTreeList
    ref="treeListRef"
    :data-source="dataSource"
    :key-expr="keyExpr"
    class="ow-treelist no-bg"
    :parent-id-expr="parentIdExpr"
    :root-value="rootValue"
    :show-borders="showBorders"
    :show-row-lines="showRowLines"
    :column-auto-width="columnAutoWidth"
    :word-wrap-enabled="wordWrapEnabled"
    :height="height"
    :no-data-text="noDataText"
    :has-items-expr="hasItemsExpr"
    :on-cell-prepared="onCellPrepared"
    @row-click="onRowClick"
    @content-ready="onContentReady"
    @node-expanding="onNodeExpanding"
    @node-collapsing="onNodeCollapsing"
  >
    <!-- 각 컬럼 동적 생성 -->
    <DxColumn
      v-for="(column, index) in processedColumns"
      :key="index"
      v-bind="column"
    />
  </DxTreeList>
</template>

<style scoped>
:deep(.dx-treelist-icon-container) {
  width: 24px !important;
  text-align: center;
}

:deep(.dx-treelist-collapsed) .dx-treelist-icon-container:before {
  content: "+" !important;
  display: inline-block;
  font-weight: bold;
  font-size: 16px;
}

:deep(.dx-treelist-expanded) .dx-treelist-icon-container:before {
  content: "-" !important;
  display: inline-block;
  font-weight: bold;
  font-size: 16px;
}

* {
  font-family: "Spoqa Han Sans Neo", "sans-serif";
}

.dx-widget {
  font-family: "Spoqa Han Sans Neo", "sans-serif";
}

.dx-treelist-container {
  font-family: "Spoqa Han Sans Neo", "sans-serif";
  font-size: 12px;
}

.dx-treelist .dx-row > td {
  padding: 7px;
}

:deep(.dx-treelist-headers .dx-header-row:first-child td) {
  font-weight: bold;
}

:deep(.dx-treelist-rowsview .dx-row td) {
  border: none !important;
}

.dx-treelist-headers .dx-treelist-table .dx-row > td {
  border-bottom: 1px solid #e0e0e0;
  padding: 10px 7px;
}

.dx-treelist-rowsview .dx-selection.dx-row:not(.dx-row-focused) > td {
  background-color: rgba(0, 0, 0, 0.04);
}
</style>
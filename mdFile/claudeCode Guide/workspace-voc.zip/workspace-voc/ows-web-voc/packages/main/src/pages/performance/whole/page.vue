<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import { useUserProfile } from '@ows/core';
import Detail from './components/Detail.vue';
import TotalSummary from './components/TotalSummary.vue';
import OwFilterCountry from '@/components/OwFilterCountry.vue';
import OwFilterOrg from '@/components/OwFilterOrg.vue';
import ColumnPopup from '@/components/ColumnPopup.vue';

const {
  openPopup: openColumnPopup,
  closePopup: closeColumnPopup,
  isPopupOpen: isColumnPopupOpen,
  getVh,
} = useOwPopup();

const { currentUserOrganizationAncestors } = useUserProfile();

const selectCountry = ['Global', '아시아', '대한민국', '국내영업총괄본부'];

const selectOrganization = [];

const popupHeight = 100;
const popupPosition = ref({ my: 'center', at: 'center', of: 'body' });
const num = ref(1); // Added num ref for the button ID

function openPopupPosition(id) {
  const vh = getVh(id);
  const popupVh = (popupHeight / window.innerHeight) * 100; // to vh %
  const diffVh = 100 - popupVh;

  let offsetY = 0;
  if (vh > diffVh) {
    offsetY = (((vh - diffVh) * window.innerHeight) / 100) * -1; // to px
  }
  popupPosition.value = {
    my: 'right top',
    at: 'right top',
    of: `#${id}`,
    offset: `0 ${offsetY + 25}`,
  };

  openColumnPopup();
}
// 팝업 외부 클릭 감지
function handleClickOutside(event) {
  // 팝업 DOM을 참조합니다.
  const popupElement = document.querySelector('.popup-class');
  // 팝업 엘리먼트를 찾지 못했을 경우, 이벤트를 무시합니다.
  if (!popupElement) {
    return;
  }
  // 클릭한태그가 SPAN인지 확인
  if (event.target.tagName === 'SPAN' || event.target.tagName === 'INPUT') {
    console.log('클릭한 태그가 SPAN입니다. 팝업을 유지합니다.');
  }
  else {
    closeColumnPopup();
  }
}
// 팝업 닫기 함수
function handleClosePopup() {
  closeColumnPopup();
}

onMounted(() => {
  window.addEventListener('click', handleClickOutside);
});
onBeforeUnmount(() => {
  window.removeEventListener('click', handleClickOutside);
});
const dateOptions = ref({
  from: dayjs().format('YYYY-MM-DD'),
  to: dayjs().hour(23).minute(59).second(59).format('YYYY-MM-DD'),
  doubleFlag: false,
  today: false,
  twice: false,
  disabledTwice: false,
  disabledDouble: false,
  disabledPicker: false,
  rangeUnit: 'month',
});

const term = ref('productTerm');
const termOptions = [
  { text: '품목', value: 'productTerm' },
  { text: '지역', value: 'countryTerm' },
  { text: '인원', value: 'personalTerm' },
];

const listGroup = ref('');
const listGroupOptions = [
  { text: '품목', value: 'product' },
  { text: '지역', value: 'country' },
  { text: '인원', value: 'personal' },
];

// 품목 코드와 텍스트 매핑
const productOptions = [
  { text: '전체', value: 'all' },
  { text: '임플란트', value: 'implant' },
  { text: '기구', value: 'instrument' },
  { text: '보존/근관', value: 'endodontic' },
  { text: '수복/접착', value: 'restorative' },
  { text: '인상/보철', value: 'impression' },
  { text: '절삭/연마', value: 'cutting' },
  { text: 'GBR', value: 'gbr' },
  { text: '위생용품', value: 'hygiene' },
  { text: '장비', value: 'equipment' },
  { text: '교정용기구', value: 'orthodontic' },
  { text: '예방/구강', value: 'prevention' },
  { text: '기공용품', value: 'dentalLab' },
  { text: '의약품', value: 'medicine' },
  { text: '생활가전', value: 'appliance' },
];

const selectedProduct = ref('all');
const today = ref(false); // Added missing today ref

const filterOptions = ref({
  product: selectedProduct.value,
  country: '',
  org: '',
});

function handleItemFilterChange() {
  // load();
}

function handleProductChange(value) {
  filterOptions.value.product = value;
  // 필요한 후속 작업 수행
}

function handleDateChange(date, newVal) {
  dateOptions.value.from = date;
  dateOptions.value.to = dayjs(newVal).hour(23).minute(59).second(59);
}

function handleUnitChange(unit) {
  dateOptions.value.rangeUnit = unit;
}

function handleTwiceChange(twice) {}

function handlePrevNextChange(unit) {}

function changeSelectOrgItem(data) {
  filterOptions.value.org = data.value;
}

function changeSelectCountryItem(data) {
  filterOptions.value.country = data.value;
}

// Helper functions to determine which filters to show
function showProductFilter() {
  if (dateOptions.value.doubleFlag) {
    return term.value !== 'productTerm';
  }
  else {
    return listGroup.value !== 'product';
  }
}

function showCountryFilter() {
  if (dateOptions.value.doubleFlag) {
    return term.value !== 'countryTerm';
  }
  else {
    return listGroup.value !== 'country';
  }
}

function showOrgFilter() {
  if (dateOptions.value.doubleFlag) {
    return term.value !== 'personalTerm';
  }
  else {
    return listGroup.value !== 'personal';
  }
}

function setSelectOrganization(organizationData, targetOrgCode = 'O000000913') {
  const result = ['마케팅본부'];

  const filteredData = organizationData.slice(0, -1);

  if (filteredData.length > 0) {
    for (let i = filteredData.length - 1; i >= 0; i--) {
      result.push(filteredData[i].orgName);
    }
  }

  return result;
}
</script>

<template>
  <div
    class="input-group mb-1"
    role="group"
  >
    <!-- Conditionally show OwFilterOrg -->
    <OwFilterOrg
      v-if="showOrgFilter()"
      department-code="O000000913"
      :props-select-item="
        setSelectOrganization(currentUserOrganizationAncestors, 'O000000913')
      "
      @select-item="changeSelectOrgItem"
    />
  </div>
  <div
    class="input-group gap-1 mb-2"
    role="group"
  >
    <OwBizDatePickerRangeExcluedPickVer2
      v-model:from="dateOptions.from"
      v-model:to="dateOptions.to"
      v-model:is-double-selected="dateOptions.doubleFlag"
      :unit="dateOptions.rangeUnit"
      :disabled-twice="dateOptions.disabledTwice"
      :default-twice="false"
      :disabled-double="dateOptions.disabledDouble"
      :years="15"
      :today="dateOptions.today"
      :hidden-units="['6months', '5years']"
      :disabled-picker="dateOptions.disabledPicker"
      @change="handleDateChange"
      @unit-change="handleUnitChange"
      @prev-next-change="handlePrevNextChange"
      @twice-change="handleTwiceChange"
    />

    <BButton
      v-if="dateOptions.doubleFlag"
      class="ow-bi ow-w24"
      variant="light"
      :style="today ? 'border: 2px solid #176de2;' : ''"
      @click="today = !today"
    >
      <i class="bi bi-box-arrow-left" />
      <span class="visually-hidden">기간/오늘 선택</span>
    </BButton>

    <OwFormRadio
      v-if="dateOptions.doubleFlag"
      v-model="term"
      :options="termOptions"
      shape="round"
      @change="handleItemFilterChange"
    />
    <OwFormRadio
      v-if="!dateOptions.doubleFlag"
      v-model="listGroup"
      type="all"
      :options="listGroupOptions"
      shape="round"
      @change="handleItemFilterChange"
    />

    <!-- Conditionally show OwFormRadio for products -->
    <OwFormRadio
      v-if="showProductFilter()"
      v-model="selectedProduct"
      :options="productOptions"
      @change="handleProductChange"
    />
    <!-- Conditionally show OwFilterCountry -->
    <OwFilterCountry
      v-if="showCountryFilter()"
      department-code="O000000914"
      :props-select-item="selectCountry"
      @select-item="changeSelectCountryItem"
    />
    <BButton
      v-if="!dateOptions.doubleFlag"
      :id="`btn-${num}`"
      variant="state"
      @click="(event) => { openPopupPosition(`btn-${num}`); event.stopPropagation(); }"
    >
      컬럼선택
    </BButton>
  </div>
  <Detail
    v-if="!dateOptions.doubleFlag"
    :date-options="dateOptions"
    :filter-options="filterOptions"
    :list-group="listGroup"
  />
  <TotalSummary
    v-if="dateOptions.doubleFlag"
    :date-options="dateOptions"
    :filter-options="filterOptions"
    :term="term"
  />
  <Teleport to="body">
    <ColumnPopup
        v-if="isColumnPopupOpen"
        class="popup-class"
        :is-popup-open="isColumnPopupOpen"
        :popup-position="popupPosition"
        :height="popupHeight"
        size="xs"
        :on-close="
        () => {
          handleClosePopup();
        }
      "
    />
  </Teleport>
</template>

<style scoped></style>

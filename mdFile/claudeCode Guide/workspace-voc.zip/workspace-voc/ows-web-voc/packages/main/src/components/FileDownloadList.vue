<script setup lang="ts">
import FileDownloadItem from './FileDownloadItem.vue';
import type { FileInfo } from '@/types/inquiry.ts';

const props = defineProps<{
  fileList: FileInfo[];
}>();
</script>

<template>
  <div
      v-if="fileList && fileList.length > 0"
      class="file-list-container"
  >
<!--    <div class="file-list-label">-->
<!--      첨부파일:-->
<!--    </div>-->
    <div class="file-list-wrapper">
      <FileDownloadItem
          v-for="(file, index) in fileList"
          :key="file.fileId"
          :file="file"
          :index="index"
      />
    </div>
  </div>
</template>

<style scoped>
.file-list-container {
  display: flex;
  align-items: flex-start;
  flex-wrap: wrap;
  gap: 8px;
  padding: 8px 0;
}

.file-list-label {
  font-weight: 500;
  color: #495057;
  white-space: nowrap;
  margin-right: 8px;
  padding-top: 4px;
}

.file-list-wrapper {
  display: flex;
  flex-wrap: nowrap; /* 줄바꿈 방지 */
  gap: 6px;
  flex: 1;
  min-width: 0;
  overflow-x: auto;  /* 가로 스크롤 */
}

@media (max-width: 768px) {
  .file-list-container {
    flex-direction: column;
    align-items: stretch;
  }

  .file-list-label {
    margin-bottom: 4px;
  }

  .file-list-wrapper {
    flex-wrap: wrap;
  }
}
</style>

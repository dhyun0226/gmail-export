<script setup>
import { ref, onMounted, defineProps, defineEmits } from "vue";

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: "요청사 양식" },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: "lg" },
  width: { type: Number, default: 1200 },
  height: { type: Number, default: 800 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: false },
  onClose: { type: Function },
});

const emit = defineEmits(["selectTemplate"]);

// 현재 선택된 필터 값
const selectedFilter = ref("os");

// 필터 라디오 옵션
const filterOptions = [
  { value: "os", text: "오스템임플란트(주)" },
  { value: "chair", text: "유니트체어연구소" },
  { value: "structure", text: "구매본부" },
  { value: "manage", text: "마케팅본부" },
  { value: "online", text: "온라인영업본부" },
  { value: "hr", text: "인사본부" },
  { value: "permit", text: "인허가실" },
  { value: "finance", text: "재경본부" },
  { value: "research", text: "치의학연구원" },
];

// 검색어
const searchText = ref("");

// 템플릿 목록
const templates = ref([
  {
    id: 1,
    name: "협조전 (오스템임플란트(주))",
    category: "os",
    thumbnail: null,
  },
  {
    id: 2,
    name: "S/W 구매에 따른 투자 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: "/sample-template.png",
  },
  {
    id: 3,
    name: "PC 구매 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: "/sample-pc.png",
  },
  {
    id: 4,
    name: "네트워크 장비 도입 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: "/sample-network.png",
  },
  {
    id: 5,
    name: "모니터 구매 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: null,
  },
  {
    id: 6,
    name: "AWS CLOUD 시스템 변경 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: "/sample-aws.png",
  },
  {
    id: 7,
    name: "서버 장비 설치 요청 (OW개발총괄연구소)",
    category: "structure",
    thumbnail: "/sample-server.png",
  },
  {
    id: 8,
    name: "구매사전요청서 (구매본부)",
    category: "structure",
    thumbnail: "/sample-purchase.png",
  },
]);

// 페이지네이션
const currentPage = ref(1);
const itemsPerPage = 8;
const totalPages = ref(Math.ceil(templates.value.length / itemsPerPage));

// 필터 변경 핸들러
const handleFilterChange = (value) => {
  selectedFilter.value = value;
};

// 템플릿 선택
const selectTemplate = (template) => {
  emit("selectTemplate", template);
};

// 검색 핸들러
const handleSearch = () => {
  // 검색 기능은 유지하지만 실제 필터링은 하지 않음
};

// 현재 페이지의 템플릿 목록
const paginatedTemplates = () => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return templates.value.slice(start, end);
};

// 페이지 변경
const changePage = (page) => {
  currentPage.value = page;
};

// 취소 버튼 클릭
const handleClose = () => {
  if (props.onClose) {
    props.onClose();
  }
};
</script>

<template>
  <OwPopup v-bind="props">
    <div class="form-container">
      <!-- 상단 검색 및 필터 영역 -->
      <div class="header-section">
        <div class="search-filter-row">
          <div class="search-section">
            <div class="label">양식명</div>
            <div class="search-input-wrapper">
              <input
                type="text"
                v-model="searchText"
                @input="handleSearch"
                placeholder="검색어 입력"
                class="search-input"
              />
              <button class="search-btn">검색</button>
            </div>
          </div>
          
          <!-- OwFormRadio 컴포넌트 -->
          <div class="form-radio-wrapper">
            <OwFormRadio
              v-model="selectedFilter"
              :options="filterOptions"
              @change="handleFilterChange"
            />
          </div>
        </div>
      </div>

      <!-- 메인 템플릿 그리드 -->
      <div class="templates-grid">
        <div 
          v-for="template in paginatedTemplates()" 
          :key="template.id"
          class="template-card"
          @click="selectTemplate(template)"
        >
          <div class="template-header">{{ template.name }}</div>
          <div class="template-content">
            <div v-if="template.thumbnail" class="template-thumbnail">
              <!-- 이미지가 있는 경우 -->
              <div class="sample-image"></div>
            </div>
            <div v-else class="template-placeholder">
              <!-- 이미지가 없는 경우 -->
              <div class="text-placeholder">
                <div class="placeholder-line"></div>
                <div class="placeholder-line short"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 하단 페이지네이션 -->
      <div class="pagination">
        <button class="page-btn first" @click="changePage(1)">&laquo;</button>
        <button class="page-btn prev" @click="changePage(Math.max(1, currentPage - 1))">&lt;</button>
        
        <button 
          v-for="page in totalPages" 
          :key="page"
          class="page-btn number" 
          :class="{ active: currentPage === page }"
          @click="changePage(page)"
        >
          {{ page }}
        </button>
        
        <button class="page-btn next" @click="changePage(Math.min(totalPages, currentPage + 1))">&gt;</button>
        <button class="page-btn last" @click="changePage(totalPages)">&raquo;</button>
      </div>
    </div>
  </OwPopup>
</template>

<style scoped>
.form-container {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  width: 100%;
  display: flex;
  flex-direction: column;
  background-color: #fff;
  height: 710px;
  overflow: hidden;
}

/* 상단 영역 */
.header-section {
  padding: 15px;
  border-bottom: 1px solid #e0e0e0;
}

.search-filter-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}

.search-section {
  display: flex;
  align-items: center;
  width: 300px;
  margin-right: 20px;
}

.label {
  width: 60px;
  font-size: 14px;
  font-weight: 500;
}

.search-input-wrapper {
  display: flex;
  flex: 1;
}

.search-input {
  width: 200px;
  padding: 6px 12px;
  border: 1px solid #ddd;
  border-radius: 4px 0 0 4px;
  font-size: 14px;
}

.search-btn {
  background-color: #287bff;
  color: white;
  border: none;
  font-size: 14px;
  cursor: pointer;
  border-radius: 0 4px 4px 0;
}

/* OwFormRadio 스타일 */
.form-radio-wrapper {
  margin-left: auto;
  display: flex;
  align-items: center;
}

/* 템플릿 그리드 영역 */
.templates-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  padding: 20px;
  overflow-y: auto;
  flex: 1;
}

.template-card {
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
  height: 250px;
  display: flex;
  flex-direction: column;
}

.template-card:hover {
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.template-header {
  padding: 12px;
  background-color: #f0f0f0;
  border-bottom: 1px solid #e0e0e0;
  font-size: 14px;
  font-weight: 500;
  color: #000;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.template-content {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 15px;
  background-color: #fff;
}

.template-thumbnail {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sample-image {
  width: 100%;
  height: 100%;
  background-color: #f5f5f5;
  border: 1px dashed #ddd;
}

.template-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.text-placeholder {
  width: 80%;
}

.placeholder-line {
  height: 8px;
  margin-bottom: 10px;
  background-color: #f0f0f0;
  width: 100%;
}

.placeholder-line.short {
  width: 60%;
}

/* 페이지네이션 */
.pagination {
  display: flex;
  justify-content: center;
  height: 40px;
}

.page-btn {
  width: 32px;
  height: 32px;
  margin: 0 3px;
  border: 1px solid #ddd;
  background-color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

.page-btn.active {
  background-color: #333;
  color: white;
  border-color: #333;
}

.page-btn:hover:not(.active) {
  background-color: #f5f5f5;
}

@media (max-width: 1200px) {
  .templates-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 900px) {
  .templates-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 600px) {
  .templates-grid {
    grid-template-columns: 1fr;
  }
}
</style>
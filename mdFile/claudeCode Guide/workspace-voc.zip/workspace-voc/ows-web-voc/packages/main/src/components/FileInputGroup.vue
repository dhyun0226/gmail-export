<script setup lang="ts">
import { useFileDownload, useFileUpload } from '@ows/core';
import { shallowRef, watch } from 'vue';
import type { AttachFile } from '@/types';

const emit = defineEmits(['update:files']); // 부모로 files 값을 전달하기 위한 emit

const { link } = useFileDownload();
const { files, open } = useFileUpload();
const items = shallowRef<AttachFile[]>([]);

function upload() {
  open();
}

function erase(data: AttachFile) {
  items.value = items.value.filter(item => item !== data);
}

const fileHandling = {
  addFile(file: AttachFile) {
    const exists = items.value.some(item => item.fileId === file.fileId);
    if (!exists) {
      items.value = [...items.value, file];
    }
  },
};

watch(files, (newFile) => {
  if (newFile) {
    fileHandling.addFile(newFile[0]);
    emit('update:files', files.value); // 부모로 files 값을 전달
  }
});
</script>

<template>
  <BTd>
    <div
      class="input-group"
      role="group"
    >
      <BFormInput
        placeholder="첨부파일을 선택해주세요"
        readonly
        :value="items.map(item => item.fileName).join(', ')"
        class="mr-10"
      />
      <BButton
        variant="state"
        class="file-upload-button"
        @click="upload"
      >
        파일첨부
      </BButton>
    </div>
  </BTd>
</template>

<style lang="scss" module>
.list-group {
  --bs-list-group-border-width: 0;
}

.list-group-item {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.875rem;
}

.list-group-item-text {
  margin-inline-end: 0.25rem;
}

.warning {
  --bs-list-group-border-width: 0;
  --bs-list-group-item-padding-y: 0.125rem;
  position: relative;
  color: #565656;
  font-size: 13px;
  line-height: 1.69;
  letter-spacing: -0.43px;

  &:before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0.5rem;
    transform: translateY(-50%);
    width: 2px;
    height: 2px;
    margin-right: 4px;
    background-color: #565656;
  }
}

.form-input {
  margin-right: 10px; // 버튼과 입력 필드 사이 간격
}
</style>

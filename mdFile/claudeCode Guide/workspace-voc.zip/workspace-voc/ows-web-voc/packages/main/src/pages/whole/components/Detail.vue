<script setup>
import { computed, onMounted, ref, watch } from 'vue';
import { useApi, useCommonCode } from '@ows/core';
import dayjs from 'dayjs';

import { useOwPopup } from '@ows/ui';
import { useColumnPopup } from '@/composables/useColumnPopupStore';
import DxListNGrid from '@/components/DxListNGrid.vue';
import { dateUtils } from '@/utils';
import VocDetailPopup from '@/components/VocDetailPopup.vue';

const props = defineProps({
  dateOptions: Object,
  filterOptions: Object,
});

const {
  openPopup: openVocDetailPopup,
  closePopup: closeVocDetailPopup,
  isPopupOpen: isVocDetailPopupOpen,
  getVh,
} = useOwPopup();

// const popupHeight = 500;
const popupPosition = ref({ my: 'center', at: 'center', of: 'body' });

function openPopupPosition(id) {
  // const vh = getVh(id);
  // const popupVh = (popupHeight / window.innerHeight) * 100; // to vh %
  // const diffVh = 100 - popupVh;

  // let offsetY = 0;
  // if (vh > diffVh) {
  //   offsetY = (((vh - diffVh) * window.innerHeight) / 100) * -1; // to px
  // }
  // popupPosition.value = {
  //   my: 'left top',
  //   at: 'right top',
  //   of: `#${id}`,
  //   offset: `5 ${offsetY}`,
  // };

  openVocDetailPopup();
}

const columnPopupStore = useColumnPopup();

const api = useApi();
const { VOC_ITM_CTG_CD } = await useCommonCode('VOC_ITM_CTG_CD');
const { VOC_DVCD } = await useCommonCode('VOC_DVCD');
const {
  VOC_RGST_DVCD: vocRgstDvcd,
  VOC_RGST_DTL_DVCD: vocRgstDtlDvcd,
} = await useCommonCode('VOC_RGST_DVCD', 'VOC_RGST_DTL_DVCD');
const vocNumber = ref(0);
const columns = ref([
  {
    caption: '접수일자',
    width: '100',
    dataField: 'vocRegistrationDateTime',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize',
    visible: true,
  },
  {
    caption: '내용',
    width: '*',
    dataField: 'vocContent',
    allowMerge: true,
    alignment: 'left',
    allowSorting: false,
    visible: true,
    cellType: 'customize3',
  },
  {
    caption: '요청자',
    width: '120',
    dataField: 'vocCustomerName',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '품목',
    width: '120',
    dataField: 'itemCode',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '요청부서',
    width: '120',
    dataField: 'vocRegistrationDivisionCode',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '유형',
    width: '120',
    dataField: 'vocRegistrationDetailDivisionCode',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

function getItemText(code) {
  const item = VOC_ITM_CTG_CD.find(item => item.value === code);
  return item ? item.text : code;
}

function getDateFormat(date) {
  if (Array.isArray(date)) {
    // 배열을 문자열로 변환
    const dateString = `${date[0]}-${date[1]}-${date[2]} ${date[3]}:${date[4]}:${date[5]}`;
    if (!dayjs(dateString).isValid()) {
      return 'Invalid Date';
    }
    return dayjs(dateString).format('YYYY-MM-DD');
  }
  if (!dayjs(date).isValid()) {
    return 'Invalid Date';
  }
  return dayjs(date).format('YYYY-MM-DD');
}

function getTimeFormat(date) {
  if (Array.isArray(date)) {
    // 배열을 문자열로 변환
    const dateString = `${date[0]}-${date[1]}-${date[2]} ${date[3]}:${date[4]}:${date[5]}`;
    if (!dayjs(dateString).isValid()) {
      return 'Invalid Date';
    }
    return dayjs(dateString).format('HH:mm');
  }
  if (!dayjs(date).isValid()) {
    return 'Invalid Date';
  }
  return dayjs(date).format('HH:mm');
}

function getNGridCountByColumns() {
  if (columnPopupStore.selectedColumns.length === 2) {
    gridOption.value.nGridCount = 6;
  }
  else if (columnPopupStore.selectedColumns.length === 3) {
    gridOption.value.nGridCount = 4;
  }
  else {
    gridOption.value.nGridCount = 2;
  }
}

function getColumnsByDate() {
  const date = props.dateOptions.rangeUnit;
  if (date === 'day') {
    columns.value.forEach((col) => {
      if (col.caption === '접수일자') {
        col.caption = '접수시간';
      }
      col.visible = true;
    });
  }
  else if (date === 'week') {
    columns.value.forEach((col) => {
      if (col.caption === '접수시간') {
        col.caption = '접수일자';
      }
      col.visible = true;
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '접수시간' || col.caption === '접수일자') {
        col.caption = '접수일자';
        col.visible = false;
      }
      if (col.caption === '요청자') {
        col.visible = false;
      }
    });
  }
  columnPopupStore.setSelectedColumns(
    columns.value.filter(col => col.visible).map(col => col.caption),
  );
}

// 셀병합할 컬럼
const mergeColumns = computed(() => {
  const arr = [];
  columns.value.forEach((e, idx) => {
    if (e.allowMerge) {
      arr.push({ idx, field: e.dataField });
    }
  });
  return arr;
});

const mergeCellIndexs = mergeColumns.value.map(e => [e.idx]);

function onCellPrepared(e) {
  // console.log('Cell prepared:', e);
  // if (e.rowType === 'data' && e.data?.header) {
  //   if (e.columnIndex === 1) {
  //     // console.log(e);
  //     e.cellElement.classList.add('sal-custom');
  //     e.cellElement.colSpan = 4;
  //   }
  //   else if (e.columnIndex > 1) {
  //     e.cellElement.classList.add('sal-disable');
  //   }
  // }
}

function onCellClick(e) {
  openPopupPosition(e.element.id);
  console.log('Cell clicked:', e);
  vocNumber.value = e.data.vocNumber;
  openVocDetailPopup();
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      fromDate: dateUtils.toLocalDateTime(props.dateOptions.from),
      toDate: dateUtils.toLocalDateTimeEnd(props.dateOptions.to),
    };

    const result = await api.get(`/voc/vocs`, { params });

    // 공통코드 매핑 로직 추가
    const mappedData = result.data.data.map(item => {
      const detailCode = vocRgstDtlDvcd.find(code => code.value === item.vocRegistrationDetailDivisionCode);
      const divisionCode = vocRgstDvcd.find(code => code.value === item.vocRegistrationDivisionCode);

      return {
        ...item,
        vocRegistrationDetailDivisionCode: detailCode ? detailCode.text : item.vocRegistrationDetailDivisionCode, // 매핑된 텍스트로 변경
        vocRegistrationDivisionCode: divisionCode ? divisionCode.text : item.vocRegistrationDivisionCode, // 매핑된 텍스트로 변경
      };
    });

    gridOption.value.datas = mappedData;
    gridOption.value.paging.totalItemCount = result.data.totalCount;

    console.log(result);
  } catch (error) {
    gridOption.value.datas = [];
    console.error('Failed to load VOC data:', error);
  }
}

onMounted(() => {
  getColumnsByDate();
  columnPopupStore.setColumns(columns.value);
  columnPopupStore.setSelectedColumns(
    columns.value.filter(col => col.visible).map(col => col.caption),
  );
  load();
});

watch(
  () => props.dateOptions,
  (newVal) => {
    console.log('Date options changed:', newVal);
    getColumnsByDate();
    load();
  },
  { deep: true },
);

watch(
  () => props.filterOptions,
  (newVal) => {
    console.log('Date options changed:', newVal);
    getNGridCountByDate();
    load();
  },
  { deep: true },
);

watch(
  () => columnPopupStore.selectedColumns,
  (newVal) => {
    console.log('Selected columns changed:', newVal);
    columns.value.forEach((col) => {
      col.visible = newVal.includes(col.caption);
    });
    getNGridCountByColumns();
  },
  { deep: true },
);
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :merge-cell-indexs="mergeCellIndexs"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <template v-if="props.dateOptions.rangeUnit === 'day'">
        {{ getTimeFormat(cell.data.vocRegistrationDateTime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.vocRegistrationDateTime) }}
        </div>
      </template>
    </template>

    <template #customize2="{ data: cell }">
      <div>{{ getItemText(cell.data.itemCode) }}</div>
    </template>

    <!-- 접수내용 셀에 대한 커스텀 템플릿 -->
    <template #customize3="{ data: cell }">
      <div>[{{ cell.data.vocTitle }}] {{ cell.data.vocContent }}</div>
    </template>

    <!-- <template #customize="{ data: data }" /> -->
  </DxListNGrid>
  <Teleport to="body">
    <VocDetailPopup
      v-if="isVocDetailPopupOpen"
      :is-popup-open="isVocDetailPopupOpen"
      :popup-position="popupPosition"
      height="auto"
      :voc-number="vocNumber"
      :voc-item-category-code="VOC_ITM_CTG_CD"
      :voc-division-code="VOC_DVCD"
      :width="1000"
      :on-close="
        () => {
          closeVocDetailPopup();
        }
      "
    />
  </Teleport>
</template>

<style></style>

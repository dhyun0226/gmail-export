import { useApi, useOverlay } from '@ows/core';
import { useOwAlert } from '@ows/ui';
import dayjs from 'dayjs';
import 'dayjs/locale/ko';
// import * as XLSX from 'xlsx';
// import XLSX from 'xlsx';

dayjs.locale('ko');

/**
 * 전화번호, 휴대번호, 안심번호 하이픈 처리
 * @param {} val 전화번호
 */
export function telPhoneHyphen(val) {
  if (val === undefined || val === null) {
    return '';
  }
  else {
    return val.replace(/\D/g, '').replace(/(^050.|^02.{0}|^01.|\d{3})(\d+)(\d{4})/, '$1-$2-$3');
  }
}

/**
 *  숫자 천단위 콤마
 */
export function setNumberFormat(data = '') {
  return data.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * 특정 글자수 이상일 때 줄임말(...) 표시
 * @param {} length 글자수 (15글자 이상일 때 줄임말 표시 -> length = 15)
 * @param {} val 텍스트
 */
// 특정 글자수 이상일 때 줄임말(...) 표시 * 기본 8자
export function textEllipsis(val, length = 8) {
  if (val === null || val === '' || val === undefined) {
    return '';
  }
  let result = val;
  if ((val.length || 0) > length) {
    result = `${val.substr(0, length)}...`;
  }
  return result;
}

/**
 * email 형식 validation
 * @param {*} email
 * @returns true or false
 */
export function validationEmail(email) {
  const reg
        = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\])|(([a-z\-0-9]+\.)+[a-z]{2,}))$/i;
  return reg.test(email);
}

/**
 * 사업자 등록 번호 정규식
 * @param {*} businessNumber 사업자등록번호
 */
export function setBusinessNumberFormat(businessNumber) {
  return businessNumber && businessNumber?.replace(/\D/g, '')
    ?.replace(/^(\d{0,3})(\d{0,2})(\d{0,5})$/g, '$1$2$3');
};

/**
 * 영업조직명 포맷
 * '영업본부'.'지점' 붙이지 않도록 함.
 * @param {*} val 조직명
 */
export function salesOrgNameFormat(val) {
  return val.replace(/(영업본부|지점)/g, '');
}

/**
 * customerStatusCode 로 거래처,비거래처 조회
 * @param {*} cust
 * @returns
 */
export function getCustDivisionCode(customerStatusCode) {
  if (customerStatusCode) {
    // 거래처상태 (0=비거래처,1=거래;F=부실;N=중지;X=폐업;M=관리)
    if (customerStatusCode == '0') {
      return 'CUST_02';
    }
    else if (
      customerStatusCode == '1'
      || customerStatusCode == 'F'
      || customerStatusCode == 'N'
      || customerStatusCode == 'X'
      || customerStatusCode == 'M'
    ) {
      return 'CUST_01';
    }
  }
  else {
    return 'CUST_03';
  }
}

/**
 * 1. 진행 중 프로그레스 출력
 * 2. 오류 발생 시 응답 공통처리
 * @returns UseApiReturn
 */
export function useSalApi() {
  const commonApi = useApi();
  const api = commonApi.create();
  api.interceptors.request.handlers = [...commonApi.interceptors.request.handlers];
  api.interceptors.response.handlers = [...commonApi.interceptors.response.handlers];
  const { owAlert } = useOwAlert();
  const overlay = useOverlay();

  api.interceptors.request.use(
    (config) => {
      overlay.show();
      return config;
    },
    (error) => {
      overlay.hide();
      return Promise.reject(error);
    },
  );
  api.interceptors.response.use(
    (response) => {
      overlay.hide();
      return response;
    },
    (error) => {
      overlay.hide();
      if (error.response && error.response.data) {
        let errorMessage = '';
        if ([200, 400].includes(error.response.status)) {
          errorMessage = error.response.data.payload.reduce((acc, cur) => acc = `${acc}\n${cur}`);
        }
        else {
          errorMessage = error.response.data.message;
        }
        const errorMessageOption = error.config.errorMessageOption;
        if (errorMessageOption) {
          if (errorMessageOption.useAlert) {
            owAlert({ title: '확인', message: errorMessage });
          }
        }
        else {
          owAlert({ title: '확인', message: errorMessage });
        }
      }
      return Promise.reject(error);
    },
    () => {
      overlay.hide();
    },
  );
  return api;
}

export function downloadExcelFile(columns, data, fileName) {
  // 컬럼에 있는 값만 추출 & 변수명을 컬럼명으로 변환
  let excelData = data.map((e) => {
    const obj = {};
    columns.forEach((col) => {
      obj[col.caption] = e[col.dataField];
    });
    return obj;
  });

  // 엑셀데이터로 변환
  excelData = excelData.map((e) => {
    const obj = JSON.parse(JSON.stringify(e));
    return obj;
  });

  // 엑셀 파일 생성
  // const wb = XLSX.utils.book_new(); // 파일
  // const ws = XLSX.utils.json_to_sheet(excelData); // 시트
  // XLSX.utils.book_append_sheet(wb, ws, fileName);
  // XLSX.writeFile(wb, `${fileName}.xlsm`);
}

/**
 *  숫자만 입력
 */
export function inputNumber(event) {
  event.target.value = event.target.value.replace(/\D/g, '');
}

/**
 * 금액 단위 한글 포멧 (억, 천, 백만원)
 * @param {*} amount
 * @returns
 */
export function formatKorAmount(amount) {
  const oneHundredMillion = 100000000; // 억 단위
  const tenMillion = 10000000; // 천만원 단위

  if (amount >= oneHundredMillion) {
    const billionPart = Math.floor(amount / oneHundredMillion); // 억 단위
    const millionPart = Math.floor((amount % oneHundredMillion) / tenMillion); // 천만원 단위

    if (millionPart > 0) {
      return `${billionPart}억 ${millionPart}천만원`;
    }
    return `${billionPart}억`;
  }
  else if (amount >= tenMillion) {
    const millionPart = Math.floor(amount / tenMillion); // 천만원 단위
    return `${millionPart}천만원`;
  }
  else if (amount >= 1000000) {
    const hundredThousandPart = Math.floor(amount / 1000000); // 백만원 단위
    return `${hundredThousandPart}백만원`;
  }
  else {
    // 기본 숫자 그대로 반환
    return `${amount}원`;
  }
}

/**
 * 국제화 (internationalization, i18n)
 *
 * 주의: 개발 환경에서는 단독으로 사용되기 때문에 메시지의 충돌이 발생하지 않을 수 있습니다.
 *
 * 그러나 전용 패키지(deploy)에 통합되어 빌드, 배포 시에는 다른 패키지와의 메시지의 충돌이 발생할 수 있습니다.
 *
 * 메시지의 충돌을 방지하기 위해 신중한 메시지의 정의가 필요합니다.
 */

/** @type { import('vue-i18n').I18nOptions['messages'] } */
export default {
  
};

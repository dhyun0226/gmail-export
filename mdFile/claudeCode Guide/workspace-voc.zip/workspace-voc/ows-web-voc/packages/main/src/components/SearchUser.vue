<script setup>
import { ref, watch, nextTick } from 'vue';
import { useApi, useUserProfile } from '@ows/core';
import { debounce } from 'lodash-es';

const emit = defineEmits(['change', 'search']);

const user = defineModel({ type: Object, default: () => ({ empName: '', empNo: '' }) });

const api = useApi();
const { currentUser } = useUserProfile();

// 상태 관리
const searchKeyword = ref('');
const userList = ref([]);
const showDropdown = ref(false);
const selectedIndex = ref(-1);
const isSelecting = ref(false); // 사용자 선택 중인지 여부

// 사용자 검색 (디바운스 적용)
const searchUsers = debounce(async (keyword) => {
  console.log('searchUsers 호출:', keyword);
  if (!keyword || keyword.length < 1) {
    userList.value = [];
    return;
  }

  try {
    const params = {
      corpCode: currentUser.corpCode,
      empName: keyword,
    };
    console.log('API 호출 params:', params);
    const response = await api.get('/tsk/user/getList', { params });
    console.log('API 응답:', response);
    
    // API 응답 구조에 따라 데이터 추출
    if (response && response.data) {
      userList.value = Array.isArray(response.data) ? response.data : response.data.data || [];
    } else if (Array.isArray(response)) {
      userList.value = response;
    } else {
      userList.value = [];
    }
    
    console.log('userList:', userList.value);
    showDropdown.value = userList.value.length > 0;
  } catch (error) {
    console.error('사용자 검색 오류:', error);
    userList.value = [];
  }
}, 300);

// 입력 핸들러
function handleInput(event) {
  const value = event.target.value;
  
  // 사용자가 선택한 것이 아니라 직접 입력하는 경우에만 처리
  if (!isSelecting.value) {
    // 이전에 선택된 사용자가 있었고, 새로 입력을 시작하는 경우
    if (user.value.empNo && value !== `${user.value.empName} (${user.value.empNo})`) {
      user.value = { empName: '', empNo: '' };
      selectedIndex.value = -1;
    }
    
    searchKeyword.value = value;
    
    if (value.length >= 1) {
      showDropdown.value = true;
      searchUsers(value);
    } else {
      userList.value = [];
      showDropdown.value = false;
    }
  }
  
  isSelecting.value = false;
}

// 사용자 선택
function selectUser(userData) {
  isSelecting.value = true; // 선택 중 플래그 설정
  
  user.value = {
    empName: userData.empName || userData.employeeName,
    empNo: userData.empNo || userData.employeeNumber,
    ...userData
  };
  searchKeyword.value = `${userData.empName || userData.employeeName} (${userData.empNo || userData.employeeNumber})`;
  showDropdown.value = false;
  selectedIndex.value = -1;
  emit('change', user.value);
  
  // 선택 후에도 input에 포커스 유지
  nextTick(() => {
    const input = document.querySelector('.search-user-wrapper input');
    if (input) {
      input.focus();
    }
  });
}

// 검색 실행
function search() {
  console.log('search 함수 호출, user:', user.value);
  
  if (user.value && user.value.empNo) {
    // 사용자가 선택된 경우
    emit('search', user.value);
  } else if (searchKeyword.value) {
    // 검색어만 있는 경우
    emit('search', { empName: searchKeyword.value, empNo: searchKeyword.value });
  } else {
    // 빈 상태인 경우 - 빈 객체로 검색 (전체 조회)
    emit('search', { empName: '', empNo: '' });
  }
}

// blur 처리 (드롭다운 닫기)
function handleBlur() {
  // setTimeout으로 클릭 이벤트가 먼저 처리되도록 함
  setTimeout(() => {
    showDropdown.value = false;
    selectedIndex.value = -1;
  }, 200);
}

// focus 처리
function handleFocus() {
  // 이미 사용자가 선택된 상태면 드롭다운 표시하지 않음
  if (!user.value.empNo && searchKeyword.value.length >= 1) {
    showDropdown.value = true;
  }
}

// 키보드 네비게이션 - 아래
function navigateDown() {
  if (!showDropdown.value && searchKeyword.value.length >= 1 && userList.value.length > 0) {
    showDropdown.value = true;
  }
  
  if (showDropdown.value && userList.value.length > 0) {
    if (selectedIndex.value < userList.value.length - 1) {
      selectedIndex.value++;
    } else {
      selectedIndex.value = 0;
    }
    scrollToSelected();
  }
}

// 키보드 네비게이션 - 위
function navigateUp() {
  if (showDropdown.value && userList.value.length > 0) {
    if (selectedIndex.value > 0) {
      selectedIndex.value--;
    } else {
      selectedIndex.value = userList.value.length - 1;
    }
    scrollToSelected();
  }
}

// 선택된 항목으로 스크롤
function scrollToSelected() {
  nextTick(() => {
    const dropdown = document.querySelector('.user-dropdown');
    const selectedItem = document.querySelector('.user-item-active');
    if (dropdown && selectedItem) {
      const dropdownRect = dropdown.getBoundingClientRect();
      const itemRect = selectedItem.getBoundingClientRect();
      
      if (itemRect.bottom > dropdownRect.bottom) {
        dropdown.scrollTop += itemRect.bottom - dropdownRect.bottom;
      } else if (itemRect.top < dropdownRect.top) {
        dropdown.scrollTop -= dropdownRect.top - itemRect.top;
      }
    }
  });
}

// 엔터키 처리
function handleEnter() {
  // 드롭다운이 열려있고 선택된 항목이 있으면 선택
  if (showDropdown.value && selectedIndex.value >= 0 && userList.value.length > 0) {
    selectUser(userList.value[selectedIndex.value]);
    // 선택 후 바로 검색 실행
    nextTick(() => {
      search();
    });
  } else if (showDropdown.value && userList.value.length === 1) {
    // 드롭다운에 항목이 1개만 있으면 자동 선택 후 검색
    selectUser(userList.value[0]);
    nextTick(() => {
      search();
    });
  } else {
    // 그 외 모든 경우 검색 실행 (빈 상태, 사용자 선택된 상태, 검색어만 있는 상태 등)
    search();
  }
}

// user 값이 변경될 때 searchKeyword 업데이트
// 사용자가 선택한 경우에만 업데이트
watch(user, (newUser, oldUser) => {
  // 사용자가 선택한 경우에만 searchKeyword 업데이트
  if (newUser && newUser.empNo && newUser.empNo !== oldUser?.empNo) {
    searchKeyword.value = `${newUser.empName} (${newUser.empNo})`;
  }
}, { immediate: false });
</script>

<template>
  <div class="search-user-wrapper">
    <input 
      v-model="searchKeyword"
      class="form-control"
      placeholder="이름을 입력해주세요."
      @input="handleInput"
      @keydown.down.prevent="navigateDown"
      @keydown.up.prevent="navigateUp"
      @keydown.enter.prevent="handleEnter"
      @focus="handleFocus"
      @blur="handleBlur"
    />
    <button 
      class="btn btn-md btn-search" 
      @click="search" 
    />
    
    <!-- 자동완성 드롭다운 -->
    <div v-if="showDropdown && userList.length > 0" class="user-dropdown">
      <div 
        v-for="(userData, index) in userList" 
        :key="`user-${index}`"
        @mousedown.prevent="selectUser(userData)"
        class="user-item"
        :class="{ 'user-item-active': selectedIndex === index }"
      >
        <div class="user-name">{{ userData.empName || userData.employeeName }} {{ userData.gradeName || '' }} <span class="user-info">({{ userData.deptName || userData.departmentName }} {{ userData.dutyName || '' }})</span></div>

      </div>
    </div>
  </div>
</template>

<style scoped>
.search-user-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  flex: 1;
  width: 100%;
}

.search-user-wrapper .form-control {
  flex: 1;
}

.search-user-wrapper .btn-search {
  margin-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

/* 자동완성 드롭다운 */
.user-dropdown {
  position: absolute;
  top: calc(100% - 1px);
  left: 0;
  right: 25px; /* 검색 버튼 너비만큼 제외 */
  max-height: 200px;
  overflow-y: auto;
  background: white;
  border: 1px solid #ced4da;
  border-radius: 0 0 0.375rem 0.375rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  z-index: 9999;
}

.user-item {
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  transition: background-color 0.2s;
}

.user-item:hover,
.user-item-active {
  background-color: #e4f3ff;
}

.user-item:last-child {
  border-bottom: none;
}

.user-name {
  font-size: 14px;
  font-weight: 500;
  color: #212529;
}

.user-info {
  font-size: 12px;
  color: #6c757d;
  margin-top: 2px;
}
</style>

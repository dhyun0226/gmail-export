<template>
  <div class="centered-text">
    준비중 입니다.
  </div>
</template>

<style scoped>
.centered-text {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* 화면 전체 높이 */
  font-size: 2rem; /* 원하는 만큼 키우기 */
  font-weight: 700;
  text-align: center;
}
</style>
<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { computed, onMounted, ref, watch } from 'vue';
import { useApi, useFileDownload, useUserProfile } from '@ows/core';
import dayjs from 'dayjs';
import { useOwAlert } from '@ows/ui';
import FileDownloadList from './FileDownloadList.vue';
import useServiceCategoryCode from '@/composables/useServiceCategoryCode';
import type { FileItem, PaginatedResponse } from '@/types/inquiry';
import FilePopupInput from '@/components/FilePopupInput.vue';
import { getFileIcon, isImageFile } from '@/types/inquiry';
import QnaDetailCommentPopup from '@/components/QnaDetailCommentPopup.vue';
import BasicEditor from '@/components/BasicEditor.vue';

const props = defineProps({
  isPopupOpen: { type: Boolean, default: false },
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '문의 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  qnaNumber: { type: Number },
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  serviceCategoryCode: { type: Object },
  processStatus: { type: String, default: '' },
});

const emit = defineEmits(['save-qna-answers', 'edit-event', 'save-success']);
const { owAlert, owConfirm, openName } = useOwAlert();
const { currentUser } = useUserProfile();
const api = useApi();
const { image } = useFileDownload();

const saving = ref(false);
const responseData = ref({
  serviceCategoryCode: '',
  openYn: 'Y',
  topFixedYn: 'Y',
  qnaTitle: '',
  qnaContent: '',
  writerMemberId: '',
  qnaRegistrationDatetime: '',
  processStatus: '',
  answerCount: 0,
  inquiryCount: 0,
});
const qnaAnswers = ref('');
const selectedQnaAnswerDetailNumber = ref('');
const fileList = ref<FileItem[]>([]);
const answerFiles = ref<FileItem[]>([]);
const editable = ref(true);

// 카테고리 코드 관련 로직
const listServiceGroup = ref('');
const detailedDivisionCode = ref('');

// ✅ 전체 카테고리 옵션 저장
const allCategoryGroupOptions = ref(props.categoryGroupOptions ?? []);

// ✅ 채널 코드 기준 필터링된 카테고리 옵션
const filteredDetailDivisionOptions = computed(() => {
  const prefix = listServiceGroup.value;
  if (!prefix) { return allCategoryGroupOptions.value; }
  return allCategoryGroupOptions.value.filter(opt =>
    opt.value.startsWith(`${prefix}_QNA`),
  );
});

// 문자 수 제한 관련
const MAX_CHAR_LENGTH = 4000;
const currentCharLength = ref(0);
const isOverLimit = ref(false);
const editableControl = ref(true);

const isCommentPopupOpen = ref(false);
function onClickComment() {
  isCommentPopupOpen.value = true;
}

function cleanEditorContent(html: string): string {
  return html
      .replace(/<div>/gi, '')
      .replace(/<\/div>/gi, '\n')
      .replace(/&nbsp;/gi, ' ')
      .replace(/\n{2,}/g, '\n') // 연속 줄바꿈 정리
      .trim();
}

async function onClickEditComment() {
  if (await owConfirm({ title: '댓글수정', message: '작성한 댓글을 수정하시겠습니까?' })) {
    const qnaNumber = props.qnaNumber;
    const qnaAnswerDetailNumber = selectedQnaAnswerDetailNumber.value;
    const answerContent = cleanEditorContent(qnaAnswers.value);
    const params = {
      qnaNumber: props.qnaNumber,
      qnaAnswerDatetime: dayjs().format('YYYY-MM-DDTHH:mm:ss'),
      answererMemberId: currentUser.userName,
      answererCorporationCode: currentUser.corpCode,
      answererDepartmentCode: currentUser.deptCode,
      answererEmployeeNumber: currentUser.empNo,
      qnaAnswerContent: answerContent,
      fileList: answerFiles.value,
    };
    try {
      await api.put(`/voc/qna-answers/${qnaNumber}/${qnaAnswerDetailNumber}`, params);
      fetchQnaData();
      qnaAnswers.value = '';
      answerFiles.value = [];
    }
    catch (error) {
      console.error('답변 삭제 오류:', error);
    }
  }
}

function closeCommentPopup() {
  isCommentPopupOpen.value = false;
}

function extractTextFromHtml(html: string): string {
  const temp = document.createElement('div');
  temp.innerHTML = html;
  return temp.textContent || '';
}

function getTextLength(html: string): number {
  const text = extractTextFromHtml(html);
  return text.length;
}

const actualEditable = computed(() => {
  return editable.value && editableControl.value;
});

async function handlePrivateToggle() {
  if (await owConfirm({ title: '비공개처리', message: '비공개처리하겠습니까?' })) {
    responseData.value.openYn = 'N';
    responseData.value.qnaTitle = '관리자에 의해 비공개 처리 되었습니다.';
    const requestData = { ...responseData.value, serviceCategoryCode: detailedDivisionCode.value };
    try {
      await api.put(`/voc/qnas/${props.qnaNumber}`, requestData);
      // 성공 처리
    }
    catch (error) {
      // 에러 처리
    }
  }
}

async function changeChannel() {
  if (await owConfirm({ title: '상세구분변경', message: '채널 및 상세구분을 변경하겠습니까?' })) {
    const requestData = { ...responseData.value, serviceCategoryCode: detailedDivisionCode.value };
    try {
      await api.put(`/voc/qnas/${props.qnaNumber}`, requestData);
      // 성공 처리
    }
    catch (error) {
      // 에러 처리
    }
  }
}

watch(qnaAnswers, (newValue) => {
  const textLength = getTextLength(newValue);
  currentCharLength.value = textLength;
  isOverLimit.value = textLength > MAX_CHAR_LENGTH;
  // 입력 제한 없이 경고만 표시, 삭제도 자유롭게 가능
});

function resetContent() {
  qnaAnswers.value = '';
  currentCharLength.value = 0;
  isOverLimit.value = false;
  editableControl.value = true;
}

function getDateFormat(dateString: string) {
  if (!dateString) { return ''; }
  return dayjs(dateString).format('YY.MM.DD HH:mm');
}

// 카테고리/셀렉트 관련
const topFxdYnGroup = ref('Y');
const topFxdYnGroupSetting = [
  { text: '상단고정', value: 'Y' },
  { text: '고정해제', value: 'N' },
];
const openYNGroup = ref('Y');
const openYNGroupSetting = [
  { text: '공개', value: 'Y' },
  { text: '비공개', value: 'N' },
];
const {
  fetchRootCategories,
  fetchChildCategories,
  findRootCategory,
} = useServiceCategoryCode();

const rootCategories = ref<any[]>([]);

const isCreateMode = computed(() => !props.qnaNumber);
const editorHeight = computed(() => (answerList.value.length > 0 ? '26vh' : '46vh'));
const answerList = ref<any[]>([]);

async function fetchQnaData() {
  try {
    const { data } = await api.get<PaginatedResponse>(
      `/voc/qnas/${props.qnaNumber}`,
      {
        params: {
          serviceCategoryCode: props.serviceCategoryCode,
          channelCode: null,
        },
      },
    );
    // ✅ 채널코드 추출 (앞 4자리)
    listServiceGroup.value = data.serviceCategoryCode?.substring(0, 4) || '';
    detailedDivisionCode.value = data.serviceCategoryCode || '';

    responseData.value.qnaTitle = data.qnaTitle || '';
    responseData.value.qnaContent = data.qnaContent || '';
    responseData.value.openYn = data.openYn || 'Y';
    responseData.value.topFixedYn = data.topFixedYn || 'N';
    responseData.value.writerMemberId = data.writerMemberId || '';
    responseData.value.qnaRegistrationDatetime = data.qnaRegistrationDatetime || '';
    responseData.value.processStatus = data.processStatus || '';
    responseData.value.answerCount = data.answerCount || 0;
    responseData.value.inquiryCount = data.inquiryCount || 0;

    if (data.fileList && data.fileList.length > 0) {
      fileList.value = data.fileList;
    }

    if (Array.isArray(data.answers)) {
      answerList.value = data.answers.filter(
        answer => answer.answererMemberId === currentUser.userName,
      );
    }
    else {
      answerList.value = [];
    }
  }
  catch (error) {
    console.error('Error loading QnA data:', error);
  }
}

function setEditorContent({
  content,
  qnaAnswerDetailNumber,
  fileList,
}: { content: string; qnaAnswerDetailNumber: number; fileList?: FileItem[] }) {
  qnaAnswers.value = content;
  selectedQnaAnswerDetailNumber.value = qnaAnswerDetailNumber;
  if (fileList) {
    answerFiles.value = fileList;
  }
}

async function clickSave() {
  if (saving.value) { return; } // 이미 저장 중이면 무시
  saving.value = true;
  if (!qnaAnswers.value?.trim()) {
    owAlert({ title: '내용 필수입력 확인', message: '답변 내용을 입력해주세요.' });
    saving.value = false;
    return;
  }
  const answerContent = cleanEditorContent(qnaAnswers.value);
  const params = {
    qnaNumber: props.qnaNumber,
    qnaAnswerDatetime: dayjs().format('YYYY-MM-DDTHH:mm:ss'),
    answererMemberId: currentUser.userName,
    answererCorporationCode: currentUser.corpCode,
    answererDepartmentCode: currentUser.deptCode,
    answererEmployeeNumber: currentUser.empNo,
    qnaAnswerContent: answerContent,
    fileList: answerFiles.value,
  };
  try {
    if (await owConfirm({ title: '등록', message: '답변을 등록하시겠습니까?', target: '#frm' })) {
      const { data } = await api.post('/voc/qna-answers', params);
      emit('save-qna-answers', data);
      if (props.onClose) { props.onClose(); }
    }
  }
  catch (error) {
    console.error('저장 오류:', error);
  }
  finally {
    saving.value = false;
  }
}

const isInitializing = ref(true);

onMounted(async () => {
  try {
    isInitializing.value = true;
    listServiceGroup.value = props.channelGroupOptions?.[0]?.value || '';
    detailedDivisionCode.value = '';
    if (!isCreateMode.value && props.qnaNumber) {
      await fetchQnaData();
    }
    currentCharLength.value = getTextLength(qnaAnswers.value);
  } catch (error) {
    console.error('카테고리 초기화 실패:', error);
  } finally {
    isInitializing.value = false;
  }
});

watch(() => listServiceGroup.value, () => {
  if (isInitializing.value) return; // 초기화 중엔 워치 동작 X
  const firstMatch = filteredDetailDivisionOptions.value[0];
  if (firstMatch) {
    detailedDivisionCode.value = firstMatch.value;
  } else {
    detailedDivisionCode.value = '';
  }
});
</script>

<template>
  <OwPopup
    :is-popup-open="props.isPopupOpen"
    v-bind="props"
    :height="826"
  >
    <div
      class="popup-content-scrollable"
      tabindex="0"
    >
      <!-- 상단 섹션 타이틀 -->
      <div
        class="d-flex"
        style="gap: 32px; margin-bottom: 8px;"
      >
        <div style="flex: 1; min-width: 350px;">
          <div class="section-title">
            접수
          </div>
        </div>
        <div style="flex: 1; min-width: 350px;">
          <div
            class="section-title-row d-flex align-items-center justify-content-between"
          >
            <span class="section-title-text">답변</span>
            <BButton
              variant="state"
              @click="onClickEditComment"
            >
              댓글수정
            </BButton>
          </div>
        </div>
      </div>
      <div
        class="d-flex"
        style="gap: 32px;"
      >
        <!-- 접수 영역 (왼쪽) -->
        <div
          class="voc-detail-container"
          style="flex: 1; min-width: 350px;"
        >
          <BTableSimple
            responsive
            bordered="false"
            small
            class="ow-table-read"
          >
            <caption class="visually-hidden">
              VOC 상세 정보
            </caption>
            <colgroup>
              <col width="90px">
              <col>
              <col width="90px">
              <col>
            </colgroup>
            <BTbody>
              <BTr>
                <BTh>제목</BTh>
                <BTd colspan="3">
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ responseData.qnaTitle }}
                  </div>
                </BTd>
              </BTr>
              <BTr>
                <BTh>요청자</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ responseData.writerMemberId }}
                  </div>
                </BTd>
                <BTh>등록일시</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ getDateFormat(responseData.qnaRegistrationDatetime) }}
                  </div>
                </BTd>
              </BTr>
              <BTr>
                <BTh>처리상태</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ props.processStatus ? "답변완료" : "문의접수" }}
                  </div>
                </BTd>
                <BTh>공개여부</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ responseData.openYn === 'Y' ? '공개' : '비공개' }}
                  </div>
                </BTd>
                <BTd>
                  <BButton
                    variant="state"
                    style="min-width: 90px;"
                    @click="handlePrivateToggle"
                  >
                    비공개처리
                  </BButton>
                </BTd>
                <!--                <BTh>조회수</BTh> -->
                <!--                <BTd> -->
                <!--                  <div -->
                <!--                    class="input-group" -->
                <!--                    role="group" -->
                <!--                  > -->
                <!--                    {{ props.inquiryCount }} -->
                <!--                  </div> -->
                <!--                </BTd> -->
              </BTr>
              <BTr>
                <BTh>채널</BTh>
                <BTd>
                  <BFormSelect
                    v-model="listServiceGroup"
                    :options="props.channelGroupOptions"
                    class="ow-select"
                    placeholder="채널 선택"
                  />
                </BTd>
                <BTh>상세구분</BTh>
                <BTd>
                  <BFormSelect
                    v-model="detailedDivisionCode"
                    :options="filteredDetailDivisionOptions"
                    class="ow-select detail-select"
                    placeholder="채널 선택 후 선택 가능"
                  />
                </BTd>
                <BTd>
                  <BButton
                    variant="state"
                    style="min-width: 90px;"
                    @click="changeChannel"
                  >
                    상세구분변경
                  </BButton>
                </BTd>
              </BTr>
              <BTr>
                <BTh>조회수</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ responseData.inquiryCount }}
                  </div>
                </BTd>
                <BTh>댓글수</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    {{ responseData.answerCount }}
                  </div>
                </BTd>
                <BTd>
                  <BButton
                    variant="state"
                    style="min-width: 90px;"
                    @click="onClickComment"
                  >
                    댓글보기
                  </BButton>
                </BTd>
              </BTr>

              <BTr>
                <BTh>내용</BTh>
                <BTd colspan="3">
                  <div class="voc-content">
                    <div class="voc-text">
                      {{ responseData.qnaContent }}
                    </div>
                    <div
                      v-if="fileList && fileList.length > 0"
                      class="voc-file-container"
                    >
                      <div class="file-list">
                        <div
                          v-for="file in fileList"
                          :key="file.fileId"
                          class="file-item"
                        >
                          <template v-if="isImageFile(file.fileExtensionName)">
                            <img
                              :src="image(file.fileId, 300, 300)"
                              class="file-image"
                              :alt="file.fileOriginalName"
                            >
                          </template>
                          <div
                            v-else
                            class="file-icon"
                          >
                            <i :class="getFileIcon(file.fileExtensionName)" />
                            <span class="file-name">{{ file.fileOriginalName }}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </BTd>
              </BTr>
              <BTr v-if="fileList && fileList.length > 0">
                <BTh>파일첨부</BTh>
                <BTd colspan="3">
                  <FileDownloadList :file-list="fileList" />
                </BTd>
              </BTr>
            </BTbody>
          </BTableSimple>
        </div>
        <!-- 답변 영역 (오른쪽) -->
        <div
          class="voc-detail-container"
          style="flex: 1; min-width: 350px;"
        >
          <!-- 답변 리스트 테이블 -->
          <BTableSimple
            v-if="answerList.length > 0"
            responsive
            bordered="false"
            small
            class="ow-table-read"
            style="margin-bottom: 16px;"
          >
            <caption class="visually-hidden">
              이전 답변 리스트
            </caption>
            <colgroup>
              <col>
              <col width="160px">
              <col width="120px">
            </colgroup>
            <BTbody>
              <BTr>
                <BTh>답변 내용</BTh>
                <BTh>작성 일시</BTh>
                <BTh>첨부 파일</BTh>
              </BTr>
              <BTr
                v-for="answer in answerList"
                :key="answer.qnaAnswerDetailNumber"
                style="cursor: pointer;"
                @click="setEditorContent({ content: answer.qnaAnswerContent, qnaAnswerDetailNumber: answer.qnaAnswerDetailNumber, fileList: answer.fileList })"
              >
                <BTd>{{ answer.qnaAnswerContent }}</BTd>
                <BTd>{{ getDateFormat(answer.qnaAnswerDatetime) }}</BTd>
                <BTd style="max-width: 120px; overflow: hidden;">
                  <FileDownloadList
                    v-if="answer.fileList && answer.fileList.length > 0"
                    :file-list="answer.fileList"
                    style="width: 100%;"
                  />
                  <span
                    v-else
                    style="color: #aaa;"
                  >-</span>
                </BTd>
              </BTr>
            </BTbody>
          </BTableSimple>
          <!-- 답변 작성 영역 -->
          <BTableSimple
            responsive
            bordered="false"
            small
            class="ow-table-read"
          >
            <caption class="visually-hidden">
              VOC 답변
            </caption>
            <colgroup>
              <col width="90px">
              <col>
            </colgroup>
            <BTbody>
              <BTr>
                <BTh>답변</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    <div :style="{ height: editorHeight, width: '100%' }">
                      <BasicEditor
                        v-model="qnaAnswers"
                      />
                    </div>
                  </div>
                  <!-- 문자 수 표시 및 경고 메시지 -->
                  <div
                    class="mt-2 d-flex align-items-center justify-content-between"
                    style="font-size: 12px;"
                  >
                    <div>
                      <span :class="{ 'text-danger': isOverLimit, 'text-muted': !isOverLimit }">
                        현재: {{ currentCharLength }}자 / 최대: {{ MAX_CHAR_LENGTH }}자
                      </span>
                      <span
                        v-if="isOverLimit"
                        class="text-danger ms-3"
                      >
                        <strong>⚠️ 4000자를 초과했습니다. 더 이상 입력할 수 없습니다.</strong>
                      </span>
                    </div>
                    <BButton
                      v-if="isOverLimit"
                      size="sm"
                      variant="outline-danger"
                      style="border-width: 1px;"
                      @click="resetContent"
                    >
                      내용 초기화
                    </BButton>
                  </div>
                </BTd>
              </BTr>
              <BTr>
                <BTh>파일 첨부</BTh>
                <BTd>
                  <div
                    class="input-group"
                    role="group"
                  >
                    <FilePopupInput
                      v-model="answerFiles"
                      :max-files="3"
                      :max-file-size="5"
                      help-text="답변파일"
                    />
                  </div>
                </BTd>
              </BTr>
            </BTbody>
          </BTableSimple>
        </div>
      </div>
    </div>
    <div class="ow-popup-bottom-fixed">
      <BButton
        size="md"
        variant="base base-gray"
        @click="props.onClose"
      >
        취소
      </BButton>
      <BButton
        id="btnOk"
        size="md"
        variant="base base-dark"
        @click="clickSave"
      >
        확인
      </BButton>
    </div>
  </OwPopup>
  <QnaDetailCommentPopup
    v-if="isCommentPopupOpen"
    :is-popup-open="isCommentPopupOpen"
    :channel-group-options="props.channelGroupOptions"
    :category-group-options="props.categoryGroupOptions"
    :qna-number="props.qnaNumber"
    :service-category-code="props.serviceCategoryCode"
    :width="1700"
    :on-close="closeCommentPopup"
  />
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.button-with-text {
  margin-right: 12px;
}

.voc-content {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.voc-text {
  line-height: 1.5;
}

.voc-file-container {
  margin-top: 1rem;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  //overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  //overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  font-size: 16px;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}

.ow-popup-bottom-fixed {
  position: sticky;
  bottom: 0;
  left: 0;
  width: 100%;
  background: #fff;
  z-index: 10;
  display: flex;
  justify-content: center; /* 가운데 정렬 */
  gap: 8px;
  padding: 16px 24px 16px 0;
  border-top: 1px solid #dee2e6;
}
.ow-popup-scrollable {
  /* 필요시 팝업 자체에 스타일 추가 */
}
.file-list-label {
  font-weight: 500;
  color: #495057;
  white-space: nowrap;
  margin-right: 8px;
  padding-top: 4px;
}

/* 그리드 로우 선 */
.deleted-row {
  text-decoration: line-through;
  color: #aaa;
}

.section-title {
  font-size: 20px;
  font-weight: bold;
  padding: 0.5rem 1rem 0.5rem 0;
  border-radius: 4px 4px 0 0;
  border-bottom: 1px solid #dee2e6;
  margin-bottom: 0;
}
.section-title-row {
  border-bottom: 1px solid #dee2e6;
  padding: 0.4rem 1rem 0.5rem 0;
  margin-bottom: 0;
}
.section-title-text {
  font-size: 20px;
  font-weight: bold;
}
</style>

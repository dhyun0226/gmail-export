<script setup>
import { ref, watch } from 'vue';
import { useFileDownload, useFileUpload } from '@ows/core';
import Editor from '@tinymce/tinymce-vue';

const content = defineModel({ type: String, default: '' });

const API_KEY = '1q1dkuycsrajbx9wkzym5sazs7fmx2exutv7bm2378ny04wh';
const config = {
  selector: '#template-editor',
  height: '100%',
  language: 'ko_KR',
  statusbar: false,
  branding: false,
  resize: false,
  content_style: 'div {margin: 3px 0}',
  forced_root_block: 'div',
  contextmenu: false,
  file_picker_types: 'image',
  quickbars_insert_toolbar: '',
  quickbars_selection_toolbar: '',
  plugins: [
    'table',
    'charmap',
    'preview',
    'insertdatetime',
    'code',
    'wordcount',
    'help',
    'autolink',
    'lists',
    'advlist',
    'searchreplace',
    'visualblocks',
  ],
  font_formats:
    '맑은 고딕=Malgun Gothic, sans-serif; 나눔고딕=NanumGothic, sans-serif; Arial=arial,helvetica,sans-serif; Courier New=courier new,courier,monospace;',
  menubar: 'edit view insert format tools table tc help',
  toolbar:
    'undo redo | bold forecolor backcolor fontsize fontfamily | imageUpload',
  paste_data_images: false,
  noneditable_editable_class: 'mceEditable',
  noneditable_noneditable_class: 'mceNonEditable',
  extended_valid_elements: 'svg[*]',
  invalid_elements: 'script,iframe,object,embed,form,input,button',
  setup: editorSetup,
};

const fileInput = {
  excludeAcceptAllOption: false,
  multiple: true,
  types: [
    {
      description: 'image',
      accept: {
        'image/*': ['.png', '.gif', '.jpeg', '.jpg'],
      },
    },
  ],
};

const { files: attachedFiles, open } = useFileUpload(fileInput);
const { link } = useFileDownload();

let initialImageIds = [];

function editorSetup(editor) {
  editor.ui.registry.addButton('imageUpload', {
    text: '이미지첨부',
    icon: 'image',
    onAction: () => {
      open();
    },
  });
}

const imageAttach = ref(null);

async function insertImageContent(file) {
  const editor = window.tinymce.activeEditor;
  editor.insertContent(getInsertTagForImage(file));
}

function getInsertTagForImage(file) {
  const insertTag = `
    <div style="display:inline;">
      <img data-id="${file.fileId}" src="${link(file.fileId)}"
      />
    </div>
  `;

  return insertTag;
}

function extractImageIds(html) {
  const div = document.createElement('div');
  div.innerHTML = html;

  const ids = new Set();
  div.querySelectorAll('img[data-id]').forEach((img) => {
    const id = img.getAttribute('data-id');
    if (id) {
      ids.add(id);
    }
  });
  return ids;
}

// 현재 이미지 ID 목록 추출
function getCurrentImageIds() {
  return extractImageIds(content.value);
}

// 삭제된 이미지 ID 추출
function getDeletedImageIds() {
  const current = getCurrentImageIds();
  const deleted = new Set();

  initialImageIds.forEach((id) => {
    if (!current.has(id)) {
      deleted.add(id);
    }
  });

  return deleted;
}

// 추가된 이미지 ID 추출
function getNewImageIds() {
  const current = getCurrentImageIds();
  const added = new Set();

  current.forEach((id) => {
    if (!initialImageIds.has(id)) {
      added.add(id);
    }
  });

  return added;
}

watch(
  () => attachedFiles.value,
  (files) => {
    files.forEach((file) => insertImageContent(file));
  }
);

let stop = null;

/**
 * @TODO stop 관련 지속적인 테스트 필요.
 */
stop = watch(
  content,
  (newVal) => {
    if (!newVal || newVal.trim() === '') {
      return;
    }
    initialImageIds = extractImageIds(newVal);

    if (stop !== null) {
      stop();
    }
  },
  { immediate: true }
);

defineExpose({
  getCurrentImageIds,
  getNewImageIds,
  getDeletedImageIds,
});
</script>

<template>
  <input
    id="ow-workspace-image-upload"
    ref="imageAttach"
    type="file"
    class="d-none"
    accept="image/*"
  />
  <Editor
    id="template-editor"
    v-model="content"
    :api-key="API_KEY"
    :init="config"
  />
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import {
  useApi,
  useCommonCode,
  useFileDownload,
  useUserProfile,
} from '@ows/core';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import FileInputGroup from '@/components/FileInputGroup.vue';
import { getFileIcon, isImageFile } from '@/types/inquiry';
import type { VocFile, VocResponse } from '@/types/voc';
import AssignmentPopup from '@/components/AssignmentPopup.vue';
import EmployeePopup2 from '@/components/EmployeePopup2.vue';
import OrgPopup from '@/components/OrgPopup.vue';
import EmployeePopup from "@/components/EmployeePopup.vue";

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: 'VOC 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  vocNumber: { type: Number },
  vocItemName: { type: String },
  vocItemCategoryCode: { type: Object },
  vocCategoryCode: { type: Object },
});

const { currentUser } = useUserProfile();

// 과제 팝업 관련
const {
  openPopup: openAssignmentPopup,
  closePopup: closeAssignmentPopup,
  isPopupOpen: isAssignmentPopupOpen,
} = useOwPopup();

const {
  openPopup: openEmployeePopup,
  closePopup: closeEmployeePopup,
  isPopupOpen: isEmployeePopupOpen,
} = useOwPopup();

// 조직 팝업 관련
const {
  openPopup: openOrgPopup,
  closePopup: closeOrgPopup,
  isPopupOpen: isOrgPopupOpen,
} = useOwPopup();

const employeePopupPosition = ref({
  my: "center",
  at: "center",
  of: "body",
  offset: "0 -200",
});

// 품목 코드와 텍스트 매핑
const productOptions = [
  { text: '임플란트', value: 'DVOC_VOC_001', code: 'implant' },
  { text: '기구', value: 'DVOC_VOC_002', code: 'instrument' },
  { text: '보존/근관', value: 'DVOC_VOC_003', code: 'endodontic' },
  { text: '수복/접착', value: 'DVOC_VOC_004', code: 'restorative' },
  { text: '인상/보철', value: 'DVOC_VOC_005', code: 'impression' },
  { text: '절삭/연마', value: 'DVOC_VOC_006', code: 'cutting' },
  { text: 'GBR', value: 'DVOC_VOC_007', code: 'gbr' },
  { text: '위생용품', value: 'DVOC_VOC_008', code: 'hygiene' },
  { text: '장비', value: 'DVOC_VOC_009', code: 'equipment' },
  { text: '교정용기구', value: 'DVOC_VOC_010', code: 'orthodontic' },
  { text: '예방/구강', value: 'DVOC_VOC_011', code: 'prevention' },
  { text: '기공용품', value: 'DVOC_VOC_012', code: 'dentalLab' },
  { text: '의약품', value: 'DVOC_VOC_013', code: 'medicine' },
  { text: '생활가전', value: 'DVOC_VOC_014', code: 'appliance' },
  { text: '기타', value: 'DVOC_VOC_015', code: 'etc' },
];

// value로 text 찾기
function getTextByValue(value) {
  const item = productOptions.find(opt => opt.value === value);
  return item ? item.text : null;
}

// value로 code 찾기
function getCodeByValue(value) {
  const item = productOptions.find(opt => opt.value === value);
  return item ? item.code : null;
}

const selectedProduct = ref('DVOC_VOC_001');
const vocDetailsItemName = ref('');
const vocChargePerson = ref({
  name: '',
  number: '',
});

// 라디오 버튼 값 변경 시 동작
function onOptionChange(newVal: string): void {
  vocChargePerson.value.name = '';
  vocChargePerson.value.number = '';
  console.log(selectedProduct.value);
  console.log(vocChargePerson.value);
}

const api = useApi();
const { image } = useFileDownload();
const user = ref('');


// VOC 응답 데이터
const responseData = ref<Partial<VocResponse>>({});
const answer = ref('');
const fileList = ref<VocFile[]>([]);
const answerFileList = ref<VocFile[]>([]);
const files = ref([]);

const sortedHistories = computed(() => {
  if (!responseData.value?.changeHistories) {
    return [];
  }

  return [...responseData.value.changeHistories].sort((a, b) => {
    const dateA = new Date(a.vocChangeDateTime);
    const dateB = new Date(b.vocChangeDateTime);
    return dateB.getTime() - dateA.getTime(); // 내림차순 정렬
  });
});

// VOC 데이터 불러오기
async function fetchVocData() {
  try {
    const { data } = await api.get(`/voc/vocs/${props.vocNumber}/with-answer`);
    responseData.value = data;
    answer.value = data.vocAnswerContent || '';
    fileList.value = data.fileList || [];
    answerFileList.value = data.answerFileList || [];
    selectedProduct.value = data.vocCategoryCode || '';
    vocChargePerson.value.name = data.vocChargePersonName || '';
    vocChargePerson.value.number = data.vocChargePersonNumber || '';
    vocDetailsItemName.value = data.vocDetailsItemName || '';

    // responseData.value.changeHistories = data.changeHistories;
  }
  catch (error) {
    responseData.value = {};
    console.error('Error loading VOC data:', error);
  }
}


// 사용자 선택 처리
function handleUpdateOrganization(item) {
  console.log(item);
  vocChargePerson.value.name = item.name;
  vocChargePerson.value.number = item.vocChargePersonNumber;
  closeOrgPopup();
}

// 분류 처리
async function clickSave() {
  const params = {
    vocContent: responseData.value.vocContent,
    vocCategoryCode: selectedProduct.value,
    itemCode: getCodeByValue(selectedProduct.value),
    vocItemName: getTextByValue(selectedProduct.value),
    vocChargePersonNumber: vocChargePerson.value.number,
    vocDetailsItemName: vocDetailsItemName.value
  };

  try {
    const { data } = await api.put(`/voc/vocs/${props.vocNumber}/classification`, params);
    if (props.onClose) {
      props.onClose();
    }
  }
  catch (error) {
    console.error('VOC 답변 저장 오류:', error);
  }
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY.MM.DD HH:mm');
}

// 값 변경 핸들러
function handleChange(value) {
}

onMounted(() => {
  fetchVocData();
});
</script>

<template>
  <OwPopup v-bind="props">
    <BTabs class="ow-tabs-full">
      <div class="voc-detail-container">
        <BTableSimple
            responsive
            bordered="false"
            small
            class="ow-table-read"
        >
          <caption class="visually-hidden">
            VOC 상세 정보
          </caption>
          <colgroup>
            <col width="105px">
            <col>
          </colgroup>
          <div
              class="mb-3"
              style="font-size: 20px; font-weight: bold"
          >
            접수
          </div>
          <BTbody>
            <BTr>
              <BTh>요청자</BTh>
              <BTd>
                <div
                    class="input-group"
                    role="group"
                >
                  {{ responseData.vocCustomerName }}
                  ({{ responseData.vocCustomerCustomerName }})
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>접수일시</BTh>
              <BTd>
                <div
                    class="input-group"
                    role="group"
                >
                  {{ getDateFormat(responseData.vocRegistrationDateTime) }}
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>접수내용</BTh>
              <BTd>
                <div class="voc-content">
                  <div class="voc-text">
                    {{ responseData.vocContent }}
                  </div>

                  <!-- 첨부 파일 이미지 -->
                  <div
                      v-if="fileList && fileList.length > 0"
                      class="voc-file-container"
                  >
                    <div class="file-list">
                      <div
                          v-for="file in fileList"
                          :key="file.fileId"
                          class="file-item"
                      >
                        <template v-if="isImageFile(file.fileExtensionName)">
                          <img
                              :src="image(file.fileId, 300, 300)"
                              class="file-image"
                              :alt="file.fileOriginalName"
                          >
                        </template>
                        <div
                            v-else
                            class="file-icon"
                        >
                          <i :class="getFileIcon(file.fileExtensionName)" />
                          <span class="file-name">{{
                              file.fileOriginalName
                            }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>품목</BTh>
              <BTd>
                <OwFormRadio
                    v-model="selectedProduct"
                    :options="productOptions"
                    @change="onOptionChange"
                />
              </BTd>
            </BTr>
            <BTr>
              <BTh>세부품목</BTh>
              <BTd>
                <input
                    id="form02"
                    class="form-control ow-form-control noline"
                    type="text"
                    placeholder="품목명을 입력해주세요."
                    v-model="vocDetailsItemName"
                >
              </BTd>
            </BTr>
            <BTr>
              <BTh>처리담당자</BTh>
              <BTd>
                <div class="d-flex">
                  <div style="margin-right: 10px;">{{vocChargePerson.name}}</div>
                  <BButton
                      variant="state"
                      @click="openEmployeePopup"
                  >
                    처리담당자선택
                  </BButton>
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div class="ow-popup-bottom">
          <BButton
              size="md"
              variant="base base-gray"
              @click="props.onClose"
          >
            취소
          </BButton>
          <BButton
              id="btnOk"
              size="md"
              variant="base base-dark"
              @click="clickSave"
          >
            확인
          </BButton>
        </div>
      </div>

    </BTabs>


      <OrgPopup
          v-if="isOrgPopupOpen"
          :is-popup-open="isOrgPopupOpen"
          :on-close="closeOrgPopup"
          :height="700"
          @update-organization="handleUpdateOrganization"
      />

    <AssignmentPopup
        v-if="isAssignmentPopupOpen"
        :is-popup-open="isAssignmentPopupOpen"
        :on-close="closeAssignmentPopup"
        :height="450"
    />
    <EmployeePopup2
        v-if="isEmployeePopupOpen"
        :is-popup-open="isEmployeePopupOpen"
        :voc-category-code="selectedProduct"
        :popup-position="employeePopupPosition"
        :on-close="closeEmployeePopup"
        height="auto"
        :voc-number="props.vocNumber"
        @update-organization="handleUpdateOrganization"
    />
  </OwPopup>
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.button-with-text {
  margin-right: 12px;
}

.voc-content {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.voc-text {
  line-height: 1.5;
}

.voc-file-container {
  margin-top: 1rem;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  font-size: 16px;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}
</style>

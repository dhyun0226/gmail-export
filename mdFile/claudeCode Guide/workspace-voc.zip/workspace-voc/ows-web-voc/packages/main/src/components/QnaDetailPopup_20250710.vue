<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { computed, onMounted, ref } from 'vue';
import { useApi, useFileDownload, useUserProfile } from '@ows/core';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import FileDownloadList from './FileDownloadList.vue';
import type { VocFile } from '@/types/voc';
import type { EventResponse, PaginatedResponse } from '@/types';
import { getFileIcon, isImageFile } from '@/types/inquiry';
// 파일 첨부 컴포넌트 import
import { dateUtils } from '@/utils';
import DxListNGrid from '@/components/DxListNGrid.vue';
import FilePopupInput from '@/components/FilePopupInput.vue';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '문의 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  qnaNumber: { type: Number },
  eventItemCategoryCode: { type: Object },
  serviceCategoryCode: { type: Object },
  serviceCategoryName: { type: String },
  disabledSelect: { type: Boolean, default: false },
});

const emit = defineEmits(['save-qna-answers', 'edit-event']); // edit-event 이벤트 추가
const { currentUser } = useUserProfile();

// 공통 코드 로드
// const { VOC_STACD: vocStatuses, VOC_CMPL_TYCD: vocTypes, VOC_RGST_DTL_DVCD: vocRegistrationDetailDivisionCodeGroup } = await useCommonCode(
//   'VOC_STACD',
//   'VOC_CMPL_TYCD',
//   'VOC_RGST_DTL_DVCD',
// );

const api = useApi();
const { image } = useFileDownload();
const user = ref('');

const selectedProcessType = ref('01');
const reasonText = ref('');

const editable = ref(true);

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY.MM.DD HH:mm');
}
// 날짜 포맷 함수
function formatDate(dateString: string): string {
  return dateUtils.formatDateWithSeparator(dateString, '.', false);
}

// qna 응답 데이터
const responseData = ref<Partial<EventResponse>>({});
const qnaTitle = ref('');
const qnaContent = ref('');
const writerMemberId = ref('');
const qnaAnswers = ref('');
const fileList = ref<VocFile[]>([]);
const answerFiles = ref<VocFile[]>([]);
const answerFileList = ref<VocFile[]>([]);

// qna 답변 데이터 불러오기
async function fetchQnaData() {
  try {
    const { data } = await api.get<PaginatedResponse>(
      `/voc/qnas/${props.qnaNumber}`,
      {
        params: {
          serviceCategoryCode: props.serviceCategoryCode,
          channelCode: null,
        },
      },
    );
    responseData.value = data;
    qnaTitle.value = data.qnaTitle || '';
    qnaContent.value = data.qnaContent || '';
    writerMemberId.value = data.writerMemberId || '';
    fileList.value = data.fileList || [];
    answerFileList.value = data.answerFileList || [];
    gridOption.value.datas = data.answers || [];
    gridOption.value.paging.totalItemCount = (data.answers || []).length;
  }
  catch (error) {
    responseData.value = {};
  }
}

// 조직 팝업 관련
const {
  openPopup: openOrgPopup,
  closePopup: closeOrgPopup,
  isPopupOpen: isOrgPopupOpen,
} = useOwPopup();

// 사용자 선택 처리
function handleUpdateOrganization(item) {
  user.value = item;
  closeOrgPopup();
}

// 저장 처리
async function clickSave() {
  // 필수 입력 검증

  if (!qnaAnswers.value?.trim()) {
    alert('답변 내용을 입력해주세요.');
    return;
  }

  const answerContent = qnaAnswers.value
    .replace(/<p>/gi, '')
    .replace(/<\/p>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n');

  const params = {
    qnaNumber: props.qnaNumber,
    // qnaAnswerDetailNumber: qnaAnswerDetailNumber.value, // 답변 상세 번호 (수정 시 필요)
    // parentAnswerDetailNumber: parentAnswerDetailNumber.value, // 부모 답변 번호 (대댓글 등)
    qnaAnswerDatetime: dayjs().format('YYYY-MM-DDTHH:mm:ss'), // 현재 시간 또는 선택값
    answererMemberId: '담당자', // 로그인 사용자 ID
    answererCorporationCode: currentUser.corpCode,
    answererDepartmentCode: currentUser.deptCode,
    answererEmployeeNumber: currentUser.empNo,
    qnaAnswerContent: answerContent, // 답변 내용
    fileList: answerFiles.value,
  };
  try {
    const { data } = await api.post('/voc/qna-answers', params);
    emit('save-qna-answers', data);
    // console.log('저장 성공:', data);
    alert('문의 답변이 등록되었습니다.');
    if (props.onClose) { props.onClose(); }
  }
  catch (error) {
    console.error('저장 오류:', error);
  }
}

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 1,
  height: '668px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const columns = computed(() => [
  {
    caption: '댓글 내용',
    width: '*',
    dataField: 'qnaAnswerContent',
    allowMerge: true,
    alignment: 'center',
    cellType: 'customize',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '작성자',
    width: '100',
    dataField: 'answererMemberId',
    allowMerge: true,
    alignment: 'center',
    cellType: 'customize1',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록일시',
    width: '100',
    dataField: 'qnaAnswerDatetime',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '첨부파일',
    width: gridOption.value.datas.some(row => row.fileList && row.fileList.length > 0) ? '*' : 80,
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
  {
    caption: '삭제',
    width: '60',
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize4',
    visible: true,
  },
]);

async function deleteAnswer(qnaAnswer) {
  if (confirm('정말 삭제하시겠습니까?')) {
    const qnaNumber = props.qnaNumber;
    const qnaAnswerDetailNumber = qnaAnswer.qnaAnswerDetailNumber;
    try {
      await api.put(`/voc/qna-answers/${qnaNumber}/${qnaAnswerDetailNumber}`, {
        ...qnaAnswer,
        deleteYn: 'Y',
      });
      fetchQnaData();
    }
    catch (error) {
      console.error('답변 삭제 오류:', error);
    }
  }
}

onMounted(async () => {
  try {
    if (props.disabledSelect) {
      fetchQnaData();
    }

    // 팝업 내부 어디서든 휠 스크롤 동작하도록 wheel 이벤트 위임
    const scrollEl = document.querySelector('.popup-content-scrollable');
    if (scrollEl) {
      scrollEl.addEventListener('wheel', (e: WheelEvent) => {
        // 자식에서 wheel 이벤트가 막혀도 부모가 스크롤 처리
        const { scrollTop, scrollHeight, clientHeight } = scrollEl as HTMLElement;
        const atTop = scrollTop === 0 && e.deltaY < 0;
        const atBottom = scrollTop + clientHeight >= scrollHeight && e.deltaY > 0;
        if (!atTop && !atBottom) {
          e.stopPropagation();
          // e.preventDefault(); // 필요시 활성화
          (scrollEl as HTMLElement).scrollTop += e.deltaY;
        }
      }, { passive: false });
    }
  }
  catch (error) {
    console.error('vocCtg 데이터 가져오기 실패:', error);
  }
});
</script>

<template>
  <OwPopup
    v-bind="props"
    class="ow-popup-scrollable"
  >
    <div
      class="popup-content-scrollable"
      tabindex="0"
    >
      <div class="d-flex">
        <BTabs
          class="ow-tabs-full"
          style="width: 900px"
        >
          <div class="voc-detail-container">
            <BTableSimple
              responsive
              bordered="false"
              small
              class="ow-table-read"
            >
              <caption class="visually-hidden">
                VOC 상세 정보
              </caption>
              <colgroup>
                <col width="90px">
                <col>
              </colgroup>
              <div
                class="mb-3"
                style="font-size: 20px; font-weight: bold"
              >
                처리
              </div>
              <BTbody>
                <BTr>
                  <BTh>답변</BTh>
                  <BTd>
                    <div
                      class="input-group"
                      role="group"
                    >
                      <div style="height: 25vh; width: 135vh">
                        <OwTinyEditor
                          v-model="qnaAnswers"
                          :editable="editable"
                          :enable-insert-image="true"
                          :enable-insert-media="false"
                          placeholder="내용을 입력해주세요."
                        />
                      </div>
                    </div>
                  </BTd>
                </BTr>
                <BTr>
                  <BTh> 파일 첨부 </BTh>
                  <BTd>
                    <div
                      class="input-group"
                      role="group"
                    >
                      <!-- 파일 첨부 컴포넌트 적용 - 썸네일 -->
                      <FilePopupInput
                        v-model="answerFiles"
                        :max-files="3"
                        :max-file-size="5"
                        help-text="답변파일"
                      />
                    </div>
                  </BTd>
                </BTr>
              </BTbody>
            </BTableSimple>
          </div>
          <div
            class="ow-popup-bottom"
            style="
              border-top: 1px solid #dee2e6;
              margin-top: 1rem;
              padding-top: 1rem;
            "
          />
          <div class="voc-detail-container">
            <BTableSimple
              responsive
              bordered="false"
              small
              class="ow-table-read"
            >
              <caption class="visually-hidden">
                VOC 상세 정보
              </caption>
              <colgroup>
                <col width="90px">
                <col>
              </colgroup>
              <div
                class="mb-3"
                style="font-size: 20px; font-weight: bold"
              >
                접수
              </div>
              <BTbody>
                <BTr>
                  <BTh>요청자</BTh>
                  <BTd>
                    <div
                      class="input-group"
                      role="group"
                    >
                      {{ writerMemberId }}
                    </div>
                  </BTd>
                </BTr>
                <BTr>
                  <BTh>접수일시</BTh>
                  <BTd>
                    <div
                      class="input-group"
                      role="group"
                    >
                      {{ getDateFormat(responseData.qnaRegistrationDatetime) }}
                    </div>
                  </BTd>
                </BTr>
                <BTr>
                  <BTh>접수내용</BTh>
                  <BTd>
                    <div class="voc-content">
                      <div class="voc-text">
                        {{ qnaContent }}
                      </div>
                      <div
                        v-if="fileList && fileList.length > 0"
                        class="voc-file-container"
                      >
                        <div class="file-list">
                          <div
                            v-for="file in fileList"
                            :key="file.fileId"
                            class="file-item"
                          >
                            <template v-if="isImageFile(file.fileExtensionName)">
                              <img
                                :src="image(file.fileId, 300, 300)"
                                class="file-image"
                                :alt="file.fileOriginalName"
                              >
                            </template>
                            <div
                              v-else
                              class="file-icon"
                            >
                              <i :class="getFileIcon(file.fileExtensionName)" />
                              <span class="file-name">{{ file.fileOriginalName }}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </BTd>
                </BTr>
                <BTr v-if="fileList && fileList.length > 0">
                  <BTh>첨부파일</BTh>
                  <BTd>
                    <FileDownloadList :file-list="fileList" />
                  </BTd>
                </BTr>
              </BTbody>
            </BTableSimple>
          </div>
        </BTabs>
        <div
          v-if="props.disabledSelect"
          class="voc-detail-container"
          style="flex: 1;"
        >
          <DxListNGrid
            :n-grid-count="gridOption.nGridCount"
            :show-gap="false"
            :all-datas="gridOption.datas"
            :columns="columns"
            :paging="gridOption.paging"
            :height="gridOption.height"
            :selection="gridOption.selection"
            :row-class="row => row.deleteYn === 'Y' ? 'deleted-row' : ''"
            :is-show-pagination="true"
          >
            <!-- 댓글 내용 -->
            <template #customize="{ data: cell }">
              <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
                {{ cell.data.qnaAnswerContent }}
              </div>
            </template>

            <!-- 작성자 -->
            <template #customize1="{ data: cell }">
              <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
                {{ cell.data.answererMemberId }}
              </div>
            </template>

            <!-- 등록일시 -->
            <template #customize2="{ data: cell }">
              <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
                {{ formatDate(cell.data.qnaAnswerDatetime) }}
              </div>
            </template>

            <!-- 첨부파일 -->
            <template #customize3="{ data: cell }">
              <div
                class="file-list"
                :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''"
                style="display: flex; gap: 8px; flex-wrap: nowrap; overflow-x: auto;"
              >
                <FileDownloadList
                  v-if="cell.data.fileList && cell.data.fileList.length > 0"
                  :file-list="cell.data.fileList"
                />
                <span
                  v-else
                  style="color: #aaa;"
                >-</span>
              </div>
            </template>

            <!-- 삭제 버튼 -->
            <template #customize4="{ data: cell }">
              <div :style="cell.data.deleteYn === 'Y' ? 'text-decoration: line-through; color: #aaa;' : ''">
                <BButton
                  variant="box-delete"
                  @click.stop="deleteAnswer(cell.data)"
                />
              </div>
            </template>
          </DxListNGrid>
        </div>
      </div>
    </div>
    <div class="ow-popup-bottom-fixed">
      <BButton
        size="md"
        variant="base base-gray"
        @click="props.onClose"
      >
        취소
      </BButton>
      <BButton
        id="btnOk"
        size="md"
        variant="base base-dark"
        @click="clickSave"
      >
        확인
      </BButton>
    </div>
  </OwPopup>
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.button-with-text {
  margin-right: 12px;
}

.voc-content {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.voc-text {
  line-height: 1.5;
}

.voc-file-container {
  margin-top: 1rem;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  //overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  //overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  font-size: 16px;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}

.popup-content-scrollable {
  max-height: 75vh;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch;
  pointer-events: auto;
}
.ow-popup-bottom-fixed {
  position: sticky;
  bottom: 0;
  left: 0;
  width: 100%;
  background: #fff;
  z-index: 10;
  display: flex;
  justify-content: center; /* 가운데 정렬 */
  gap: 8px;
  padding: 16px 24px 16px 0;
  border-top: 1px solid #dee2e6;
}
.ow-popup-scrollable {
  /* 필요시 팝업 자체에 스타일 추가 */
}
.file-list-label {
  font-weight: 500;
  color: #495057;
  white-space: nowrap;
  margin-right: 8px;
  padding-top: 4px;
}

/* 그리드 로우 선 */
.deleted-row {
  text-decoration: line-through;
  color: #aaa;
}
</style>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch, nextTick } from "vue";
import { useApi, useCommonCode } from "@ows/core";

const api = useApi();

// 원하는 경로를 정의 (Global -> 아시아 -> 대한민국 -> 국내영업총괄본부)
const defaultPath = ["Global", "아시아", "대한민국", "국내영업총괄본부"];

// 각 레벨에서 보여줄 최대 항목 수 (5번째 레벨에서는 6개만 표시)
const MAX_VISIBLE_ITEMS = 1;

const props = defineProps({
  propsId: {
    type: String,
    default: "itemSelectionsFilter",
  },
  label: {
    type: String,
    default: null,
  },
  propsListItem: {
    type: Array,
    default: () => [],
  },
  propsSelectItem1: {
    type: String,
    default: null,
  },
  propsSelectItem2: {
    type: String,
    default: null,
  },
  propsSelectItem: {
    type: Array,
    default: () => [null, null, null, null, null, null],
  },
  viewDepth: {
    type: Number,
    default: null,
  },
  propsWidth: {
    type: String,
    default: "auto",
  },
  corporationCode: {
    type: String,
    default: "KR1",
  },
  departmentCode: {
    type: String,
  },
});

const emit = defineEmits(["selectItem"]);

const root = ref(null);
const filter = ref(null);
const index = ref(0);

// 팝업 관련 상태 추가
const popupVisible = ref(false);
const popupItems = ref([]);
const popupLevel = ref(0);
const popupParentName = ref('');
const popupPosition = ref({ top: 0, left: 0 });

const state = reactive({
  item2_select: props.propsSelectItem2,
  item_list: [],
  original_list: [],
  item1_select: props.propsSelectItem1,
  overflow: false,
  item_select: [...props.propsSelectItem],
  loading: false,
  error: null,
  selectedValues: [null, null, null, null, null, null], // 6 레벨까지 지원
});

// 계층형 데이터로 변환하는 함수
function transformToHierarchical(flatData) {
  // 부서 데이터와 사원 데이터 분리
  const deptData = flatData.filter((item) => !item.data.empNo);
  const empData = flatData.filter((item) => item.data.empNo);

  // 결과 객체를 저장할 맵 생성
  const deptMap = new Map();
  
  // 최상위 부서들을 담을 배열
  const result = [];

  // 부서 데이터를 맵에 저장
  deptData.forEach((dept) => {
    deptMap.set(dept.key, {
      name: dept.data.deptName,
      value: dept.data.deptCode,
      itemList: [],
      data: dept.data,
    });
  });

  // 부서 계층 구조 구성
  deptData.forEach((dept) => {
    const deptObj = deptMap.get(dept.key);

    if (dept.parentId && deptMap.has(dept.parentId)) {
      // 부모 부서가 있는 경우 부모의 itemList에 추가
      const parentDept = deptMap.get(dept.parentId);
      parentDept.itemList.push(deptObj);
    } else if (dept.parentId === null || !deptMap.has(dept.parentId)) {
      // 최상위 부서인 경우 결과 배열에 직접 추가
      result.push(deptObj);
    }
  });

  // 사원 데이터를 해당 부서의 itemList에 추가
  empData.forEach((emp) => {
    if (emp.parentId && deptMap.has(emp.parentId)) {
      const parentDept = deptMap.get(emp.parentId);
      parentDept.itemList.push({
        name: `${emp.data.dutyName ? `(${emp.data.dutyName}) ` : ""}${
          emp.data.empName
        }${emp.data.gradeName ? ` ${emp.data.gradeName}` : ""}`,
        value: emp.data.empNo,
        itemList: [],
        data: emp.data,
      });
    }
  });

  return result;
}

// API에서 조직 데이터 가져오기
async function fetchOrganizationData() {
  state.loading = true;
  state.error = null;

  try {
    const response = await api.get("/com/v2/department", {
      params: {
        corporationCode: props.corporationCode,
        departmentCode: props.departmentCode,
      },
    });

    // API 데이터를 계층 구조로 변환
    let hierarchicalData = transformToHierarchical(response || []);
    
    // Global -> 아시아 -> 대한민국 -> 변환된 계층 데이터 구성
    const modifiedData = [
      {
        name: "Global",
        value: "global",
        data: { 
          deptName: "Global",
          deptCode: "global"
        },
        itemList: [
          {
            name: "아시아",
            value: "asia",
            data: { 
              deptName: "아시아",
              deptCode: "asia"
            },
            itemList: [
              {
                name: "대한민국",
                value: "korea",
                data: { 
                  deptName: "대한민국", 
                  deptCode: "korea"
                },
                // 변환된 계층 데이터를 대한민국 하위에 배치
                itemList: hierarchicalData
              }
            ]
          }
        ]
      }
    ];

    state.item_list = modifiedData;
    state.original_list = modifiedData;
    
    // 경로 선택
    state.item_select = defaultPath;
    selectPredefinedPath();
  } catch (error) {
    console.error("Failed to fetch organization data:", error);
    state.error = "조직 데이터를 가져오는 데 실패했습니다.";
  } finally {
    state.loading = false;
  }
}

// "더보기" 버튼 또는 항목 클릭 처리 - 위치 정보 추가
function showMoreItems(level, items, parentName, event) {
  popupItems.value = items;
  popupLevel.value = level;
  popupParentName.value = parentName;
  
  // 클릭 이벤트에서 위치 계산
  if (event && event.target) {
    const rect = event.target.getBoundingClientRect();
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    
    // 클릭한 요소 바로 아래에 팝업 위치 설정
    popupPosition.value = {
      top: rect.bottom + scrollTop,
      left: rect.left
    };
  }
  
  popupVisible.value = true;
}

// 팝업에서 항목 선택 시 처리
function selectPopupItem(item) {
  itemSelectAction(popupLevel.value, item.name, item, item.grp);
  closePopup();
}

// 팝업 닫기
function closePopup() {
  popupVisible.value = false;
}

// 미리 정의된 경로를 선택하는 함수
function selectPredefinedPath() {
  // 초기화: 모든 선택 상태 리셋
  state.item_select = defaultPath.map((name, index) => index < defaultPath.length ? name : null);
  state.selectedValues = Array(defaultPath.length).fill(null);
  
  // 선택 경로에 해당하는 값을 찾아 설정
  let currentItems = state.original_list;
  let currentItem = null;
  
  for (let depth = 0; depth < defaultPath.length; depth++) {
    const targetName = defaultPath[depth];
    currentItem = currentItems.find(item => item.name === targetName);
    
    if (!currentItem) {
      console.warn(`Path item not found: ${targetName} at depth ${depth}`);
      break;
    }
    
    // 현재 수준의 값 설정
    state.selectedValues[depth] = currentItem.value;
    
    // 선택 이벤트 발생
    emit("selectItem", {
      name: currentItem.name,
      value: currentItem.value,
      depth: depth,
      grp: currentItem.grp,
      data: currentItem.data,
      root: depth === 0 // depth가 0인 경우 최상위 항목
    });
    
    // 다음 수준으로 이동
    currentItems = currentItem.itemList || [];
  }
}

// 첫 번째 항목을 자동으로 선택하는 함수
function selectFirstItem() {
  if (state.original_list && state.original_list.length > 0) {
    const firstItem = state.original_list[0];
    
    // 첫 번째 항목 선택 상태로 설정
    state.item_select[0] = firstItem.name;
    state.selectedValues[0] = firstItem.value;
    
    // 부모 컴포넌트에 선택 이벤트 발생 (root 플래그 추가)
    emit("selectItem", {
      name: firstItem.name,
      value: firstItem.value,
      depth: 0,
      grp: firstItem.grp,
      data: firstItem.data,
      root: true // 최상위 항목임을 표시
    });
  }
}

const filteredItems = computed(() => {
  // 아무것도 선택되지 않은 경우 모든 항목 표시
  if (!state.item_select[0]) {
    return state.original_list;
  }

  // 현재 선택된 가장 깊은 레벨과 선택된 항목들의 경로를 찾음
  let currentLevel = -1;
  const selectedPath = [];

  for (let i = 0; i < state.item_select.length; i++) {
    if (state.item_select[i]) {
      currentLevel = i;
      selectedPath.push(state.item_select[i]);
    }
  }

  // 선택된 항목을 찾아 그 항목과 하위 구조만 반환
  function findSelectedItem(items, level = 0) {
    if (level >= selectedPath.length) {
      return null;
    }

    const selectedItem = items.find(
      (item) => item.name === selectedPath[level]
    );
    if (!selectedItem) {
      return null;
    }

    // 선택된 항목의 복사본 생성
    const result = { ...selectedItem };

    // 마지막 선택 레벨이 아니고 하위 항목이 있으면 재귀적으로 처리
    if (level < currentLevel && result.itemList?.length > 0) {
      const nextLevel = findSelectedItem(result.itemList, level + 1);
      if (nextLevel) {
        result.itemList = [nextLevel];
      }
    }

    return result;
  }

  const selectedItem = findSelectedItem(state.original_list);
  return selectedItem ? [selectedItem] : [];
});

watch(
  () => props.viewDepth,
  (newDepth) => {
    if (newDepth != null) {
      switch (newDepth) {
        case 2:
          state.item_select = state.item_select.map((_, i) =>
            i === 0 ? "Implant" : null
          );
          break;
        case 3:
          state.item_select = state.item_select.map((_, i) => {
            if (i === 1) {
              return "Fixture";
            }
            return i < 1 ? state.item_select[i] : null;
          });
          break;
        default:
          // 기본값으로 원하는 경로 설정
          selectPredefinedPath();
      }
    }
  }
);

watch(
  () => props.propsListItem,
  (newValue) => {
    if (newValue && newValue.length > 0) {
      state.item_list = [...newValue];
      state.original_list = [...newValue];
      
      // 리스트 아이템이 변경될 때도 원하는 경로 자동 선택
      selectPredefinedPath();
    }
  }
);

watch(
  () => props.propsSelectItem,
  (newValue) => {
    state.item_select = newValue;
    
    // 만약 모든 값이 null이면 원하는 경로 선택
    if (newValue.every(val => val === null)) {
      selectPredefinedPath();
    }
  }
);

watch(
  () => props.corporationCode,
  (newValue) => {
    if (newValue) {
      fetchOrganizationData();
    }
  }
);

// 항목 선택 핸들러
function itemSelectAction(depth, name, item, grp) {
  // 특정 항목 선택 시
  const newSelect = state.item_select.map(() => null);
  const newValues = state.selectedValues.map(() => null);

  for (let i = 0; i <= depth; i++) {
    if (i === depth) {
      newSelect[i] = name;
      newValues[i] = item.value;
    } else {
      newSelect[i] = state.item_select[i];
      newValues[i] = state.selectedValues[i];
    }
  }

  state.item_select = newSelect;
  state.selectedValues = newValues;

  // 선택된 항목의 정보를 emit으로 전달 (root 플래그 추가)
  // depth가 0이면 최상위 항목이므로 root = true
  emit("selectItem", {
    name,
    value: item.value,
    depth,
    grp,
    data: item.data,
    root: depth === 0 // depth가 0인 경우 최상위 항목
  });
}

function getContentRect(dom) {
  if (!dom) {
    return DOMRectReadOnly.fromRect();
  }
  return dom.getBoundingClientRect();
}

const observer = new ResizeObserver((entries) => {
  for (const entry of entries) {
    const { width: outerWidth } = entry.contentRect;
    const { width: innerWidth } = getContentRect(filter.value);
    if (entry.target === root.value) {
      state.overflow = outerWidth < innerWidth;
    }
  }
});

onMounted(() => {
  if (root.value) {
    observer.observe(root.value);
  }

  // 컴포넌트 마운트 시 조직 데이터 가져오기
  fetchOrganizationData();
});

onUnmounted(() => {
  observer.disconnect();
});

// 특정 레벨에서 표시할 항목 수 제한 계산
function getVisibleItems(items, level) {
  if (level === 4 && items.length > MAX_VISIBLE_ITEMS) {
    return items.slice(0, MAX_VISIBLE_ITEMS);
  }
  return items;
}

// 더 많은 항목이 있는지 확인
function hasMoreItems(items, level) {
  return level === 4 && items.length > MAX_VISIBLE_ITEMS;
}

// 추가 항목 수 계산
function getRemainingCount(items, level) {
  if (level === 4 && items.length > MAX_VISIBLE_ITEMS) {
    return items.length - MAX_VISIBLE_ITEMS;
  }
  return 0;
}

// 더보기 항목 가져오기
function getMoreItems(items, level) {
  if (level === 4 && items.length > MAX_VISIBLE_ITEMS) {
    return items.slice(MAX_VISIBLE_ITEMS);
  }
  return [];
}
</script>

<template>
      <div class="ow-filter">
        <div ref="filter" class="ow-filter-cont">
          <ul class="log_style_towdepth_radio">
            <li
              v-for="item in state.original_list"
              :key="item.name"
              :class="[
                state.item_select[0] == item.name ? 'active' : '',
                { 'has-arrow': item.itemList?.length > 0 },
              ]"
            >
              <button @click="itemSelectAction(0, item.name, item, item.grp)">
                {{ item.name }}
              </button>
              <ul v-if="item.itemList?.length > 0">
                <li
                  v-for="item2 in item.itemList"
                  :key="item2.name"
                  :class="[
                    state.item_select[1] == item2.name ? 'active' : '',
                    { 'has-arrow': item2.itemList?.length > 0 },
                  ]"
                >
                  <button
                    @click="itemSelectAction(1, item2.name, item2, item2.grp)"
                  >
                    {{ item2.name }}
                  </button>
                  <ul v-if="item2.itemList?.length > 0">
                    <li
                      v-for="item3 in item2.itemList"
                      :key="item3.name"
                      :class="[
                        state.item_select[2] == item3.name ? 'active' : '',
                        { 'has-arrow': item3.itemList?.length > 0 },
                      ]"
                    >
                      <button
                        @click="
                          itemSelectAction(2, item3.name, item3, item3.grp)
                        "
                      >
                        {{ item3.name }}
                      </button>
                      <ul v-if="item3.itemList?.length > 0">
                        <li
                          v-for="item4 in item3.itemList"
                          :key="item4.name"
                          :class="[
                            state.item_select[3] == item4.name ? 'active' : '',
                            { 'has-arrow': item4.itemList?.length > 0 },
                          ]"
                        >
                          <button
                            @click="
                              itemSelectAction(3, item4.name, item4, item4.grp)
                            "
                          >
                            {{ item4.name }}
                          </button>
                          <ul v-if="item4.itemList?.length > 0">
                            <!-- 5번째 레벨에서는 항목 수 제한 -->
                            <li
                              v-for="item5 in getVisibleItems(item4.itemList, 4)"
                              :key="item5.name"
                              :class="[
                                state.item_select[4] == item5.name
                                  ? 'active'
                                  : '',
                                { 'has-arrow': item5.itemList?.length > 0 },
                              ]"
                            >
                              <button
                                @click="
                                  itemSelectAction(
                                    4,
                                    item5.name,
                                    item5,
                                    item5.grp
                                  )
                                "
                              >
                                {{ item5.name }}
                              </button>
                              <ul v-if="item5.itemList?.length > 0">
                                <li
                                  v-for="item6 in item5.itemList"
                                  :key="item6.name"
                                  :class="[
                                    state.item_select[5] == item6.name
                                      ? 'active'
                                      : '',
                                    { 'has-arrow': item6.itemList?.length > 0 },
                                  ]"
                                >
                                  <button
                                    @click="
                                      itemSelectAction(
                                        5,
                                        item6.name,
                                        item6,
                                        item6.grp
                                      )
                                    "
                                  >
                                    {{ item6.name }}
                                  </button>
                                </li>
                              </ul>
                            </li>
                            <!-- 5번째 레벨에서 "..." 버튼 추가 (기존의 "더보기" 대체) -->
                            <li v-if="hasMoreItems(item4.itemList, 4)" class="more-items">
                              <button 
                                class="ellipsis-button"
                                @click="showMoreItems(4, getMoreItems(item4.itemList, 4), item4.name, $event)"
                              >
                                ...
                              </button>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </ul>
          
          <!-- 팝업 모달 - 위치 조정 -->
          <div v-if="popupVisible" class="popup-modal" @click.self="closePopup">
            <div class="popup-content" :style="{ position: 'absolute', top: `${popupPosition.top}px`, left: `${popupPosition.left}px` }">
              <div class="popup-header">
                <h3>{{ popupParentName }} 추가 항목</h3>
                <button class="close-button" @click="closePopup">×</button>
              </div>
              <div class="popup-body">
                <ul class="popup-items">
                  <li v-for="item in popupItems" :key="item.name">
                    <button @click="selectPopupItem(item)">
                      {{ item.name }}
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

</template>

<style lang="scss" scoped>
.loading-indicator,
.error-message,
.empty-message {
  padding: 10px;
  text-align: center;
  font-size: 14px;
}

.error-message {
  color: #e74c3c;
}

.empty-message {
  color: #7f8c8d;
}

.ow-filter {
  padding: 0;
  max-width: var(--maxWidth, 100%);
  .ow-filter-cont {
    white-space: nowrap;
    position: relative; // 팝업을 위한 포지셔닝 컨텍스트
  }
}

.log_style_towdepth_radio {
  align-items: center;
  display: flex;
  overflow: hidden;
  padding-left: 1px;
  background: #fff;
  margin-bottom: 0px;
}

.log_style_towdepth_radio li {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: -1px;
  color: #333;
  background: #e1e6ea;
}

.log_style_towdepth_radio li a,
.log_style_towdepth_radio li button {
  float: left;
  display: block;
  border: 1px solid #e1e6ea;
  padding: 0 5px;
  font-weight: 700;
  letter-spacing: 0px;
  color: #333;
  line-height: 22px;
  margin-left: -1px;
  background: #e1e6ea;
}

.log_style_towdepth_radio li ul {
  display: none;
  overflow: hidden;
  padding: 0px 6px;
}

.log_style_towdepth_radio li ul a,
.log_style_towdepth_radio li ul button {
  line-height: 18px;
  border-radius: 2px;
}

.log_style_towdepth_radio li.active > a,
.log_style_towdepth_radio li.active > button {
  border-color: #176de2;
  background-color: #4e95f5;
  color: #fff;
  position: relative;
}

.log_style_towdepth_radio li.active:has(li) > a:after,
.log_style_towdepth_radio li.active:has(li) > button:after {
  content: "";
  position: absolute;
  height: 7px;
  width: 7px;
  right: -4px;
  background-color: #4e95f5;
  transform: translateY(100%) rotate(135deg);
  border-left: 1px solid #176de2;
  border-top: 1px solid #176de2;
}

.log_style_towdepth_radio li.active:hover > a,
.log_style_towdepth_radio li.active:hover > button {
  border-color: #176de2;
  background-color: #4e95f5;
}

.log_style_towdepth_radio li.active > ul {
  display: inline-block;
}

.log_style_towdepth_radio li.active > ul a:after,
.log_style_towdepth_radio li.active > ul button:after {
  margin-top: -2px;
}

.log_style_towdepth_radio li.active:has(.active) > a,
.log_style_towdepth_radio li.active:has(.active) > button {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active:has(.active) > a:after,
.log_style_towdepth_radio li.active:has(.active) > button:after {
  background-color: #677280;
  border-color: #677280;
}

.log_style_towdepth_radio li.active + li a,
.log_style_towdepth_radio li.active + li button {
  margin-left: 0;
}

/* 더보기 점 표시 스타일 */
.more-items {
  background: transparent !important;
  display: flex;
  justify-content: center;
}

.ellipsis-button {
  color: #333 !important;
  background-color: #e1e6ea !important;
  border: 1px solid #e1e6ea !important;
  cursor: pointer;
  padding: 0 8px;
  font-weight: bold !important;
  font-size: 14px !important;
  text-align: center;
  line-height: 18px;
  border-radius: 2px;
}

/* 팝업 모달 스타일 */
.popup-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  z-index: 1000;
}

.popup-content {
  background-color: white;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
  width: 300px;
  max-height: 400px;
  display: flex;
  flex-direction: column;
  z-index: 1001;
}

.popup-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 15px;
  border-bottom: 1px solid #e1e6ea;
}

.popup-header h3 {
  margin: 0;
  font-size: 14px;
  font-weight: bold;
}

.close-button {
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
  color: #333;
}

.popup-body {
  padding: 10px;
  overflow-y: auto;
  max-height: 340px;
}

.popup-items {
  list-style: none;
  padding: 0;
  margin: 0;
}

.popup-items li {
  margin-bottom: 5px;
}

.popup-items button {
  width: 100%;
  text-align: left;
  background-color: #f1f1f1;
  border: 1px solid #ddd;
  padding: 8px 10px;
  border-radius: 3px;
  cursor: pointer;
  font-size: 12px;
  transition: background-color 0.2s;
}

</style>
import { defineStore } from 'pinia';
import { ref } from 'vue';

export const useColumnPopup = defineStore('columnPopup', () => {
  const columns = ref([]);
  const selectedColumns = ref([]);

  const setColumns = (data) => {
    columns.value = data;
  };

  const setSelectedColumns = (data) => {
    selectedColumns.value = data;
  };

  return { columns, selectedColumns, setColumns, setSelectedColumns };
});

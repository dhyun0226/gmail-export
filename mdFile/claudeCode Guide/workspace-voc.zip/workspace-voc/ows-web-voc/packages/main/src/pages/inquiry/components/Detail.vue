<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { useApi, useCommonCode } from "@ows/core";
import dayjs from "dayjs";
import { useOwAlert, useOwPopup } from "@ows/ui";
import { useColumnPopup } from "@/composables/useColumnPopupStore";
import DxListNGrid from "@/components/DxListNGrid.vue";
import { dateUtils } from "@/utils";
import InquiryDetailPopup from "@/components/InquiryDetailPopup.vue";
import type { PaginatedResponse } from "@/types";

const props = defineProps({
  dateOptions: Object,
  filterOptions: Object,
  shouldReload: Boolean,
  selectedServiceOptions: {
    type: Array,
    default: () => [],
  },
});

const emit = defineEmits(["reloaded"]);

const { owConfirm } = useOwAlert();

const {
  openPopup: openDetailPopup,
  closePopup: closeDetailPopup = () => {},
  isPopupOpen,
  getVh,
} = useOwPopup();

const popupHeight = 500;
const popupPosition = ref({ my: "center", at: "center", of: "body" });

const columnPopupStore = useColumnPopup();

const api = useApi();
const { VOC_ITM_CTG_CD } = await useCommonCode("VOC_ITM_CTG_CD");
const { VOC_DVCD } = await useCommonCode("VOC_DVCD");

const channelOptions = ref([
  { text: "TV", value: "D001" },
  { text: "Mall", value: "D002" },
  { text: "Education", value: "D003" },
  { text: "Job", value: "D004" },
  { text: "Software", value: "D005" },
  { text: "Osstem Home", value: "D006" },
]);

const eventParticipationDivisionCodeOptions = ref([
  { text: "댓글참여", value: "01" },
  { text: "인증참여", value: "02" },
]);

const individualInquiryNumber = ref(0);
const vocCategoryCode = ref("");
const vocCategoryName = ref("");
const columns = ref([
  {
    caption: "번호",
    width: "90",
    dataField: "individualInquiryNumber",
    allowMerge: true,
    alignment: "center",
    allowSorting: false,
    visible: true,
  },

  {
    caption: "등록일자",
    width: "100",
    dataField: "individualInquiryRegistrationDatetime",
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    cellType: "ymd",
    visible: true,
  },
  {
    caption: "제목",
    width: "*",
    dataField: "individualInquiryTitle",
    allowMerge: false,
    alignment: "left",
    allowSorting: false,
    visible: true,
  },
  {
    caption: "처리상태",
    width: "100",
    dataField: "processStatus",
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    cellType: "customize6",
    visible: true,
  },
  {
    caption: "채널",
    width: "100",
    dataField: "vocCategoryCode",
    allowMerge: true,
    alignment: "center",
    allowSorting: false,
    visible: true,
    cellType: "customize",
  },
  // {
  //   caption: '파일',
  //   width: '50',
  //   dataField: 'fileId',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   cellType: 'customize4',
  //   visible: true,
  // },
  // {
  //   caption: '카테고리',
  //   width: '100',
  //   dataField: 'eventParticipationDivisionCode',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   visible: true,
  //   cellType: 'customize2',
  // },

  // {
  //   caption: '조회건수',
  //   width: '70',
  //   dataField: 'inquiryCount',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   visible: true,
  // },
  {
    caption: "등록자",
    width: "100",
    dataField: "vocWriterName",
    allowMerge: false,
    alignment: "center",
    allowSorting: false,
    visible: true,
  },

  // {
  //   caption: '수정자',
  //   width: '120',
  //   dataField: '',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   visible: true,
  // },
  // {
  //   caption: '수정일시',
  //   width: '120',
  //   dataField: '',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   cellType: 'customize',
  //   visible: true,
  // },
  // {
  //   caption: '삭제',
  //   width: '70',
  //   dataField: '',
  //   allowMerge: false,
  //   alignment: 'center',
  //   allowSorting: false,
  //   cellType: 'customize3',
  //   visible: true,
  // },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: "725px",
  selection: { mode: "none", showCheckBoxesMode: "none" },
  pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

function getItemText(code) {
  // const item = VOC_ITM_CTG_CD.find(item => item.value === code);
  // return item ? item.text : code;
  return code;
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format("YY-MM-DD");
}

function getTimeFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format("HH:mm");
}

function getColumnsByDate() {
  const date = props.dateOptions.rangeUnit;
  if (date === "day") {
    columns.value.forEach((col) => {
      if (col.caption === "접수일자") {
        col.caption = "접수시간";
      }
      col.visible = true;
    });
  } else if (date === "week") {
    columns.value.forEach((col) => {
      if (col.caption === "접수시간") {
        col.caption = "접수일자";
      }
      col.visible = true;
    });
  } else {
    columns.value.forEach((col) => {
      if (col.caption === "접수시간" || col.caption === "접수일자") {
        col.caption = "접수일자";
        col.visible = false;
      }
      if (col.caption === "요청자") {
        col.visible = false;
      }
    });
  }
  columnPopupStore.setSelectedColumns(
    columns.value.filter((col) => col.visible).map((col) => col.caption)
  );
}

// 셀병합할 컬럼
const mergeColumns = computed(() => {
  const arr = [];
  columns.value.forEach((e, idx) => {
    if (e.allowMerge) {
      arr.push({ idx, field: e.dataField });
    }
  });
  return arr;
});

const mergeCellIndexs = mergeColumns.value.map((e) => [e.idx]);

function onCellPrepared(e) {
  // if (e.rowType === 'data' && e.data?.header) {
  //   if (e.columnIndex === 1) {
  //     e.cellElement.classList.add('sal-custom');
  //     e.cellElement.colSpan = 4;
  //   }
  //   else if (e.columnIndex > 1) {
  //     e.cellElement.classList.add('sal-disable');
  //   }
  // }
}

function onCellClick(e) {
  individualInquiryNumber.value = e.data.individualInquiryNumber;
  vocCategoryCode.value = e.data.vocCategoryCode;
  vocCategoryName.value = e.data.vocCategoryName;
  openDetailPopup();
}

async function load() {
  try {
    // 문의 데이터를 가져옴
    const result = await api.get<PaginatedResponse>(
      "/voc/individual-inquiries",
      {
        params: {
          keyword: "",
          channelCode: null,
          pageNo: gridOption.value.paging.pageNo,
          pageSize:
            gridOption.value.paging.pageSize * gridOption.value.nGridCount,
          fromDate: dateUtils.toLocalDateTime(props.dateOptions.from),
          toDate: dateUtils.toLocalDateTime(props.dateOptions.to),
          ...(props.selectedServiceOptions &&
          props.selectedServiceOptions.length > 0
            ? { channelCode: props.selectedServiceOptions.join(",") }
            : {}),
        },
      }
    );
    const inquiryData = result.data.data;
    // VOC 카테고리 데이터를 가져옴
    const vocCategoryResponse = await api.get("/voc/serviceCategories");
    const vocCategorys = vocCategoryResponse.data;

    // vocCategoryCode와 vocCategoryCd를 매핑하여 vocCategoryName 추가
    const enrichedData = inquiryData.map((item) => {
      const matchedCtg = vocCategorys.find(
        (ctg) => ctg.vocCategoryCd === item.vocCategoryCode
      );

      if (!matchedCtg) {
      }

      return {
        ...item,
        vocCategoryName: matchedCtg ? matchedCtg.vocCategoryName : "Unknown",
      };
    });

    // 데이터를 gridOption에 설정
    gridOption.value.datas = enrichedData;
    gridOption.value.paging.totalItemCount = result.data.totalCount;
  } catch (error) {
    gridOption.value.datas = [];
    console.error("Failed to load 문의 data:", error);
  }
}

function editDetailPopup() {
  closeDetailPopup();
  load();
}

async function deleteRow(individualInquiryNumber) {
  alert("삭제하시겠습니까?");
  try {
    await api.delete(`/voc/individual-inquiries/${individualInquiryNumber}`);
  } catch (error) {
    console.error("Failed to delete event:", error);
  }
  load();
}

function checkFileId(fileId) {
  if (fileId) {
    return "Y";
  } else {
    return "N";
  }
}

function getChannelText(code) {
  const channel = channelOptions.value.find((item) =>
    code.includes(item.value)
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

function getParticipationText(code) {
  const participation = eventParticipationDivisionCodeOptions.value.find(
    (item) => item.value === code
  );
  return participation ? participation.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

watch(
  () => props.dateOptions,
  (newVal) => {
    getColumnsByDate();
    load();
  },
  { deep: true }
);

watch(
  () => props.filterOptions,
  (newVal) => {
    load();
  },
  { deep: true }
);

// shouldReload prop 감시
watch(
  () => props.shouldReload,
  (newValue) => {
    if (newValue) {
      load().then(() => {
        emit("reloaded"); // 리로드 완료 후 부모에게 알림
      });
    }
  }
);

onMounted(() => {
  getColumnsByDate();
  columnPopupStore.setColumns(columns.value);
  columnPopupStore.setSelectedColumns(
    columns.value.filter((col) => col.visible).map((col) => col.caption)
  );
  load();
});
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :merge-cell-indexs="mergeCellIndexs"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <div>
        {{ getChannelText(cell.data.vocCategoryCode) }}
      </div>
    </template>

    <template #customize2="{ data: cell }">
      <div>
        {{ getParticipationText(cell.data.eventParticipationDivisionCode) }}
      </div>
    </template>

    <template #customize3="{ data: cell }">
      <div>
        <BButton
          variant="box-delete"
          @click.stop="deleteRow(cell.data.individualInquiryNumber)"
        />
      </div>
    </template>
    <template #customize4="{ data: cell }">
      <div>{{ cell.data.topFixedYesOrNo == "Y" ? "고정" : "해제" }}</div>
    </template>
    <template #customize5="{ data: cell }">
      <div>{{ cell.data.useYesOrNo == "Y" ? "사용" : "미사용" }}</div>
    </template>
    <template #customize6="{ data: cell }">
      <div>{{ cell.data.processStatus ? "답변완료" : "문의접수" }}</div>
    </template>
  </DxListNGrid>
  <InquiryDetailPopup
    v-if="isPopupOpen"
    :is-popup-open="isPopupOpen"
    height="auto"
    title="1:1문의 수정"
    :individual-inquiry-number="individualInquiryNumber"
    :voc-category-code="vocCategoryCode"
    :voc-category-name="vocCategoryName"
    :disabled-select="true"
    :width="1100"
    :on-close="
      () => {
        closeDetailPopup();
      }
    "
    @edit-event="editDetailPopup"
  />
</template>

<style></style>

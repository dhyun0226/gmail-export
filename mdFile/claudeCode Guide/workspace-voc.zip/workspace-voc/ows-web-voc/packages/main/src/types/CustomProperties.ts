import type { ChannelKey } from '@dns/core';

export interface Override {
  href: string;
}

export interface CustomProperties {
  overrides: {
    [key in ChannelKey]?: Override
  };
}

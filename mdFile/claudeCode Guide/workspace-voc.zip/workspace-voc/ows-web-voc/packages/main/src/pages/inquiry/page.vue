<script setup>
import { ref } from 'vue';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';

import Detail from './components/Detail.vue';
import TotalSummary from './components/TotalSummary.vue';
import EventDetailPopup from '@/components/EventDetailPopup.vue';

const {
  openPopup: openColumnPopup,
  isPopupOpen: isDetailPopupOpen,
  closePopup: closeDetailPopup,
  getVh,
} = useOwPopup();

const popupHeight = 100;
const popupPosition = ref({ my: 'center', at: 'center', of: 'body' });

function openPopupPosition(id) {
  const vh = getVh(id);
  const popupVh = (popupHeight / window.innerHeight) * 100; // to vh %
  const diffVh = 100 - popupVh;

  let offsetY = 0;
  if (vh > diffVh) {
    offsetY = (((vh - diffVh) * window.innerHeight) / 100) * -1; // to px
  }
  popupPosition.value = {
    my: 'left top',
    at: 'right top',
    of: `#${id}`,
    offset: `5 ${offsetY}`,
  };

  openColumnPopup();
}

const dateOptions = ref({
  from: dayjs().format('YYYY-MM-DD'),
  to: dayjs().hour(23).minute(59).second(59).format('YYYY-MM-DD'),
  doubleFlag: false,
  today: false,
  twice: false,
  disabledTwice: false,
  disabledDouble: false,
  disabledPicker: false,
  rangeUnit: 'year',
});

const searchGroup = ref('전체');
const searchGroupOptions = ref([
  { text: '전체', value: '전체' },
  { text: '제목', value: '제목' },
  { text: '내용', value: '내용' },
  { text: '등록자', value: '등록자' },
  { text: '수정자', value: '수정자' },
]);

const selectedServiceOptions = ref([]);
const ServiceOptions = ref([
  { text: 'TV', value: 'D001' },
  { text: 'Mall', value: 'D002' },
  { text: 'Education', value: 'D003' },
  { text: 'Job', value: 'D004' },
  { text: 'Software', value: 'D005' },
  { text: 'Osstem Home', value: 'D006' },
]);

const listCategoryGroup = ref('');
const listCategoryGroupOptions = [
  { text: '댓글참여', value: '01' },
  { text: '인증참여', value: '02' },
];

const useSettingGroup = ref('');
const useSettingGroupOptions = [
  { text: '사용', value: 'Y' },
  { text: '미사용', value: 'N' },
];

const options = ref([
  { text: '제목', value: 'ASGN' },
  { text: '등록자', value: 'MEET' },
  { text: '수정자', value: 'OWAY' },
  // {text: '담당자', value: 'VCTN'}
]);
const initialEmpty = ref('');

const filterOptions = ref({
  selectedServiceOptions,
  listCategoryGroup,
  useSettingGroup,
});

function handleItemFilterChange() {
  // load();
}

function handleDateChange(date, newVal) {
  dateOptions.value.from = date;
  dateOptions.value.to = dayjs(newVal).hour(23).minute(59).second(59);
}

function change() {

}

function handleUnitChange(unit) {
  dateOptions.value.rangeUnit = unit;
}

function handleTwiceChange(twice) {
}

function handlePrevNextChange(unit) {
}

const shouldReloadGrid = ref(false);

function saveDetailPopup() {
  closeDetailPopup();
  shouldReloadGrid.value = true;
}

function reloadGrid() {
  // load();
}
</script>

<template>
  <div
    class="input-group gap-1 mb-2"
    role="group"
  >
    <OwBizDatePickerRangeExcluedPickVer2
      v-model:from="dateOptions.from"
      v-model:to="dateOptions.to"
      v-model:is-double-selected="dateOptions.doubleFlag"
      :unit="dateOptions.rangeUnit"
      :disabled-twice="dateOptions.disabledTwice"
      :default-twice="false"
      :disabled-double="dateOptions.disabledDouble"
      :years="15"
      :today="dateOptions.today"
      :hidden-units="['6months', '5years']"
      @change="handleDateChange"
      @unit-change="handleUnitChange"
      @prev-next-change="handlePrevNextChange"
      @twice-change="handleTwiceChange"
    />

    <BButton
      v-if="dateOptions.doubleFlag"
      class="ow-bi ow-w24"
      variant="light"
      :style="today ? 'border: 2px solid #176de2;' : ''"
      @click="today = !today"
    >
      <i class="bi bi-box-arrow-left" />
      <span class="visually-hidden">기간/오늘 선택</span>
    </BButton>

    <div class="ow-filter">
      <label class="ow-stit">채널</label>
      <div style="display: flex; gap: 2px">
        <OwFormCheckbox
          v-model="selectedServiceOptions"
          :options="ServiceOptions"
          @change="change"
        />
      </div>
    </div>

    <!--    <label class="ow-stit">카테고리</label> -->
    <!--    <OwFormCheckbox -->
    <!--      v-model="listCategoryGroup" -->
    <!--      :options="listCategoryGroupOptions" -->
    <!--      @change="change" -->
    <!--    /> -->

    <!--    <label class="ow-stit">답변상태</label> -->
    <!--    <OwFormCheckbox -->
    <!--      v-model="useSettingGroup" -->
    <!--      :options="useSettingGroupOptions" -->
    <!--      @change="change" -->
    <!--    /> -->

    <!--    <OwFormRadio -->
    <!--      v-model="initialEmpty" -->
    <!--      :options="options" -->
    <!--      type="all" -->
    <!--      shape="text" -->
    <!--      @change="change" -->
    <!--    /> -->

    <!--    <div style="width: 400px"> -->
    <!--      <div -->
    <!--        class="input-group" -->
    <!--        role="group" -->
    <!--      > -->
    <!--        <OwFormRadio -->
    <!--          :id="uniqueId('search-group')" -->
    <!--          v-model="searchGroup" -->
    <!--          :options="searchGroupOptions" -->
    <!--          shape="text" -->
    <!--          style="margin-right: 3px" -->
    <!--          action-type="input" -->
    <!--          @change="handleItemFilterChange" -->
    <!--        /> -->
    <!--        <input -->
    <!--          id="form01" -->
    <!--          class="form-control" -->
    <!--          type="text" -->
    <!--          placeholder="검색어를 입력해주세요." -->
    <!--        > -->
    <!--        <button -->
    <!--          class="btn btn-md btn-search" -->
    <!--          type="button" -->
    <!--        /> -->
    <!--      </div> -->
    <!--    </div> -->

    <!--    <BButton variant="state"> -->
    <!--      <i class="bi bi-arrow-clockwise" /> -->
    <!--      초기화 -->
    <!--    </BButton> -->

    <!--    <BButton variant="state"> -->
    <!--      필터 고정 -->
    <!--    </BButton> -->

    <!--    <BButton -->
    <!--      v-if="!dateOptions.doubleFlag" -->
    <!--      :id="`btn-${num}`" -->
    <!--      variant="state" -->
    <!--      style="margin-left: 1070px" -->
    <!--      @click="openPopupPosition(`btn-${num}`)" -->
    <!--    > -->
    <!--      문의 등록 -->
    <!--    </BButton> -->

    <!--    <BButton -->
    <!--      variant="state" -->
    <!--      @click="" -->
    <!--    > -->
    <!--      카테고리 관리 -->
    <!--    </BButton> -->
  </div>
  <Detail
    v-if="!dateOptions.doubleFlag"
    :date-options="dateOptions"
    :filter-options="filterOptions"
    :should-reload="shouldReloadGrid"
    :selected-service-options="selectedServiceOptions"
    @reloaded="() => shouldReloadGrid = false"
  />
  <TotalSummary
    v-if="dateOptions.doubleFlag"
    :date-options="dateOptions"
  />
  <!-- <Teleport to="body">
    <ColumnPopup
      v-if="isColumnPopupOpen"
      :is-popup-open="isColumnPopupOpen"
      :popup-position="popupPosition"
      :height="popupHeight"
      :size="xs"
      :on-close="
        () => {
          closeColumnPopup();
        }
      "
    />
  </Teleport> -->
  <EventDetailPopup
    v-if="isDetailPopupOpen"
    :is-popup-open="isDetailPopupOpen"
    height="auto"
    title="이벤트 등록"
    :width="1100"
    :on-close="
      () => {
        closeDetailPopup();
      }
    "
    @save-event="saveDetailPopup"
  />
</template>

<style scoped></style>

// data.ts
import { computed } from "vue";

// 데이터 타입 정의 (공통)
export interface BaseTreeGridItem {
  id: number | string;
  display: string;
  total: number;
  parentId: number | string | null;
  hasChildren?: boolean;
}

// 일별 데이터 타입
export interface DailyTreeGridItem extends BaseTreeGridItem {
  h0_8: number;
  h9: number;
  h10: number;
  h11: number;
  h12: number;
  h13: number;
  h14: number;
  h15: number;
  h16: number;
  h17: number;
  h18: number;
  h19: number;
  h20: number;
  h21: number;
  h22: number;
  h23: number;
}

// 월별 데이터 타입
export interface MonthlyTreeGridItem extends BaseTreeGridItem {
  d1: number;
  d2: number;
  d3: number;
  d4: number;
  d5: number;
  d6: number;
  d7: number;
  d8: number;
  d9: number;
  d10: number;
  d11: number;
  d12: number;
  d13: number;
  d14: number;
  d15: number;
  d16: number;
  d17: number;
  d18: number;
  d19: number;
  d20: number;
  d21: number;
  d22: number;
  d23: number;
  d24: number;
  d25: number;
  d26: number;
  d27: number;
  d28: number;
  d29: number;
  d30: number;
  d31: number;
}

// 연별 데이터 타입
export interface YearlyTreeGridItem extends BaseTreeGridItem {
  m1: number; // 1월
  m2: number; // 2월
  m3: number; // 3월
  m4: number; // 4월
  m5: number; // 5월
  m6: number; // 6월
  m7: number; // 7월
  m8: number; // 8월
  m9: number; // 9월
  m10: number; // 10월
  m11: number; // 11월
  m12: number; // 12월
}


/**
 * 날짜 범위 단위(일, 주, 월, 년)에 따라 동적으로 컬럼을 생성하는 함수
 */
export function getColumns(rangeUnit, startDate = null, endDate = null) {
  // 현재 날짜 정보
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const currentDate = now.getDate();
  
  // 기본 구분 컬럼
  const baseColumn = {
    dataField: "display",
    caption: "구분",
    width: 150,
    alignment: "left",
  };
  
  // 날짜 기반 컬럼들
  let columns = [];
  
  switch (rangeUnit) {
    case "day":
      // 시간별 통계 (0시~23시)
      columns = [
        baseColumn,
        {
          caption: `${currentYear}년 ${currentMonth + 1}월 ${currentDate}일`,
          alignment: "center",
          columns: [
            {
              dataField: "statistics.total",
              caption: "전체",
              alignment: "center",
              width: 80,
            },
            ...Array.from({ length: 24 }, (_, hour) => ({
              dataField: `statistics.h${hour}`,
              caption: `${hour}시`,
              alignment: "center",
              width: "*",
            })),
          ],
        },
      ];
      break;

    case "week":
      // 월별 주차 계산 함수
      const getMonthWeekNumber = (date) => {
        const firstDayOfMonth = new Date(
          date.getFullYear(),
          date.getMonth(),
          1
        );
        const firstDayOfWeek = firstDayOfMonth.getDay(); // 0(일) ~ 6(토)

        // 해당 날짜가 월의 몇 번째 주인지 계산
        return Math.ceil((date.getDate() + firstDayOfWeek) / 7);
      };

      // 주간 통계
      const monthWeekNumber = getMonthWeekNumber(now);
      const currentDay = now.getDay(); // 0(일) ~ 6(토)
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - currentDay);

      const weekEnd = new Date(now);
      weekEnd.setDate(now.getDate() + (6 - currentDay));

      columns = [
        baseColumn,
        {
          caption: `${currentYear}년 ${
            currentMonth + 1
          }월 ${monthWeekNumber}주차`,
          alignment: "center",
          columns: [
            {
              dataField: "statistics.total",
              caption: "전체",
              alignment: "center",
              width: 80,
            },
            ...Array.from({ length: 7 }, (_, i) => {
              const day = new Date(weekStart);
              day.setDate(weekStart.getDate() + i);
              return {
                dataField: `statistics.d${i + 1}`,
                caption: `${day.getDate()}일`,
                alignment: "center",
                width: "*",
              };
            }),
          ],
        },
      ];
      break;

    case "month":
      // 월별 일자 통계
      const targetMonth = startDate
        ? new Date(startDate).getMonth()
        : currentMonth;
      const targetYear = startDate
        ? new Date(startDate).getFullYear()
        : currentYear;

      // 해당 월의 일수 계산
      const daysInMonth = new Date(targetYear, targetMonth + 1, 0).getDate();

      columns = [
        baseColumn,
        {
          caption: `${targetYear}년 ${targetMonth + 1}월`,
          alignment: "center",
          columns: [
            {
              dataField: "statistics.total",
              caption: "전체",
              alignment: "center",
              width: 80,
            },
            ...Array.from({ length: daysInMonth }, (_, day) => ({
              dataField: `statistics.d${day + 1}`,
              caption: `${day + 1}일`,
              alignment: "center",
              width: "*",
            })),
          ],
        },
      ];
      break;

    case "year":
      // 연간 월별 통계
      const targetYr = startDate
        ? new Date(startDate).getFullYear()
        : currentYear;

      columns = [
        baseColumn,
        {
          caption: `${targetYr}년`,
          alignment: "center",
          columns: [
            {
              dataField: "statistics.total",
              caption: "전체",
              alignment: "center",
              width: 80,
            },
            ...Array.from({ length: 12 }, (_, month) => ({
              dataField: `statistics.m${month + 1}`,
              caption: `${month + 1}월`,
              alignment: "center",
              width: "*",
            })),
          ],
        },
      ];
      break;
  }
  
  return columns;
}

// 셀 렌더링 스타일 함수
export const cellStyleHandlers = {
  // 0인 셀을 회색으로 표시
  applyZeroValueStyle: (cell) => {
    if (
      cell.rowType === "data" &&
      cell.column.dataField !== "display" &&
      cell.value === 0
    ) {
      cell.cellElement.style.color = "#999";
    }
  },

  // 부모 항목 텍스트 굵게 표시
  applyParentStyle: (cell) => {
    if (
      cell.rowType === "data" &&
      cell.column.dataField === "display" &&
      cell.data.hasChildren
    ) {
      cell.cellElement.style.fontWeight = "bold";
    }
  },

  // 새로운 함수 추가: null 값을 0으로 변환
  convertNullToZero: (e) => {
    // 데이터 셀이고, 특정 컬럼이 아니며, 값이 null인 경우
    if (
      e.rowType === "data" &&
      e.column.dataField !== "key" &&
      e.column.dataField !== "name" &&
      e.value === undefined
    ) {
      e.cellElement.textContent = "0";
    }
  },
};

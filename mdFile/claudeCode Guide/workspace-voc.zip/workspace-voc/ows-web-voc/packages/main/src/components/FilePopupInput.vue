<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { BButton } from "bootstrap-vue-next";
import { useFileUpload } from "@ows/core";
import type { FileItem } from "@/types/inquiry";

const props = defineProps({
  modelValue: {
    type: Array as () => FileItem[],
    default: () => [],
  },
  maxFiles: {
    type: Number,
    default: 3,
  },
  maxFileSize: {
    type: Number,
    default: 5, // MB
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  helpText: {
    type: String,
    default: "파일 첨부",
  }
});

const emit = defineEmits(['update:modelValue']);

// 파일 업로드 스토어
const fileUploadStore = useFileUpload();

// 파일 목록 (양방향 바인딩)
const fileList = computed({
  get: () => props.modelValue,
  set: (newValue) => emit('update:modelValue', newValue)
});

// 파일 업로드 제한 확인
const isFileUploadLimited = computed(() => {
  return fileList.value.length >= props.maxFiles;
});

// useFileUpload의 files 변화 감지하여 파일 목록에 추가
watch(
  () => fileUploadStore.files.value,
  (newFiles) => {
    if (newFiles && newFiles.length > 0) {
      const updatedFiles = [...fileList.value, ...newFiles];
      emit('update:modelValue', updatedFiles);
      console.log("파일 추가됨:", newFiles);
    }
  }
);

// 파일 삭제 처리
function removeFile(index: number) {
  const updatedFiles = [...fileList.value];
  updatedFiles.splice(index, 1);
  emit('update:modelValue', updatedFiles);
}

// 파일 크기를 읽기 쉬운 형식으로 변환 (KB 또는 MB)
function formatFileSize(bytes: number): string {
  if (!bytes) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

// 파일 아이콘 결정
function getFileIcon(fileName: string): string {
  const extension = fileName.split('.').pop()?.toLowerCase() || '';
  
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) {
    return 'dx-icon-image';
  } else if (['pdf'].includes(extension)) {
    return 'dx-icon-file-pdf';
  } else if (['doc', 'docx'].includes(extension)) {
    return 'dx-icon-file-doc';
  } else if (['xls', 'xlsx'].includes(extension)) {
    return 'dx-icon-file-xls';
  } else if (['ppt', 'pptx'].includes(extension)) {
    return 'dx-icon-file-ppt';
  } else if (['zip', 'rar', '7z'].includes(extension)) {
    return 'dx-icon-file-zip';
  } else {
    return 'dx-icon-file';
  }
}
</script>

<template>
  <div class="file-attachment-component">
    <div class="file-upload-container">
      <div class="d-flex align-items-center">
        <BButton
          variant="state"
          @click="fileUploadStore.open"
          :disabled="isFileUploadLimited || disabled"
        >
          파일첨부
        </BButton>
        <div class="d-flex flex-column">
          <label class="info ml-2">
            {{ helpText }} {{ maxFiles }}개 등록 가능. 파일당 최대 {{ maxFileSize }}MB
            <span v-if="fileList.length > 0">({{ fileList.length }}/{{ maxFiles }})</span>
          </label>
          <label class="info ml-2">
            첨부 가능 확장자 : jpg, gif, bmp, png, heic, hwp, doc, docx, ppt, pptx, xls, xlsx, zip, pdf, txt, mov, mpeg4, mp4, mkv, m4v, avi, wmv
          </label>
        </div>

      </div>
    </div>

    <!-- 파일 목록 표시 -->
    <div v-if="fileList.length > 0" class="mt-3">
      <div class="file-list-items">
        <div
          v-for="(file, index) in fileList"
          :key="index"
          class="file-list-item"
        >
          <div class="file-icon">
            <i :class="getFileIcon(file.fileOriginalName)"></i>
          </div>
          <div class="file-info">
            <span class="file-name" :title="file.fileOriginalName">{{ file.fileOriginalName }}</span>
            <span class="file-size">{{ formatFileSize(file.fileSize || file.size) }}</span>
          </div>
          <button
            type="button"
            class="btn-close file-remove-btn"
            aria-label="Close"
            @click="removeFile(index)"
            :disabled="disabled"
          >
            <span class="btn-close-icon">×</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.file-upload-container {
  margin: 0.75rem 0;
}

.file-list-items {
  display: flex;
  gap: 8px;
  width: 100%;
  overflow-x: auto;
  white-space: nowrap;
}

.file-list-item {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  border-radius: 4px;
  background-color: #f8f9fa;
  border: 1px solid #e9ecef;
  box-sizing: border-box;
  min-width: 0;
  flex: 1;
  max-width: calc(100% - 16px);
}

/* 파일이 1개일 때 */
.file-list-items:has(.file-list-item:only-child) .file-list-item {
  max-width: 100%;
}

/* 파일이 2개일 때 */
.file-list-items:has(.file-list-item:nth-child(2)):not(:has(.file-list-item:nth-child(3))) .file-list-item {
  max-width: calc(50% - 4px);
}

/* 파일이 3개일 때 */
.file-list-items:has(.file-list-item:nth-child(3)) .file-list-item {
  max-width: calc(33.33% - 5.33px);
}

.file-icon {
  font-size: 18px;
  color: #6c757d;
  margin-right: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.file-info {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  min-width: 0;
  overflow: hidden;
}

.file-name {
  font-size: 14px;
  font-weight: 500;
  color: #212529;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 파일이 1개일 때는 파일명 전체 표시 */
.file-list-items:has(.file-list-item:only-child) .file-name {
  white-space: normal;
  word-break: break-word;
  cursor: default;
}

.file-size {
  font-size: 12px;
  color: #6c757d;
  margin-top: 2px;
}

.file-remove-btn {
  width: 24px;
  height: 24px;
  min-width: 24px;
  min-height: 24px;
  padding: 0;
  margin-left: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background-color: #e9ecef;
  border: none;
  cursor: pointer;
  transition: background-color 0.2s;
  flex-shrink: 0;
}

.file-remove-btn:hover {
  background-color: #dee2e6;
}

.file-remove-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-close-icon {
  font-size: 16px;
  font-weight: bold;
  color: #495057;
  line-height: 1;
}

.ml-2 {
  margin-left: 0.5rem;
}

.mt-3 {
  margin-top: 0.75rem;
}
</style>
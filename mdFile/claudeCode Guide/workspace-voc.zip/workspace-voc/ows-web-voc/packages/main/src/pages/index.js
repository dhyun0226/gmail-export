/**
 * 주의: 개발 환경에서는 단독으로 사용되기 때문에 vue-router의 path 충돌이 발생하지 않을 수 있습니다.
 *
 * 그러나 전용 패키지(deploy)에 통합되어 빌드, 배포 시에는 다른 패키지와의 path 충돌이 발생할 수 있습니다.
 *
 * 경로 충돌을 방지하기 위해 신중한 경로 정의가 필요합니다.
 */

/** @type { import('vue-router').RouterOptions['routes'] } */
export default [
  {
    // 전체
    path: '/UI-SAL-VOC-001',
    component: () => import('./whole/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },

  {
    // 접수
    path: '/UI-SAL-VOC-002',
    component: () => import('./received/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },

  {
    // 처리대상 > 전체
    path: '/UI-SAL-VOC-003',
    component: () => import('./processing/whole/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // 처리대상 > 진행현황
    path: '/UI-SAL-VOC-004',
    component: () => import('./processing/status/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // 처리실적 > VOC전체
    path: '/UI-SAL-VOC-0012',
    component: () => import('./performance/whole/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },

  {
    // 담당자배정기준
    path: '/UI-SAL-VOC-005',
    component: () => import('./allocationCriteria/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // VOC담당자배정기준
    path: '/UI-SAL-VOC-006',
    component: () => import('./vocAllocationCriteria/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // 공지사항
    path: '/UI-SAL-VOC-009',
    component: () => import('./notice/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },

  {
    // FAQ
    path: '/UI-SAL-VOC-010',
    component: () => import('./faq/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },

  {
    // 이벤트
    path: '/UI-SAL-VOC-011',
    component: () => import('./event/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // QNA
    path: '/UI-SAL-VOC-013',
    component: () => import('./qna/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // 1:1문의
    path: '/UI-SAL-VOC-014',
    component: () => import('./inquiry/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // AS
    path: '/UI-SAL-VOC-015',
    component: () => import('./event/page.vue'),
    meta: { layout: 'default', requiresAuth: true },
  },
  {
    // 임시
    path: '/UI-TSK-RRR-101',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-RRR-102',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-RRR-103',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-RQS-100',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-RQS-101',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-RCV-101',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-MET-401',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-TSK-SCH-401',
    component: () => import('./temp.vue'),
  },
  {
    // 임시
    path: '/UI-EAP-MBX-002',
    component: () => import('./temp.vue'),
  },
];

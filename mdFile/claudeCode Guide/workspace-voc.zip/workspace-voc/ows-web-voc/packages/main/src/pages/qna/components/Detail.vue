<script setup lang="ts">
import { computed, defineExpose, onMounted, ref, watch } from 'vue';
import { useApi } from '@ows/core';
import { useOwPopup } from '@ows/ui';
import DxListNGrid from '@/components/DxListNGrid.vue';
import dayjs from 'dayjs';
import QnaDetailPopup from '@/components/QnaDetailPopup.vue';
import QnaDetailCommentPopup from '@/components/QnaDetailCommentPopup.vue';

const props = defineProps({
  from: String,
  to: String,
  dateUnit: String,
  filterOptions: Object,
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  employeeGroupOptions: Array,
  searchType: String,
  keyword: String,
});

// const { owConfirm } = useOwAlert();

const {
  openPopup,
  closePopup: closeDetailPopup = () => {},
  isPopupOpen,
  getVh,
} = useOwPopup();

function openDetailPopup() {
  isPopupOpen.value = true;
  console.log('팝업 오픈 상태:', isPopupOpen.value);
}
const isCommentPopupOpen = ref(false);
const api = useApi();

const qnaNumber = ref(0);
const serviceCategoryCode = ref('');

const columns = ref([
  {
    caption: '채널',
    width: '100',
    dataField: 'channelCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    visible: true,
    cellType: 'customize2',
  },
  {
    caption: '상세구분',
    width: '100',
    dataField: 'serviceCategoryCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize5',
    visible: true,
  },
  {
    caption: '제목',
    width: '*',
    dataField: 'qnaTitle',
    allowMerge: false,
    alignment: 'left',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '공개',
    width: '80',
    dataField: 'openYn',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
  {
    caption: '처리상태',
    width: '100',
    dataField: 'processStatus',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize4',
    visible: true,
  },
  {
    caption: '조회건수',
    width: '70',
    dataField: 'inquiryCount',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '댓글수',
    width: '60',
    dataField: 'answerCount',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록자',
    width: '100',
    dataField: 'writerMemberId',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize6',
    visible: true,
  },
  {
    caption: '등록일자',
    width: '100',
    dataField: 'qnaRegistrationDatetime',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize',
    visible: true,
  },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

function getColumnsByDate() {
  const date = props.dateUnit;
  if (date === 'day') {
    columns.value.forEach((col) => {
      if (col.caption === '접수일자') {
        col.caption = '접수시간';
      }
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '접수시간') {
        col.caption = '접수일자';
      }
    });
  }
}

function getColumnsByChannel() {
  if (props.filterOptions.channelGroup.value === '') {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = true;
      }
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = false;
      }
    });
  }
}

// 카테고리 코드를 채널 이름으로 변환하는 함수 개선
function getChannelText(code) {
  const channel = props.channelGroupOptions.find(item =>
    code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 카테고리 코드를 카테고리 이름으로 변환하는 함수 개선
function getCategoryText(code) {
  const channel = props.categoryGroupOptions.find(item =>
    code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 등록자 사번을 이름으로 변환하는 함수 개선
function getEmployeeName(code) {
  const employee = props.employeeGroupOptions.find(item =>
    code === item.employeeNumber,
  );
  return employee ? employee.employeeName : code; // 매핑된 값이 없으면 원래 코드를 반환
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY-MM-DD');
}

function getTimeFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('HH:mm');
}

function onCellPrepared(e) {
  // if (e.rowType === 'data' && e.data?.header) {
  //   if (e.columnIndex === 1) {
  //     e.cellElement.classList.add('sal-custom');
  //     e.cellElement.colSpan = 4;
  //   }
  //   else if (e.columnIndex > 1) {
  //     e.cellElement.classList.add('sal-disable');
  //   }
  // }
}

function onCellClick(e) {
  qnaNumber.value = e.data.qnaNumber;
  serviceCategoryCode.value = e.data.serviceCategoryCode;
  if (e.column?.dataField === 'answerCount') {
    // 댓글수 컬럼 클릭 시 댓글 팝업 오픈
    openCommentPopup();
  }
  else {
    // 그 외는 기존 팝업 오픈
    openDetailPopup();
  }
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      fromDate: props.from,
      toDate: props.to,
      channelCode: props.filterOptions.channelGroup.value,
      serviceCategoryCode: props.filterOptions.categoryGroup.value,
      openYn: props.filterOptions.openYnGroup.value,
      processStatus: props.filterOptions.processStatusGroup.value,
      searchType: props.searchType,
      keyword: props.keyword,
    };

    // 문의 데이터를 가져옴
    const result = await api.get(`/voc/qnas`, { params });

    gridOption.value.datas = result.data.data;
    gridOption.value.paging.totalItemCount = result.data.totalCount;
  }
  catch (error) {
    gridOption.value.datas = [];
  }
}

function openCommentPopup() {
  isCommentPopupOpen.value = true;
}
function closeCommentPopup() {
  isCommentPopupOpen.value = false;
}
function editCommentPopup() {
  closeCommentPopup();
  load();
}

function handleSaveSuccess() {
  load();
}

async function deleteRow(qnaNumber) {
  alert('삭제하시겠습니까?');
  try {
    await api.delete(`/voc/events/${qnaNumber}`);
  }
  catch (error) {}
  load();
}


watch(
  [() => props.from, () => props.to],
  () => {
    getColumnsByDate();
    load();
  },
);

watch(
  () => props.filterOptions,
  () => {
    getColumnsByChannel();
    load();
  },
  { deep: true },
);

defineExpose({
  load,
});
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <template v-if="props.dateUnit === 'day'">
        {{ getTimeFormat(cell.data.qnaRegistrationDatetime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.qnaRegistrationDatetime) }}
        </div>
      </template>
    </template>

    <template #customize2="{ data: cell }">
      <div>{{ getChannelText(cell.data.serviceCategoryCode) }}</div>
    </template>

    <template #customize3="{ data: cell }">
      <div>{{ cell.data.openYn === "Y" ? "공개" : "비공개" }}</div>
    </template>

    <template #customize4="{ data: cell }">
      <div>
        {{ cell.data.processStatus ? "답변완료" : "문의접수" }}
      </div>
    </template>
    <template #customize5="{ data: cell }">
      <div>{{ getCategoryText(cell.data.serviceCategoryCode) }}</div>
    </template>
    <template #customize6="{ data: cell }">
      <div>{{ getEmployeeName(cell.data.writerMemberId) }}</div>
    </template>
  </DxListNGrid>
  <QnaDetailPopup
    v-if="isPopupOpen"
    :is-popup-open="isPopupOpen"
    :channel-group-options="props.channelGroupOptions"
    :category-group-options="props.categoryGroupOptions"
    :qna-number="qnaNumber"
    :service-category-code="serviceCategoryCode"
    height="auto"
    title="문의 접수처리"
    :width="1700"
    :on-close="
      () => {
        closeDetailPopup();
      }
    "
    @save-success="handleSaveSuccess"
  />
  <QnaDetailCommentPopup
    v-if="isCommentPopupOpen"
    :is-popup-open="isCommentPopupOpen"
    :channel-group-options="props.channelGroupOptions"
    :category-group-options="props.categoryGroupOptions"
    :qna-number="qnaNumber"
    :width="1200"
    :on-close="() => { closeCommentPopup(); }"
    @edit-event="editCommentPopup"
  />
</template>

<style></style>

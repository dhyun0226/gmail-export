import dayjs from 'dayjs';
import weekOfYear from 'dayjs/plugin/weekOfYear';
import isoWeek from 'dayjs/plugin/isoWeek';

dayjs.extend(weekOfYear);
dayjs.extend(isoWeek);

export const dateUtils = {
  // Format a date in a custom or default format
  formatDate: (date, format = 'YYYY-MM-DD') => {
    return dayjs(date).format(format);
  },

  // Get today's date in a custom or default format
  getToday: (format = 'YYYY-MM-DD') => {
    return dayjs().format(format);
  },

  // Add days to a given date
  addDays: (date, days) => {
    return dayjs(date).add(days, 'day').format('YYYY-MM-DD');
  },

  // Subtract days from a given date
  subtractDays: (date, days) => {
    return dayjs(date).subtract(days, 'day').format('YYYY-MM-DD');
  },

  // Convert a date to local date-time format (start of the day)
  toLocalDateTime: (date) => {
    return dayjs(date).startOf('day').format('YYYY-MM-DDTHH:mm:ss');
  },

  // Convert a date to local date-time format (end of the day)
  toLocalDateTimeEnd: (date) => {
    return dayjs(date).endOf('day').format('YYYY-MM-DDTHH:mm:ss');
  },

  /**
   * Calculate start and end date-time range based on unit
   * @param {string|Date|Array} date - input date or Java LocalDateTime array
   * @param {'year'|'month'|'week'|'date'} unit - range unit
   * @returns {{from: string, to: string}} - formatted range in 'YYYY-MM-DDTHH:mm:ss'
   */
  getRangeByUnit: (date, unit) => {
    let d;
    if (Array.isArray(date)) {
      // Java LocalDateTime 배열 처리
      const iso = dateUtils.formatJavaLocalDateTime(date, '-', true).replace(' ', 'T');
      d = dayjs(iso);
    } else if (unit === 'week' && typeof date === 'string' && date.includes('-W')) {
      // "YYYY-WWW" 포맷 파싱
      const [yearStr, weekStr] = date.split('-W');
      d = dayjs()               // 기준은 현재 날짜지만
          .year(parseInt(yearStr)) // 연도 설정
          .isoWeek(parseInt(weekStr)); // ISO 주차 설정
    } else {
      d = dayjs(date);
    }

    let start, end;
    switch (unit) {
      case 'year':
        start = d.startOf('year');
        end   = d.endOf('year');
        break;

      case 'month':
        start = d.startOf('month');
        end   = d.endOf('month');
        break;

      case 'week':
        // ISO Week의 월요일 00:00:00 ~ 일요일 23:59:59
        start = d.startOf('isoWeek');
        end   = d.endOf('isoWeek');
        break;

      default:  // 'date'
        start = d.startOf('day');
        end   = d.endOf('day');
    }

    return {
      from: start.format('YYYY-MM-DDTHH:mm:ss'),
      to:   end.format('YYYY-MM-DDTHH:mm:ss'),
    };
  },

  /**
   * Java LocalDateTime 배열을 원하는 형식의 문자열로 변환
   * @param dateArray Java에서 넘어온 [year, month, day, hour, minute, second] 배열
   * @param format 날짜 구분자 ('.' 또는 '-' 등)
   * @param includeTime 시간 포함 여부
   * @returns 포맷팅된 날짜 문자열
   */
  formatJavaLocalDateTime: (
      dateArray,
      format,
      includeTime,
  ) => {
    if (!dateArray || !Array.isArray(dateArray) || dateArray.length < 3) {
      return '';
    }

    const year = dateArray[0];
    const month = String(dateArray[1]).padStart(2, '0');
    const day = String(dateArray[2]).padStart(2, '0');

    const dateStr = `${year}${format}${month}${format}${day}`;

    if (includeTime && dateArray.length >= 5) {
      const hour = String(dateArray[3] || 0).padStart(2, '0');
      const minute = String(dateArray[4] || 0).padStart(2, '0');
      const second = String(dateArray[5] || 0).padStart(2, '0');

      return `${dateStr} ${hour}:${minute}:${second}`;
    }

    return dateStr;
  },

  /**
   * 날짜 형식을 변환 (다양한 입력 형식 지원)
   * @param date 날짜 (문자열, Date, LocalDateTime 배열)
   * @param separator 구분자 ('.' 또는 '-' 등)
   * @param includeTime 시간 포함 여부
   * @returns 포맷팅된 날짜 문자열
   */
  formatDateWithSeparator: (
      date,
      separator,
      includeTime,
  ) => {
    if (!date) {
      return '';
    }

    if (Array.isArray(date)) {
      return dateUtils.formatJavaLocalDateTime(date, separator, includeTime);
    }

    const dateObj = date instanceof Date ? date : new Date(date);
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0');

    const dateStr = `${year}${separator}${month}${separator}${day}`;

    if (includeTime) {
      const hours = String(dateObj.getHours()).padStart(2, '0');
      const minutes = String(dateObj.getMinutes()).padStart(2, '0');
      const seconds = String(dateObj.getSeconds()).padStart(2, '0');
      return `${dateStr} ${hours}:${minutes}:${seconds}`;
    }

    return dateStr;
  },
};

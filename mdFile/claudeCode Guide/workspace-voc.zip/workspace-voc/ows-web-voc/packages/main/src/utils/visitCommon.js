// 방문계획 "이동 (1h)" 제외하기
export const getCustNameTakeOutMove = (str) => {
  if (!str) return '';

  let name = customerNameFormat(str);
  if (!'이동 (1h)'.includes(name) && name) return name;
  else return '';
};

// 치과명 포맷 : '치과'.'치과병원','의원' 등은 붙이지 않도록 함.
export const customerNameFormat = (val = '', type = '') => {
  // 치과명
  let name = val.replace(/(치과|병원|의원|주식회사|\(주\)|기공소|보건치소|보건소|의료|법인|재단)/gi, '');

  // 비거래처
  name = nonCustomerNameFormat(name, type);

  return name.trim();
};

// 비거래처 포맷 : 치과명에 * 붙임
export const nonCustomerNameFormat = (val = '', type = '') => {
  if (type === 'CUST_02') {
    val += ' *';
  }
  return val;
};

//전화번호, 휴대번호, 안심번호 하이픈 처리
// export const telPhoneHyphen = (val) => {
//   if (val === undefined || val === null) {
//     return '';
//   } else {
//     return val.replace(/(^050.{1}|^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, '$1-$2-$3');
//   }
// };

//특정 글자수 이상일 때 줄임말(...) 표시 * 기본 8자
// export const textEllipsis = (val, length = 8) => {
//   if (val === null || val === '' || val === undefined) {
//     return '';
//   }
//   let result = val;
//   if ((val.length || 0) > length) {
//     result = val.substr(0, length) + '...';
//   }
//   return result;
// };

export const timeList = [
  '09:00',
  '09:30',
  '10:00',
  '10:30',
  '11:00',
  '11:30',
  '12:00',
  '12:30',
  '13:00',
  '13:30',
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
];

export const timeList2 = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
export const timeList3 = ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
export const timeList4 = [
  ['09 : 00', '09 : 30'],
  ['10 : 00', '10 : 30'],
  ['11 : 00', '11 : 30'],
  ['12 : 00', '12 : 30'],
  ['13 : 00', '13 : 30'],
  ['14 : 00', '14 : 30'],
  ['15 : 00', '15 : 30'],
  ['16 : 00', '16 : 30'],
  ['17 : 00', '17 : 30'],
];
export const timeList5 = ['09시', '10시', '11시', '12시', '13시', '14시', '15시', '16시', '17시'];
export const timeList6 = ['09시', '10시', '11시', '14시', '15시', '16시', '17시'];

export const organizationNameFormat = (val) => {
  if (val == '국내영업총괄본부') return  '국내영업총괄본부'; //'한국';
  else return val.replace(/(영업본부|지점)/gi, '');
};

export const setGrouping = (list, group, keyword) => {
  let temp = {};
  for (let item of group) {
    if (keyword) temp[item[keyword]] = list.filter((e) => e[keyword] == item[keyword]);
    else temp[item] = list.filter((e) => e == item);
  }
  return temp;
};

<script setup>
import { computed, onMounted } from 'vue';
import { useOwPagination } from '@ows/ui';

const props = defineProps({
  data: { type: Array, default: () => [] },
  totalCount: { type: Number, default: 0 },
  count: { type: Number, default: 1 },
  fields: { type: Array, default: () => [] },
  options: { type: Object, default: () => ({}) },
  pageNo: { type: Number, default: 1 },
  pageSize: { type: Number, default: 15 },
  hiddenPageSizes: { type: Boolean, default: false },
  allowedPageSizes: { type: Array, default: () => [15, 20, 50, 100] },
});

const emit = defineEmits(['paging', 'update:pageNo', 'update:pageSize']);

const { pageNo, pageSize, pageChange } = useOwPagination();

const perPage = computed(() => pageSize.value * props.count);

const getSliceData = (index) => {
  const size = pageSize.value;

  const start = (index - 1) * size;
  const end = start + size;

  return computed(() => props.data.slice(start, end));
};

function pagingChange(no, size) {
  pageChange(no, size)
  emit('paging', { pageNo: no, pageSize: size });
}

function init() {
  pageNo.value = props.pageNo;
  pageSize.value = props.pageSize;
}

onMounted(() => init());
</script>

<template>
  <div class="grid-container d-flex flex-column flex-grow-1 overflow-hidden">
    <BRow 
      class="flex-grow-1 overflow-hidden m-0" 
      align-v="stretch"
    >
      <BCol 
        v-for="index in count" 
        :key="index" 
        align-self="stretch" 
        class="h-100 p-0"
      >
        <div class="h-100 overflow-auto">
          <template v-if="$slots.default">
            <slot :items="getSliceData(index)?.value" />
          </template>
          <template v-else>
            <BTable 
              v-bind="options" 
              :items="getSliceData(index)?.value" 
              :fields="fields" 
              responsive 
              sticky-header
              class="m-0 h-100"
            >
            </BTable>
          </template>
        </div>
      </BCol>
    </BRow>

    <OwPagination 
      :page-no="pageNo" 
      :page-size="pageSize" 
      :ngrid-count="2" 
      :total-count="totalCount" 
      :pageSizeOptions="allowedPageSizes"
      :visible-page-options="true" 
      :visible-total-count="true" 
      :on-change="pagingChange"
      class="mt-2"
    >
    </OwPagination>
  </div>
</template>

<style lang="scss" scoped>
.grid-container {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
}

// 추가적인 스타일이 필요한 경우 여기에 작성할 수 있습니다.
</style>
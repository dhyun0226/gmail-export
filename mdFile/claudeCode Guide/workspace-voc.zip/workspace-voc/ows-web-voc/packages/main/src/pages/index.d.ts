import type { RouterOptions } from 'vue-router';

declare const pages: RouterOptions['routes'];

export default pages;

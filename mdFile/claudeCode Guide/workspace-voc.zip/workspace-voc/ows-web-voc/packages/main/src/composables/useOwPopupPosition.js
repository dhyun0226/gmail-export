import { readonly } from 'vue';
import { useOwPopup } from '@ows/ui';

export function useOwPopupPosition() {
  const {
    getVw,
    getVh,
  } = useOwPopup();

  const defaultPosition = readonly({ of: 'main', my: 'center', at: 'center', offset: '0 0' });

  function getPosition(id, popupWidth, popupHeight) {
    const target = document.querySelector(`#${id}`);
    if (!target) {
      return defaultPosition;
    }
    const vw = getVw(id);
    const vh = getVh(id);
    const rects = target.getBoundingClientRect();
    const at = { width: 'center', height: 'top' };
    const my = { width: 'center', height: 'top' };
    const offset = { x: 0, y: 0 };

    // width
    if (vw < 50) {
      at.width = 'right';
      my.width = 'left';
      offset.x = 5;
    }
    if (vw === 50) {
      at.width = 'left';
      my.width = 'left';
      offset.x = -5;
    }
    else {
      if (rects.left > popupWidth) {
        at.width = 'left';
        my.width = 'right';
        offset.x = -5;
      }
    }

    // height
    const popupVh = (popupHeight / window.innerHeight) * 100; // to vh %
    const diffVh = 100 - popupVh;
    if (vh > diffVh) {
      offset.y = (vh - diffVh) * window.innerHeight / 100 * -1; // to px
    }
    if (-offset.y > rects.top) {
      offset.y = 0;
    }

    const values = {
      of: `#${id}`,
      my: `${my.width} ${my.height}`,
      at: `${at.width} ${at.height}`,
      offset: `${offset.x} ${offset.y}`,
    };

    return values;
  }

  return {
    getPosition,
  };
}

export default useOwPopupPosition;

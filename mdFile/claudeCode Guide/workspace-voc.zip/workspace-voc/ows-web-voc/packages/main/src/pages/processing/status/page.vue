<script setup>
import { ref } from 'vue';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';

import Detail from './components/Detail.vue';
import TotalSummary from './components/TotalSummary.vue';

import OwFilterProduct from '@/components/OwFilterProduct.vue';
import OwFilterCountry from '@/components/OwFilterCountry.vue';
import OwFilterOrg from '@/components/OwFilterOrg.vue';
import ColumnPopup from '@/components/ColumnPopup.vue';

const {
  openPopup: openColumnPopup,
  closePopup: closeColumnPopup,
  isPopupOpen: isColumnPopupOpen,
  getVh,
} = useOwPopup();

const popupHeight = 150;
const popupPosition = ref({ my: 'center', at: 'center', of: 'body' });
function openPopupPosition(id) {
  const vh = getVh(id);
  const popupVh = (popupHeight / window.innerHeight) * 100; // to vh %
  const diffVh = 100 - popupVh;

  let offsetY = 0;
  if (vh > diffVh) {
    offsetY = (((vh - diffVh) * window.innerHeight) / 100) * -1; // to px
  }
  popupPosition.value = {
    my: 'left top',
    at: 'right top',
    of: `#${id}`,
    offset: `5 ${offsetY}`,
  };

  openColumnPopup();
}

const dateOptions = ref({
  from: dayjs().format('YYYY-MM-DD'),
  to: dayjs().format('YYYY-MM-DD'),
  doubleFlag: false,
  today: false,
  twice: false,
  disabledTwice: false,
  disabledDouble: false,
  disabledPicker: false,
  rangeUnit: 'day',
});

const term = ref('productTerm');
const termOptions = [
  { text: '품목기간', value: 'productTerm' },
  { text: '지역기간', value: 'countryTerm' },
  { text: '인원기간', value: 'personalTerm' },
];

const listGroup = ref('');
const listGroupOptions = [
  { text: '품목', value: 'product' },
  { text: '지역', value: 'country' },
  { text: '인원', value: 'personal' },
];

const filterOptions = ref({
  product: '',
  country: '',
  org: '',
});

function handleItemFilterChange() {
  // load();
}

function handleDateChange(date, newVal) {
  console.log('Date unit changed:', date);
  console.log('Date unit changed:', newVal);
  dateOptions.value.from = date;
  dateOptions.value.to = newVal;
}

function handleUnitChange(unit) {
  console.log('Date unit changed:', unit);
  dateOptions.value.rangeUnit = unit;
}

function handleTwiceChange(twice) {
  console.log('Twice changed:', twice);
}

function handlePrevNextChange(unit) {
  console.log('Date unit changed:', unit);
}
</script>

<template>
  <div
    class="input-group gap-1 mb-2"
    role="group"
  >
    <OwBizDatePickerRangeExcluedPickVer2
      v-model:from="dateOptions.from"
      v-model:to="dateOptions.to"
      v-model:is-double-selected="dateOptions.doubleFlag"
      :unit="dateOptions.rangeUnit"
      :disabled-twice="dateOptions.disabledTwice"
      :default-twice="false"
      :disabled-double="dateOptions.disabledDouble"
      :years="15"
      :today="dateOptions.today"
      :hidden-units="['6months']"
      :disabled-picker="disabledPicker"
      @change="handleDateChange"
      @unit-change="handleUnitChange"
      @prev-next-change="handlePrevNextChange"
      @twice-change="handleTwiceChange"
    />

    <BButton
      v-if="dateOptions.doubleFlag"
      class="ow-bi ow-w24"
      variant="light"
      :style="today ? 'border: 2px solid #176de2;' : ''"
      @click="today = !today"
    >
      <i class="bi bi-box-arrow-left" />
      <span class="visually-hidden">기간/오늘 선택</span>
    </BButton>

    <OwFormRadio
      v-if="dateOptions.doubleFlag"
      v-model="term"
      :options="termOptions"
      shape="round"
      @change="handleItemFilterChange"
    />
    <OwFormRadio
      v-if="!dateOptions.doubleFlag"
      v-model="listGroup"
      type="all"
      :options="listGroupOptions"
      shape="round"
      @change="handleItemFilterChange"
    />
    <OwFilterCountry />
    <OwFilterProduct />
    <OwFilterOrg />

    <!--    <BButton :id="`btn-${num}`" variant="state" @click="openPopupPosition(`btn-${num}`)"> -->
    <!--      컬럼추가 -->
    <!--    </BButton> -->
    <div
      class="d-flex mt-10 mr-5 ml-5"
      style="align-items: center; right: 0px"
    >
      <!-- <CrmOwFormOrg3 :propsSelectItem="propsSelectItem3" class="mr-10" @selectItem="changePropsListItem" /> -->
      <div
        class="ml-4"
        style="width: 10px; height: 10px; background-color: #f3f3f3"
      />
      <div class="ml-4">
        시작전
      </div>
      <div
        class="ml-4"
        style="width: 10px; height: 10px; background-color: #dcebff"
      />
      <div class="ml-4">
        진행중
      </div>
      <div
        class="ml-4"
        style="width: 10px; height: 10px; background-color: #4977e4"
      />
      <div class="ml-4">
        완료
      </div>
      <div
        class="ml-4"
        style="width: 10px; height: 10px; background-color: #ffcdcd"
      />
      <div class="ml-4">
        지연
      </div>
      <!--        <CrmOwFormCountry3 class="mr-10" :propsSelectItem="propsSelectItem" @selectItem="changePropsListItem" /> -->
    </div>
  </div>
  <Detail
    v-if="!dateOptions.doubleFlag"
    :date-options="dateOptions"
    :filter-options="filterOptions"
  />
  <TotalSummary v-if="dateOptions.doubleFlag" />
  <Teleport to="body">
    <ColumnPopup
      v-if="isColumnPopupOpen"
      :is-popup-open="isColumnPopupOpen"
      :popup-position="popupPosition"
      :height="popupHeight"
      :size="xs"
      :on-close="() => {
        closeColumnPopup();
      }
      "
    />
  </Teleport>
</template>

<style scoped></style>

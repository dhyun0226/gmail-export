import { defineStore } from 'pinia';
import { reactive, ref } from 'vue';
export const useFilter = defineStore('filter', () => {
  const filter = reactive({
    empNo: '', // 사번 Number
    role: '', // 역할자 Code
    fromDate: '', // 시작일 Filter
    toDate: '', // 종료일 Filter
    id: '', // Controller ID
    searchType: '', // 검색 타입
    searchKeyWord: '', // 검색 키워드
  });
  return { filter };
});

export const useFilterGroupToggleComp = defineStore('filterGroupToggleComp', () => {
  const title = ref('');
  const stateType = ref([]);
  const searchCodeList = ref([]);
  const selectedAll = ref(true);

  return { title, stateType, searchCodeList, selectedAll };
});

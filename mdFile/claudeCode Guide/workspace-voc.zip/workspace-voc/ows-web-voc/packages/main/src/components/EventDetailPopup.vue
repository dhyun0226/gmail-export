<script setup lang="ts">
import { BButton } from 'bootstrap-vue-next';
import { computed, onMounted, ref, watch } from 'vue';
import {
  useApi,
  useFileDownload,
  useUserProfile,
} from '@ows/core';
import { useOwAlert, useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import OrgPopup from '@/components/OrgPopup.vue';
import type { VocFile } from '@/types/voc';
import type { EventResponse, PaginatedResponse } from '@/types';
import FilePopupInput from '@/components/FilePopupInput.vue';
import { dateUtils } from '@/utils';
import useServiceCategoryCode from '@/composables/useServiceCategoryCode';
import EventDetailCommentPopup from '@/components/EventDetailCommentPopup.vue';
import BasicEditor from '@/components/BasicEditor.vue';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: '이벤트 상세' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: [Number, String], default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  eventNumber: { type: Number },
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  serviceCategoryCode: { type: String },
  disabledSelect: { type: Boolean, default: false },
  isPopupOpen: { type: Boolean, default: false },
  eventDivisionCode: { type: String, default: '' },
});

const emit = defineEmits(['save-event', 'edit-event']);

const { owAlert, owConfirm, openName } = useOwAlert();

const { currentUser } = useUserProfile();
const api = useApi();
const { image } = useFileDownload();
const user = ref('');
const editable = ref(true);
const content = ref('');
const saving = ref(false);
const useSettingGroup = ref('Y');
const useSettingGroupOptions = [
  { text: '사용', value: 'Y' },
  { text: '미사용', value: 'N' },
];

const topFixedSettingGroup = ref('N');
const topFixedSettingGroupOptions = [
  { text: '고정', value: 'Y' },
  { text: '해제', value: 'N' },
];

const useDeleteGroupOptions = [
  { text: '삭제', value: 'Y' },
  { text: '미삭제', value: 'N' },
];

const dateFormRangeFrom = ref(dayjs().format('YYYY-MM-DD'));
const dateFormRangeTo = ref(dayjs().add(1, 'month').format('YYYY-MM-DD'));

function changeDateRangeForm(from, to, newValue) {}

function handleChange(value) {}

function change(value) {}

function formatDate(dateString: string): string {
  return dateUtils.formatDateWithSeparator(dateString, '.', false);
}

// 카테고리 코드 관련 로직
const listServiceGroup = ref('');
const detailedDivisionCode = ref('');

// ✅ 전체 카테고리 옵션 저장
const allCategoryGroupOptions = ref(props.categoryGroupOptions ?? []);

// ✅ 채널 코드 기준 필터링된 카테고리 옵션
const filteredDetailDivisionOptions = computed(() => {
  const prefix = listServiceGroup.value;
  if (!prefix) return allCategoryGroupOptions.value;
  return allCategoryGroupOptions.value.filter(opt =>
      opt.value.startsWith(`${prefix}_EVT`)
  );
});

const listCategoryGroup = ref('01');
const listCategoryGroupOptions = [
  { text: '댓글참여', value: '01' },
  { text: '인증참여', value: '02' },
];

const eventTitle = ref('');
const eventContent = ref('');
const fileList = ref<VocFile[]>([]);
const files = ref([]);
const thumbnailFile = ref<VocFile[]>([]);

const responseData = ref<Partial<EventResponse>>({});

// 이벤트 데이터 불러오기
async function fetchEventData() {
  try {
    const { data } = await api.get<PaginatedResponse>(
      `/voc/events/${props.eventNumber}`,
      {
        params: {
          serviceCategoryCode: props.serviceCategoryCode,
        },
      },
    );

    responseData.value = data;
    eventTitle.value = data.eventTitle || '';
    eventContent.value = data.eventContent || '';
    fileList.value = data.fileList || [];
    
    // ✅ 채널코드 추출 (앞 4자리)
    listServiceGroup.value = data.serviceCategoryCode?.substring(0, 4) || '';
    detailedDivisionCode.value = data.serviceCategoryCode || '';

    gridOption.value.datas = data.eventAnswers || [];
    dateFormRangeFrom.value = data.eventStartDatetime || '';
    dateFormRangeTo.value = data.eventEndDatetime || '';
    files.value = data.fileList || [];
    thumbnailFile.value = data.thumbnailFile || [];
    gridOption.value.paging.totalItemCount = data.eventAnswerTotalCount || 0;
    useSettingGroup.value = data.useYesOrNo || 'Y';
    topFixedSettingGroup.value = data.topFixedYesOrNo || 'N';
    listCategoryGroup.value = data.eventParticipationDivisionCode || '01';
  }
  catch (error) {
    responseData.value = {};
    detailedDivisionCode.value = '';
  }
}

// 조직 팝업 관련
const {
  openPopup: openOrgPopup,
  closePopup: closeOrgPopup,
  isPopupOpen: isOrgPopupOpen,
} = useOwPopup();

function handleUpdateOrganization(item) {
  user.value = item;
  closeOrgPopup();
}
const isCommentPopupOpen = ref(false);
function onClickComment() {
  isCommentPopupOpen.value = true;
}
function closeCommentPopup() {
  isCommentPopupOpen.value = false;
}

function editDetailPopup() {

}

// 이벤트 삭제 처리
async function deleteEvent() {
  if (await owConfirm({ title: '삭제', message: '이벤트를 삭제하시겠습니까?', target: '#frm' })) {
    try {
      await api.delete(`/voc/events/${props.eventNumber}`);
      if (props.onClose) {
        props.onClose();
      }
      emit('edit-event');
    }
    catch (error) {
      if (error.response) {
        console.error(
          `이벤트 삭제 실패: ${error.response.status} - ${error.response.data}`,
        );
      }
      else {
        console.error(`이벤트 삭제 실패:`, error.message || error);
      }
    }
  }
}
// 저장 처리
async function clickSave() {
  if (saving.value) return;
  saving.value = true;
  if (!eventTitle.value?.trim()) {
    owAlert({ title: '제목 필수입력 확인', message: '이벤트 제목을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!eventContent.value?.trim()) {
    owAlert({ title: '내용 필수입력 확인', message: '이벤트 내용을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!detailedDivisionCode.value) {
    owAlert({ title: '상세구분 필수입력 확인', message: '상세구분을 선택해주세요.' });
    saving.value = false;
    return;
  }

  const eventStartDatetime = dayjs(dateFormRangeFrom.value).format('YYYY-MM-DD[T]HH:mm:ss');
  const eventEndDatetime = dayjs(dateFormRangeTo.value).hour(23).minute(59).second(59).format('YYYY-MM-DD[T]HH:mm:ss');
  const params = {
    serviceCategoryCode: detailedDivisionCode.value,
    eventTitle: eventTitle.value,
    eventContent: eventContent.value,
    eventStartDatetime,
    eventEndDatetime,
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    useYesOrNo: useSettingGroup.value,
    topFixedYesOrNo: topFixedSettingGroup.value,
    eventParticipationDivisionCode: listCategoryGroup.value,
    fileList: files.value?.length > 0 ? files.value : null,
    thumbnailFile: thumbnailFile.value?.length > 0 ? thumbnailFile.value : null,
  };
  try {
    if (await owConfirm({ title: '등록', message: '이벤트를 등록하시겠습니까?', target: '#frm' })) {
      const { data } = await api.post('/voc/events', params);
      emit('save-event', data);
      if (props.onClose) props.onClose();
    }
  } catch (error) {
    console.error('event 저장 오류:', error);
    owAlert({ title: '내용 필수입력 확인', message: '이벤트 내용을 입력해주세요.' });
  } finally {
    saving.value = false;
  }
}

// 수정 처리
async function clickEdit() {
  if (!eventTitle.value?.trim()) {
    owAlert({ title: '제목 필수입력 확인', message: '이벤트 제목을 입력해주세요.' });
    return;
  }
  if (!eventContent.value?.trim()) {
    owAlert({ title: '내용 필수입력 확인', message: '이벤트 내용을 입력해주세요.' });
    return;
  }
  if (!detailedDivisionCode.value) {
    owAlert({ title: '상세구분 필수입력 확인', message: '상세구분을 선택해주세요.' });
    return;
  }

  const params = {
    serviceCategoryCode: detailedDivisionCode.value,
    eventRegistrationDatetime: responseData.value.eventRegistrationDatetime,
    eventTitle: eventTitle.value,
    eventContent: eventContent.value,
    eventStartDatetime: dateUtils.toLocalDateTime(dateFormRangeFrom.value),
    eventEndDatetime: dateUtils.toLocalDateTime(
      dayjs(dateFormRangeTo.value).hour(23).minute(59).second(59),
    ),
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    useYesOrNo: useSettingGroup.value,
    topFixedYesOrNo: topFixedSettingGroup.value,
    eventParticipationDivisionCode: listCategoryGroup.value,
    inquiryCount: responseData.value.inquiryCount,
    fileList: files.value?.length > 0 ? files.value : null,
    thumbnailFile: thumbnailFile.value ? thumbnailFile.value : null,
  };

  try {
    if (await owConfirm({ title: '수정', message: '이벤트를 수정하시겠습니까?', target: '#frm' })) {
      const { data } = await api.put(`/voc/events/${props.eventNumber}`, params);
      emit('edit-event', data);

      if (props.onClose) {
        props.onClose();
      }
    }
  }
  catch (error) {
    console.error('event 저장 오류:', error);
  }
}

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 1,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const columns = ref([
  {
    caption: '댓글 내용',
    width: '*',
    dataField: 'eventParticipationContent',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '작성자',
    width: '100',
    dataField: 'participantMemberId',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록일시',
    width: '100',
    dataField: 'eventParticipationDatetime',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '삭제',
    width: '130',
    dataField: '',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
]);

async function deleteAnswer(eventAnswer) {
  const params = {
    eventNumber: responseData.value.eventNumber,
    eventParticipationDatetime: eventAnswer.eventParticipationDatetime,
    deleteYesOrNo: eventAnswer.deleteYesOrNo,
  };
  try {
    await api.delete('/voc/event-answers', { data: params });
  }
  catch (error) {}
}

// ✅ 채널 바뀔 때 상세구분 첫 번째 값 자동 설정
watch(() => listServiceGroup.value, () => {
  const firstMatch = filteredDetailDivisionOptions.value[0];
  if (firstMatch) {
    detailedDivisionCode.value = firstMatch.value;
  } else {
    detailedDivisionCode.value = '';
  }
});

onMounted(async () => {
  try {
    listServiceGroup.value = props.channelGroupOptions?.[0]?.value || '';
    detailedDivisionCode.value = '';
    
    // 수정 모드라면 데이터 로드
    if (props.disabledSelect && props.eventNumber) {
      await fetchEventData();
    }
  } catch (error) {
    console.error('카테고리 초기화 실패:', error);
  }
});
</script>

<template>
  <OwPopup v-bind="props">
    <div class="d-flex">
      <div
        class="voc-detail-container"
        style="flex: 3"
      >
        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            event 상세 정보
          </caption>
          <colgroup>
            <col width="130px">
            <col>
          </colgroup>
          <BTbody>
            <BTr>
              <BTd colspan="2">
                <div class="settings-row">
                  <div class="setting-group">
                    <span class="setting-label compact-label">채널</span>
                    <BFormSelect
                      v-model="listServiceGroup"
                      :options="props.channelGroupOptions"
                      class="ow-select"
                      style="width: 85px"
                      @change="handleChange"
                    />
                  </div>

                  <div class="setting-group">
                    <span class="setting-label compact-label">상세구분</span>
                    <BFormSelect
                      v-model="detailedDivisionCode"
                      :options="filteredDetailDivisionOptions"
                      class="ow-select detail-select"
                      style="width: 85px"
                      placeholder="채널 선택 후 선택 가능"
                      @change="handleChange"
                    />
                  </div>

                  <div class="setting-group">
                    <span class="setting-label compact-label">참여구분</span>
                    <BFormSelect
                      v-model="listCategoryGroup"
                      :options="listCategoryGroupOptions"
                      shape="text"
                      style="width: 80px"
                      @change="handleChange"
                    />
                  </div>

                  <div class="setting-group">
                    <span class="setting-label compact-label">사용</span>
                    <OwFormRadio
                      id="rdo02"
                      v-model="useSettingGroup"
                      :options="useSettingGroupOptions"
                      class="compact-radio"
                      @change="change"
                    />
                  </div>

                  <div class="setting-group">
                    <span class="setting-label compact-label">상단고정</span>
                    <OwFormRadio
                      id="rdo03"
                      v-model="topFixedSettingGroup"
                      :options="topFixedSettingGroupOptions"
                      class="compact-radio"
                      @change="change"
                    />
                  </div>

                  <div class="setting-group">
                    <span class="setting-label compact-label">이벤트기간</span>
                    <OwFormDateRange
                      v-model:from="dateFormRangeFrom"
                      v-model:to="dateFormRangeTo"
                      position="center"
                      :visible-week="false"
                      class="date-picker-compact"
                      @change="changeDateRangeForm"
                    />
                  </div>
                  <div
                    v-if="props.disabledSelect"
                    class="setting-group"
                  >
                    <span class="setting-label compact-label">삭제</span>
                    <BButton
                      style="margin-left: 5px"
                      variant="box-delete"
                      size="sm"
                      @click.stop="deleteEvent"
                    />
                    <BButton
                      variant="state"
                      @click="onClickComment"
                    >
                      댓글보기
                    </BButton>
                  </div>
                </div>
              </BTd>
            </BTr>

            <BTr v-if="listServiceGroup && listServiceGroup.startsWith('D001')">
              <BTh class="required">
                썸네일 첨부
              </BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <FilePopupInput
                    v-model="thumbnailFile"
                    :max-files="1"
                    :max-file-size="5"
                    help-text="썸네일"
                  />
                </div>
              </BTd>
            </BTr>

            <BTr>
              <BTh class="required">
                이벤트 제목
              </BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <input
                    id="form02"
                    v-model="eventTitle"
                    class="form-control ow-form-control noline"
                    type="text"
                    placeholder="제목을 입력해주세요."
                  >
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div style="height: 40vh">
          <BasicEditor
            v-model="eventContent"
          />
        </div>

        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            이벤트 상세 정보
          </caption>
          <colgroup>
            <col width="130px">
            <col>
          </colgroup>
          <BTbody>
            <BTr>
              <BTh>파일 첨부</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <FilePopupInput
                    v-model="files"
                    :max-files="3"
                    :max-file-size="5"
                    help-text="파일"
                  />
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div class="ow-popup-bottom">
          <BButton
            size="md"
            variant="base base-gray"
            @click="props.onClose"
          >
            취소
          </BButton>
          <BButton
            v-if="!props.disabledSelect"
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickSave"
          >
            확인
          </BButton>
          <BButton
            v-if="props.disabledSelect"
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickEdit"
          >
            수정
          </BButton>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <OrgPopup
        v-if="isOrgPopupOpen"
        :is-popup-open="isOrgPopupOpen"
        :on-close="closeOrgPopup"
        :height="700"
        @update-organization="handleUpdateOrganization"
      />
    </Teleport>
  </OwPopup>
  <EventDetailCommentPopup
    v-if="isCommentPopupOpen"
    :is-popup-open="isCommentPopupOpen"
    height="auto"
    title="이벤트 수정"
    :event-number="props.eventNumber"
    :service-category-code="props.serviceCategoryCode"
    :disabled-select="true"
    :width="1700"
    :on-close="closeCommentPopup"
    @edit-event="editDetailPopup"
  />
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  vertical-align: middle;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

.ow-popup-bottom {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}

.detail-select {
  min-width: 85px;
}

.settings-row {
  display: flex;
  flex-wrap: nowrap;
  gap: 12px;
  align-items: center;
  width: 100%;
  padding: 2px 0;
}

.setting-group {
  display: flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
}

.setting-label {
  font-weight: 500;
  min-width: auto;
}

.compact-label {
  font-size: 0.8rem;
}

.compact-radio :deep(.ow-radio) {
  margin-right: 6px;
}

.compact-radio :deep(.ow-radio input + label span) {
  padding: 0 6px;
}

.date-range-group {
  margin-left: auto;
}

.date-picker-compact {
  transform: scale(0.95);
  transform-origin: left center;
}

.delete-btn-group {
  margin-left: 8px;
  display: flex;
  align-items: center;
}

@media (max-width: 1200px) {
  .settings-row {
    flex-wrap: wrap;
  }

  .date-range-group {
    margin-left: 0;
    margin-top: 8px;
    width: 100%;
  }

  .delete-btn-group {
    margin-left: 0;
    margin-top: 8px;
  }
}

@media (max-width: 768px) {
  .settings-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }

  .setting-group {
    margin-bottom: 4px;
    width: 100%;
  }
}
</style>

import type { FileInfo, UploadResponse } from '@/type';

const BASE_URL = 'https://local.osstem.com:8041';
// const UPLOAD_URL = import.meta.env.VITE_APP_UPLOAD_URL;

export interface VocResponse<T> {
  success: boolean;
  error: string;
  message: string;
  data: T | undefined | null;
}

export const VocResponseUtil = {
  successful: <T>(data: T): VocResponse<T> => ({
    success: true,
    error: '000000',
    message: 'OK',
    data,
  }),
  error: <T>(errorCode: string, message: string): VocResponse<T> => ({
    success: false,
    error: errorCode,
    message,
    data: null,
  }),
};

// useFetch.ts

export function useFetch() {
  const fetchData = async <T>(path: string, options: RequestInit): Promise<VocResponse<T>> => {
    try {
      const url = `${BASE_URL}${path}`; // Combine base URL with the path
      const res = await fetch(url, options);

      const responseData: VocResponse<T> = await res.json();

      if (!res.ok) {
        return VocResponseUtil.error(res.status.toString(), responseData.message);
      }

      return responseData;
    }
    catch (error: any) {
      return VocResponseUtil.error('999998', error);
    }
  };

  const get = async <T>(path: string): Promise<VocResponse<T>> => {
    return await fetchData<T>(path, { method: 'GET', credentials: 'include' });
  };

  const post = async <T>(path: string, data: any): Promise<VocResponse<T>> => {
    return await fetchData<T>(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      credentials: 'include',
    });
  };

  const put = async <T>(path: string, data: any): Promise<VocResponse<T>> => {
    return await fetchData<T>(path, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      credentials: 'include',
    });
  };

  const patch = async <T>(path: string, data: any): Promise<VocResponse<T>> => {
    return await fetchData<T>(path, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      credentials: 'include',
    });
  };

  const del = async <T>(path: string): Promise<VocResponse<T>> => {
    return await fetchData<T>(path, { method: 'DELETE', credentials: 'include' });
  };

  //   /**
  //    * 공통파일서버에 업로드
  //    * @param formData
  //    * @returns
  //    */
  //   const uploadFile = async (formData: FormData): Promise<UploadResponse> => {
  //     const response = await fetch(`${UPLOAD_URL}/file/upload`, {
  //       method: 'POST',
  //       body: formData,
  //       headers: {
  //         'X-Oway-System': 'MCS',
  //       },
  //     });
  //     return response.json() as Promise<UploadResponse>;
  //   };

  //   /**
  //    * 공통파일서버에 파일정보 저장
  //    * @param data
  //    * @returns
  //    */
  //   async function uploadDbSave(data: FileInfo[]): Promise<UploadResponse> {
  //     const response = await fetch(`${UPLOAD_URL}/file/save`, {
  //       method: 'POST',
  //       body: JSON.stringify(data),
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'X-Oway-System': 'MCS',
  //       },
  //     });
  //     return response.json() as Promise<UploadResponse>;
  //   }

  return { get, post, put, patch, del };
}

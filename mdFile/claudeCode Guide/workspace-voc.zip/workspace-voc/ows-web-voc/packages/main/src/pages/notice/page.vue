<script setup>
import { ref, computed, watch, onMounted, nextTick } from 'vue';
import dayjs from 'dayjs';
import { useOwPopup } from '@ows/ui';
import { uniqueId } from 'lodash-es';
import { dateUtils } from '@/utils/dateUtils';
import useServiceCategoryCode from '@/composables/useServiceCategoryCode';
import {
  openYNGroupOptions,
  searchGroupOptions,
  topFxdYnGroupOptions,
} from '@/types/data.ts';

import Detail from './components/Detail.vue';
import NoticeDetailPopup from '@/components/NoticeDetailPopup.vue';
import SearchUser from "@/components/SearchUser.vue";

// Popup for registration
const {
  openPopup: openNoticeDetailPopup,
  closePopup: closeNoticeDetailPopup,
  isPopupOpen,
} = useOwPopup();

const detailRef = ref();

// Date picker state
const date = ref(dayjs().format('YYYY-MM-DD'));
const dateUnit = ref('year');
const range = computed(() => dateUtils.getRangeByUnit(date.value, dateUnit.value));

// VOC 카테고리 스토어
const { fetchEmployeeChannels, fetchEmployeeCategorys, fetchOrganizationData } = useServiceCategoryCode();

// Filters
const channelGroup = ref('');
const categoryGroup = ref([]);

const openYnGroup = ref('');
const topFxdYnGroup = ref('');

const searchType = ref('title');
const keyword = ref('');
const user = ref({
  empName: '',
  empNo: ''
});

const filterOptions = { channelGroup, categoryGroup, openYnGroup, topFxdYnGroup };

// 옵션 데이터
const channelGroupOptions = ref([]);
const employeeGroupOptions = ref([]);
const allCategoryGroupOptions = ref([]);
const categoryGroupOptions = computed(() => {
  // 채널이 선택되지 않으면 전체 카테고리, 아니면 prefix 필터
  if (!channelGroup.value) {
    return allCategoryGroupOptions.value;
  }
  return allCategoryGroupOptions.value.filter(opt =>
      opt.value.startsWith(channelGroup.value + '_'+ 'NTF')
  );
});

// 채널이 바뀔 때마다 카테고리 선택값 리셋
watch(channelGroup, () => {
  categoryGroup.value = categoryGroupOptions.value.map(opt => opt.value);
});

// searchType이 변경될 때 keyword 초기화 및 검색
watch(searchType, (newValue, oldValue) => {
  console.log('searchType 변경:', oldValue, '->', newValue);
  keyword.value = '';
  user.value = {
    empName: '',
    empNo: ''
  };
  
  // writer로 변경될 때는 검색하지 않음 (사용자가 직접 검색해야 함)
  if (newValue !== 'writer') {
    detailRef.value?.load();
  }
});

// 검색/필터 핸들러
function handleSearch() {
  detailRef.value?.load();
}

// 검색/필터 핸들러
function handleSearchUser(userData) {
  console.log('handleSearchUser 호출:', userData);
  if (userData && userData.empNo) {
    keyword.value = userData.empNo;
  } else {
    // 빈 상태로 검색하는 경우 keyword를 빈 문자열로 설정
    keyword.value = '';
  }
  detailRef.value?.load();
}

function handleItemFilterChange() {
  detailRef.value?.load();
}

// 등록 팝업
function onRegClick() {
  openNoticeDetailPopup();
}

function handleSaveSuccess() {
  console.log('handleSaveSuccess 호출됨');
  // 팝업을 닫고 약간의 지연 후 데이터 로드
  setTimeout(() => {
    detailRef.value?.load();
  }, 100);
}

// clearKeyword 함수는 더 이상 필요 없음 - searchType watch에서 처리

// 초기 데이터 로드
async function loadRootCategories() {
  try {
    const channels = await fetchEmployeeChannels('NTF');
    const categories = await fetchEmployeeCategorys('NTF');
    employeeGroupOptions.value = await fetchOrganizationData('KR1');

    channelGroupOptions.value = channels.map(ch => ({
        text: ch.serviceCategoryName,
        value: ch.serviceCategoryCode,
      }))
    ;

    allCategoryGroupOptions.value = categories.map(cat => ({
      text: cat.serviceCategoryName,
      value: cat.serviceCategoryCode,
    }));

    categoryGroup.value = allCategoryGroupOptions.value.map(opt => opt.value);
  }
  catch (err) {
    console.error(err);
  }
}

onMounted(async () => {
  await loadRootCategories();
});
</script>

<template>
  <div class="input-group gap-1 mb-2" role="group">
    <!-- Date Picker -->
    <OwDatePicker
        v-model="date"
        :unit="dateUnit"
        :hidden-units="['5years','6months']"
        @unit-change="u => dateUnit = u"
    />

    <!-- 채널 라디오 -->
    <div class="ow-filter">
      <label class="ow-stit">채널</label>
      <OwFormRadio
          :id="uniqueId('cha-chk-')"
          v-model="channelGroup"
          type="all"
          :options="channelGroupOptions"
          @change="handleItemFilterChange"
      />
    </div>

    <!-- 카테고리 체크박스 (채널별 필터링) -->
    <div v-if="channelGroup !== ''" class="ow-filter" >
      <label class="ow-stit">상세구분</label>
      <OwFormCheckbox
          :id="uniqueId('cat-chk-')"
          v-model="categoryGroup"
          :options="categoryGroupOptions"
          class="ow-filter-more"
          @change="handleItemFilterChange"
      />
    </div>

    <!-- 공개 여부 -->
    <div class="ow-filter">
      <OwFormRadio
          :id="uniqueId('open-chk-')"
          v-model="openYnGroup"
          :options="openYNGroupOptions"
          type="all"
          @change="handleItemFilterChange"
      />
    </div>

    <!-- 상단 고정 여부 -->
    <div class="ow-filter">
      <OwFormRadio
          :id="uniqueId('fix-chk-')"
          v-model="topFxdYnGroup"
          :options="topFxdYnGroupOptions"
          type="all"
          @change="handleItemFilterChange"
      />
    </div>

    <!-- 검색 -->
    <div style="width: 400px">
      <div class="input-group" role="group">
        <OwFormRadio
            :id="uniqueId('search-group')"
            v-model="searchType"
            :options="searchGroupOptions"
            shape="text"
            style="margin-right: 3px"
            action-type="input"
        />
        <template v-if="searchType !== 'writer'">
        <input
            v-model="keyword"
            class="form-control"
            placeholder="검색어를 입력해주세요."
            @keyup.enter="handleSearch"
        />
          <button class="btn btn-md btn-search" @click="handleSearch" />
        </template>
        <template v-else>
          <SearchUser
              v-model="user"
              @change="handleSearchUser"
              @search="handleSearchUser(user)"
          />
        </template>
      </div>
    </div>

    <!-- 등록 버튼 -->
    <BButton variant="state" @click="onRegClick">
      공지사항 등록
    </BButton>
  </div>

  <!-- Detail 컴포넌트 -->
  <Detail
    ref="detailRef"
    :from="range.from"
    :to="range.to"
    :date-unit="dateUnit"
    :filter-options="filterOptions"
    :search-type="searchType"
    :keyword="keyword"
    :channel-group-options="channelGroupOptions"
    :category-group-options="categoryGroupOptions"
    :employee-group-options="employeeGroupOptions"
  />

  <NoticeDetailPopup
      v-if="isPopupOpen"
      :is-popup-open="isPopupOpen"
      :channel-group-options="channelGroupOptions"
      :category-group-options="categoryGroupOptions"
      height="auto"
      title="공지사항 등록"
      :width="1200"
      :on-close="
      () => {
        closeNoticeDetailPopup();
      }
    "
      @save-success="handleSaveSuccess"
  />
</template>

<style scoped>
/* 필요하신 경우 스타일 추가 */
</style>

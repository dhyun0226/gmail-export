<script setup>
import { computed, onMounted, ref, watch } from 'vue';
import { useApi, useCommonCode } from '@ows/core';
import dayjs from 'dayjs';

import { useOwPopup } from '@ows/ui';
import { DxDataGrid } from 'devextreme-vue/data-grid';
import { useColumnPopup } from '@/composables/useColumnPopupStore';
import { dateUtils } from '@/utils';
import VocDetailPopup from '@/components/VocDetailPopup.vue';

const props = defineProps({
  dateOptions: Object,
  filterOptions: Object,
});

const {
  openPopup: openVocDetailPopup,
  closePopup: closeVocDetailPopup,
  isPopupOpen: isVocDetailPopupOpen,
  getVh,
} = useOwPopup();

const columnPopupStore = useColumnPopup();

const api = useApi();
const { VOC_ITM_CTG_CD } = await useCommonCode('VOC_ITM_CTG_CD');
const { VOC_DVCD } = await useCommonCode('VOC_DVCD');

const vocNumber = ref(0);
// const columns = ref([
//   // {
//   //   caption: '접수시간',
//   //   width: '100',
//   //   dataField: 'registrationDateTime',
//   //   allowMerge: true,
//   //   alignment: 'center',
//   //   allowSorting: false,
//   //   cellType: 'customize',
//   //   visible: true,
//   // },
//   // {
//   //   caption: '품목',
//   //   width: '120',
//   //   dataField: 'vocItemCategoryCode',
//   //   allowMerge: true,
//   //   alignment: 'left',
//   //   allowSorting: false,
//   //   cellType: 'customize2',
//   //   visible: true,
//   // },
//   // {
//   //   caption: '접수내용',
//   //   width: '*',
//   //   dataField: 'vocContent',
//   //   allowMerge: false,
//   //   alignment: 'left',
//   //   allowSorting: false,
//   //   visible: true,
//   // },
//   // {
//   //   caption: '요청자',
//   //   width: '120',
//   //   dataField: 'customerCode',
//   //   allowMerge: false,
//   //   alignment: 'center',
//   //   allowSorting: false,
//   //   visible: true,
//   // },
//   {
//     caption: '접수',
//     sub: [
//       {
//         caption: '접수일',
//         width: '70',
//         align: 'center',
//         field: 'a0',
//         visible: true,
//       },
//       {
//         caption: '내용',
//         width: '750',
//         visible: true,
//         field: 'a3',
//         align: 'left',
//         cellTemplate: 'a3_0ContentType',
//       },
//       {
//         caption: '요청자',
//         width: '100',
//         visible: true,
//         field: 'a2',
//         align: 'center',
//         cellTemplate: 'a4ContentType',
//       },
//     ],
//     align: 'center',
//   },
//   {
//     caption: '처리',
//     sub: [
//
//       {
//         caption: '품목',
//         width: '80',
//         visible: true,
//         field: 'a7',
//         align: 'center',
//         cellTemplate: 'a7ContentType',
//       },
//       {
//         caption: '처리담당',
//         width: '120',
//         visible: true,
//         field: 'a14[0]',
//         align: 'center',
//         cellTemplate: 'a14ContentType',
//       },
//       {
//         caption: '진행현황',
//         width: '*',
//         align: 'center',
//         field: 'a3[3]',
//         visible: true,
//         cellTemplate: 'processType',
//       },
//
//     ],
//     align: 'center',
//   },
//
// ]);

const columns = ref([
  {
    caption: '접수',
    columns: [
      {
        caption: '접수일',
        width: '70',
        align: 'center',
        dataField: 'a0',
        visible: true,
      },
      {
        caption: '내용',
        width: '750',
        visible: true,
        dataField: 'a3',
        align: 'left',
        cellTemplate: 'a3_0ContentType',
      },
      {
        caption: '요청자',
        width: '100',
        visible: true,
        dataField: 'a2',
        align: 'center',
        cellTemplate: 'a4ContentType',
      },
    ],
    align: 'center',
  },
  {
    caption: '처리',
    columns: [
      {
        caption: '품목',
        width: '80',
        visible: true,
        dataField: 'a7',
        align: 'center',
        cellTemplate: 'a7ContentType',
      },
      {
        caption: '처리담당',
        width: '120',
        visible: true,
        dataField: 'a14[0]',
        align: 'center',
        cellTemplate: 'a14ContentType',
      },
      {
        caption: '진행현황',
        width: '*',
        align: 'center',
        dataField: 'a3[3]',
        visible: true,
        cellTemplate: 'processType',
      },
    ],
    align: 'center',
  },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

function getItemText(code) {
  const item = VOC_ITM_CTG_CD.find(item => item.value === code);
  return item ? item.text : code;
}

function getDateFormat(date) {
  return dayjs(date).format('YYYY-MM-DD');
}

function getTimeFormat(date) {
  return dayjs(date).format('HH:mm');
}

function getNGridCountByColumns() {
  if (columnPopupStore.selectedColumns.length === 2) {
    gridOption.value.nGridCount = 6;
  }
  else if (columnPopupStore.selectedColumns.length === 3) {
    gridOption.value.nGridCount = 4;
  }
  else {
    gridOption.value.nGridCount = 2;
  }
}

function getColumnsByDate() {
  const date = props.dateOptions.rangeUnit;
  if (date === 'day') {
    columns.value.forEach((col) => {
      if (col.caption === '접수일자') {
        col.caption = '접수시간';
      }
      col.visible = true;
    });
  }
  else if (date === 'week') {
    columns.value.forEach((col) => {
      if (col.caption === '접수시간') {
        col.caption = '접수일자';
      }
      col.visible = true;
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '접수시간' || col.caption === '접수일자') {
        col.caption = '접수일자';
        col.visible = false;
      }
      if (col.caption === '요청자') {
        col.visible = false;
      }
    });
  }
  columnPopupStore.selectedColumns = columns.value
    .filter(col => col.visible)
    .map(col => col.caption);
}

// 셀병합할 컬럼
const mergeColumns = computed(() => {
  const arr = [];
  columns.value.forEach((e, idx) => {
    if (e.allowMerge) {
      arr.push({ idx, field: e.dataField });
    }
  });
  return arr;
});

const mergeCellIndexs = mergeColumns.value.map(e => [e.idx]);

function onCellPrepared(e) {
  // if (e.rowType === 'data' && e.data?.header) {
  //   if (e.columnIndex === 1) {
  //     // console.log(e);
  //     e.cellElement.classList.add('sal-custom');
  //     e.cellElement.colSpan = 4;
  //   }
  //   else if (e.columnIndex > 1) {
  //     e.cellElement.classList.add('sal-disable');
  //   }
  // }
}

function onCellClick(e) {
  console.log('Cell clicked:', e);
  vocNumber.value = e.data;
  openVocDetailPopup();
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      fromDate: dateUtils.toLocalDateTime(props.dateOptions.from),
      toDate: dateUtils.toLocalDateTime(props.dateOptions.to),
      // vocDivisionCode: '',
      // itemFilter: 'all',
      // countryFilter: 'all',
      // orgFilter: 'all',
    };

    const result = await api.get(`/voc/vocs`, { params });
    gridOption.value.datas = result.data.data;
    gridOption.value.paging.totalItemCount = result.data.totalCount;

    console.log(result);
  }
  catch (error) {
    gridOption.value.datas = [];
    console.error('Failed to load VOC data:', error);
  }
}

onMounted(() => {
  getColumnsByDate();
  columnPopupStore.columns = columns.value;
  columnPopupStore.selectedColumns = columns.value
    .filter(col => col.visible)
    .map(col => col.caption);
  load();
});

watch(
  () => props.dateOptions,
  (newVal) => {
    console.log('Date options changed:', newVal);
    getColumnsByDate();
    load();
  },
  { deep: true },
);

watch(
  () => props.filterOptions,
  (newVal) => {
    console.log('Date options changed:', newVal);
    getNGridCountByDate();
    load();
  },
  { deep: true },
);

watch(
  () => columnPopupStore.selectedColumns,
  (newVal) => {
    console.log('Selected columns changed:', newVal);
    columns.value.forEach((col) => {
      col.visible = newVal.includes(col.caption);
    });
    getNGridCountByColumns();
  },
  { deep: true },
);
</script>

<template>
  <DxDataGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :merge-cell-indexs="mergeCellIndexs"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <template v-if="props.dateOptions.rangeUnit === 'day'">
        {{ getTimeFormat(cell.data.registrationDateTime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.registrationDateTime) }}
        </div>
      </template>
    </template>

    <template #customize2="{ data: cell }">
      <div>{{ getItemText(cell.data.vocItemCategoryCode) }}</div>
    </template>

    <!-- <template #customize="{ data: data }" /> -->
  </DxDataGrid>
  <OwPopup
    v-if="isVocDetailPopupOpen"
    :is-popup-open="isVocDetailPopupOpen"
    :on-close="closeVocDetailPopup"
    title="VOC상세"
    :show-title="true"
    :show-close-button="true"
    :height="750"
    :width="850"
  >
    <VocDetailPopup
      :voc-number="vocNumber.value"
      :voc-item-category-code="VOC_ITM_CTG_CD"
      :voc-division-code="VOC_DVCD"
    />
  </OwPopup>
</template>

<style></style>

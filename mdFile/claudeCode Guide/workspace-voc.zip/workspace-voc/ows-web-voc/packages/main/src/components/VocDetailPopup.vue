<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import {
  useApi,
  useCommonCode,
  useFileDownload,
  useUserProfile,
} from '@ows/core';
import { useOwPopup } from '@ows/ui';
import dayjs from 'dayjs';
import FileInputGroup from '@/components/FileInputGroup.vue';
import { getFileIcon, isImageFile } from '@/types/inquiry';
import type { VocFile, VocResponse } from '@/types/voc';

const props = defineProps({
  showTitle: { type: Boolean, default: true },
  title: { type: String, default: 'VOC 접수처리' },
  showCloseButton: { type: Boolean, default: true },
  size: { type: String, default: 'md' },
  width: { type: Number, default: 800 },
  height: { type: Number, default: 400 },
  footerHeight: { type: Number, default: 52 },
  hasFooter: { default: true },
  onClose: { type: Function },
  vocNumber: { type: Number },
  vocItemName: { type: String },
  vocItemCategoryCode: { type: Object },
  vocCategoryCode: { type: Object },
});

const { currentUser } = useUserProfile();

// 과제 팝업 관련
const {
  openPopup: openAssignmentPopup,
  closePopup: closeAssignmentPopup,
  isPopupOpen: isAssignmentPopupOpen,
} = useOwPopup();

// 과제 팝업 관련
const {
  openPopup: openWorkRequestPopup,
  closePopup: closeWorkRequestPopup,
  isPopupOpen: isWorkRequestPopupOpen,
} = useOwPopup();

// 공통 코드 로드
const { VOC_CMPL_TYCD: vocTypes } = await useCommonCode(
  'VOC_STACD',
  'VOC_CMPL_TYCD',
);

const isEditMode = ref(false); // 편집 모드 여부

// 품목 코드와 텍스트 매핑
const productOptions = [
  { text: '임플란트', value: 'implant' },
  { text: '기구', value: 'instrument' },
  { text: '보존/근관', value: 'endodontic' },
  { text: '수복/접착', value: 'restorative' },
  { text: '인상/보철', value: 'impression' },
  { text: '절삭/연마', value: 'cutting' },
  { text: 'GBR', value: 'gbr' },
  { text: '위생용품', value: 'hygiene' },
  { text: '장비', value: 'equipment' },
  { text: '교정용기구', value: 'orthodontic' },
  { text: '예방/구강', value: 'prevention' },
  { text: '기공용품', value: 'dentalLab' },
  { text: '의약품', value: 'medicine' },
  { text: '생활가전', value: 'appliance' },
];

// 품목 편집 모드 토글 함수
function toggleEditMode() {
  isEditMode.value = !isEditMode.value;
}
// 라디오 버튼 값 변경 시 동작
function onOptionChange(newVal: string): void {
  responseData.value.itemCode = newVal;
  isEditMode.value = false; // 라디오에서 값 선택 후 텍스트 모드로 즉시 변경
}

const selectedOptionText = computed(() => {
  const option = productOptions.find(option => option.value === responseData.value.itemCode);
  return option?.text || '선택된 품목 없음';
});

const selectedProduct = ref('all');

const api = useApi();
const { image } = useFileDownload();
const user = ref('');

const selectedProcessType = ref('01');
const reasonText = ref('');
const selectedItem = ref('전체'); // 품목필터 기본 선택값 설정
// 품목 텍스트 가져오기
function getItemText(code: string) {
  const item = props.vocItemCategoryCode?.find(item => item.value === code);
  return item ? item.text : code;
}

// VOC 응답 데이터
const responseData = ref<Partial<VocResponse>>({});
const answer = ref('');
const fileList = ref<VocFile[]>([]);
const answerFileList = ref<VocFile[]>([]);
const files = ref([]);

const sortedHistories = computed(() => {
  if (!responseData.value?.changeHistories) {
    return [];
  }

  return [...responseData.value.changeHistories].sort((a, b) => {
    const dateA = new Date(a.vocChangeDateTime);
    const dateB = new Date(b.vocChangeDateTime);
    return dateB.getTime() - dateA.getTime(); // 내림차순 정렬
  });
});

// VOC 데이터 불러오기
async function fetchVocData() {
  try {
    const { data } = await api.get(`/voc/vocs/${props.vocNumber}/with-answer`);
    responseData.value = data;
    answer.value = data.vocAnswerContent || '';
    fileList.value = data.fileList || [];
    answerFileList.value = data.answerFileList || [];
    // responseData.value.changeHistories = data.changeHistories;
  }
  catch (error) {
    responseData.value = {};
    console.error('Error loading VOC data:', error);
  }
}

// 조직 팝업 관련
const {
  openPopup: openOrgPopup,
  closePopup: closeOrgPopup,
  isPopupOpen: isOrgPopupOpen,
} = useOwPopup();

// 사용자 선택 처리
function handleUpdateOrganization(item) {
  user.value = item;
  closeOrgPopup();
}

// 저장 처리
async function clickSave() {
  const params = {
    vocNumber: props.vocNumber,
    vocAnswerContent: answer.value,
    fileList: files.value?.length > 0 ? files.value : null,
    vocCategoryCode: responseData.value.vocCategoryCode,
    answererCorporationCode: currentUser.corpCode,
    answererDepartmentCode: currentUser.deptCode,
    answererEmployeeNumber: currentUser.empNo,
  };

  try {
    const { data } = await api.post('/voc/voc-answers', params);
    if (props.onClose) {
      props.onClose();
    }
  }
  catch (error) {
    console.error('VOC 답변 저장 오류:', error);
  }
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY.MM.DD HH:mm');
}

// 값 변경 핸들러
function handleChange(value) {
}

// itemCode 변경 감지
watch(
  () => responseData.value.itemCode,
  (newVal) => {
    isEditMode.value = false; // 값 변경 시 텍스트 모드로 전환
  },
);

onMounted(() => {
  fetchVocData();
});
</script>

<template>
  <OwPopup v-bind="props">

    <BTabs class="ow-tabs-full">
      <div class="voc-detail-container">
        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            VOC 상세 정보
          </caption>
          <colgroup>
            <col width="105px">
            <col>
          </colgroup>
          <div
            class="mb-3"
            style="font-size: 20px; font-weight: bold"
          >
            처리
          </div>
          <BTbody>
            <BTr>
              <BTh>답변</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <BFormTextarea
                    id="textarea-answer"
                    v-model="answer"
                    :readonly="responseData.hasAnswer"
                    placeholder="답변을 입력해주세요."
                    rows="5"
                    class="w-100"
                  />
                </div>
                <div
                  v-if="answerFileList && answerFileList.length > 0"
                  class="voc-file-container"
                >
                  <div class="file-list">
                    <div
                      v-for="file in answerFileList"
                      :key="file.fileId"
                      class="file-item"
                    >
                      <template v-if="isImageFile(file.fileExtensionName)">
                        <img
                          :src="image(file.fileId, 300, 300)"
                          class="file-image"
                          :alt="file.fileOriginalName"
                        >
                      </template>
                      <div
                        v-else
                        class="file-icon"
                      >
                        <i :class="getFileIcon(file.fileExtensionName)" />
                        <span class="file-name">{{
                          file.fileOriginalName
                        }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </BTd>
            </BTr>
            <BTr v-if="!responseData.hasAnswer">
              <BTh>파일첨부</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <div class="button-with-text" style="margin-left: -17px">
                    <FileInputGroup v-model:files="files" />
                  </div>
                </div>
              </BTd>
            </BTr>

            <!-- 이관 시 표시 -->
            <BTr v-if="selectedProcessType === '02'">
              <BTh>처리담당</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <div class="button-with-text">
                    <SearchUser
                      v-model="user"
                      @search="openOrgPopup()"
                    />
                  </div>
                  <BButton
                    variant="state"
                    @click="openWorkRequestPopup"
                  >
                    업무요청서
                  </BButton>
                </div>
              </BTd>
            </BTr>

            <!-- 통합 시 표시 -->
            <BTr v-if="selectedProcessType === '03'">
              <BTh>통합대상</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <div class="button-with-text">
                    {{ reasonText }}
                  </div>
                  <BButton
                    variant="state"
                    @click="openAssignmentPopup"
                  >
                    과제선택
                  </BButton>
                </div>
              </BTd>
            </BTr>

            <!-- 종결 시 표시 -->
            <BTr v-if="selectedProcessType === '04'">
              <BTh>사유</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  <BFormTextarea
                    id="textarea-reason"
                    v-model="reasonText"
                    placeholder="종결사유를 입력해주세요."
                    rows="2"
                    class="w-100"
                  />
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>
      </div>
      <!-- 밑줄 그어야함 -->
      <div
        class="ow-popup-bottom"
        style="
            border-top: 1px solid #dee2e6;
            margin-top: 1rem;
            padding-top: 1rem;
          "
      />
      <div class="voc-detail-container">
        <BTableSimple
          responsive
          bordered="false"
          small
          class="ow-table-read"
        >
          <caption class="visually-hidden">
            VOC 상세 정보
          </caption>
          <colgroup>
            <col width="105px">
            <col>
          </colgroup>
          <div
            class="mb-3"
            style="font-size: 20px; font-weight: bold"
          >
            접수
          </div>
          <BTbody>
            <BTr>
              <BTh>요청자</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  {{ responseData.vocCustomerName }}
                  ({{ responseData.vocCustomerCustomerName }})
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>접수일시</BTh>
              <BTd>
                <div
                  class="input-group"
                  role="group"
                >
                  {{ getDateFormat(responseData.vocRegistrationDateTime) }}
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>품목</BTh>
              <BTd>
                <div @click="toggleEditMode">
                  <!-- 라디오 버튼 모드 -->
                  <template v-if="isEditMode">
                    <OwFormRadio
                      v-model="responseData.itemCode"
                      :options="productOptions"
                      @on-change="onOptionChange"
                    />
                  </template>
                  <!-- 텍스트 모드 -->
                  <template v-else>
                    {{ selectedOptionText }}
                  </template>
                </div>
              </BTd>
            </BTr>

            <BTr>
              <BTh>접수내용</BTh>
              <BTd>
                <div class="voc-content">
                  <div class="voc-text">
                    <span v-if="responseData.vocTitle">[</span>{{ responseData.vocTitle
                    }}<span v-if="responseData.vocTitle">]</span>
                    {{ responseData.vocContent }}
                  </div>

                  <!-- 첨부 파일 이미지 -->
                  <div
                    v-if="fileList && fileList.length > 0"
                    class="voc-file-container"
                  >
                    <div class="file-list">
                      <div
                        v-for="file in fileList"
                        :key="file.fileId"
                        class="file-item"
                      >
                        <template v-if="isImageFile(file.fileExtensionName)">
                          <img
                            :src="image(file.fileId, 300, 300)"
                            class="file-image"
                            :alt="file.fileOriginalName"
                          >
                        </template>
                        <div
                          v-else
                          class="file-icon"
                        >
                          <i :class="getFileIcon(file.fileExtensionName)" />
                          <span class="file-name">{{
                            file.fileOriginalName
                          }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </BTd>
            </BTr>
            <BTr>
              <BTh>세부품목</BTh>
              <BTd>
                {{responseData.vocDetailsItemName}}
              </BTd>
            </BTr>
            <BTr>
              <BTh>처리담당자</BTh>
              <BTd>
                <div class="d-flex">
                  {{responseData.vocChargePersonName}}
                </div>
              </BTd>
            </BTr>
          </BTbody>
        </BTableSimple>

        <div class="ow-popup-bottom">
          <BButton
            size="md"
            variant="base base-gray"
            @click="props.onClose"
          >
            취소
          </BButton>
          <BButton
            id="btnOk"
            size="md"
            variant="base base-dark"
            @click="clickSave"
          >
            확인
          </BButton>
        </div>
      </div>


    </BTabs>


    <!-- 조직 선택 팝업 -->
    <Teleport to="body">
      <OrgPopup
        v-if="isOrgPopupOpen"
        :is-popup-open="isOrgPopupOpen"
        :on-close="closeOrgPopup"
        :height="700"
        @update-organization="handleUpdateOrganization"
      />
    </Teleport>
    <AssignmentPopup
      v-if="isAssignmentPopupOpen"
      :is-popup-open="isAssignmentPopupOpen"
      :on-close="closeAssignmentPopup"
      :height="450"
    />
    <WorkRequestPopup
      v-if="isWorkRequestPopupOpen"
      :is-popup-open="isWorkRequestPopupOpen"
      :on-close="closeWorkRequestPopup"
    />
  </OwPopup>
</template>

<style scoped>
.voc-detail-container {
  padding: 0.5rem;
}

.input-group {
  align-items: center;
  position: relative;
  display: flex;
  flex-wrap: wrap;
  width: 100%;
}

.button-with-text {
  margin-right: 12px;
}

.voc-content {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.voc-text {
  line-height: 1.5;
}

.voc-file-container {
  margin-top: 1rem;
}

.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
}

.file-item {
  width: 130px;
  height: 130px;
  overflow: hidden;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.file-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.file-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 8px;
  text-align: center;
}

.file-icon i {
  font-size: 36px;
  color: #6c757d;
  margin-bottom: 8px;
}

.file-name {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-all;
}

/* 테이블 간격 개선 */
.ow-table-read td,
.ow-table-read th {
  padding: 0.75rem 1rem;
  font-size: 16px;
}

.ow-table-read tbody tr:hover {
  background-color: #f8f9fa;
}

/* 하단 버튼 영역 */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}
</style>

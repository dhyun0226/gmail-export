// types/inquiry.ts

// 백엔드 API 응답 형식
export interface InquiryItem {
  individualInquiryNumber: number;
  individualInquiryRegistrationDatetime: string | number[];
  channelCode?: string;
  vocCategoryCode?: string;
  individualInquiryTitle: string;
  individualInquiryContent: string;
  itemCode?: string;
  itemName?: string;
  memberYn?: string;
  writerMemberId?: string;
  vocWriterName?: string;
  writerEmailAddress?: string;
  writerTelephoneNumber?: string;
  writerHandPhoneNumber?: string;
  individualInformationCollectionTermsOfUseAgreementYesOrNo?: string;
  fileId?: string;
  fileList?: FileInfo[];
  individualInquiryAnswerContent?: string;
  individualInquiryAnswerDatetime?: string | null;
  answererCorporationCode?: string;
  answererDepartmentCode?: string;
  answererEmployeeNumber?: string;
  answerFileId?: string;
  answerFileList?: FileInfo[];
}

// VOC 항목 인터페이스
export interface VocItem {
  vocNumber: string;
  registrationDateTime: string;
  vocContent: string;
  vocItemCategoryCode: string;
}

// 개인문의 등록 요청 DTO
export interface InquiryCreateRequest {
  individualInquiryTitle: string;
  individualInquiryContent: string;
  itemCode: string;
  vocWriterName?: string;
  writerEmailAddress?: string;
  writerHandPhoneNumber?: string;
  individualInformationCollectionTermsOfUseAgreementYesOrNo: string;
  fileId?: string;
  fileList?: FileItem[];
}

// 페이징 정보를 포함한 응답 타입
export interface PaginatedResponse {
  data: InquiryItem[];
  totalCount: number;
}

// 파일 첨부 인터페이스
export interface FileItem {
  fileId: string;
  fileName: string;
  fileUrl: string;
  fileExtensionName: string;
  fileSize: number;
  fileMIME?: string;
  fileOriginalName?: string;
}

// 백엔드 파일 정보 인터페이스
export interface FileInfo {
  fileId: string;
  filePath?: string;
  referenceOwTaskCode?: string | null;
  referenceTableName?: string | null;
  referenceDistinguishColumnValueContent?: string | null;
  fileOriginalName: string;
  fileExtensionName: string;
  fileSize: string | number;
  fileUrl?: string;
}

// 폼 데이터 인터페이스
export interface InquiryFormData {
  inquiry: {
    individualInquiryContent: string;
    individualInquiryTitle: string;
  };
  answer: {
    individualInquiryAnswerContent: string;
    individualInquiryAnswerDatetime?: string | null;
  };
  inquiryFiles: FileInfo[];
  answerFiles: FileInfo[];
  selectedTags: string[];
}

// VOC 등록 폼 데이터 인터페이스
export interface VocRegisterFormData {
  content: string;
  selectedCategory: string;
  phoneNumber: string;
  email: string;
  termsAgreed: boolean;
  uploadedFiles: FileItem[];
  vocType: string;
}

// 카테고리 태그 데이터
export const primaryTags: string[] = [
  '임플란트',
  '기구',
  '보존/근관',
  '수복/접착',
  '인상/보철',
  '절삭/방부',
  'GBR',
  '위생용품',
  '장비',
  '교정용기구',
  '예방/구강',
  '기공용품',
  '의약품',
  '생활가전',
  'X-Ray',
  '미품목',
];

// VOC 유형 데이터
export const vocTypes: { value: string; text: string }[] = [
  { value: 'SUGGEST', text: '제안' },
  { value: 'COMPLAIN', text: '불만' },
  { value: 'REQUEST', text: '요청' },
  { value: 'INQUIRY', text: '문의' },
];

// 품목코드 맵핑 함수
export function getCategoryCode(category: string): string {
  const categoryMap: Record<string, string> = {
    '임플란트': 'IMPL_TS3',
    'X-Ray': 'XRAY_PRO400',
    '기구': 'INSTR_GEN',
    '보존/근관': 'ENDO_TOOL',
    '수복/접착': 'REST_MAT',
    '인상/보철': 'PROST_MAT',
    '절삭/방부': 'DRILL_TOOL',
    'GBR': 'GBR_MAT',
    '위생용품': 'HYGN_PROD',
    '장비': 'EQUIP_GEN',
    '교정용기구': 'ORTHO_TOOL',
    '예방/구강': 'PREV_ORAL',
    '기공용품': 'LAB_MAT',
    '의약품': 'MEDICINE',
    '생활가전': 'HOME_APPL',
    '미품목': 'MISC_ITEM',
  };

  return categoryMap[category] || 'MISC_ITEM';
}

// 이미지 파일 체크
export function isImageFile(extension: unknown): boolean {
  if (typeof extension !== 'string') {
    return false; // 문자열이 아니면 이미지 파일이 아님
  }
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  return imageExtensions.includes(extension.toLowerCase());
}

// 파일 아이콘 가져오기
export function getFileIcon(extension: unknown): string {
  if (typeof extension !== 'string') {
    return 'fas fa-file'; // 기본 아이콘 반환
  }
  const iconMap: Record<string, string> = {
    pdf: 'fas fa-file-pdf',
    doc: 'fas fa-file-word',
    docx: 'fas fa-file-word',
    xls: 'fas fa-file-excel',
    xlsx: 'fas fa-file-excel',
    mp4: 'fas fa-file-video',
    mov: 'fas fa-file-video',
    avi: 'fas fa-file-video',
    jpg: 'fas fa-file-image',
    jpeg: 'fas fa-file-image',
    png: 'fas fa-file-image',
    gif: 'fas fa-file-image',
  };
  return iconMap[extension.toLowerCase()] || 'fas fa-file';
}

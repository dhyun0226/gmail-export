import dayjs from 'dayjs';
import { cloneDeep, concat, filter, groupBy } from 'lodash-es';
import { getDateFormat, timeList5, timeList6 } from '../utils';
import { useFilterGroupToggleComp } from '@/composables/useFilter';

const CATEGORY = ['판촉', '일반', '상담', 'VOC'];

const gridWidth = '*';
// let gridWidth = "38px";
const dateWidth = '68';
const timeWidth = '37.64'; // 37.64
// @cell-prepared="(...args) => useMergeCells(...args, [[]])"
export function useMergeCells(cell, options) {
  if (cell.rowType == 'data') {
    const mergeByColumnIndex = (columns, option) => {
      if (cell.column.allowMerge && option.includes(cell.columnIndex)) {
        let r = cell.rowIndex;
        const addRowClassYn = cell.columnIndex < 1;

        const isSameCellDataRowUp = (c) => {
          const cellData = cell.component.cellValue(r, c);
          const checkEmpty = cellData != undefined && cellData != '';
          const checkSame = cell.component.cellValue(r - 1, c) == cellData;
          return checkEmpty && checkSame;
        };

        const isSameCellDataRowDown = (c) => {
          const cellData = cell.component.cellValue(r, c);
          const checkEmpty = cellData != undefined && cellData != '';
          const checkSame = cell.component.cellValue(r + 1, c) == cellData;
          return checkEmpty && checkSame;
        };

        if (r && columns.every(isSameCellDataRowUp)) {
          cell.cellElement.style.display = 'none';
          cell.cellElement.classList.add('merged-cell');
        }
        else {
          while (columns.every(isSameCellDataRowDown)) {
            r++;
            cell.cellElement.rowSpan += 1;
          }

          if (addRowClassYn) {
            cell.cellElement.classList.add('merge-row-gab');
            cell.row.data.mergedRow = true;
          }
        }
      }
    };

    let columns = [];
    for (const option of options) {
      columns = [...columns, ...option];
      mergeByColumnIndex(columns, option);
    }
  }
}

/**
 *
 * @param {*} list 리스트
 * @param {*} devide 분리할 수
 */
/**
 * List 형태
 * {
    id: 0,
    name: '치과명',
    detail: [
      { month: 1, date: [{ day: 1, action: ['KS System'], type: 1 }] },
 */
export function simpleDevide(list, devide) {
  // return 될 Data Array
  const inputArray = new Array(devide);
  // return 될 Data Array 의 크기
  const inputArraySize = new Array(devide);

  for (let i = 0; i < devide; i++) {
    inputArraySize[i] = 0;
  }

  // Raw List 순번
  let listIndex = 0;
  // Raw List 길이
  const listLength = list.length;
  // Raw List date > action 데이터 길이
  let actionLength = 0;
  // Insert할 List 순번
  let inputIndex = 0;
  const insertId = 0;
  // action 안에 들어갈수 있는 최대 길이
  const maxCount = 49;

  while (true) {
    actionLength = 0;
    list[listIndex].detail.forEach((element1) => {
      element1.date.forEach((element2) => {
        actionLength = actionLength + 3;
        element2.action.forEach((element3) => {
          actionLength = actionLength + 2;
        });
      });
    });
    // 가장 작은 길이를 가진 배열 찾기
    inputIndex = lowArray(inputArraySize);

    // Grid 크기 계산 부여
    inputArraySize[inputIndex] = inputArraySize[inputIndex] + Math.ceil(actionLength / maxCount);

    // 처음이면 공간 할당 / 2번째부터는 push
    if (inputArray[inputIndex] == undefined) {
      inputArray[inputIndex] = [list[listIndex]];
    }
    else { inputArray[inputIndex].push(list[listIndex]); }

    // Next Array Search
    listIndex++;
    // 배열이 끝이 면 Break
    if (listIndex == listLength) { break; }
  }
  return inputArray;
}

// 날짜별 6개로 짤라서 구분 detail[date]의 갯수로 counting
export function simpleDevide2(list, devideSize, arraySize) {
  list = serialize(list);
  // console.log('serialize => ', list);
  // return;
  // return 될 Data Array
  const inputArray = new Array(devideSize);

  // return 될 Data Array 의 크기
  // 치과 한개의 Date가 30개 면 0 ,1 , 2 , 3 ,4 가 하나의 치과 데이터가 되고 Grid하나에 5개가 차기때문에 나머지 2Grid 에 할당해야함
  const inputArraySize = new Array(devideSize);

  for (let i = 0; i < devideSize; i++) {
    inputArraySize[i] = 0;
    inputArray[i] = [];
  }

  // Insert할 List 순번
  let inputIndex = 0;
  // Insert할 List의 세부 순번
  let inputDetailIndex = 0;

  let inputData = {};
  let overflow = false;
  let tempMonth = 0;
  let tempDay = 0;
  const maxSize = 4;
  // const arraySize = 16;

  let name = '';
  list.forEach((data, index) => {
    // 2023-05-17
    const year = data.visitDate.substring(0, 4);
    let month = data.visitDate.slice(5, 7);
    let day = data.visitDate.slice(8, 10);

    if (month.slice(0, 1) == '0') { month = month.slice(1, 2); }
    if (day.slice(0, 1) == '0') { day = day.slice(1, 2); }

    // test
    // if (data.name != '유플러스 덴탈') return;

    name = '';
    inputDetailIndex = 0;
    overflow = false;
    for (var i = 0; i < inputArray.length; i++) {
      inputArray[i].forEach((element, index) => {
        if (inputArray[i].length <= arraySize && element.size < maxSize) {
          if (element.name == data.name) {
            name = element.name;
            inputIndex = i; // Insert 할 List 순번
            inputDetailIndex = index; // Insert 할 List의 세부 순번

            if (element.size >= maxSize) { overflow = true; }
            return false;
          }
        }
      });

      if (name != '') { break; }
    }

    //   // matching 되는 Array 가 없다면 새로운 ID 부여 Array ID에서 name으로 매칭
    if (name == '') {
      // 가장 작은 길이를 가진 배열 찾기
      inputIndex = lowArray2(inputArraySize, arraySize);
      if (inputIndex == undefined) { return inputArray; }

      inputData = {
        name: data.name,
        employeeNumber: data.employeeNumber,
        isAdd: data.isAdd,
        isChange: data.isChange,
        isPlaned: data.isPlaned,
        isVisited: data.isVisited,
        visitDate: data.visitDate,
        jobDutyCode: data.jobDutyCode,
        size: 1,
        detail: [
          {
            month,
            date: [
              {
                day,
                isChange: data.isChange,
                isPlaned: data.isPlaned,
                isVisited: data.isVisited,
                action: [data.action],
              },
            ],
          },
        ],
      };

      inputArray[inputIndex].push(inputData);
      inputArraySize[inputIndex] = inputArraySize[inputIndex] + 1;
    }
    else {
      // 신규 Insert

      let newArray = true;

      if (overflow) {
        inputArray[inputIndex].forEach((element, index) => {
          if (element.size <= maxSize) {
            newArray = false;
            inputDetailIndex = index;
            return false;
          }
          inputDetailIndex = index;
        });
      }
      else {
        newArray = false;
      }

      // 새로운 Array 추가 할지 여부
      if (tempMonth == month && tempDay == day) { newArray = false; }

      if (newArray) {
        inputDetailIndex = inputDetailIndex + 1;

        inputData = {
          name: data.name,
          employeeNumber: data.employeeNumber,
          isAdd: data.isAdd,
          isChange: data.isChange,
          isPlaned: data.isPlaned,
          isVisited: data.isVisited,
          visitDate: data.visitDate,
          jobDutyCode: data.jobDutyCode,
          size: 1,
          detail: [
            {
              month,
              date: [
                {
                  day,
                  isChange: data.isChange,
                  isPlaned: data.isPlaned,
                  isVisited: data.isVisited,
                  action: [data.action],
                },
              ],
            },
          ],
        };
        inputArray[inputIndex].push(inputData);
        inputArraySize[inputIndex] = inputArraySize[inputIndex] + 1;
      }
      else {
        // 월 matching
        let monthBool = false;
        let dayBool = false;
        let dayIndex = 0;
        let detailIndex = 0;

        // 같은 월 , 같은 일 인지 확인
        inputArray[inputIndex][inputDetailIndex].detail.forEach((element, index) => {
          if (element.month == month) {
            detailIndex = index;
            monthBool = true;
            element.date.forEach((element2, index2) => {
              if (element2.day == day) {
                dayBool = true;
                dayIndex = index2;
                return false;
              }
            });
            return false;
          }
        });

        // 월매칭
        if (monthBool) {
          // 일매칭
          if (dayBool) {
            // 일 Insert
            inputData = data.action;
            inputArray[inputIndex][inputDetailIndex].detail[detailIndex].date[dayIndex].action.push(inputData);
          }
          else {
            // 월 Insert
            (inputData = {
              day,
              isChange: data.isChange,
              isPlaned: data.isPlaned,
              isVisited: data.isVisited,
              action: [data.action],
            }),
            (tempMonth = month);
            tempDay = day;

            inputArray[inputIndex][inputDetailIndex].size = inputArray[inputIndex][inputDetailIndex].size + 1;
            inputArray[inputIndex][inputDetailIndex].detail[detailIndex].date.push(inputData);
          }
        }
        else {
          // 일 matching
          inputData = {
            month,
            date: [
              {
                day,
                isChange: data.isChange,
                isPlaned: data.isPlaned,
                isVisited: data.isVisited,
                action: [data.action],
              },
            ],
          };

          tempMonth = month;
          tempDay = day;

          inputArray[inputIndex][inputDetailIndex].size = inputArray[inputIndex][inputDetailIndex].size + 1;
          inputArray[inputIndex][inputDetailIndex].detail.push(inputData);
        }
      }
    }
  });

  const arrays = inputArray.filter((item) => {
    return item.length !== 0;
  });

  return arrays;
}

// 간략히 보기 (월)
export function simpleDevide3(list, devide) {
  // return 될 Data Array
  const inputArray = new Array(devide);

  // return 될 Data Array 의 크기
  // 치과 한개의 Date가 30개 면 0 ,1 , 2 , 3 ,4 가 하나의 치과 데이터가 되고 Grid하나에 5개가 차기때문에 나머지 2Grid 에 할당해야함
  const inputArraySize = new Array(devide);

  let inputIndex = 0;
  // Insert할 List의 세부 순번
  let inputDetailIndex = 0;

  for (let i = 0; i < devide; i++) {
    inputArraySize[i] = 0;
    inputArray[i] = [];
  }

  let name = '';
  let overflow = false;
  let tempMonth = 0;
  const tempDay = 0;
  const maxSize = 4;
  const arraySize = 20;
  let inputData = {};
  let detailIndex = 0;

  list.forEach((data, index) => {
    // if (data.name != '(주)덴토존') return;

    const year = data.vstDt.substring(0, 4);
    let month = data.vstDt.slice(5, 7);
    let day = data.vstDt.slice(8, 10);

    // if (data.type != undefined) console.log(data.name, ' => ', data.type);

    if (month.slice(0, 1) == '0') { month = month.slice(1, 2); }
    if (day.slice(0, 1) == '0') { day = day.slice(1, 2); }

    name = '';
    inputDetailIndex = 0;
    overflow = false;
    for (var i = 0; i < inputArray.length; i++) {
      inputArray[i].forEach((element, index) => {
        if (element.name == data.name) {
          name = element.name;
          inputIndex = i; // Insert 할 List 순번
          inputDetailIndex = index; // Insert 할 List의 세부 순번

          if (element.size >= maxSize) { overflow = true; }
          return false;
        }
      });
    }

    // matching 되는 Array 가 없다면 새로운 ID 부여 Array ID에서 name으로 매칭
    if (name == '') {
      // 가장 작은 길이를 가진 배열 찾기
      inputIndex = lowArray2(inputArraySize, arraySize);

      inputData = {
        name: data.name,
        complete: data.complete,
        result: data.type,
        size: 1,
        detail: [
          {
            month,
            type: data.type,
            date: [
              {
                day,
                type: data.type,
                action: [
                  {
                    name: data.detailName,
                    type: data.detailType,
                  },
                ],
              },
            ],
          },
        ],
      };
      inputArray[inputIndex].push(inputData);
      inputArraySize[inputIndex] = inputArraySize[inputIndex] + 1;
    }
    else {
      // 기존에 있는 Array순번에 부여
      let newArray = true;

      if (overflow) {
        inputArray[inputIndex].forEach((element, index) => {
          if (element.size <= maxSize) {
            newArray = false;
            inputDetailIndex = index;
            return false;
          }
          inputDetailIndex = index;
        });
      }
      else {
        newArray = false;
      }

      if (tempMonth == month) { newArray = false; }

      // Name은 같으나 Maxsize에 넘어가서 새로운곳에 할당해야하는지?
      if (newArray) {
        inputData = {
          name: data.name,
          complete: data.complete,
          result: data.type,
          size: 1,
          detail: [
            {
              month,
              type: data.type,
              date: [
                {
                  day,
                  type: data.type,
                  action: [
                    {
                      name: data.detailName,
                      type: data.detailType,
                    },
                  ],
                },
              ],
            },
          ],
        };
        inputArray[inputIndex].push(inputData);
        inputArraySize[inputIndex] = inputArraySize[inputIndex] + 1;
      }
      else {
        let monthBool = false;
        let dayBool = false;

        // 같은 월 , 같은 일 인지 확인
        inputArray[inputIndex][inputDetailIndex].detail.forEach((element, index) => {
          if (element.month == month) {
            detailIndex = index;
            monthBool = true;
            element.date.forEach((element2) => {
              if (element2.day == day) {
                dayBool = true;
                return false;
              }
            });
            return false;
          }
        });

        // 날짜 중복 데이터는 Insert하지 않음
        if (!dayBool) {
          // Month이 중복이면 Day Add
          if (monthBool) {
            inputData = {
              day,
              type: data.detailType,
              action: [
                {
                  name: data.detailName,
                  type: data.detailType,
                },
              ],
            };

            tempMonth = month;
            inputArray[inputIndex][inputDetailIndex].detail[detailIndex].date.push(inputData);

            // Month Add
          }
          else {
            inputData = {
              month,
              type: data.type,
              date: [
                {
                  day,
                  type: data.type,
                  action: [
                    {
                      name: data.detailName,
                      type: data.detailType,
                    },
                  ],
                },
              ],
            };
            tempMonth = month;

            inputArray[inputIndex][inputDetailIndex].size = inputArray[inputIndex][inputDetailIndex].size + 1;
            inputArray[inputIndex][inputDetailIndex].detail.push(inputData);
          }
        }
      }
      // end newArray
    }
    // end Else
  });

  return inputArray;
}

// 간략히 보기 (활동)
export function simpleDevide4(list, devideSize, arraySize) {
  const inputArray = new Array(devideSize);
  let arrayIndex = 0;
  let inputData = {};
  const focusPropelItemList = [];

  for (let i = 0; i < devideSize; i++) {
    inputArray[i] = [];
  }

  for (const key in list) {
    // 틀
    inputData = {
      name: list[key][0].customerName,
      code: list[key][0].customerCode,
      complete: 0,
      result: list[key][0].saleCustomerDivisionCode,
      detail: [],
    };
    var month = '';
    var day = '';
    var detail = {};
    var overlap = -1;
    var type = '';
    var saleCheckCode = null;
    var focusPropelItem = [];
    var focusPropelItemGroup = [];

    list[key].forEach((item) => {
      focusPropelItem = [];
      overlap = -1; // 초기화
      month = item.visitDate.slice(5, 7);
      day = item.visitDate.slice(8, 10);

      // 실적 count
      item.actions.forEach((action) => {
        if (action.isActed) { inputData.complete++; }
        type = action.customerOpinionCode;
        if (action.saleCheckCode !== undefined) { saleCheckCode = action.saleCheckCode; }
      });

      // 고객의견코드 push
      item.taskVisitActionExecutions.forEach((action) => {
        if (action.actionName != undefined) {
          // if (action.focusPropelItemYn == 'Y') {
          // 일별 중점추진품목 filter
          if (!focusPropelItem.includes(action.actionName)) { focusPropelItem.push(action.actionName); }
          // 월별 중점추진품목 filter
          if (!focusPropelItemGroup.includes(action.actionName)) { focusPropelItemGroup.push(action.actionName); }
          // 전체 중점추진품목 filter
          if (!focusPropelItemList.includes(action.actionName)) { focusPropelItemList.push(action.actionName); }
          // }
        }
      });

      overlap = inputData.detail.findIndex(data => data.month == month);

      if (overlap == -1) {
        detail = {
          month,
          focusPropelItemGroup,
          date: [
            {
              day,
              type,
              focusPropelItem,
              saleCheckCode,
            },
          ],
        };
        inputData.detail.push(detail);
      }
      else {
        const date = {
          day,
          type,
          focusPropelItem,
          saleCheckCode,
        };
        inputData.detail[overlap].date.push(date);
      }
    });

    if (inputArray[arrayIndex].length == arraySize) { arrayIndex++; }

    inputArray[arrayIndex].push(inputData);
  }

  return { list: inputArray, focusItem: focusPropelItemList };
}

// 간략히 보기 (활동) [거래처 기준]
export function simpleDevide5(list, devideSize, arraySize) {
  const inputArray = new Array(devideSize);
  let arrayIndex = 0;
  let inputData = {};
  const focusPropelItemList = [];

  for (let i = 0; i < devideSize; i++) {
    inputArray[i] = [];
  }

  for (const key in list) {
    // 틀
    inputData = {
      name: list[key][0].customerName,
      code: list[key][0].customerCode,
      complete: 0,
      customerStatusCode: list[key][0].customerStatusCode,
      result: list[key][0].saleCustomerDivisionCode,
      detail: [],
    };

    var visitDate = '';
    var month = '';
    var day = '';
    var detail = {};
    var overlap = -1;
    var type = '';
    var saleCheckCode = null;
    // var focusPropelItem = [];
    // var focusPropelItemGroup = [];

    list[key].forEach((item) => {
      // focusPropelItem = [];
      overlap = -1; // 초기화

      if (item.executeDate != undefined) {
        visitDate = getDateFormat('ymd', dayjs(item.executeDate));
        month = visitDate.slice(5, 7);
        day = visitDate.slice(8, 10);

        // 실적 count
        // item.actions.forEach((action) => {
        //   if (action.isActed) inputData.complete++;
        //   type = action.customerOpinionCode;
        //   if (action.saleCheckCode !== undefined) saleCheckCode = action.saleCheckCode;
        // });

        // 실적 count
        if (item.planActionYn) { inputData.complete++; }
        type = item.customerOpinionCode;
        if (item.saleCheckCode !== undefined) { saleCheckCode = item.saleCheckCode; }

        // 고객의견코드 push
        // if (item.actionName != undefined) {
        //   // if (action.focusPropelItemYn == 'Y') {
        //   // 일별 중점추진품목 filter
        //   if (!focusPropelItem.includes(item.actionName)) focusPropelItem.push(item.actionName);
        //   // 월별 중점추진품목 filter
        //   if (!focusPropelItemGroup.includes(item.actionName)) focusPropelItemGroup.push(item.actionName);
        //   // 전체 중점추진품목 filter
        //   if (!focusPropelItemList.includes(item.actionName)) focusPropelItemList.push(item.actionName);
        //   // }
        // }

        overlap = inputData.detail.findIndex(data => data.month == month);

        if (overlap == -1) {
          detail = {
            month,
            // focusPropelItemGroup: focusPropelItemGroup,
            date: [
              {
                day,
                type,
                // focusPropelItem: focusPropelItem,
                saleCheckCode,
              },
            ],
          };
          inputData.detail.push(detail);
        }
        else {
          const date = {
            day,
            type,
            // focusPropelItem: focusPropelItem,
            saleCheckCode,
          };
          inputData.detail[overlap].date.push(date);
        }
      }
    });

    if (inputArray[arrayIndex].length == arraySize) { arrayIndex++; }

    inputArray[arrayIndex].push(inputData);
  }

  return { list: inputArray };
}

function lowArray(list) {
  // 최소값 찾기r
  const min = Math.min(...list);
  // 최소값 위치 반환
  return list.indexOf(min);
}

function lowArray2(list, size) {
  // 최소값 찾기
  let check = false;
  for (let i = 0; i < list.length; i++) {
    check = true;
    if (list[i] < size) {
      check = false;
      return i;
    }
  }
  // if (check) return false;
}

function idArray(inputArray, listId) {
  // ID 값 매칭
  for (let i = 0; i < inputArray.length; i++) {
    if (inputArray[i].id == listId) { return i; }
  }
  return false;
}

function insertArray(list) {}

function leftPad(value) {
  if (value >= 10) {
    return value;
  }

  return `0${value}`;
}

function toStringByFormatting(source, delimiter = '-') {
  const year = source.getFullYear();
  const month = leftPad(source.getMonth() + 1);
  const day = leftPad(source.getDate());

  return [year, month, day].join(delimiter);
}

function serialize(list) {
  const result = [];
  let insert = {};
  list.forEach((element) => {
    if (element.actions.length == 0) {
      insert = {
        name: element.customerName,
        visitDate: element.visitDate,
        isAdd: element.isAdd,
        isChange: element.isChange,
        isPlaned: element.isPlaned,
        isVisited: element.isVisited,
        action: [],
        employeeNumber: element.employeeNumber,
        jobDutyCode: element.jobDutyCode,
      };

      result.push(insert);
    }
    else {
      element.actions.forEach((action) => {
        insert = {
          name: element.customerName,
          visitDate: element.visitDate,
          isAdd: element.isAdd,
          isChange: element.isChange,
          isPlaned: element.isPlaned,
          isVisited: element.isVisited,
          action,
          employeeNumber: element.employeeNumber,
          jobDutyCode: element.jobDutyCode,
        };
        result.push(insert);
      });
    }
  });
  return result;
}

// 계획 , 실적 Data 가공

export function vistiActionDate(list) {
  const result = [];
  let insert = {};
  const setTime = 0;
  list.plan.list.forEach((data, index) => {
    const conData = toStringByFormatting(new Date(data.visitDate)).toString();

    if (data.customerName == '') { return false; }

    const action = [];
    const actionName = [];
    data.actionList.forEach((item) => {
      action.push(item.actionAliasName);
      actionName.push(item.actionName);
    });

    // var endTime = new Date(data.visitDt + ' ' + data.visitTime);
    // endTime = endTime.setHours(endTime.getHours() + data.actionTime);
    // 30분일때 0.5로 pasing
    // if(data.actionTime < 1) endTime.setMinutes(endTime.getMinutes() + data.actionTime);
    // else endTime.setHours(endTime.getHours() + data.actionTime);

    // new Date('2022.05.20 10:30:20');

    insert = {
      id: index,
      actions: action,
      actionsName: actionName,
      startDate: new Date(`${conData} ${data.visitTime}`),
      endDate: new Date(`${conData} ${data.endTime}`),
      endTime: data.endTime,
      isPlanned: false,
      statusId: 2,
      text: data.customerName,
    };

    result.push(insert);
  });

  return result;
}

// 지점장 2주 Header
export function resultBmHeader(list, fromDate, toDate) {
  const curr = new Date(fromDate);
  const end = new Date(toDate);

  const gridWidth = '*';
  // let gridWidth = "38px";
  const dateWidth = '68';
  const timeWidth = '37.64'; // 37.64
  const result = [];
  let insert = { cellType: 'customize-time', dataField: 'sp0', caption: '시간', width: timeWidth, alignment: 'center' };

  result.push(insert);

  // var resultA = list.filter((item1, idx1) => {
  //   return (
  //     list.findIndex((item2) => {
  //       return item1.employeeName == item2.employeeName;
  //     }) == idx1
  //   );
  // });

  let idx = 0;
  let id = 0;
  while (curr <= end) {
    insert = { caption: toStringByFormatting(new Date(curr)).toString(), width: gridWidth, children: [] };

    list.forEach((element, index) => {
      insert.children.push({
        cellType: 'customize',
        // dataField: 'sp' + id,
        dataField: `sp${element.employeeNumber}_${toStringByFormatting(new Date(curr)).toString()}`,
        // dataField: 'sp' + (index + 1) + '-' + idx,
        caption: element.userName,
        width: gridWidth,
        employeeNumber: element.employeeNumber,
      });
    });
    id++;
    curr.setDate(new Date(curr.getDate() + 1));
    result.push(insert);
    idx++;
    if (idx == 5) { break; }
  }

  return result;
}

export function mainBmData(mainBm, fromDate, toDate, data) {
  const curr = new Date(fromDate);
  const end = new Date(toDate);

  const group = groupBy(data.union, item => dayjs(item.startDate).format('HH:mm:ss').substring(0, 5));

  let timeKey = '';
  let groupData = [];

  const result = [];

  const time = [
    ['09 : 00', '09 : 30'],
    ['10 : 00', '10 : 30'],
    ['11 : 00', '11 : 30'],
    ['12 : 00', '12 : 30'],
    ['13 : 00', '13 : 30'],
    ['14 : 00', '14 : 30'],
    ['15 : 00', '15 : 30'],
    ['16 : 00', '16 : 30'],
    ['17 : 00', '17 : 30'],
  ];
  for (let index = 0; index < time.length; index++) {
    const temp = {};

    for (const item of mainBm) {
      if (item.children && !item.dataField) {
        for (const i of item.children) {
          var day = i.dataField.split('_')[1];
          var insert = '';
          const half = false;

          time[index].forEach((times) => {
            let groupFilter = [];
            let dayFilter = [];
            // 시간 Key Header
            timeKey = times.replace(/ /g, '');
            // Key Header Data
            // console.log('timeKey => ', timeKey);
            groupData = group[timeKey];
            // console.log('groupData', groupData);
            if (groupData != undefined) {
              groupFilter = groupData.filter(e => e.employeeNumber == i.employeeNumber);

              if (groupFilter.length != 0) {
                dayFilter = groupFilter.filter(e => e.visitDate == day);
                if (dayFilter.length != 0) {
                  if (insert != '') {
                    // console.log('insert ==>> ', insert.lenght);
                    const temp = insert.data;
                    // insert.data[1] = dayFilter;
                    temp.push(dayFilter[0]);
                    insert.data = temp;
                    // insert.data[1] = dayFilter[0];
                  }
                  else {
                    dayFilter.reverse();
                    const result = dayFilter.filter((item1, idx1) => {
                      return (
                        dayFilter.findIndex((item2, idx2) => {
                          return (
                            dayjs(item1.startDate).format('HH:mm:ss').substring(0, 5)
                            == dayjs(item2.startDate).format('HH:mm:ss').substring(0, 5)
                          );
                        }) == idx1
                      );
                    });
                    result.reverse();
                    dayFilter = result;

                    insert = {
                      id: `${i.dataField}-${index}`,
                      employeeNumber: i.employeeNumber,
                      visitTime: `${day} ${timeKey}:00`,
                      data: dayFilter,
                    };
                  }
                }
              }
            }
          });

          // console.log('insert=>');
          // console.log(insert);

          if (insert == '') {
            insert = {
              id: `${i.dataField}-${index}`,
              employeeNumber: i.employeeNumber,
              visitTime: `${day} ${timeKey}:00`,
            };
          }

          temp[i.dataField] = insert;

          // if (index == 0 && i.employeeNumber == '12101301' && timeKey == '09:00') {
          //   console.log('here');
          //   console.log(temp[i.dataField]);
          //   temp[i.dataField] = [
          //     {
          //       id: i.dataField + '-' + index,
          //       ...res,
          //     },
          //     {
          //       id: i.dataField + '-' + index,
          //       ...res,
          //     },
          //   ];
          //   console.log(temp[i.dataField]);
          // }
        }
      }
      else {
        // 시간 make
        if (item.dataField == 'sp0') {
          temp[item.dataField] = time[index];
        }
      }
      // console.log('temp => ', temp);
    }
    // console.log('result => ', result);

    result.push(temp);
  }

  result.forEach;

  return result;
}

// 지점별 5개씩 Grid
export function weeklyColumHm(item, empInx, gridSize) {
  const forSize = (empInx + 1) * gridSize;
  const empList = cloneDeep(item);
  const myself = empList.filter(e => e.organizationLevelNumber === 2);
  const another = empList.filter(e => e.organizationLevelNumber === 4);
  const group = groupBy(another, 'organizationName');
  const groupData = [];
  let index = 0;
  let forIndex = 0;
  for (const key in group) {
    if (empInx * gridSize <= forIndex && forIndex < forSize) {
      groupData.push({
        caption: key,
        children: [],
        width: '*',
      });

      group[key].map((element) => {
        groupData[index].children.push({
          caption: element.userName,
          cellType: 'hover',
          dataField: `sp${element.employeeNumber}`,
          width: '*',
        });
      });

      index++;
    }
    forIndex++;
  }

  return concat(
    {
      caption: '일자',
      dataField: 'vstPlnDt',
      width: dateWidth,
      alignment: 'center',
      allowMerge: true,
      cellType: 'customize',
    },
    {
      caption: '시간',
      dataField: 'vstPlnHh',
      width: timeWidth,
      alignment: 'center',
      allowMerge: true,
    },
    {
      caption: myself[0].organizationName,
      cellType: 'hover',
      dataField: `sp${myself[0].employeeNumber}`,
      width: '*',
    },
    groupData,
  );
}

// 지점 상관없이 20명씩 사원별 Filter
export function weeklyColumHm2(item, empInx, gridInit) {
  const forInx = empInx * gridInit;
  const forSize = (empInx + 1) * gridInit;
  const empList = cloneDeep(item);
  const myself = empList.filter(e => e.organizationLevelNumber === 2);
  const another = empList.filter(e => e.organizationLevelNumber === 4);

  let group = [];
  another.map((e, inx) => {
    if (forInx <= inx && inx < forSize) {
      group.push(e);
    }
  });
  const width = '*';

  group = groupBy(group, 'organizationName');
  const groupData = [];
  let index = 0;
  for (const key in group) {
    groupData.push({
      caption: key,
      children: [],
      width,
      headerType: 'customize',
    });

    group[key].map((element) => {
      groupData[index].children.push({
        caption: element.userName,
        cellType: 'hover',
        dataField: `sp${element.employeeNumber}`,
        width,
      });
    });

    index++;
  }

  let self = '';
  if (myself.length > 0) {
    if (myself[0].employeeNumber != undefined) {
      self = {
        caption: myself[0].organizationName,
        cellType: 'hover',
        dataField: `sp${myself[0].employeeNumber}`,
        width,
      };
    }
  }

  let size = 0;
  groupData.map((element) => {
    size += element.children.length;
  });

  if (size < gridInit) {
    while (size < gridInit) {
      groupData.push({
        caption: '',
        cellType: 'hover',
        dataField: '',
        width,
      });
      size++;
    }
  }

  if (self != '') {
    return concat(
      {
        caption: '일자',
        dataField: 'vstPlnDt',
        width: dateWidth,
        alignment: 'center',
        allowMerge: true,
        cellType: 'customize',
      },
      {
        caption: '시간',
        dataField: 'vstPlnHh',
        width: timeWidth,
        alignment: 'center',
        allowMerge: true,
      },
      self,
      groupData,
    );
  }
  else {
    return concat(
      {
        caption: '일자',
        dataField: 'vstPlnDt',
        width: dateWidth,
        alignment: 'center',
        allowMerge: true,
        cellType: 'customize',
      },
      {
        caption: '시간',
        dataField: 'vstPlnHh',
        width: timeWidth,
        alignment: 'center',
        allowMerge: true,
      },
      groupData,
    );
  }
}

// 지점별 Grid
export function weeklyDataHm(empList, planResultList, unionList, dateList, empInx, gridSize) {
  const plan = [];
  const result = [];
  const union = [];
  const date = cloneDeep(dateList);
  let day;
  const days = [];
  let idx = 0;
  const empGrp = [];
  const forSize = (empInx + 1) * gridSize;
  let forIndex = 0;
  empGrp.push(empList[0]);

  const another = empList.filter(e => e.organizationLevelNumber === 4);
  const group = groupBy(another, 'organizationName');

  for (const key in group) {
    if (empInx * gridSize <= forIndex && forIndex < forSize) {
      group[key].map((element) => {
        empGrp.push(element);
      });
    }
    forIndex++;
  }

  while (true) {
    // 토 일 jump
    if (idx != 5 && idx != 6) {
      day = new Date(date.fromDate);
      day.setDate(day.getDate() + idx);
      days.push(dayjs(day, 'YYYY-MM-DD'));
    }
    idx++;
    if (idx == 12) { break; }
  }

  for (let i = 0; i < 3; i++) {
    var list = [];
    var type = '';
    if (i == 0) {
      list = cloneDeep(planResultList.plan);
      type = 'plan';
    }
    else if (i == 1) {
      list = cloneDeep(planResultList.result);
      type = 'result';
    }
    else if (i == 2) {
      list = cloneDeep(unionList);
      type = 'union';
    }

    days.map((date, dIdx) => {
      timeList5.map((time) => {
        const temp = {};
        temp.vstPlnDt = getDateFormat('mdd', date);
        temp.vstPlnHh = time;
        empGrp.map((emp) => {
          const group = groupBy(list, 'employeeNumber');

          let filterData2 = [];

          if (group[emp.employeeNumber] != undefined) {
            if (i == 0) {
              // plan
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  && e.planTime.substr(0, 2) == time.substr(0, 2),
              );
            }
            else if (i == 1) {
              // result
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  && e.executeTime.substr(0, 2) == time.substr(0, 2),
              );
            }
            else if (i == 2) {
              // union
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  && e.startTime.substr(0, 2) == time.substr(0, 2),
              );

              if (filterData2.length == 2) {
                filterData2 = filterData2.reverse();
                filterData2[0].notPlanVisit = false;
                if (filterData2[0].startTime == filterData2[1].startTime) {
                  if (Object.keys(filterData2[0]).includes('executeTime')) {
                    filterData2.pop();
                  }
                  else { filterData2.shift(); }

                  filterData2[0].notPlanVisit = true;
                }
                // filterData2[0]
              }
              // 그럴리 없겠지만 굳이 30분 단위로 방문계획을 세운후 2번다 계획과 2번다 다른곳을 방문한 경우
              else if (filterData2.length == 4) {
                filterData2[0].notPlanVisit = false;
                for (let over = 1; over < filterData2.length; over++) {}

                if (filterData2[0].startTime == filterData2[1].startTime) {
                  if (Object.keys(filterData2[0]).includes('executeTime')) {
                    filterData2.pop();
                  }
                  else { filterData2.shift(); }

                  filterData2[0].notPlanVisit = true;
                }
                // filterData2[0]
              }
            }
          }

          // 없을시 빈칸만들기
          if (filterData2.length == 0) {
            temp[`sp${emp.employeeNumber}`] = {
              visitDate: dayjs(date, 'YYYY-MM-DD'),
              visitTime: time,
              spNum: `sp${emp.employeeNumber}`,
              // custName: emp.customerName,
              isEmpty: true,
              type,
            };
          }
          else {
            let custName = '';
            let isVisit = '';
            let isPlaned = '';
            let isPassed = '';
            let notPlanVisit = '';
            let checkTargetYn = 'N';
            let code = '';
            if (filterData2.length > 1) {
              custName = `${filterData2[0].customerName}||${filterData2[1].customerName}`;
              code = `${filterData2[0].customerCode}||${filterData2[1].customerCode}`;
              isVisit = filterData2[0].isVisited
                ? 'visit'
                : `notVisit` + `||${filterData2[1].isVisit}`
                  ? 'visit'
                  : 'notVisit';
              isPlaned = filterData2[0].isPlaned
                ? 'planed'
                : `notPlaned` + `||${filterData2[1].isPlaned}`
                  ? 'planed'
                  : 'notPlaned';
              isPassed = filterData2[0].isPassed
                ? 'passed'
                : `notPassed` + `||${filterData2[1].isPassed}`
                  ? 'passed'
                  : 'notPassed';
              checkTargetYn
                = filterData2[0].checkTargetYn == 'Y'
                  ? 'Y'
                  : `N` + `||${filterData2[1].checkTargetYn}` == 'Y'
                    ? 'Y'
                    : 'N';
              notPlanVisit
                = filterData2[0].notPlanVisit == true
                  ? 'Y'
                  : `N` + `||${filterData2[1].notPlanVisit}` == true
                    ? 'Y'
                    : 'N';
            }
            else {
              custName = filterData2[0].customerName;
              code = filterData2[0].customerCode;
              isVisit = filterData2[0].isVisited ? 'visit' : 'notVisit';
              isPlaned = filterData2[0].isPlaned ? 'planed' : 'notPlaned';
              isPassed = filterData2[0].isPassed ? 'passed' : 'notPassed';
              notPlanVisit = filterData2[0].notPlanVisit ? 'Y' : 'N';
              checkTargetYn = filterData2[0].checkTargetYn == 'Y' ? 'Y' : 'N';
            }

            // if (filterData2[0].notPlanVisit) console.log('ddoop  =>', filterData2[0]);

            temp[`sp${emp.employeeNumber}`] = {
              visitDate: dayjs(date, 'YYYY-MM-DD'),
              visitTime: time,
              spNum: `sp${emp.employeeNumber}`,
              custName,
              code,
              isVisit,
              isPlaned,
              isPassed,
              isEmpty: false,
              type,
              checkTargetYn,
              notPlanVisit,
              endDate: filterData2[0].endDate,
            };
          }
        });

        if (i == 0) { plan.push(temp); }
        else if (i == 1) { result.push(temp); }
        else if (i == 2) { union.push(temp); }
      });
    });
  }

  // console.log('result => ', resultData);
  return { plan, result, union };
}

// 사원별 Count 갯수 별 Grid
export function weeklyDataHm2(empList, planResultList, unionList, dateList, empInx, gridInit) {
  const plan = [];
  const result = [];
  const union = [];
  const date = cloneDeep(dateList);
  let day;
  const days = [];
  let idx = 0;
  const empGrp = [];
  const forInx = empInx * gridInit;
  const forSize = (empInx + 1) * gridInit;
  if (empList[0].employeeNumber != undefined) { empGrp.push(empList[0]); }
  const another = empList.filter(e => e.organizationLevelNumber === 4);

  another.map((e, inx) => {
    if (forInx <= inx && inx < forSize) {
      empGrp.push(e);
    }
  });

  while (true) {
    // 토 일 jump
    if (idx != 5 && idx != 6) {
      day = new Date(date.fromDate);
      day.setDate(day.getDate() + idx);
      days.push(dayjs(day, 'YYYY-MM-DD'));
    }
    idx++;
    if (idx == 12) { break; }
  }

  for (let i = 0; i < 3; i++) {
    var list = [];
    var type = '';
    if (i == 0) {
      list = cloneDeep(planResultList.plan);
      type = 'plan';
    }
    else if (i == 1) {
      list = cloneDeep(planResultList.result);
      type = 'result';
    }
    else if (i == 2) {
      list = cloneDeep(unionList).union;
      type = 'union';
    }

    days.map((date, dIdx) => {
      // timeList5.map((time) => {
      timeList6.map((time) => {
        const temp = {};
        temp.vstPlnDt = getDateFormat('mdd', date);
        temp.vstPlnHh = time;
        empGrp.map((emp) => {
          const group = groupBy(list, 'employeeNumber');

          let filterData2 = [];

          if (group[emp.employeeNumber] != undefined) {
            if (i == 0) {
              // plan
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  && e.planTime.substr(0, 2) == time.substr(0, 2),
              );
            }
            else if (i == 1) {
              // result
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  // e.executeTime.substr(0, 2) == time.substr(0, 2)
                  && dayjs(e.startDate).format('HH') == time.substr(0, 2),
              );

              // if (filterData2 == []) {
              // console.log(dayjs(e.startDate).format('HH:mm'));
              // console.log(group[emp.employeeNumber]);

              // var filterTemp = filter(
              //   group[emp.employeeNumber],
              //   (e) =>
              //     getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date) &&
              //     dayjs(e.startDate).format('HH:mm').substr(0, 2) == time.substr(0, 2) &&
              //     e.saleCustomerDivisionCode == 'CUST_03'
              // );
              // console.log(filterTemp);
              // }
            }
            else if (i == 2) {
              // console.log('check!!');
              // console.log(group[emp.employeeNumber]);
              // console.log(dayjs(group[emp.employeeNumber][0].startDate).format('HH'));
              // dayjs(e.startDate).format('HH')
              // union
              filterData2 = filter(
                group[emp.employeeNumber],
                e =>
                  getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date)
                  && dayjs(e.startDate).format('HH') == time.substr(0, 2),
              );

              if (filterData2.length == 2) {
                filterData2[0].notPlanVisit = false;
                if (
                  dayjs(filterData2[0].startDate).format('HH:mm') == dayjs(filterData2[1].startDate).format('HH:mm')
                ) {
                  if (Object.keys(filterData2[0]).includes('executeTime')) {
                    filterData2.pop();
                  }
                  else { filterData2.shift(); }

                  filterData2[0].notPlanVisit = true;
                }
              }
              else if (filterData2.length == 3) {
                const time1 = dayjs(filterData2[0].startDate).format('HH:mm');
                const time2 = dayjs(filterData2[1].startDate).format('HH:mm');
                const time3 = dayjs(filterData2[2].startDate).format('HH:mm');
                const end1 = dayjs(filterData2[0].endDate).format('HH:mm');
                const end2 = dayjs(filterData2[1].endDate).format('HH:mm');
                const end3 = dayjs(filterData2[2].endDate).format('HH:mm');
                filterData2[0].notPlanVisit = false;
                if (time1 == time2) {
                  if (Object.keys(filterData2[0]).includes('executeTime')) {
                    // 1번방 배열 삭제
                    filterData2[1] = cloneDeep(filterData2[2]);
                    filterData2[0].notPlanVisit = true;
                    filterData2.pop();
                  }
                  else {
                    if (end1 == end3) { filterData2[2].notPlanVisit = true; }

                    // 0번방 배열 삭제
                    filterData2[0] = cloneDeep(filterData2[1]);
                    filterData2[1] = cloneDeep(filterData2[2]);
                    filterData2[0].notPlanVisit = true;
                    filterData2.pop();
                  }
                }
                else if (time1 == time3) {
                  if (Object.keys(filterData2[0]).includes('executeTime')) {
                    // 2번방 배열 삭제
                    filterData2[0].notPlanVisit = true;
                    filterData2.pop();
                  }
                  else {
                    // 0번방 배열 삭제
                    filterData2[0] = cloneDeep(filterData2[1]);
                    filterData2[1] = cloneDeep(filterData2[2]);
                    filterData2[1].notPlanVisit = true;
                    filterData2.pop();
                  }
                }
                else if (time2 == time3) {
                  if (Object.keys(filterData2[1]).includes('executeTime')) {
                    // 2번방 배열 삭제
                    filterData2[1].notPlanVisit = true;
                    filterData2.pop();
                  }
                  else {
                    // 0번방 배열 삭제
                    filterData2[1] = cloneDeep(filterData2[2]);
                    filterData2[1].notPlanVisit = true;
                    filterData2.pop();
                  }
                }
              }
              // 그럴리 없겠지만 굳이 30분 단위로 방문계획을 세운후 2번다 계획과 2번다 다른곳을 방문한 경우
              else if (filterData2.length == 4) {
                filterData2[0] = cloneDeep(filterData2[2]);
                filterData2[1] = cloneDeep(filterData2[3]);

                filterData2[0].notPlanVisit = true;
                filterData2[1].notPlanVisit = true;

                filterData2.pop();
                filterData2.pop();
              }
            }
          }

          // 없을시 빈칸만들기
          if (filterData2.length == 0) {
            temp[`sp${emp.employeeNumber}`] = {
              visitDate: dayjs(date, 'YYYY-MM-DD'),
              visitTime: time,
              spNum: `sp${emp.employeeNumber}`,
              // custName: emp.customerName,
              isEmpty: true,
              type,
            };
          }
          else {
            let custName = '';
            let isVisit = '';
            let isPlaned = '';
            let isPassed = '';
            let notPlanVisit = '';
            let checkTargetYn = 'N';
            let code = '';
            let saleCustomerDivisionCode = '';
            let endDate = '';
            let isHalf = false;
            if (filterData2.length == 2) {
              custName = `${filterData2[0].customerName}||${filterData2[1].customerName}`;
              code = `${filterData2[0].customerCode}||${filterData2[1].customerCode}`;
              const visit1 = filterData2[0].isVisited ? 'visit' : 'notVisit';
              const visit2 = filterData2[1].isVisited ? 'visit' : 'notVisit';
              isVisit = `${visit1}||${visit2}`;
              // isVisit = isVisit + filterData2[1].isVisited ? 'visit' : 'notVisit';
              const plan1 = filterData2[0].isPlaned ? 'planed' : 'notPlaned';
              const plan2 = filterData2[1].isPlaned ? 'planed' : 'notPlaned';
              isPlaned = `${plan1}||${plan2}`;
              const pass1 = filterData2[0].isPassed ? 'passed' : 'notPassed';
              const pass2 = filterData2[1].isPassed ? 'passed' : 'notPassed';
              isPassed = `${pass1}||${pass2}`;
              const check1 = filterData2[0].checkTargetYn == 'Y' ? 'Y' : 'N';
              const check2 = filterData2[1].checkTargetYn == 'Y' ? 'Y' : 'N';
              checkTargetYn = `${check1}||${check2}`;
              const notvisit1 = filterData2[0].notPlanVisit ? 'Y' : 'N';
              const notvisit2 = filterData2[1].notPlanVisit ? 'Y' : 'N';
              notPlanVisit = `${notvisit1}||${notvisit2}`;
              saleCustomerDivisionCode
                = `${filterData2[0].saleCustomerDivisionCode}||${filterData2[1].saleCustomerDivisionCode}`;
              endDate = `${filterData2[0].endDate}||${filterData2[1].endDate}`;
              isHalf = true;
            }
            else {
              custName = filterData2[0].customerName;
              code = filterData2[0].customerCode;
              isVisit = filterData2[0].isVisited ? 'visit' : 'notVisit';
              isPlaned = filterData2[0].isPlaned ? 'planed' : 'notPlaned';
              isPassed = filterData2[0].isPassed ? 'passed' : 'notPassed';
              notPlanVisit = filterData2[0].notPlanVisit ? 'Y' : 'N';
              checkTargetYn = filterData2[0].checkTargetYn == 'Y' ? 'Y' : 'N';
              saleCustomerDivisionCode = filterData2[0].saleCustomerDivisionCode;
              endDate = filterData2[0].endDate;

              // 하나라도 30분짜리가 있으면 grid 절반으로 보여야함
              if (
                dayjs(filterData2[0].startDate).format('mm') == '30'
                || dayjs(filterData2[0].endDate).format('mm') == '30'
              ) {
                isHalf = true;

                if (dayjs(filterData2[0].startDate).format('mm') == '30') {
                  custName = `` + `||${filterData2[0].customerName}`;
                  isVisit = `` + `||${isVisit}`;
                }
              }
            }

            // if (filterData2[0].notPlanVisit) console.log('ddoop  =>', filterData2[0]);

            temp[`sp${emp.employeeNumber}`] = {
              visitDate: dayjs(date, 'YYYY-MM-DD'),
              visitTime: time,
              spNum: `sp${emp.employeeNumber}`,
              custName,
              code,
              isVisit,
              isPlaned,
              isPassed,
              isEmpty: false,
              type,
              checkTargetYn,
              notPlanVisit,
              endDate,
              saleCustomerDivisionCode,
              isHalf,
            };
          }
        });

        if (i == 0) { plan.push(temp); }
        else if (i == 1) { result.push(temp); }
        else if (i == 2) { union.push(temp); }
      });
    });
  }

  // console.log('result => ', resultData);
  return { plan, result, union };
}

// 지점 상관없이 20명씩 사원별 Filter
export function weeklyColumHm3(item, empInx, gridInit) {
  const forInx = empInx * gridInit;
  const forSize = (empInx + 1) * gridInit;
  const empList = cloneDeep(item);
  const myself = empList.filter(e => e.organizationLevelNumber === 2);
  const another = empList.filter(e => e.organizationLevelNumber === 4);

  let group = [];
  another.map((e, inx) => {
    if (forInx <= inx && inx < forSize) {
      group.push(e);
    }
  });
  const width = '*';

  group = groupBy(group, 'organizationName');
  const groupData = [];
  let index = 0;
  for (const key in group) {
    groupData.push({
      caption: key,
      children: [],
      width,
      headerType: 'customize',
    });

    group[key].map((element) => {
      groupData[index].children.push({
        caption: element.userName,
        cellType: 'hover',
        dataField: `sp${element.employeeNumber}`,
        width,
      });
    });

    index++;
  }

  let self = '';
  if (myself.length > 0) {
    if (myself[0].employeeNumber != undefined) {
      self = {
        caption: myself[0].organizationName,
        cellType: 'hover',
        dataField: `sp${myself[0].employeeNumber}`,
        width,
      };
    }
  }

  let size = 0;
  groupData.map((element) => {
    size += element.children.length;
  });

  if (size < gridInit) {
    while (size < gridInit) {
      groupData.push({
        caption: '',
        cellType: 'hover',
        dataField: '',
        width,
      });
      size++;
    }
  }

  if (self != '') {
    return concat(
      {
        caption: '일자',
        dataField: 'vstPlnDt',
        width: dateWidth,
        alignment: 'center',
        allowMerge: true,
        cellType: 'customize',
      },
      // {
      //   caption: '시간',
      //   dataField: 'vstPlnHh',
      //   width: timeWidth,
      //   alignment: 'center',
      //   allowMerge: true,
      // },
      self,
      groupData,
    );
  }
  else {
    return concat(
      {
        caption: '일자',
        dataField: 'vstPlnDt',
        width: dateWidth,
        alignment: 'center',
        allowMerge: true,
        cellType: 'customize',
      },
      {
        caption: '시간',
        dataField: 'vstPlnHh',
        width: timeWidth,
        alignment: 'center',
        allowMerge: true,
      },
      groupData,
    );
  }
}

function categoryNum(num) {
  return CATEGORY[num];
}

// 사원별 Count 갯수 별 Grid
export function weeklyDataHm3(empList, planResultList, unionList, dateList, empInx, gridInit, categoryCode) {
  const useFilterComp = useFilterGroupToggleComp();
  const plan = [];
  const result = [];
  const union = [];
  const date = cloneDeep(dateList);
  let day;
  const days = [];
  let idx = 0;
  const empGrp = [];
  const forInx = empInx * gridInit;
  const forSize = (empInx + 1) * gridInit;
  if (empList[0].employeeNumber != undefined) { empGrp.push(empList[0]); }
  const another = empList.filter(e => e.organizationLevelNumber === 4);

  another.map((e, inx) => {
    if (forInx <= inx && inx < forSize) {
      empGrp.push(e);
    }
  });

  while (true) {
    // 토 일 jump
    if (idx != 5 && idx != 6) {
      day = new Date(date.fromDate);
      day.setDate(day.getDate() + idx);
      days.push(dayjs(day, 'YYYY-MM-DD'));
    }
    idx++;
    if (idx == 12) { break; }
  }

  for (let i = 0; i < 3; i++) {
    var list = [];
    var type = '';
    if (i == 0) {
      list = cloneDeep(planResultList.plan);
      type = 'plan';
    }
    else if (i == 1) {
      list = cloneDeep(planResultList.result);
      type = 'result';
    }
    else if (i == 2) {
      list = cloneDeep(unionList).union;
      type = 'union';
    }

    days.map((date, dIdx) => {
      const temp = {};
      temp.vstPlnDt = getDateFormat('mdd', date);
      // temp['vstPlnHh'] = time;
      empGrp.map((emp) => {
        let category = 0;
        const group = groupBy(list, 'employeeNumber');

        let filterData2 = [];

        if (group[emp.employeeNumber] != undefined) {
          filterData2 = filter(
            group[emp.employeeNumber],
            e => getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date),
          );

          if (i == 0) {
            // plan
            filterData2 = filter(
              group[emp.employeeNumber],
              e => getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date),
            );
          }
          else if (i == 1) {
            // result
            filterData2 = filter(
              group[emp.employeeNumber],
              e => getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date),
            );
          }
          else if (i == 2) {
            // union
            filterData2 = filter(
              group[emp.employeeNumber],
              e => getDateFormat('ymd', e.visitDate) == getDateFormat('ymd', date),
            );

            // if (filterData2.length == 2) {
            //   filterData2[0].notPlanVisit = false;
            //   if (
            //     dayjs(filterData2[0].startDate).format('HH:mm') == dayjs(filterData2[1].startDate).format('HH:mm')
            //   ) {
            //     if (Object.keys(filterData2[0]).includes('executeTime')) filterData2.pop();
            //     else filterData2.shift();

            //     filterData2[0].notPlanVisit = true;
            //   }
            // } else if (filterData2.length == 3) {
            //   var time1 = dayjs(filterData2[0].startDate).format('HH:mm');
            //   var time2 = dayjs(filterData2[1].startDate).format('HH:mm');
            //   var time3 = dayjs(filterData2[2].startDate).format('HH:mm');
            //   var end1 = dayjs(filterData2[0].endDate).format('HH:mm');
            //   var end2 = dayjs(filterData2[1].endDate).format('HH:mm');
            //   var end3 = dayjs(filterData2[2].endDate).format('HH:mm');
            //   filterData2[0].notPlanVisit = false;
            //   if (time1 == time2) {
            //     if (Object.keys(filterData2[0]).includes('executeTime')) {
            //       // 1번방 배열 삭제
            //       filterData2[1] = cloneDeep(filterData2[2]);
            //       filterData2[0].notPlanVisit = true;
            //       filterData2.pop();
            //     } else {
            //       if (end1 == end3) filterData2[2].notPlanVisit = true;

            //       // 0번방 배열 삭제
            //       filterData2[0] = cloneDeep(filterData2[1]);
            //       filterData2[1] = cloneDeep(filterData2[2]);
            //       filterData2[0].notPlanVisit = true;
            //       filterData2.pop();
            //     }
            //   } else if (time1 == time3) {
            //     if (Object.keys(filterData2[0]).includes('executeTime')) {
            //       // 2번방 배열 삭제
            //       filterData2[0].notPlanVisit = true;
            //       filterData2.pop();
            //     } else {
            //       // 0번방 배열 삭제
            //       filterData2[0] = cloneDeep(filterData2[1]);
            //       filterData2[1] = cloneDeep(filterData2[2]);
            //       filterData2[1].notPlanVisit = true;
            //       filterData2.pop();
            //     }
            //   } else if (time2 == time3) {
            //     if (Object.keys(filterData2[1]).includes('executeTime')) {
            //       // 2번방 배열 삭제
            //       filterData2[1].notPlanVisit = true;
            //       filterData2.pop();
            //     } else {
            //       // 0번방 배열 삭제
            //       filterData2[1] = cloneDeep(filterData2[2]);
            //       filterData2[1].notPlanVisit = true;
            //       filterData2.pop();
            //     }
            //   }
            // }
            // // 그럴리 없겠지만 굳이 30분 단위로 방문계획을 세운후 2번다 계획과 2번다 다른곳을 방문한 경우
            // else if (filterData2.length == 4) {
            //   filterData2[0] = cloneDeep(filterData2[2]);
            //   filterData2[1] = cloneDeep(filterData2[3]);

            //   filterData2[0].notPlanVisit = true;
            //   filterData2[1].notPlanVisit = true;

            //   filterData2.pop();
            //   filterData2.pop();
            // }
          }
        }

        const custList = [];

        if (filterData2.length == 0) {
          temp[`sp${emp.employeeNumber}`] = {
            visitDate: dayjs(date, 'YYYY-MM-DD'),
            // visitTime: time,
            spNum: `sp${emp.employeeNumber}`,
            isEmpty: true,
            type,
          };
        }
        else {
          filterData2.forEach((data) => {
            if (data.customerName != '') {
              if (categoryCode != undefined) {
                // if (categoryCode.find((e) => e == categoryNum(category)) != undefined) {
                custList.push({
                  custName: data.customerName,
                  isVisit: data.isVisited,
                  isPlaned: data.isPlaned,
                  isPassed: data.isPassed,
                  notPlanVisit: data.notPlanVisit,
                  checkTargetYn: data.checkTargetYn,
                  code: data.customerCode,
                  category: categoryNum(category),
                });
                // }

                const filter = useFilterComp.stateType.filter(e => e.name == categoryNum(category));
                // console.log('filter => ', filter[0]);
                filter[0].count++;

                category++;

                if (category == 4) { category = 0; }
              }
            }
          });
        }

        // 없을시 빈칸만들기
        // if (filterData2.length == 0) {
        //   temp['sp' + emp.employeeNumber] = {
        //     visitDate: dayjs(date, 'YYYY-MM-DD'),
        //     // visitTime: time,
        //     spNum: 'sp' + emp.employeeNumber,
        //     // custName: emp.customerName,
        //     isEmpty: true,
        //     type: type,
        //   };
        // } else {
        //   var custName = '';
        //   var isVisit = '';
        //   var isPlaned = '';
        //   var isPassed = '';
        //   var notPlanVisit = '';
        //   var checkTargetYn = 'N';
        //   var code = '';
        //   var saleCustomerDivisionCode = '';
        //   var endDate = '';
        //   var isHalf = false;
        //   if (filterData2.length == 2) {
        //     custName = filterData2[0].customerName + '||' + filterData2[1].customerName;
        //     code = filterData2[0].customerCode + '||' + filterData2[1].customerCode;
        //     var visit1 = filterData2[0].isVisited ? 'visit' : 'notVisit';
        //     var visit2 = filterData2[1].isVisited ? 'visit' : 'notVisit';
        //     isVisit = visit1 + '||' + visit2;
        //     // isVisit = isVisit + filterData2[1].isVisited ? 'visit' : 'notVisit';
        //     var plan1 = filterData2[0].isPlaned ? 'planed' : 'notPlaned';
        //     var plan2 = filterData2[1].isPlaned ? 'planed' : 'notPlaned';
        //     isPlaned = plan1 + '||' + plan2;
        //     var pass1 = filterData2[0].isPassed ? 'passed' : 'notPassed';
        //     var pass2 = filterData2[1].isPassed ? 'passed' : 'notPassed';
        //     isPassed = pass1 + '||' + pass2;
        //     var check1 = filterData2[0].checkTargetYn == 'Y' ? 'Y' : 'N';
        //     var check2 = filterData2[1].checkTargetYn == 'Y' ? 'Y' : 'N';
        //     checkTargetYn = check1 + '||' + check2;
        //     var notvisit1 = filterData2[0].notPlanVisit ? 'Y' : 'N';
        //     var notvisit2 = filterData2[1].notPlanVisit ? 'Y' : 'N';
        //     notPlanVisit = notvisit1 + '||' + notvisit2;
        //     saleCustomerDivisionCode =
        //       filterData2[0].saleCustomerDivisionCode + '||' + filterData2[1].saleCustomerDivisionCode;
        //     endDate = filterData2[0].endDate + '||' + filterData2[1].endDate;
        //     isHalf = true;
        //   } else {
        //     custName = filterData2[0].customerName;
        //     code = filterData2[0].customerCode;
        //     isVisit = filterData2[0].isVisited ? 'visit' : 'notVisit';
        //     isPlaned = filterData2[0].isPlaned ? 'planed' : 'notPlaned';
        //     isPassed = filterData2[0].isPassed ? 'passed' : 'notPassed';
        //     notPlanVisit = filterData2[0].notPlanVisit ? 'Y' : 'N';
        //     checkTargetYn = filterData2[0].checkTargetYn == 'Y' ? 'Y' : 'N';
        //     saleCustomerDivisionCode = filterData2[0].saleCustomerDivisionCode;
        //     endDate = filterData2[0].endDate;

        //     // 하나라도 30분짜리가 있으면 grid 절반으로 보여야함
        //     if (
        //       dayjs(filterData2[0].startDate).format('mm') == '30' ||
        //       dayjs(filterData2[0].endDate).format('mm') == '30'
        //     ) {
        //       isHalf = true;

        //       if (dayjs(filterData2[0].startDate).format('mm') == '30') {
        //         custName = '' + '||' + filterData2[0].customerName;
        //         isVisit = '' + '||' + isVisit;
        //       }
        //     }
        //   }

        //   // if (filterData2[0].notPlanVisit) console.log('ddoop  =>', filterData2[0]);

        //   temp['sp' + emp.employeeNumber] = {
        //     visitDate: dayjs(date, 'YYYY-MM-DD'),
        //     // visitTime: time,
        //     spNum: 'sp' + emp.employeeNumber,
        //     custName: custName,
        //     code: code,
        //     isVisit: isVisit,
        //     isPlaned: isPlaned,
        //     isPassed: isPassed,
        //     isEmpty: false,
        //     type: type,
        //     checkTargetYn: checkTargetYn,
        //     notPlanVisit: notPlanVisit,
        //     endDate: endDate,
        //     saleCustomerDivisionCode: saleCustomerDivisionCode,
        //     isHalf: isHalf,
        //   };
        // }

        temp[`sp${emp.employeeNumber}`] = {
          visitDate: dayjs(date, 'YYYY-MM-DD'),
          // visitTime: time,
          spNum: `sp${emp.employeeNumber}`,
          custList,
          // code: code,
          // isVisit: isVisit,
          // isPlaned: isPlaned,
          // isPassed: isPassed,
          // isEmpty: false,
          // type: type,
          // checkTargetYn: checkTargetYn,
          // notPlanVisit: notPlanVisit,
          // endDate: endDate,
          // saleCustomerDivisionCode: saleCustomerDivisionCode,
          // isHalf: isHalf,
        };
      });

      if (i == 0) { plan.push(temp); }
      else if (i == 1) { result.push(temp); }
      else if (i == 2) { union.push(temp); }
      // });
    });
  }

  // console.log('result => ', resultData);
  return { plan, result, union };
}

// empList, plan&result , union , date, empInx
export function weeklyGridHm(empList, planResultList, unionList, dateList, empInx, gridSize, gridInit) {
  return {
  // 지점별 Grid 방식 [추후에 사용할지도 몰라서 짜놓은 코드 남겨둠]
  // column: weeklyColumHm(empList, empInx, gridSize),
  // data: weeklyDataHm(empList, planResultList, unionList, dateList, empInx, gridSize),
  // 사원 갯수별 Grid 방식 [현재는 이 방식 사용]
    column2: weeklyColumHm2(empList, empInx, gridInit),
    data2: weeklyDataHm2(empList, planResultList, unionList, dateList, empInx, gridInit),
  };
}

// empList, plan&result , union , date, empInx
export function weeklyGridHm2(empList, planResultList, unionList, dateList, empInx, gridSize, gridInit, categoryCode) {
  return {
  // 지점별 Grid 방식 [추후에 사용할지도 몰라서 짜놓은 코드 남겨둠]
  // column: weeklyColumHm(empList, empInx, gridSize),
  // data: weeklyDataHm(empList, planResultList, unionList, dateList, empInx, gridSize),
  // 사원 갯수별 Grid 방식 [현재는 이 방식 사용]
    column2: weeklyColumHm3(empList, empInx, gridInit),
    data2: weeklyDataHm3(empList, planResultList, unionList, dateList, empInx, gridInit, categoryCode),
  };
}

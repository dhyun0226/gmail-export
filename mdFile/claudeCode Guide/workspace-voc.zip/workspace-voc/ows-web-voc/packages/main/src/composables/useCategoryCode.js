// src/composables/useCategoryCode.js
import { ref, computed } from "vue";
import { useApi } from "@ows/core";

export default function useCategoryCode() {
  // API 인스턴스 생성
  const api = useApi();

  // 상태 관리
  const categories = ref([]);
  const currentCategory = ref(null);
  const childCategories = ref([]);
  const loading = ref(false);
  const error = ref(null);

  // API 기본 URL
  const baseUrl = "/voc/vocCategories";

  /**
   * 특정 VOC 카테고리 조회
   * @param {string} categoryCode - 조회할 카테고리 코드
   */
  const fetchCategory = async (categoryCode) => {
    if (!categoryCode) return;

    loading.value = true;
    error.value = null;

    try {
      const response = await api.get(`${baseUrl}/${categoryCode}`);
      currentCategory.value = response.data;
      return response.data;
    } catch (err) {
      error.value =
        err.response?.data?.message ||
        "카테고리 정보를 불러오는 중 오류가 발생했습니다.";
      console.error("카테고리 조회 실패:", err);
      return null;
    } finally {
      loading.value = false;
    }
  };

  /**
   * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
   * @param {string} parentCategoryCode - 상위 카테고리 코드
   */
  const fetchChildCategories = async (parentCategoryCode) => {
    if (!parentCategoryCode) return [];

    loading.value = true;
    error.value = null;

    try {
      const response = await api.get(
        `${baseUrl}/${parentCategoryCode}/children`
      );
      childCategories.value = response.data;
      return response.data;
    } catch (err) {
      error.value =
        err.response?.data?.message ||
        "하위 카테고리 목록을 불러오는 중 오류가 발생했습니다.";
      console.error("하위 카테고리 조회 실패:", err);
      return [];
    } finally {
      loading.value = false;
    }
  };

  /**
   * 모든 VOC 카테고리 조회
   */
  const fetchAllCategories = async () => {
    loading.value = true;
    error.value = null;

    try {
      const response = await api.get(baseUrl);
      categories.value = response.data;
      return response.data;
    } catch (err) {
      error.value =
        err.response?.data?.message ||
        "카테고리 목록을 불러오는 중 오류가 발생했습니다.";
      console.error("카테고리 목록 조회 실패:", err);
      return [];
    } finally {
      loading.value = false;
    }
  };

  /**
   * 최상위 카테고리 목록 조회
   * @param {string} openYn - 공개 여부 ('Y', 'N')
   */
  const fetchRootCategories = async (openYn = "Y") => {
    loading.value = true;
    error.value = null;

    try {
      // 요청 URL에 쿼리 파라미터로 openYn 추가
      const response = await api.get(`${baseUrl}/root`, {
        params: {
          openYn: openYn,
        },
      });

      categories.value = response.data;
      return response.data;
    } catch (err) {
      error.value =
        err.response?.data?.message ||
        "최상위 카테고리 목록을 불러오는 중 오류가 발생했습니다.";
      console.error("최상위 카테고리 조회 실패:", err);
      return [];
    } finally {
      loading.value = false;
    }
  };

  /**
   * 특정 카테고리의 최상위(루트) 카테고리 조회
   * @param {string} categoryCode - 카테고리 코드
   * @returns {Promise<Object|null>} 최상위 카테고리 정보
   */
  const findRootCategory = async (categoryCode) => {
    if (!categoryCode) return null;

    loading.value = true;
    error.value = null;

    try {
      const response = await api.get(`${baseUrl}/${categoryCode}/root`);
      return response.data;
    } catch (err) {
      error.value =
        err.response?.data?.message ||
        "최상위 카테고리를 찾는 중 오류가 발생했습니다.";
      console.error("최상위 카테고리 조회 실패:", err);
      return null;
    } finally {
      loading.value = false;
    }
  };

  /**
   * 카테고리 코드에서 루트 카테고리 코드 추출
   * @param {string} categoryCode - 카테고리 코드 (예: D002_NTF_003)
   * @returns {Promise<string|null>} 루트 카테고리 코드 (예: D002)
   */
  const extractRootCategoryCode = async (categoryCode) => {
    if (!categoryCode) return null;

    try {
      // 서버 API 호출로 루트 카테고리 가져오기
      const rootCategory = await findRootCategory(categoryCode);
      return rootCategory ? rootCategory.vocCategoryCode : null;
    } catch (err) {
      console.error("루트 카테고리 코드 추출 실패:", err);

      // API 호출 실패 시 코드에서 직접 추출 시도 (백업 방법)
      if (categoryCode.includes("_")) {
        return categoryCode.split("_")[0];
      }
      return categoryCode;
    }
  };

  /**
   * 카테고리 트리 구조 생성 (재귀적으로 하위 카테고리 로드)
   * @param {string} startCategoryCode - 시작 카테고리 코드 (없으면 최상위부터)
   */
  const loadCategoryTree = async (startCategoryCode = null) => {
    loading.value = true;
    error.value = null;

    try {
      // 시작점이 있으면 해당 카테고리부터, 아니면 최상위 카테고리부터 시작
      const startCategories = startCategoryCode
        ? [await fetchCategory(startCategoryCode)]
        : await fetchRootCategories();

      // 각 카테고리에 대해 하위 카테고리 로드
      const result = await Promise.all(
        startCategories.map(async (category) => {
          const children = await fetchChildCategories(category.vocCategoryCode);
          return {
            ...category,
            children,
          };
        })
      );

      return result;
    } catch (err) {
      error.value = "카테고리 트리를 불러오는 중 오류가 발생했습니다.";
      console.error("카테고리 트리 로드 실패:", err);
      return [];
    } finally {
      loading.value = false;
    }
  };

  // 계산된 속성: 카테고리를 계층 구조로 표시하기 위한 옵션 배열
  const categoryOptions = computed(() => {
    return categories.value.map((cat) => ({
      value: cat.vocCategoryCode,
      text: cat.vocCategoryName,
    }));
  });

  // 카테고리 이름으로 검색
  const searchCategoriesByName = (searchTerm) => {
    if (!searchTerm) return categories.value;

    const lowerSearchTerm = searchTerm.toLowerCase();
    return categories.value.filter((category) =>
      category.vocCategoryName.toLowerCase().includes(lowerSearchTerm)
    );
  };

  // 카테고리 코드로 카테고리 찾기
  const findCategoryByCode = (code) => {
    return categories.value.find((cat) => cat.vocCategoryCode === code);
  };

  // 카테고리 코드에 해당하는 카테고리 이름 가져오기
  const getCategoryName = (code) => {
    const category = findCategoryByCode(code);
    return category ? category.vocCategoryName : "";
  };

  /**
   * 카테고리 코드의 부모/하위 관계 확인
   * @param {string} parentCode - 상위 카테고리 코드로 예상되는 값
   * @param {string} childCode - 하위 카테고리 코드로 예상되는 값
   * @returns {Promise<boolean>} 부모/하위 관계가 맞는지 여부
   */
  const isParentChildRelationship = async (parentCode, childCode) => {
    if (!parentCode || !childCode) return false;
    if (parentCode === childCode) return false;

    try {
      const children = await fetchChildCategories(parentCode);
      return children.some((child) => child.vocCategoryCode === childCode);
    } catch (err) {
      console.error("카테고리 관계 확인 실패:", err);
      return false;
    }
  };



  return {
    // 상태
    categories,
    currentCategory,
    childCategories,
    loading,
    error,

    // 액션 (API 호출)
    fetchCategory,
    fetchChildCategories,
    fetchAllCategories,
    fetchRootCategories,
    findRootCategory,
    extractRootCategoryCode,
    loadCategoryTree,

    // 계산된 속성
    categoryOptions,

    // 유틸리티 함수
    searchCategoriesByName,
    findCategoryByCode,
    getCategoryName,
    isParentChildRelationship,
  };
}

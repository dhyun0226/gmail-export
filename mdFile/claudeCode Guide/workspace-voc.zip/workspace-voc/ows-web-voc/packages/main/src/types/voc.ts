/**
 * VOC 파일 정보를 나타내는 인터페이스
 */
export interface VocFile {
  /** 파일 ID */
  fileId: string;
  /** 파일 경로 */
  filePath: string;
  /** 참조 OW 태스크 코드 */
  referenceOwTaskCode: string | null;
  /** 참조 테이블 이름 */
  referenceTableName: string | null;
  /** 참조 구분 컬럼 값 내용 */
  referenceDistinguishColumnValueContent: string | null;
  /** 파일 원본 이름 */
  fileOriginalName: string;
  /** 파일 확장자 이름 */
  fileExtensionName: string;
  /** 파일 크기 */
  fileSize: string;
}

/**
 * VOC 응답 데이터를 나타내는 인터페이스
 */
export interface VocResponse {
  /** VOC 번호 */
  vocNumber: number;
  channelCode?: string;
  vocCategoryCode?: string;
  /** Denall VOC 번호 */
  denallVocNumber: number;
  /** VOC 등록자 구분 코드 */
  vocRegistererDivisionCode: string;
  /** VOC 제목 */
  vocTitle: string;
  /** VOC 내용 */
  vocContent: string;
  /** VOC 파일 ID */
  vocFileId: string;
  /** VOC 상태 코드 */
  vocStateCode: string;
  /** VOC 등록 일시 */
  vocRegistrationDateTime: string;
  /** 답변 여부 */
  hasAnswer: boolean;
  /** 파일 목록 */
  fileList: VocFile[];
}
<script lang="ts" setup>
import { onMounted, reactive, ref, computed, watch } from "vue";
import CustomStore from "devextreme/data/custom_store";
import { cellStyleHandlers, getColumns } from "../data";
import DxTreeList from "@/components/DxTreeList.vue";
import { useApi, useCommonCode } from "@ows/core";
import { dateUtils } from "@/utils";

const api = useApi();

const { VOC_STACD: vocStatuses } = await useCommonCode("VOC_STACD");

// Props 정의
const props = defineProps({
  dateOptions: {
    type: Object,
    default: () => ({
      rangeUnit: "day", // 'day', 'month', 'year' 중 하나
      startDate: null,
      endDate: null,
    }),
  },
  filterOptions: Object,
  term: {
    type: String,
  },
});

// 트리 그리드 컴포넌트 참조
const treeListRef = ref(null);

// 컬럼 정의 동적으로 생성 (rangeUnit에 따라 다른 컬럼 정의)
const columns = computed(() => {
  return getColumns(props.dateOptions.rangeUnit ,props.dateOptions.from);
});

// rangeUnit에 따른 API 경로 계산
const getApiEndpoint = computed(() => {
  // 날짜 단위에 따른 기본 경로 결정
  let basePath;
  switch (props.dateOptions.rangeUnit) {
    case "day":
      basePath = "/daily/search";
      break;
    case "week":
      basePath = "/weekly/search";
      break;
    case "month":
      basePath = "/monthly/search";
      break;
    case "year":
      basePath = "/yearly/search";
      break;
    default:
      basePath = "/daily/search";
  }
 
  // term 타입에 따라 다른 API 경로 선택
  if (props.term === "productTerm") {
    return `/voc/statistics/item${basePath}`;
  } else if (props.term === "personalTerm") {
    return `/voc/statistics/charge-person${basePath}`;
  } else {
    // personalTerm이거나 기본값
    return `/voc/statistics${basePath}`;
  }
});

// 요청 매개변수 계산
// 요청 매개변수 계산
const getRequestParams = computed(() => {
  const params = {
    vocStateCode: vocStatuses
      .filter((stat) => stat.text == "처리중")
      .map((item) => item.value),
    itemCode:
      props.filterOptions.product == "all" ? null : props.filterOptions.product,
    vocRegistererDepartmentCode: props.filterOptions.country,
    vocChargePersonDepartmentCode:
        props.filterOptions.org == "root" ? null : props.filterOptions.org,
  };

  if (props.term === "countryTerm") {
    params.rootDepartmentCode = "O000000914";
  } else if (props.term === "personalTerm") {
    params.rootDepartmentCode = "O000000913";
  }

  // 날짜 범위가 있을 경우 추가
  if (props.dateOptions.from) {
    params.startDate = dateUtils.toLocalDateTime(props.dateOptions.from);
  }

  if (props.dateOptions.to) {
    params.endDate = dateUtils.toLocalDateTime(props.dateOptions.to);
  }

  return params;
});

// 서버에서 데이터를 가져오는 함수
async function fetchTreeData(parentId: number | string | null = null) {
  try {
    // API 경로와 요청 매개변수 가져오기
    const endpoint = getApiEndpoint.value;
    const params = getRequestParams.value;

    // API 호출
    const result = await api.get(endpoint, { params });

    return result.data;
  } catch (error) {
    // 오류 발생 시 빈 배열 반환
    return [];
  }
}

// CustomStore 설정
const customDataSource = new CustomStore({
  key: "key",
  load: async (loadOptions) => {
    // 부모 ID 가져오기
    const parentId =
      loadOptions.parentIds && loadOptions.parentIds.length > 0
        ? loadOptions.parentIds[0]
        : null;

    // 서버에서 데이터 가져오기
    const data = await fetchTreeData(parentId);
    return data;
  },
});

// dataSource를 반응형으로 설정
const dataSource = reactive({
  store: customDataSource,
});


// 셀 준비 이벤트
function onCellPrepared(e: any) {
  // 셀 스타일 핸들러 호출
  cellStyleHandlers.applyZeroValueStyle(e);
  cellStyleHandlers.applyParentStyle(e);
  cellStyleHandlers.convertNullToZero(e);
}

// 그리드 새로고침 메서드
function refresh() {
  if (treeListRef.value) {
    if (typeof treeListRef.value.refresh === "function") {
      treeListRef.value.refresh();
    } else if (
      treeListRef.value.instance &&
      typeof treeListRef.value.instance.refresh === "function"
    ) {
      treeListRef.value.instance.refresh();
    }
  }
}

watch(
  () => props.filterOptions,
  (newVal) => {
    refresh();
  },
  { deep: true }
);

// rangeUnit이 변경될 때 데이터를 다시 로드
watch(
  () => props.dateOptions.rangeUnit,
  (newUnit, oldUnit) => {
    if (newUnit !== oldUnit) {
      refresh();
    }
  }
);

watch(
  () => props.dateOptions.from,
  () => {
    refresh();
  }
);

watch(
  () => props.term,
  () => {
    refresh();
  }
);

// dateOptions의 startDate나 endDate가 변경될 때도 데이터를 다시 로드
watch(
  () => [props.dateOptions.startDate, props.dateOptions.endDate],
  () => {
    refresh();
  },
  { deep: true }
);

// 외부에서 사용할 메서드 노출
defineExpose({
  refresh,
});

// 컴포넌트 초기화
onMounted(() => {
  treeListRef.value.expandAllRows();
});
</script>

<template>
  <div>
    <DxTreeList
      ref="treeListRef"
      :data-source="dataSource"
      :columns="columns"
      :show-borders="true"
      :show-row-lines="true"
      :column-auto-width="true"
      :word-wrap-enabled="true"
      has-items-expr="hasChildren"
      :auto-expand-top="true"
      :on-cell-prepared="onCellPrepared"
    />
  </div>
</template>

<style scoped>
/* 스타일은 DxTreeList 컴포넌트에 정의됨 */
</style>

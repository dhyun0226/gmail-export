<script setup lang="ts">
import { defineExpose, ref, watch } from 'vue';
import { useApi } from '@ows/core';
import dayjs from 'dayjs';
import { useOwPopup } from '@ows/ui';

import DxListNGrid from '@/components/DxListNGrid.vue';
import NoticeDetailPopup from '@/components/NoticeDetailPopup.vue';

const props = defineProps({
  from: String,
  to: String,
  dateUnit: String,
  filterOptions: Object,
  channelGroupOptions: Array,
  categoryGroupOptions: Array,
  employeeGroupOptions: Array,
  searchType: String,
  keyword: String,
});

const {
  openPopup: openDetailPopup,
  closePopup: closeDetailPopup,
  isPopupOpen,
} = useOwPopup();

const api = useApi();

const noticeNumber = ref(0);
const columns = ref([
  {
    caption: '채널',
    width: '100',
    dataField: 'channelCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize2',
    visible: true,
  },
  {
    caption: '상세구분',
    width: '100',
    dataField: 'serviceCategoryCode',
    allowMerge: true,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize5',
    visible: true,
  },
  {
    caption: '공지제목',
    width: '*',
    dataField: 'noticeTitle',
    allowMerge: false,
    alignment: 'left',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '공개',
    width: '80',
    dataField: 'openYn',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize3',
    visible: true,
  },
  {
    caption: '상단고정',
    width: '70',
    dataField: 'topFixedYn',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize4',
    visible: true,
  },
  {
    caption: '조회건수',
    width: '80',
    dataField: 'inquiryCount',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    visible: true,
  },
  {
    caption: '등록자',
    width: '100',
    dataField: 'registererEmployeeNumber',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize6',
    visible: true,
  },
  {
    caption: '등록일자',
    width: '100',
    dataField: 'noticeRegistrationDatetime',
    allowMerge: false,
    alignment: 'center',
    allowSorting: false,
    cellType: 'customize',
    visible: true,
  },
]);

const gridOption = ref({
  datas: [],
  paging: {
    pageSize: 20,
    pageNo: 1,
    totalItemCount: 0,
  },
  nGridCount: 2,
  height: '725px',
  selection: { mode: 'none', showCheckBoxesMode: 'none' },
  // pagination: true,
});

const handlePaging = ref((pageNo) => {
  gridOption.value.paging.pageNo = pageNo;
  load();
});

// 카테고리 코드를 채널 이름으로 변환하는 함수 개선
function getChannelText(code) {
  const channel = props.channelGroupOptions.find(item =>
    code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 카테고리 코드를 카테고리 이름으로 변환하는 함수 개선
function getCategoryText(code) {
  const channel = props.categoryGroupOptions.find(item =>
    code.includes(item.value),
  );
  return channel ? channel.text : code; // 매핑된 값이 없으면 원래 코드를 반환
}

// 등록자 사번을 이름으로 변환하는 함수 개선
function getEmployeeName(code) {
  const employee = props.employeeGroupOptions.find(item =>
    code === item.employeeNumber,
  );
  return employee ? employee.employeeName : code; // 매핑된 값이 없으면 원래 코드를 반환
}

function getDateFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('YY-MM-DD');
}

function getTimeFormat(dateString) {
  const formattedDate = dayjs(dateString);
  return formattedDate.format('HH:mm');
}

function getColumnsByDate() {
  const date = props.dateUnit;
  if (date === 'day') {
    columns.value.forEach((col) => {
      if (col.caption === '등록일자') {
        col.caption = '등록시간';
      }
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '등록시간') {
        col.caption = '등록일자';
      }
    });
  }
}

function getColumnsByChannel() {
  if (props.filterOptions.channelGroup.value === '') {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = true;
      }
    });
  }
  else {
    columns.value.forEach((col) => {
      if (col.caption === '채널') {
        col.visible = false;
      }
    });
  }
}

function onCellPrepared(e) {

}

function onCellClick(e) {
  noticeNumber.value = e.data.noticeNumber;
  openDetailPopup();
}

async function load() {
  try {
    const params = {
      pageNo: gridOption.value.paging.pageNo,
      pageSize: gridOption.value.paging.pageSize * gridOption.value.nGridCount,
      fromDate: props.from,
      toDate: props.to,
      channelCode: props.filterOptions.channelGroup.value,
      serviceCategoryCode: props.filterOptions.categoryGroup.value,
      openYn: props.filterOptions.openYnGroup.value,
      topFixedYn: props.filterOptions.topFxdYnGroup.value,
      searchType: props.searchType,
      keyword: props.keyword,
    };

    // 공지사항 데이터를 가져옴
    const result = await api.get(`/voc/notices`, { params });

    gridOption.value.datas = result.data.data;
    gridOption.value.paging.totalItemCount = result.data.totalCount;
  }
  catch (error) {
    gridOption.value.datas = [];
  }
}

function handleSaveSuccess() {
  load();
}

watch(
  [() => props.from, () => props.to],
  () => {
    getColumnsByDate();
    load();
  },
);

watch(
  () => props.filterOptions,
  () => {
    getColumnsByChannel();
    load();
  },
  { deep: true },
);

defineExpose({
  load,
});
</script>

<template>
  <DxListNGrid
    :n-grid-count="gridOption.nGridCount"
    :show-gap="false"
    :all-datas="gridOption.datas"
    :columns="columns"
    :paging="gridOption.paging"
    :height="gridOption.height"
    :selection="gridOption.selection"
    :is-show-pagination="true"
    @on-click-cell="onCellClick"
    @on-cell-prepared="onCellPrepared"
    @on-move-page="handlePaging"
  >
    <template #customize="{ data: cell }">
      <template v-if="props.dateUnit === 'day'">
        {{ getTimeFormat(cell.data.noticeRegistrationDatetime) }}
      </template>
      <template v-else>
        <div class="sal-custom">
          {{ getDateFormat(cell.data.noticeRegistrationDatetime) }}
        </div>
      </template>
    </template>

    <template #customize2="{ data: cell }">
      <div>{{ getChannelText(cell.data.serviceCategoryCode) }}</div>
    </template>
    <template #customize3="{ data: cell }">
      <div>{{ cell.data.openYn === "Y" ? "공개" : "비공개" }}</div>
    </template>
    <template #customize4="{ data: cell }">
      <div>{{ cell.data.topFixedYn === "Y" ? "고정" : "해제" }}</div>
    </template>
    <template #customize5="{ data: cell }">
      <div>{{ getCategoryText(cell.data.serviceCategoryCode) }}</div>
    </template>
    <template #customize6="{ data: cell }">
      <div>{{ getEmployeeName(cell.data.registererEmployeeNumber) }}</div>
    </template>
  </DxListNGrid>
  <NoticeDetailPopup
    v-if="isPopupOpen"
    :is-popup-open="isPopupOpen"
    :channel-group-options="props.channelGroupOptions"
    :category-group-options="props.categoryGroupOptions"
    height="auto"
    title="공지사항 상세"
    :notice-number="noticeNumber"
    :width="1200"
    :on-close="
      () => {
        closeDetailPopup();
      }
    "
    @save-success="handleSaveSuccess"
  />
</template>

<style></style>

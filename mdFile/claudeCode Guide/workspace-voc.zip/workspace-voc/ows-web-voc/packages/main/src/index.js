/**
 * 주의: 이 패키지는 build 후 npm으로 배포합니다.
 *
 * 개발 환경에서는 '/apps/web'을 통해 vite로 실행됩니다.
 *
 * 프로덕션 환경에서는 전용 패키지(deploy)에 통합되어 vite로 빌드, 배포됩니다.
 */

import messages from './messages';
import pages from './pages';

/** @type { import('@ows/core').OwsModule } */
export default {
  messages,
  pages,
  install(app) {
    // Object.entries(components).forEach(([name, component]) => app.component(name, component));
  },
};

# VOC 오류 #60: 팝업 하단 버튼 OW UI 표준 준수 필요

## 오류 정보
- **테스트 시나리오명**: 관리자 공지사항 조회
- **요약**: 팝업 하단 버튼 OW UI 표준 준수 필요(취소| 확인)
- **유형**: UI

## 문제점 분석
여러 팝업 컴포넌트에서 버튼 정렬 방식이 일관되지 않아 OW UI 표준을 위반하고 있습니다.

### 표준 위반 컴포넌트들
1. **우측 정렬 (비표준)**
   - QnaDetailPopup.vue
   - VocDetailPopup.vue
   - VocDetailPopup2.vue
   - VocDetailPopup250613.vue

2. **중앙 정렬 (표준)**
   - NoticeDetailPopup.vue
   - EventDetailPopup.vue
   - FaqDetailPopup.vue
   - InquiryDetailPopup.vue

## OW UI 표준 가이드

### 1. 표준 버튼 레이아웃
```vue
<div class="ow-popup-bottom">
  <BButton
    size="md"
    variant="base base-gray"
    @click="handleCancel"
  >
    취소
  </BButton>
  <BButton
    id="btnOk"
    size="md"
    variant="base base-dark"
    @click="handleConfirm"
  >
    확인
  </BButton>
</div>
```

### 2. 표준 CSS 스타일
```css
/* OW 표준 팝업 버튼 스타일 */
.ow-popup-bottom {
  display: flex;
  justify-content: center;  /* 중앙 정렬 (표준) */
  gap: 15px;               /* 버튼 간격 */
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}
```

### 3. 비표준 스타일 (수정 필요)
```css
/* 비표준 - 우측 정렬 */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;  /* ❌ 비표준 */
  gap: 10px;                  /* ❌ 간격 불일치 */
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #dee2e6;
}
```

## 개선 방안

### 1. QnaDetailPopup.vue 수정
```css
/* 원본 (비표준) */
.ow-popup-bottom {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  /* ... */
}

/* 개선 (표준) */
.ow-popup-bottom {
  display: flex;
  justify-content: center;
  gap: 15px;
  /* ... */
}
```

### 2. 일관성 문제 해결
QnaDetailPopup.vue에서 두 가지 스타일이 혼재:
```css
/* 문제: 같은 컴포넌트에서 다른 정렬 */
.ow-popup-bottom {
  justify-content: flex-end;  /* 우측 정렬 */
}
.ow-popup-bottom-fixed {
  justify-content: center;    /* 중앙 정렬 */
}

/* 해결: 통일된 정렬 */
.ow-popup-bottom,
.ow-popup-bottom-fixed {
  justify-content: center;    /* 모두 중앙 정렬 */
}
```

### 3. 비표준 클래스명 수정
```vue
<!-- 원본 (AssignmentPopup.vue) -->
<div class="button-container">
  <!-- 버튼들 -->
</div>

<!-- 개선 -->
<div class="ow-popup-bottom">
  <!-- 버튼들 -->
</div>
```

## OW UI 표준 체크리스트
✅ **버튼 순서**: 취소(왼쪽) → 확인(오른쪽)
✅ **버튼 크기**: `size="md"`
✅ **버튼 변형**: 
   - 취소: `variant="base base-gray"`
   - 확인: `variant="base base-dark"`
✅ **버튼 정렬**: `justify-content: center` (중앙)
✅ **버튼 간격**: `gap: 15px`
✅ **컨테이너 클래스**: `ow-popup-bottom`
✅ **상단 테두리**: `border-top: 1px solid #dee2e6`

## 영향받는 파일 목록
1. `C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\QnaDetailPopup.vue`
2. `C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\VocDetailPopup.vue`
3. `C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\VocDetailPopup2.vue`
4. `C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\VocDetailPopup250613.vue`
5. `C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\AssignmentPopup.vue`

## 개선 효과
1. **일관된 사용자 경험**: 모든 팝업에서 동일한 버튼 위치
2. **디자인 시스템 준수**: OW UI 표준 가이드라인 준수
3. **유지보수성 향상**: 통일된 스타일로 관리 용이
4. **접근성 개선**: 예측 가능한 인터페이스로 사용성 향상
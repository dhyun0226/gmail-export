# VOC 오류 #5: Alert/confirm 팝업창 타이틀 수정 필요

## 오류 정보
- **테스트 시나리오명**: 관리자 공지사항 등록
- **요약**: Alert/confirm 팝업창 타이틀 수정 필요
- **유형**: UI

## 파일 위치
`C:\ows-project\workspace-voc\ows-web-voc\packages\main\src\components\NoticeDetailPopup.vue`

## 문제점 분석
현재 Alert/confirm 팝업창의 타이틀이 일관성이 없고 사용자에게 명확한 정보를 제공하지 못하고 있습니다.

### 원본 코드
```javascript
// 유효성 검사 Alert
owAlert({ title: '제목 필수입력 확인', message: '공지사항 제목을 입력해주세요.' });
owAlert({ title: '내용 필수입력 확인', message: '공지사항 내용을 입력해주세요.' });
owAlert({ title: '채널 필수입력 확인', message: '채널을 선택해주세요.' });
owAlert({ title: '상세구분 필수입력 확인', message: '상세구분을 선택해주세요.' });

// 확인 Dialog
if (await owConfirm({ title: '등록', message: '공지사항을 등록하시겠습니까?', target: '#frm' })) {
if (await owConfirm({ title: '수정', message: '공지사항을 수정하시겠습니까?', target: '#frm' })) {
if (await owConfirm({ title: '삭제', message: '공지사항을 삭제하시겠습니까?', target: '#frm' })) {
```

## 개선된 코드
```javascript
// 유효성 검사 Alert - 일관된 타이틀 형식 적용
owAlert({ title: '공지사항 등록', message: '공지사항 제목을 입력해주세요.' });
owAlert({ title: '공지사항 등록', message: '공지사항 내용을 입력해주세요.' });
owAlert({ title: '공지사항 등록', message: '채널을 선택해주세요.' });
owAlert({ title: '공지사항 등록', message: '상세구분을 선택해주세요.' });

// 확인 Dialog - 더 명확한 타이틀 제공
if (await owConfirm({ title: '공지사항 등록 확인', message: '공지사항을 등록하시겠습니까?', target: '#frm' })) {
if (await owConfirm({ title: '공지사항 수정 확인', message: '공지사항을 수정하시겠습니까?', target: '#frm' })) {
if (await owConfirm({ title: '공지사항 삭제 확인', message: '공지사항을 삭제하시겠습니까?', target: '#frm' })) {
```

## 전체 개선된 메서드
```javascript
async function clickSave() {
  if (saving.value) return;
  saving.value = true;

  const alertTitle = isCreateMode.value ? '공지사항 등록' : '공지사항 수정';

  if (!responseData.value.noticeTitle?.trim()) {
    owAlert({ title: alertTitle, message: '공지사항 제목을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.noticeContent?.trim()) {
    owAlert({ title: alertTitle, message: '공지사항 내용을 입력해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.channelCode) {
    owAlert({ title: alertTitle, message: '채널을 선택해주세요.' });
    saving.value = false;
    return;
  }
  if (!responseData.value.serviceCategoryCode) {
    owAlert({ title: alertTitle, message: '상세구분을 선택해주세요.' });
    saving.value = false;
    return;
  }

  const noticeData = {
    noticeTitle: responseData.value.noticeTitle,
    noticeContent: responseData.value.noticeContent,
    channelCode: responseData.value.channelCode,
    serviceCategoryCode: responseData.value.serviceCategoryCode,
    openYn: openYNGroup.value || 'Y',
    registererCorporationCode: currentUser.corpCode,
    registererDepartmentCode: currentUser.deptCode,
    registererEmployeeNumber: currentUser.empNo,
    topFixedYn: topFxdYnGroup.value || 'N',
    fileList: fileList.value,
  };

  if (!isCreateMode.value && props.noticeNumber) {
    noticeData.noticeNumber = props.noticeNumber;
  }

  try {
    if (isCreateMode.value) {
      if (await owConfirm({ title: '공지사항 등록 확인', message: '공지사항을 등록하시겠습니까?', target: '#frm' })) {
        await api.post('voc/notices', noticeData);
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    } else {
      if (await owConfirm({ title: '공지사항 수정 확인', message: '공지사항을 수정하시겠습니까?', target: '#frm' })) {
        await api.put(`voc/notices/${props.noticeNumber}`, noticeData);
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    }
  } catch (error) {
    console.error('공지사항 저장 오류:', error);
  } finally {
    saving.value = false;
  }
}

async function deleteRow(noticeNumber: number) {
  if (await owConfirm({ title: '공지사항 삭제 확인', message: '공지사항을 삭제하시겠습니까?', target: '#frm' })) {
    try {
      const result = await api.delete(`/voc/notices/${noticeNumber}`);
      if (result.status === 200) {
        emit('save-success', 'refresh');
        if (props.onClose) props.onClose();
      }
    } catch (error) {
      console.error('Error deleting notice:', error);
    }
  }
}
```

## 개선 사항 요약
1. **일관된 타이틀 형식**: 모든 Alert에서 '공지사항 등록' 또는 '공지사항 수정' 사용
2. **명확한 확인 메시지**: '등록', '수정', '삭제' → '공지사항 등록 확인', '공지사항 수정 확인', '공지사항 삭제 확인'
3. **동적 타이틀 적용**: isCreateMode에 따라 타이틀을 동적으로 변경하여 일관성 유지
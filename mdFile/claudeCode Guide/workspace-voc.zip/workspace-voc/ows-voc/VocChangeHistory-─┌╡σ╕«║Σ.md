# VocChangeHistory.java & VocChangeHistoryId.java 엔티티 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 불완전한 이력 저장
**문제점**: Voc 엔티티의 일부 필드만 저장하여 완전한 변경 이력 추적 불가
**라인**: VocChangeHistory.java 전체
```java
public class VocChangeHistory extends BaseEntity {
    // Voc 엔티티의 일부 필드만 복사됨
    private String vocCategoryCode;
    private String vocTitle;
    private String vocContent;
    // 누락된 필드들: vocCustomerName, vocCustomerEmailAddress, fileId, deleteYesOrNo 등
}
```

#### 연관관계 설정 부재
**문제점**: 원본 Voc 엔티티와의 연관관계가 설정되지 않아 추적 불가
**라인**: VocChangeHistory.java 19-20번 라인
```java
@EmbeddedId
private VocChangeHistoryId id; // VOC 번호만 복합키로 있을 뿐 연관관계 없음
```

#### 변경 유형 정보 부재
**문제점**: 어떤 종류의 변경인지(생성, 수정, 삭제, 상태변경 등) 알 수 없음
**라인**: VocChangeHistory.java 전체
```java
public class VocChangeHistory extends BaseEntity {
    // 변경 유형을 나타내는 필드 없음 (CREATE, UPDATE, DELETE, STATE_CHANGE 등)
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 변경 사유 정보 부재
**문제점**: 왜 변경되었는지에 대한 사유나 설명이 없음
**라인**: VocChangeHistory.java 전체
```java
public class VocChangeHistory extends BaseEntity {
    // 변경 사유나 변경 설명을 기록하는 필드 없음
}
```

#### 필드 검증 부재
**문제점**: 중요한 필드들에 대한 validation 어노테이션이 없음
**라인**: VocChangeHistory.java 34-38번 라인
```java
@Column(name = "VOC_TTL", length = 100, nullable = false)
private String vocTitle; // @NotBlank, @Size 검증 없음

@Column(name = "VOC_CN", length = 2000, nullable = false)
private String vocContent; // @NotBlank, @Size 검증 없음
```

#### 비즈니스 로직 부재
**문제점**: 이력 비교, 이력 조회 등의 비즈니스 로직이 전혀 없음
**라인**: VocChangeHistory.java 전체
```java
public class VocChangeHistory extends BaseEntity {
    // 이력 비교, 특정 시점 복원, 변경 내역 요약 등의 로직 없음
}
```

#### 복합키 생성자 불일치
**문제점**: VocChangeHistoryId에 생성자는 있지만 @AllArgsConstructor가 없어 일관성 부족
**라인**: VocChangeHistoryId.java 24-27번 라인
```java
public VocChangeHistoryId(Long vocNumber, LocalDateTime vocChangeDateTime) {
    this.vocNumber = vocNumber;
    this.vocChangeDateTime = vocChangeDateTime;
}
// @AllArgsConstructor가 없어 Lombok과 수동 생성자가 혼재
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 이력 메타데이터 부족
**문제점**: 변경 전후 값 비교, 변경 크기 등의 메타 정보 부재
**라인**: VocChangeHistory.java 전체
```java
public class VocChangeHistory extends BaseEntity {
    // 변경된 필드 수, 변경 전 값과의 diff 정보 등 메타데이터 없음
}
```

#### 인덱싱 최적화 부재
**문제점**: 이력 조회 성능을 위한 인덱스 설정이 없음
**라인**: VocChangeHistory.java 9번 라인
```java
@Table(name = "TB_VOC_CHG_H") // 인덱스 설정 없음
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전

#### 개선된 VocChangeHistory.java
```java
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Entity
@Table(name = "TB_VOC_CHG_H", indexes = {
    @Index(name = "idx_voc_change_history_voc", columnList = "VOC_NO"),
    @Index(name = "idx_voc_change_history_datetime", columnList = "VOC_CHG_DTM"),
    @Index(name = "idx_voc_change_history_type", columnList = "CHG_TYPE"),
    @Index(name = "idx_voc_change_history_processor", columnList = "CHG_PROCR_EMP_NO")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocChangeHistory extends BaseEntity {

    @EmbeddedId
    private VocChangeHistoryId id;

    // 원본 Voc와의 연관관계 추가
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_NO", insertable = false, updatable = false)
    private Voc originalVoc;

    // 변경 유형 추가
    @Enumerated(EnumType.STRING)
    @Column(name = "CHG_TYPE", length = 20, nullable = false)
    @NotNull(message = "변경 유형은 필수입니다")
    private VocChangeType changeType;

    // 변경 사유 추가
    @Column(name = "CHG_RSN", length = 500)
    @Size(max = 500, message = "변경 사유는 500자를 초과할 수 없습니다")
    private String changeReason;

    // 변경 설명 추가
    @Column(name = "CHG_DESC", length = 1000)
    @Size(max = 1000, message = "변경 설명은 1000자를 초과할 수 없습니다")
    private String changeDescription;

    // === VOC 스냅샷 필드들 (완전한 복사) ===
    
    @Column(name = "VOC_CHPR_NO")
    private Long vocChargePersonNumber;

    @Column(name = "VOC_CTG_CD", length = 12, nullable = false)
    @NotBlank(message = "VOC 카테고리 코드는 필수입니다")
    @Size(max = 12, message = "VOC 카테고리 코드는 12자를 초과할 수 없습니다")
    private String vocCategoryCode;

    @Column(name = "ITM_CD", length = 90)
    @Size(max = 90, message = "아이템 코드는 90자를 초과할 수 없습니다")
    private String itemCode;

    @Column(name = "VOC_ITM_NM", length = 100)
    @Size(max = 100, message = "VOC 아이템명은 100자를 초과할 수 없습니다")
    private String vocItemName;

    @Column(name = "VOC_TTL", length = 100, nullable = false)
    @NotBlank(message = "VOC 제목은 필수입니다")
    @Size(max = 100, message = "VOC 제목은 100자를 초과할 수 없습니다")
    private String vocTitle;

    @Column(name = "VOC_CN", length = 2000, nullable = false)
    @NotBlank(message = "VOC 내용은 필수입니다")
    @Size(max = 2000, message = "VOC 내용은 2000자를 초과할 수 없습니다")
    private String vocContent;

    // 고객 정보 (스냅샷)
    @Column(name = "VOC_CTMR_NM", length = 50)
    @Size(max = 50, message = "고객명은 50자를 초과할 수 없습니다")
    private String vocCustomerName;

    @Column(name = "VOC_CTMR_EML_ADDR", length = 50)
    @Size(max = 50, message = "고객 이메일은 50자를 초과할 수 없습니다")
    private String vocCustomerEmailAddress;

    @Column(name = "VOC_CTMR_TLNO", length = 20)
    @Size(max = 20, message = "고객 전화번호는 20자를 초과할 수 없습니다")
    private String vocCustomerTelephoneNumber;

    // 등록자 정보 스냅샷
    @Column(name = "RGSTR_CPRN_CD", length = 3)
    @Size(max = 3, message = "등록자 회사코드는 3자를 초과할 수 없습니다")
    private String registererCorporationCode;

    @Column(name = "RGSTR_DEPT_CD", length = 30)
    @Size(max = 30, message = "등록자 부서코드는 30자를 초과할 수 없습니다")
    private String registererDepartmentCode;

    @Column(name = "RGSTR_EMP_NO", length = 60)
    @Size(max = 60, message = "등록자 직원번호는 60자를 초과할 수 없습니다")
    private String registererEmployeeNumber;

    // 판매 담당자 정보
    @Column(name = "VOC_SALE_CHPR_CPRN_CD", length = 3)
    @Size(max = 3, message = "판매담당자 회사코드는 3자를 초과할 수 없습니다")
    private String vocSaleChargeCorporationCode;

    @Column(name = "VOC_SALE_CHPR_DEPT_CD", length = 30)
    @Size(max = 30, message = "판매담당자 부서코드는 30자를 초과할 수 없습니다")
    private String vocSaleChargeDepartmentCode;

    @Column(name = "VOC_SALE_CHPR_EMP_NO", length = 60)
    @Size(max = 60, message = "판매담당자 직원번호는 60자를 초과할 수 없습니다")
    private String vocSaleChargeEmployeeNumber;

    // VOC 상태 정보
    @Column(name = "VOC_STACD", length = 2, nullable = false)
    @NotBlank(message = "VOC 상태코드는 필수입니다")
    @Size(max = 2, message = "VOC 상태코드는 2자를 초과할 수 없습니다")
    private String vocStateCode;

    @Column(name = "VOC_CMPL_TYCD", length = 2)
    @Size(max = 2, message = "VOC 완료유형코드는 2자를 초과할 수 없습니다")
    private String vocCompletionTypeCode;

    @Column(name = "BIZ_RQST_NO")
    private Long businessRequestNumber;

    @Column(name = "ASGNMT_PRCS_NO")
    private Long assignmentProcedureNumber;

    @Column(name = "END_RSN", length = 500)
    @Size(max = 500, message = "종료사유는 500자를 초과할 수 없습니다")
    private String endReason;

    @Column(name = "FILE_ID", length = 50)
    @Size(max = 50, message = "파일 ID는 50자를 초과할 수 없습니다")
    private String fileId;

    @Column(name = "DEL_YN", length = 1)
    @Convert(converter = YesNoToBooleanConverter.class)
    private Boolean deleted;

    @Column(name = "VOC_RGST_DTM")
    private LocalDateTime vocRegistrationDateTime;

    // 변경 처리자 정보
    @Column(name = "CHG_PROCR_CPRN_CD", length = 3)
    @Size(max = 3, message = "변경처리자 회사코드는 3자를 초과할 수 없습니다")
    private String changeProcessorCorporationCode;

    @Column(name = "CHG_PROCR_DEPT_CD", length = 30)
    @Size(max = 30, message = "변경처리자 부서코드는 30자를 초과할 수 없습니다")
    private String changeProcessorDepartmentCode;

    @Column(name = "CHG_PROCR_EMP_NO", length = 60, nullable = false)
    @NotBlank(message = "변경처리자 직원번호는 필수입니다")
    @Size(max = 60, message = "변경처리자 직원번호는 60자를 초과할 수 없습니다")
    private String changeProcessorEmployeeNumber;

    @Column(name = "CHG_PROCR_NM", length = 50)
    @Size(max = 50, message = "변경처리자명은 50자를 초과할 수 없습니다")
    private String changeProcessorName;

    // 변경 메타데이터
    @Column(name = "CHG_FLD_CNT")
    private Integer changedFieldCount; // 변경된 필드 수

    @Column(name = "CHG_SIZE")
    private Long changeSize; // 변경 크기 (바이트)

    // 변경 상세 정보 (JSON 형태로 저장)
    @Lob
    @Column(name = "CHG_DTLS")
    private String changeDetails; // 변경 전후 값의 상세 비교 정보

    /**
     * VOC 엔티티로부터 변경 이력을 생성합니다.
     *
     * @param voc 원본 VOC 엔티티
     * @param changeType 변경 유형
     * @param changeReason 변경 사유
     * @param processorId 처리자 ID
     * @return 변경 이력 엔티티
     */
    public static VocChangeHistory createFromVoc(Voc voc, VocChangeType changeType, 
                                                String changeReason, String processorId) {
        validateInputs(voc, changeType, processorId);
        
        VocChangeHistoryId historyId = new VocChangeHistoryId(voc.getVocNumber(), LocalDateTime.now());
        
        return VocChangeHistory.builder()
                .id(historyId)
                .originalVoc(voc)
                .changeType(changeType)
                .changeReason(changeReason)
                // VOC 필드들 복사
                .vocChargePersonNumber(voc.getVocChargePersonNumber())
                .vocCategoryCode(voc.getVocCategoryCode())
                .itemCode(voc.getItemCode())
                .vocItemName(voc.getVocItemName())
                .vocTitle(voc.getVocTitle())
                .vocContent(voc.getVocContent())
                .vocCustomerName(voc.getVocCustomerName())
                .vocCustomerEmailAddress(voc.getVocCustomerEmailAddress())
                .vocCustomerTelephoneNumber(voc.getVocCustomerTelephoneNumber())
                .registererCorporationCode(voc.getRegistererCorporationCode())
                .registererDepartmentCode(voc.getRegistererDepartmentCode())
                .registererEmployeeNumber(voc.getRegistererEmployeeNumber())
                .vocSaleChargeCorporationCode(voc.getVocSaleChargeCorporationCode())
                .vocSaleChargeDepartmentCode(voc.getVocSaleChargeDepartmentCode())
                .vocSaleChargeEmployeeNumber(voc.getVocSaleChargeEmployeeNumber())
                .vocStateCode(voc.getVocStateCode())
                .vocCompletionTypeCode(voc.getVocCompletionTypeCode())
                .businessRequestNumber(voc.getBusinessRequestNumber())
                .assignmentProcedureNumber(voc.getAssignmentProcedureNumber())
                .endReason(voc.getEndReason())
                .fileId(voc.getFileId())
                .deleted(voc.getDeleteYesOrNo() != null ? "Y".equals(voc.getDeleteYesOrNo()) : false)
                .vocRegistrationDateTime(voc.getVocRegistrationDateTime())
                .changeProcessorEmployeeNumber(processorId)
                .build();
    }

    /**
     * 두 VOC 엔티티의 차이점을 비교하여 변경 이력을 생성합니다.
     *
     * @param oldVoc 변경 전 VOC
     * @param newVoc 변경 후 VOC
     * @param changeReason 변경 사유
     * @param processorId 처리자 ID
     * @return 변경 이력 엔티티
     */
    public static VocChangeHistory createWithDiff(Voc oldVoc, Voc newVoc, String changeReason, String processorId) {
        VocChangeHistory history = createFromVoc(newVoc, VocChangeType.UPDATE, changeReason, processorId);
        
        // 변경 내역 계산
        Map<String, Object> changes = calculateChanges(oldVoc, newVoc);
        history.changedFieldCount = changes.size();
        history.changeDetails = convertChangesToJson(changes);
        
        return history;
    }

    /**
     * 변경 유형이 특정 유형인지 확인합니다.
     *
     * @param type 확인할 변경 유형
     * @return 일치 여부
     */
    public boolean isChangeType(VocChangeType type) {
        return this.changeType == type;
    }

    /**
     * 특정 시간 범위 내의 변경인지 확인합니다.
     *
     * @param startTime 시작 시간
     * @param endTime 종료 시간
     * @return 범위 내 포함 여부
     */
    public boolean isChangedBetween(LocalDateTime startTime, LocalDateTime endTime) {
        LocalDateTime changeTime = this.id.getVocChangeDateTime();
        return !changeTime.isBefore(startTime) && !changeTime.isAfter(endTime);
    }

    /**
     * 특정 처리자가 변경한 이력인지 확인합니다.
     *
     * @param processorId 처리자 ID
     * @return 일치 여부
     */
    public boolean isChangedBy(String processorId) {
        return this.changeProcessorEmployeeNumber != null && 
               this.changeProcessorEmployeeNumber.equals(processorId);
    }

    /**
     * 변경 요약 정보를 생성합니다.
     *
     * @return 변경 요약
     */
    public String generateChangeSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append(String.format("[%s] ", changeType.getDescription()));
        
        if (changeReason != null && !changeReason.trim().isEmpty()) {
            summary.append(String.format("사유: %s ", changeReason));
        }
        
        if (changedFieldCount != null && changedFieldCount > 0) {
            summary.append(String.format("(%d개 필드 변경)", changedFieldCount));
        }
        
        return summary.toString();
    }

    // private 유틸리티 메서드들
    private static void validateInputs(Voc voc, VocChangeType changeType, String processorId) {
        if (voc == null) {
            throw new IllegalArgumentException("VOC 엔티티는 필수입니다");
        }
        if (changeType == null) {
            throw new IllegalArgumentException("변경 유형은 필수입니다");
        }
        if (processorId == null || processorId.trim().isEmpty()) {
            throw new IllegalArgumentException("처리자 ID는 필수입니다");
        }
    }

    private static Map<String, Object> calculateChanges(Voc oldVoc, Voc newVoc) {
        Map<String, Object> changes = new HashMap<>();
        
        // 주요 필드들의 변경 사항 비교
        compareField(changes, "vocTitle", oldVoc.getVocTitle(), newVoc.getVocTitle());
        compareField(changes, "vocContent", oldVoc.getVocContent(), newVoc.getVocContent());
        compareField(changes, "vocStateCode", oldVoc.getVocStateCode(), newVoc.getVocStateCode());
        compareField(changes, "vocChargePersonNumber", oldVoc.getVocChargePersonNumber(), newVoc.getVocChargePersonNumber());
        // ... 다른 필드들도 비교
        
        return changes;
    }

    private static void compareField(Map<String, Object> changes, String fieldName, Object oldValue, Object newValue) {
        if (!Objects.equals(oldValue, newValue)) {
            Map<String, Object> fieldChange = new HashMap<>();
            fieldChange.put("old", oldValue);
            fieldChange.put("new", newValue);
            changes.put(fieldName, fieldChange);
        }
    }

    private static String convertChangesToJson(Map<String, Object> changes) {
        // JSON 변환 로직 (Jackson ObjectMapper 사용 권장)
        // 여기서는 간단한 형태로 표현
        return changes.toString();
    }
}

// 변경 유형 Enum
public enum VocChangeType {
    CREATE("생성"),
    UPDATE("수정"),
    DELETE("삭제"),
    STATE_CHANGE("상태변경"),
    ASSIGN("담당자할당"),
    COMPLETE("완료처리"),
    RESTORE("복원");

    private final String description;

    VocChangeType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
```

#### 개선된 VocChangeHistoryId.java
```java
package com.osstem.ow.voc.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Embeddable
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@EqualsAndHashCode
public class VocChangeHistoryId implements Serializable {

    @Column(name = "VOC_NO", nullable = false, updatable = false)
    private Long vocNumber;

    @Column(name = "VOC_CHG_DTM", nullable = false, updatable = false)
    private LocalDateTime vocChangeDateTime;

    /**
     * VOC 번호와 변경 시간으로 복합키 생성
     *
     * @param vocNumber VOC 번호
     * @param vocChangeDateTime 변경 일시
     */
    public static VocChangeHistoryId of(Long vocNumber, LocalDateTime vocChangeDateTime) {
        validateInputs(vocNumber, vocChangeDateTime);
        return new VocChangeHistoryId(vocNumber, vocChangeDateTime);
    }

    /**
     * 현재 시간으로 복합키 생성
     *
     * @param vocNumber VOC 번호
     */
    public static VocChangeHistoryId ofNow(Long vocNumber) {
        return of(vocNumber, LocalDateTime.now());
    }

    private static void validateInputs(Long vocNumber, LocalDateTime vocChangeDateTime) {
        if (vocNumber == null || vocNumber <= 0) {
            throw new IllegalArgumentException("VOC 번호는 양수여야 합니다");
        }
        if (vocChangeDateTime == null) {
            throw new IllegalArgumentException("변경 일시는 필수입니다");
        }
    }

    @Override
    public String toString() {
        return String.format("VocChangeHistoryId{vocNumber=%d, vocChangeDateTime=%s}", 
                           vocNumber, vocChangeDateTime);
    }
}
```

## 3. 다른 접근법

### 3.1 Event Sourcing 패턴
```java
@Entity
@Table(name = "TB_VOC_EVENT_STORE")
public class VocEventStore {
    
    @Id
    @GeneratedValue
    private Long eventId;
    
    @Column(name = "VOC_NO")
    private Long vocNumber;
    
    @Column(name = "EVENT_TYPE")
    private String eventType;
    
    @Column(name = "EVENT_VERSION")
    private Long eventVersion;
    
    @Lob
    @Column(name = "EVENT_DATA")
    private String eventData; // JSON 형태의 이벤트 데이터
    
    @Column(name = "EVENT_DTM")
    private LocalDateTime eventDateTime;
    
    @Column(name = "EVENT_USER")
    private String eventUser;
    
    // VOC의 모든 변경을 이벤트로 저장하고 재생하여 현재 상태 복원
    public static List<VocEventStore> replayEvents(Long vocNumber) {
        // 해당 VOC의 모든 이벤트를 시간순으로 조회하여 상태 재생
        return vocEventStoreRepository.findByVocNumberOrderByEventVersionAsc(vocNumber);
    }
}
```

### 3.2 Differential 저장 방식
```java
@Entity
@Table(name = "TB_VOC_CHANGE_DIFF")
public class VocChangeDiff {
    
    @Id
    @GeneratedValue
    private Long diffId;
    
    @Column(name = "VOC_NO")
    private Long vocNumber;
    
    @Column(name = "FIELD_NAME")
    private String fieldName;
    
    @Column(name = "OLD_VALUE")
    private String oldValue;
    
    @Column(name = "NEW_VALUE") 
    private String newValue;
    
    @Column(name = "CHANGE_DTM")
    private LocalDateTime changeDateTime;
    
    @Column(name = "CHANGE_USER")
    private String changeUser;
    
    // 필드별로 변경 사항을 별도로 저장하여 세밀한 추적 가능
}
```

### 3.3 Snapshot + Delta 방식
```java
@Entity
@Table(name = "TB_VOC_SNAPSHOT")
public class VocSnapshot {
    // 주기적으로 전체 스냅샷 저장
    
    @Id
    private VocSnapshotId id;
    
    @Lob
    private String vocDataSnapshot; // 전체 VOC 데이터의 JSON
    
    @OneToMany(mappedBy = "snapshot")
    private List<VocDelta> deltas; // 스냅샷 이후의 변경사항들
}

@Entity
@Table(name = "TB_VOC_DELTA")
public class VocDelta {
    // 스냅샷 이후의 변경사항만 저장
    
    @Id
    @GeneratedValue
    private Long deltaId;
    
    @ManyToOne
    @JoinColumn(name = "SNAPSHOT_ID")
    private VocSnapshot snapshot;
    
    private String deltaData; // 변경사항만 JSON으로 저장
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **파티셔닝**: 날짜별로 테이블 파티셔닝하여 조회 성능 향상
- **압축**: 오래된 이력 데이터는 압축 저장
- **아카이빙**: 일정 기간 경과 후 별도 아카이브 테이블로 이동

### 4.2 데이터 일관성 측면
- **트랜잭션**: VOC 변경과 이력 저장을 같은 트랜잭션에서 처리
- **순서 보장**: 동시 변경 시에도 이력 순서가 올바르게 기록되도록 보장
- **무결성**: 원본 VOC 삭제 시 이력 데이터 처리 방안

### 4.3 보안 및 감사 측면
- **암호화**: 민감한 고객 정보는 이력에서도 암호화 저장
- **접근 제어**: 이력 조회 권한 세밀하게 관리
- **변조 방지**: 이력 데이터의 무결성 검증 메커니즘

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 완전한 이력 저장 구조 | 높음 | 4시간 | 이력 추적 핵심 |
| 변경 유형 및 사유 추가 | 높음 | 2시간 | 이력 의미 부여 |
| 연관관계 설정 | 높음 | 1시간 | 객체 관계 설정 |
| 비즈니스 로직 추가 | 중간 | 3시간 | 이력 활용 기능 |
| 필드 검증 추가 | 중간 | 2시간 | 데이터 무결성 |
| 변경 비교 기능 | 중간 | 4시간 | 고급 이력 기능 |
| 인덱싱 최적화 | 낮음 | 1시간 | 성능 개선 |

**총 예상 소요 시간**: 17시간
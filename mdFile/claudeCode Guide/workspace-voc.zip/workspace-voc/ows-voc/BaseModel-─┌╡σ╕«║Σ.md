# Base Model 클래스들 코드 리뷰
## (ResultDto.java, PagingDto.java, GroupedResultDto.java)

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### ResultDto의 도메인 특화 필드 포함
**문제점**: 기본 응답 DTO에 특정 도메인(serviceCategoryCodes)에 종속적인 필드가 포함됨
**파일**: ResultDto.java 16, 23-27번 라인
```java
public class ResultDto<T> {
    private List<T> data;
    private long totalCount;
    private List<String> serviceCategoryCodes; // 특정 도메인에 종속적인 필드
    
    public ResultDto(List<T> data, long totalCount, List<String> serviceCategoryCodes) {
        // 기본 DTO에 도메인 특화 로직이 혼재됨
    }
}
```

#### 중복된 기능의 클래스 존재
**문제점**: ResultDto와 GroupedResultDto가 유사한 기능을 수행하여 혼란 초래
**파일**: ResultDto.java vs GroupedResultDto.java
```java
// ResultDto
public class ResultDto<T> {
    private List<T> data;
    private long totalCount;
}

// GroupedResultDto
public class GroupedResultDto<T> {
    private List<T> data;
    private long totalCount;  // 동일한 역할
    // + 페이징 정보 추가
}
```

#### Interface의 부적절한 사용
**문제점**: PagingDto가 interface로 되어 있어 매번 구현해야 하는 번거로움
**파일**: PagingDto.java 20번 라인
```java
public interface PagingDto {
    Integer getPageNo();    // 매번 구현 필요
    Integer getPageSize();  // 매번 구현 필요
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 필드 타입 일관성 부족
**문제점**: 유사한 역할의 필드가 서로 다른 타입을 사용
**파일**: ResultDto.java vs GroupedResultDto.java
```java
// ResultDto
private long totalCount;        // long 타입

// GroupedResultDto  
private int pageNo;             // int 타입
private int pageSize;           // int 타입
private long totalCount;        // long 타입 (일관성 부족)
```

#### 중복된 검증 로직
**문제점**: PagingDto의 default 메서드에서 동일한 검증 로직이 중복됨
**파일**: PagingDto.java 30-40번 라인
```java
@JsonIgnore
default Integer getLimit() {
    return getPageSize() == null ? DEFAULT_PAGE_SIZE : Math.min(getPageSize(), MAX_PAGE_SIZE);
}

@JsonIgnore
default Integer getOffset() {
    // 동일한 검증 로직이 반복됨
    Integer adjustedPageSize = getPageSize() == null ? DEFAULT_PAGE_SIZE : Math.min(getPageSize(), MAX_PAGE_SIZE);
}
```

#### 데이터 검증 부재
**문제점**: null 체크나 유효성 검증이 없어 잘못된 데이터 설정 가능
**파일**: 모든 클래스
```java
// ResultDto - null 체크 없음
public ResultDto(List<T> data, long totalCount) {
    this.data = data;           // null 가능
    this.totalCount = totalCount; // 음수 가능
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 유용한 팩토리 메서드 부족
**문제점**: 빈 결과나 일반적인 생성 패턴을 위한 팩토리 메서드 부족
**파일**: ResultDto.java
```java
public class ResultDto<T> {
    // empty(), of(), success() 등의 팩토리 메서드 없음
}
```

#### 페이징 메타데이터 부족
**문제점**: 다음/이전 페이지 존재 여부, 첫/마지막 페이지 여부 등의 정보 부재
**파일**: GroupedResultDto.java
```java
public class GroupedResultDto<T> {
    // hasNext(), hasPrevious(), isFirst(), isLast() 등의 유용한 메서드 없음
}
```

## 2. 개선 코드 예시

### 2.1 통합된 기본 응답 DTO
```java
package com.osstem.ow.voc.model.base;

import lombok.*;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * API 응답을 위한 기본 DTO 클래스
 * 페이징 정보와 함께 리스트 데이터를 반환합니다.
 */
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode
public class ApiResponseDto<T> {

    @Builder.Default
    private List<T> data = Collections.emptyList();
    
    @Builder.Default
    private Long totalCount = 0L;
    
    private Integer pageNo;
    private Integer pageSize;
    private Integer totalPages;
    
    // 메타데이터
    @Builder.Default
    private Boolean hasNext = false;
    
    @Builder.Default
    private Boolean hasPrevious = false;
    
    @Builder.Default
    private Boolean isFirst = true;
    
    @Builder.Default
    private Boolean isLast = true;

    /**
     * 빈 결과를 생성합니다.
     */
    public static <T> ApiResponseDto<T> empty() {
        return ApiResponseDto.<T>builder()
                .data(Collections.emptyList())
                .totalCount(0L)
                .build();
    }

    /**
     * 페이징 없는 단순 리스트 결과를 생성합니다.
     */
    public static <T> ApiResponseDto<T> of(List<T> data) {
        validateData(data);
        
        return ApiResponseDto.<T>builder()
                .data(data)
                .totalCount((long) data.size())
                .build();
    }

    /**
     * 페이징 정보가 포함된 결과를 생성합니다.
     */
    public static <T> ApiResponseDto<T> of(List<T> data, Long totalCount, PageInfo pageInfo) {
        validateData(data);
        validateTotalCount(totalCount);
        validatePageInfo(pageInfo);
        
        return ApiResponseDto.<T>builder()
                .data(data)
                .totalCount(totalCount)
                .pageNo(pageInfo.getPageNo())
                .pageSize(pageInfo.getPageSize())
                .totalPages(calculateTotalPages(totalCount, pageInfo.getPageSize()))
                .hasNext(calculateHasNext(pageInfo.getPageNo(), totalCount, pageInfo.getPageSize()))
                .hasPrevious(calculateHasPrevious(pageInfo.getPageNo()))
                .isFirst(pageInfo.getPageNo() <= 1)
                .isLast(calculateIsLast(pageInfo.getPageNo(), totalCount, pageInfo.getPageSize()))
                .build();
    }

    /**
     * 성공 응답을 생성합니다.
     */
    public static <T> ApiResponseDto<T> success(List<T> data, Long totalCount) {
        return of(data, totalCount, PageInfo.of(1, data.size()));
    }

    /**
     * 데이터가 비어있는지 확인합니다.
     */
    public boolean isEmpty() {
        return data == null || data.isEmpty();
    }

    /**
     * 데이터 개수를 반환합니다.
     */
    public int getDataSize() {
        return data != null ? data.size() : 0;
    }

    /**
     * 유효한 페이징 정보가 있는지 확인합니다.
     */
    public boolean hasPagingInfo() {
        return pageNo != null && pageSize != null;
    }

    // private 유틸리티 메서드들
    private static <T> void validateData(List<T> data) {
        Objects.requireNonNull(data, "데이터는 null일 수 없습니다");
    }

    private static void validateTotalCount(Long totalCount) {
        Objects.requireNonNull(totalCount, "총 개수는 null일 수 없습니다");
        if (totalCount < 0) {
            throw new IllegalArgumentException("총 개수는 0 이상이어야 합니다");
        }
    }

    private static void validatePageInfo(PageInfo pageInfo) {
        Objects.requireNonNull(pageInfo, "페이징 정보는 null일 수 없습니다");
    }

    private static Integer calculateTotalPages(Long totalCount, Integer pageSize) {
        if (pageSize <= 0) {
            return 0;
        }
        return (int) Math.ceil((double) totalCount / pageSize);
    }

    private static Boolean calculateHasNext(Integer pageNo, Long totalCount, Integer pageSize) {
        if (pageSize <= 0) {
            return false;
        }
        return pageNo * pageSize < totalCount;
    }

    private static Boolean calculateHasPrevious(Integer pageNo) {
        return pageNo > 1;
    }

    private static Boolean calculateIsLast(Integer pageNo, Long totalCount, Integer pageSize) {
        if (pageSize <= 0) {
            return true;
        }
        return pageNo * pageSize >= totalCount;
    }
}
```

### 2.2 개선된 페이징 정보 클래스
```java
package com.osstem.ow.voc.model.base;

import lombok.*;

/**
 * 페이징 정보를 담는 클래스
 */
@Getter
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode
public class PageInfo {

    public static final int DEFAULT_PAGE_NO = 1;
    public static final int DEFAULT_PAGE_SIZE = 10;
    public static final int MAX_PAGE_SIZE = 1000;

    @Builder.Default
    private Integer pageNo = DEFAULT_PAGE_NO;
    
    @Builder.Default
    private Integer pageSize = DEFAULT_PAGE_SIZE;

    /**
     * 기본 페이징 정보를 생성합니다.
     */
    public static PageInfo defaultPage() {
        return PageInfo.builder().build();
    }

    /**
     * 페이징 정보를 생성합니다.
     */
    public static PageInfo of(Integer pageNo, Integer pageSize) {
        validatePageNo(pageNo);
        validatePageSize(pageSize);
        
        return PageInfo.builder()
                .pageNo(pageNo)
                .pageSize(Math.min(pageSize, MAX_PAGE_SIZE))
                .build();
    }

    /**
     * OFFSET 값을 계산합니다.
     */
    public Integer getOffset() {
        return (getAdjustedPageNo() - 1) * getAdjustedPageSize();
    }

    /**
     * LIMIT 값을 반환합니다.
     */
    public Integer getLimit() {
        return getAdjustedPageSize();
    }

    /**
     * 조정된 페이지 번호를 반환합니다.
     */
    public Integer getAdjustedPageNo() {
        return pageNo != null && pageNo > 0 ? pageNo : DEFAULT_PAGE_NO;
    }

    /**
     * 조정된 페이지 크기를 반환합니다.
     */
    public Integer getAdjustedPageSize() {
        if (pageSize == null || pageSize <= 0) {
            return DEFAULT_PAGE_SIZE;
        }
        return Math.min(pageSize, MAX_PAGE_SIZE);
    }

    /**
     * 유효한 페이징 정보인지 확인합니다.
     */
    public boolean isValid() {
        return getAdjustedPageNo() > 0 && getAdjustedPageSize() > 0;
    }

    /**
     * 다음 페이지 정보를 생성합니다.
     */
    public PageInfo nextPage() {
        return PageInfo.of(getAdjustedPageNo() + 1, getAdjustedPageSize());
    }

    /**
     * 이전 페이지 정보를 생성합니다.
     */
    public PageInfo previousPage() {
        int prevPageNo = Math.max(1, getAdjustedPageNo() - 1);
        return PageInfo.of(prevPageNo, getAdjustedPageSize());
    }

    // private 검증 메서드들
    private static void validatePageNo(Integer pageNo) {
        if (pageNo != null && pageNo < 1) {
            throw new IllegalArgumentException("페이지 번호는 1 이상이어야 합니다");
        }
    }

    private static void validatePageSize(Integer pageSize) {
        if (pageSize != null && pageSize < 1) {
            throw new IllegalArgumentException("페이지 크기는 1 이상이어야 합니다");
        }
        if (pageSize != null && pageSize > MAX_PAGE_SIZE) {
            throw new IllegalArgumentException("페이지 크기는 " + MAX_PAGE_SIZE + " 이하여야 합니다");
        }
    }
}
```

### 2.3 도메인 특화 응답 DTO (확장 예시)
```java
package com.osstem.ow.voc.model.response;

import com.osstem.ow.voc.model.base.ApiResponseDto;
import lombok.*;

import java.util.List;

/**
 * VOC 서비스 카테고리 정보가 포함된 응답 DTO
 */
@Getter
@EqualsAndHashCode(callSuper = true)
public class VocServiceCategoryResponseDto<T> extends ApiResponseDto<T> {

    private final List<String> serviceCategoryCodes;

    @Builder(builderMethodName = "vocBuilder")
    private VocServiceCategoryResponseDto(List<T> data, Long totalCount, PageInfo pageInfo, 
                                         List<String> serviceCategoryCodes) {
        super(data, totalCount, pageInfo);
        this.serviceCategoryCodes = serviceCategoryCodes;
    }

    /**
     * VOC 서비스 카테고리 응답을 생성합니다.
     */
    public static <T> VocServiceCategoryResponseDto<T> of(List<T> data, Long totalCount, 
                                                         PageInfo pageInfo, List<String> serviceCategoryCodes) {
        return VocServiceCategoryResponseDto.<T>vocBuilder()
                .data(data)
                .totalCount(totalCount)
                .pageInfo(pageInfo)
                .serviceCategoryCodes(serviceCategoryCodes)
                .build();
    }
}
```

## 3. 다른 접근법

### 3.1 제네릭 래퍼 클래스 패턴
```java
public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;
    private ApiMetadata metadata;
    
    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(true, "성공", data, null);
    }
    
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null, null);
    }
}

public class PagedData<T> {
    private List<T> content;
    private PageInfo pageInfo;
    private long totalElements;
}
```

### 3.2 Spring Data의 Page 인터페이스 활용
```java
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

public class CustomPageResponse<T> {
    public static <T> ApiResponseDto<T> fromPage(Page<T> page) {
        return ApiResponseDto.of(
            page.getContent(),
            page.getTotalElements(),
            PageInfo.of(page.getNumber() + 1, page.getSize())
        );
    }
}
```

### 3.3 Builder 패턴을 활용한 플루언트 API
```java
public class ResponseBuilder<T> {
    private List<T> data;
    private Long totalCount;
    private PageInfo pageInfo;
    
    public static <T> ResponseBuilder<T> create() {
        return new ResponseBuilder<>();
    }
    
    public ResponseBuilder<T> withData(List<T> data) {
        this.data = data;
        return this;
    }
    
    public ResponseBuilder<T> withPaging(int pageNo, int pageSize, long totalCount) {
        this.pageInfo = PageInfo.of(pageNo, pageSize);
        this.totalCount = totalCount;
        return this;
    }
    
    public ApiResponseDto<T> build() {
        return ApiResponseDto.of(data, totalCount, pageInfo);
    }
}

// 사용 예시
ApiResponseDto<VocDto> response = ResponseBuilder.<VocDto>create()
    .withData(vocList)
    .withPaging(1, 10, 100)
    .build();
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **불변성**: 응답 DTO들을 불변 객체로 만들어 안전성 확보
- **메모리 효율성**: 빈 결과의 경우 Collections.emptyList() 사용
- **지연 계산**: 페이징 메타데이터를 필요할 때만 계산

### 4.2 API 일관성 측면
- **표준화**: 모든 API 응답이 동일한 구조를 가지도록 표준화
- **확장성**: 새로운 메타데이터 추가 시 기존 API에 영향 없도록 설계
- **버전 관리**: API 응답 구조 변경 시 하위 호환성 고려

### 4.3 사용성 측면
- **문서화**: 각 필드의 의미와 사용법에 대한 명확한 문서화
- **팩토리 메서드**: 일반적인 사용 패턴을 위한 편의 메서드 제공
- **검증**: 잘못된 데이터 설정을 방지하는 유효성 검사

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 도메인 특화 필드 분리 | 높음 | 2시간 | 아키텍처 개선 핵심 |
| 중복 클래스 통합 | 높음 | 3시간 | 코드 중복 제거 |
| Interface를 Class로 변경 | 높음 | 1시간 | 사용성 개선 |
| 필드 타입 일관성 개선 | 중간 | 1시간 | 데이터 일관성 |
| 검증 로직 통합 | 중간 | 2시간 | 코드 품질 향상 |
| 팩토리 메서드 추가 | 중간 | 2시간 | 사용성 개선 |
| 페이징 메타데이터 추가 | 낮음 | 3시간 | 기능 확장 |

**총 예상 소요 시간**: 14시간
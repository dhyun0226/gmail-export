# VocAnswerDetail.java 엔티티 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 연관관계 설정 부재
**문제점**: Voc 엔티티와의 연관관계가 설정되지 않아 객체지향적 접근 불가
**라인**: 22-23번 라인
```java
@Id
@Column(name = "VOC_NO", nullable = false, updatable = false)
private Long vocNumber;
// Voc 엔티티와의 @OneToOne 또는 @ManyToOne 관계 설정 없음
```

#### 중복된 setter 메서드
**문제점**: Lombok @Setter가 있음에도 fileId setter를 명시적으로 재정의
**라인**: 14, 34-36번 라인
```java
@Setter // Lombok이 모든 필드의 setter를 자동 생성
// ...
public void setFileId(String fileId) { // 불필요한 중복 정의
    this.fileId = fileId;
}
```

#### 답변자 정보 부재
**문제점**: 누가 답변을 작성했는지 알 수 없어 감사 추적 불가
**라인**: 전체 엔티티
```java
public class VocAnswerDetail extends BaseEntity {
    // 답변자 ID, 답변자 이름 등의 정보 없음
    // BaseEntity의 rgstProcrId를 사용할 수 있지만 명시적이지 않음
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 필드 검증 부재
**문제점**: 중요한 필드들에 대한 validation 어노테이션이 없음
**라인**: 28-29, 31-32번 라인
```java
@Column(name = "VOC_ANS_CN", length = 1000)
private String vocAnswerContent; // @NotBlank, @Size 검증 없음

@Column(name = "FILE_ID", length = 50)
private String fileId; // @Size 검증 없음
```

#### 비즈니스 로직 부재
**문제점**: 답변 관련 비즈니스 로직이 전혀 없음
**라인**: 전체 엔티티
```java
public class VocAnswerDetail extends BaseEntity {
    // 답변 수정, 답변 삭제, 답변 유효성 검증 등의 비즈니스 로직 없음
}
```

#### 엔티티 관계 모호성
**문제점**: vocNumber를 ID로 사용하지만 Voc와의 관계가 1:1인지 1:N인지 불명확
**라인**: 22-23번 라인
```java
@Id
private Long vocNumber; // Voc와 1:1 관계인지, 복합키의 일부인지 모호함
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### @PrePersist 로직 개선 필요
**문제점**: onCreate 메서드의 로직이 단순하고 명확한 의도 표현 부족
**라인**: 38-43번 라인
```java
@PrePersist
protected void onCreate() {
    if (vocAnswerDateTime == null) {
        vocAnswerDateTime = LocalDateTime.now(); // 항상 현재 시간 설정하는 것이 더 명확할 수 있음
    }
}
```

#### 답변 수정 이력 관리 부재
**문제점**: 답변이 수정된 이력을 추적할 수 없음
**라인**: 전체 엔티티
```java
// 답변 수정 시간, 수정자 등의 이력 관리 필드 없음
// BaseEntity의 필드를 활용할 수 있지만 명시적이지 않음
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_ANS_D", indexes = {
    @Index(name = "idx_voc_answer_datetime", columnList = "VOC_ANS_DTM"),
    @Index(name = "idx_voc_answer_respondent", columnList = "ANS_PRCRN_ID")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocAnswerDetail extends BaseEntity {

    @Id
    @Column(name = "VOC_NO", nullable = false, updatable = false)
    private Long vocNumber;

    // Voc 엔티티와의 연관관계 설정
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_NO", insertable = false, updatable = false)
    private Voc voc;

    @Column(name = "VOC_ANS_DTM", nullable = false)
    @NotNull(message = "VOC 답변 일시는 필수입니다")
    private LocalDateTime vocAnswerDateTime;

    @Column(name = "VOC_ANS_CN", length = 1000)
    @NotBlank(message = "VOC 답변 내용은 필수입니다")
    @Size(max = 1000, message = "VOC 답변 내용은 1000자를 초과할 수 없습니다")
    private String vocAnswerContent;

    @Column(name = "FILE_ID", length = 50)
    @Size(max = 50, message = "파일 ID는 50자를 초과할 수 없습니다")
    private String fileId;

    // 답변자 정보 추가
    @Column(name = "ANS_PRCRN_ID", length = 20, nullable = false)
    @NotBlank(message = "답변 처리자 ID는 필수입니다")
    @Size(max = 20, message = "답변 처리자 ID는 20자를 초과할 수 없습니다")
    private String answerProcessorId;

    @Column(name = "ANS_PRCRN_NM", length = 50)
    @Size(max = 50, message = "답변 처리자명은 50자를 초과할 수 없습니다")
    private String answerProcessorName;

    @Column(name = "ANS_DEPT_CD", length = 30)
    @Size(max = 30, message = "답변 부서코드는 30자를 초과할 수 없습니다")
    private String answerDepartmentCode;

    // 답변 상태 관리
    @Column(name = "ANS_STAT_CD", length = 2, nullable = false)
    @NotBlank(message = "답변 상태코드는 필수입니다")
    @Builder.Default
    private String answerStatusCode = "01"; // 01: 임시저장, 02: 답변완료

    // 답변 수정 이력
    @Column(name = "ANS_MOD_DTM")
    private LocalDateTime answerModificationDateTime;

    @Column(name = "ANS_MOD_PRCRN_ID", length = 20)
    @Size(max = 20, message = "답변 수정자 ID는 20자를 초과할 수 없습니다")
    private String answerModificationProcessorId;

    @Column(name = "ANS_MOD_RSN", length = 200)
    @Size(max = 200, message = "답변 수정 사유는 200자를 초과할 수 없습니다")
    private String answerModificationReason;

    // 상수 정의
    public static final String STATUS_DRAFT = "01";
    public static final String STATUS_COMPLETED = "02";
    public static final String STATUS_DELETED = "99";

    /**
     * 답변 내용을 수정합니다.
     *
     * @param newContent 새로운 답변 내용
     * @param modificationReason 수정 사유
     * @param processorId 수정자 ID
     */
    public void updateAnswerContent(String newContent, String modificationReason, String processorId) {
        validateAnswerContent(newContent);
        validateModificationReason(modificationReason);
        validateProcessorId(processorId);
        
        // 기존 내용과 동일한지 확인
        if (this.vocAnswerContent != null && this.vocAnswerContent.equals(newContent)) {
            throw new IllegalArgumentException("기존 답변 내용과 동일합니다");
        }
        
        this.vocAnswerContent = newContent;
        this.answerModificationDateTime = LocalDateTime.now();
        this.answerModificationProcessorId = processorId;
        this.answerModificationReason = modificationReason;
        
        // BaseEntity 정보 업데이트
        updateModificationInfo(processorId);
    }

    /**
     * 답변을 완료 상태로 변경합니다.
     *
     * @param processorId 처리자 ID
     */
    public void completeAnswer(String processorId) {
        validateProcessorId(processorId);
        validateAnswerForCompletion();
        
        this.answerStatusCode = STATUS_COMPLETED;
        updateModificationInfo(processorId);
    }

    /**
     * 답변을 임시저장 상태로 변경합니다.
     *
     * @param processorId 처리자 ID
     */
    public void saveDraft(String processorId) {
        validateProcessorId(processorId);
        
        this.answerStatusCode = STATUS_DRAFT;
        updateModificationInfo(processorId);
    }

    /**
     * 첨부파일을 추가합니다.
     *
     * @param fileId 파일 ID
     * @param processorId 처리자 ID
     */
    public void attachFile(String fileId, String processorId) {
        validateFileId(fileId);
        validateProcessorId(processorId);
        
        this.fileId = fileId;
        updateModificationInfo(processorId);
    }

    /**
     * 첨부파일을 제거합니다.
     *
     * @param processorId 처리자 ID
     */
    public void removeFile(String processorId) {
        validateProcessorId(processorId);
        
        this.fileId = null;
        updateModificationInfo(processorId);
    }

    /**
     * 답변이 완료되었는지 확인합니다.
     *
     * @return 완료 여부
     */
    public boolean isCompleted() {
        return STATUS_COMPLETED.equals(this.answerStatusCode);
    }

    /**
     * 답변이 임시저장 상태인지 확인합니다.
     *
     * @return 임시저장 여부
     */
    public boolean isDraft() {
        return STATUS_DRAFT.equals(this.answerStatusCode);
    }

    /**
     * 답변이 수정되었는지 확인합니다.
     *
     * @return 수정 여부
     */
    public boolean isModified() {
        return this.answerModificationDateTime != null;
    }

    /**
     * 첨부파일이 있는지 확인합니다.
     *
     * @return 첨부파일 존재 여부
     */
    public boolean hasAttachedFile() {
        return this.fileId != null && !this.fileId.trim().isEmpty();
    }

    @PrePersist
    protected void onCreate() {
        if (this.vocAnswerDateTime == null) {
            this.vocAnswerDateTime = LocalDateTime.now();
        }
        if (this.answerStatusCode == null) {
            this.answerStatusCode = STATUS_DRAFT;
        }
    }

    // private 검증 메서드들
    private void validateAnswerContent(String content) {
        if (content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("답변 내용은 필수입니다");
        }
        if (content.length() > 1000) {
            throw new IllegalArgumentException("답변 내용은 1000자를 초과할 수 없습니다");
        }
    }

    private void validateModificationReason(String reason) {
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("수정 사유는 필수입니다");
        }
        if (reason.length() > 200) {
            throw new IllegalArgumentException("수정 사유는 200자를 초과할 수 없습니다");
        }
    }

    private void validateProcessorId(String processorId) {
        if (processorId == null || processorId.trim().isEmpty()) {
            throw new IllegalArgumentException("처리자 ID는 필수입니다");
        }
    }

    private void validateFileId(String fileId) {
        if (fileId == null || fileId.trim().isEmpty()) {
            throw new IllegalArgumentException("파일 ID는 필수입니다");
        }
        if (fileId.length() > 50) {
            throw new IllegalArgumentException("파일 ID는 50자를 초과할 수 없습니다");
        }
    }

    private void validateAnswerForCompletion() {
        if (this.vocAnswerContent == null || this.vocAnswerContent.trim().isEmpty()) {
            throw new IllegalStateException("답변 내용이 없어 완료 처리할 수 없습니다");
        }
    }

    private void updateModificationInfo(String processorId) {
        this.setModProcDtm(LocalDateTime.now());
        this.setModProcrId(processorId);
    }
}
```

## 3. 다른 접근법

### 3.1 복합키를 이용한 다중 답변 지원
```java
@Entity
@Table(name = "TB_VOC_ANS_D")
@IdClass(VocAnswerDetailId.class)
public class VocAnswerDetail extends BaseEntity {
    
    @Id
    @Column(name = "VOC_NO")
    private Long vocNumber;
    
    @Id
    @Column(name = "ANS_SEQ")
    private Integer answerSequence;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_NO", insertable = false, updatable = false)
    private Voc voc;
    
    // 하나의 VOC에 여러 답변 허용
}

@Embeddable
public class VocAnswerDetailId implements Serializable {
    private Long vocNumber;
    private Integer answerSequence;
    
    // equals, hashCode 구현
}
```

### 3.2 상태 패턴 적용
```java
public abstract class VocAnswerState {
    public abstract void complete(VocAnswerDetail answer);
    public abstract void modify(VocAnswerDetail answer, String content);
    public abstract boolean canDelete();
}

public class DraftAnswerState extends VocAnswerState {
    @Override
    public void complete(VocAnswerDetail answer) {
        answer.setAnswerStatusCode(VocAnswerDetail.STATUS_COMPLETED);
        answer.setState(new CompletedAnswerState());
    }
    
    @Override
    public void modify(VocAnswerDetail answer, String content) {
        answer.setVocAnswerContent(content);
    }
    
    @Override
    public boolean canDelete() {
        return true;
    }
}

public class CompletedAnswerState extends VocAnswerState {
    @Override
    public void complete(VocAnswerDetail answer) {
        throw new IllegalStateException("이미 완료된 답변입니다");
    }
    
    @Override
    public void modify(VocAnswerDetail answer, String content) {
        throw new IllegalStateException("완료된 답변은 수정할 수 없습니다");
    }
    
    @Override
    public boolean canDelete() {
        return false;
    }
}
```

### 3.3 이벤트 소싱 패턴
```java
@Entity
public class VocAnswerDetail extends BaseEntity {
    
    @OneToMany(mappedBy = "vocAnswerDetail", cascade = CascadeType.ALL)
    private List<VocAnswerEvent> events = new ArrayList<>();
    
    public void recordEvent(VocAnswerEvent event) {
        events.add(event);
        applyEvent(event);
    }
    
    private void applyEvent(VocAnswerEvent event) {
        switch (event.getEventType()) {
            case ANSWER_CREATED:
                // 답변 생성 이벤트 처리
                break;
            case ANSWER_MODIFIED:
                // 답변 수정 이벤트 처리
                break;
            case ANSWER_COMPLETED:
                // 답변 완료 이벤트 처리
                break;
        }
    }
}

@Entity
public class VocAnswerEvent {
    @Id
    @GeneratedValue
    private Long id;
    
    @ManyToOne
    private VocAnswerDetail vocAnswerDetail;
    
    private VocAnswerEventType eventType;
    private String eventData;
    private LocalDateTime eventDateTime;
    private String processorId;
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **지연 로딩**: Voc 엔티티와의 연관관계에서 LAZY 로딩 사용
- **인덱싱**: 답변 일시, 답변자 ID 등에 대한 인덱스 설정
- **캐싱**: 자주 조회되는 답변에 대한 2차 캐시 적용

### 4.2 데이터 일관성 측면
- **제약조건**: 데이터베이스 레벨의 외래키 제약조건 설정
- **트랜잭션**: 답변 생성/수정 시 VOC 상태 동기화
- **낙관적 락**: 동시 수정 방지를 위한 @Version 사용

### 4.3 보안 측면
- **접근 제어**: 답변 수정 권한 검증
- **감사 로그**: 답변 수정 이력의 상세 기록
- **데이터 마스킹**: 민감한 답변 내용에 대한 마스킹 처리

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 연관관계 설정 | 높음 | 2시간 | 객체지향 설계 핵심 |
| 중복 setter 제거 | 높음 | 10분 | 코드 정리 |
| 답변자 정보 추가 | 높음 | 3시간 | 감사 추적 필수 |
| 필드 검증 추가 | 중간 | 1시간 | 데이터 무결성 |
| 비즈니스 로직 추가 | 중간 | 4시간 | 도메인 로직 강화 |
| 답변 상태 관리 | 중간 | 2시간 | 워크플로우 개선 |
| @PrePersist 개선 | 낮음 | 30분 | 코드 품질 향상 |

**총 예상 소요 시간**: 12시간 40분
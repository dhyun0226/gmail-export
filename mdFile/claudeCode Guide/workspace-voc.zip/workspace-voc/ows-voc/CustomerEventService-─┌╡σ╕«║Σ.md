# CustomerEventService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 예외 처리 부재
**문제점**: Feign Client 호출 실패 시 예외 처리가 없어 장애 전파 가능
**라인**: 전체 메서드 (20-38번 라인)
```java
public EventResponseDto getEvent(Long id, String serviceCategoryCode, String userRole) {
    return eventServiceClient.getEventById(id, serviceCategoryCode, userRole); // 예외 처리 없음
}
```

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 20, 24, 28, 32, 36번 라인
```java
public EventResponseDto getEvent(Long id, String serviceCategoryCode, String userRole) {
    // id, serviceCategoryCode, userRole null 검증 없음
    return eventServiceClient.getEventById(id, serviceCategoryCode, userRole);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 로깅 부재
**문제점**: 비즈니스 로직 추적과 디버깅이 어려움
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class CustomerEventService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 불필요한 의존성
**문제점**: VocChargePersonService를 주입받지만 사용하지 않음
**라인**: 18번 라인
```java
private final VocChargePersonService vocChargePersonService; // 사용되지 않는 의존성
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 어떤 작업을 수행했는지 추적 불가
**라인**: 전체 메서드
```java
public EventResponseDto create(EventRequestDto dto) {
    // 사용자 정보 로깅 없음
    return eventServiceClient.createEvent(dto);
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 외부 서비스 호출에 대한 트랜잭션 전략이 명확하지 않음
**라인**: 전체 메서드
```java
// @Transactional 애노테이션 없음
public void delete(Long id) {
    eventServiceClient.deleteEvent(id);
}
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.EventServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.EventRequestDto;
import com.osstem.ow.voc.model.customer.EventResponseDto;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerEventService {

    private final EventServiceClient eventServiceClient;

    /**
     * 이벤트 단건 조회
     * @param id 이벤트 ID
     * @param serviceCategoryCode 서비스 카테고리 코드
     * @param userRole 사용자 역할
     * @return 이벤트 정보
     */
    public EventResponseDto getEvent(Long id, String serviceCategoryCode, String userRole) {
        log.info("이벤트 조회 시작 - id: {}, serviceCategoryCode: {}, userRole: {}", 
                id, serviceCategoryCode, userRole);
        
        // 파라미터 검증
        validateEventId(id);
        validateServiceCategoryCode(serviceCategoryCode);
        validateUserRole(userRole);
        
        try {
            EventResponseDto result = eventServiceClient.getEventById(id, serviceCategoryCode, userRole);
            log.info("이벤트 조회 완료 - id: {}", id);
            return result;
        } catch (Exception e) {
            log.error("이벤트 조회 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("event.retrieval.failed", e);
        }
    }

    /**
     * 이벤트 생성
     * @param dto 이벤트 생성 요청 정보
     * @return 생성된 이벤트 정보
     */
    public EventResponseDto create(EventRequestDto dto) {
        log.info("이벤트 생성 시작 - title: {}", dto != null ? dto.getTitle() : "null");
        
        // 파라미터 검증
        validateEventRequestDto(dto);
        
        try {
            EventResponseDto result = eventServiceClient.createEvent(dto);
            log.info("이벤트 생성 완료 - id: {}", result.getId());
            return result;
        } catch (Exception e) {
            log.error("이벤트 생성 실패 - dto: {}, error: {}", dto, e.getMessage(), e);
            throw new BusinessException("event.creation.failed", e);
        }
    }

    /**
     * 이벤트 수정
     * @param id 이벤트 ID
     * @param dto 이벤트 수정 요청 정보
     * @return 수정된 이벤트 정보
     */
    public EventResponseDto update(Long id, EventRequestDto dto) {
        log.info("이벤트 수정 시작 - id: {}, title: {}", id, dto != null ? dto.getTitle() : "null");
        
        // 파라미터 검증
        validateEventId(id);
        validateEventRequestDto(dto);
        
        try {
            EventResponseDto result = eventServiceClient.updateEvent(id, dto);
            log.info("이벤트 수정 완료 - id: {}", id);
            return result;
        } catch (Exception e) {
            log.error("이벤트 수정 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("event.update.failed", e);
        }
    }

    /**
     * 이벤트 삭제
     * @param id 이벤트 ID
     */
    public void delete(Long id) {
        log.info("이벤트 삭제 시작 - id: {}", id);
        
        // 파라미터 검증
        validateEventId(id);
        
        try {
            eventServiceClient.deleteEvent(id);
            log.info("이벤트 삭제 완료 - id: {}", id);
        } catch (Exception e) {
            log.error("이벤트 삭제 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("event.deletion.failed", e);
        }
    }

    /**
     * 이벤트 검색
     * @param dto 검색 조건
     * @return 검색 결과
     */
    public ResultDto<EventResponseDto> search(EventRequestDto dto) {
        log.info("이벤트 검색 시작 - dto: {}", dto);
        
        // 파라미터 검증
        validateEventRequestDto(dto);
        
        try {
            ResultDto<EventResponseDto> result = eventServiceClient.searchEvents(dto);
            log.info("이벤트 검색 완료 - count: {}", result.getList().size());
            return result;
        } catch (Exception e) {
            log.error("이벤트 검색 실패 - dto: {}, error: {}", dto, e.getMessage(), e);
            throw new BusinessException("event.search.failed", e);
        }
    }

    // 검증 메서드들
    private void validateEventId(Long id) {
        if (Objects.isNull(id) || id <= 0) {
            throw new BusinessException("event.invalid.id");
        }
    }

    private void validateServiceCategoryCode(String serviceCategoryCode) {
        if (!StringUtils.hasText(serviceCategoryCode)) {
            throw new BusinessException("event.invalid.serviceCategoryCode");
        }
    }

    private void validateUserRole(String userRole) {
        if (!StringUtils.hasText(userRole)) {
            throw new BusinessException("event.invalid.userRole");
        }
    }

    private void validateEventRequestDto(EventRequestDto dto) {
        if (Objects.isNull(dto)) {
            throw new BusinessException("event.invalid.request");
        }
        // 추가적인 DTO 내부 필드 검증 로직 필요
    }
}
```

## 3. 다른 접근법

### 3.1 AOP를 이용한 로깅 처리
```java
@Aspect
@Component
@Slf4j
public class ServiceLoggingAspect {
    
    @Around("execution(* com.osstem.ow.voc.domain.CustomerEventService.*(..))")
    public Object logServiceMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();
        
        log.info("서비스 메서드 호출 시작: {} - args: {}", methodName, Arrays.toString(args));
        
        try {
            Object result = joinPoint.proceed();
            log.info("서비스 메서드 호출 완료: {}", methodName);
            return result;
        } catch (Exception e) {
            log.error("서비스 메서드 호출 실패: {} - error: {}", methodName, e.getMessage(), e);
            throw e;
        }
    }
}
```

### 3.2 Circuit Breaker 패턴 적용
```java
@Service
@RequiredArgsConstructor
public class CustomerEventService {
    
    private final EventServiceClient eventServiceClient;
    private final CircuitBreaker circuitBreaker;
    
    @CircuitBreaker(name = "eventService", fallbackMethod = "getEventFallback")
    public EventResponseDto getEvent(Long id, String serviceCategoryCode, String userRole) {
        return eventServiceClient.getEventById(id, serviceCategoryCode, userRole);
    }
    
    public EventResponseDto getEventFallback(Long id, String serviceCategoryCode, String userRole, Exception ex) {
        log.warn("이벤트 서비스 호출 실패, fallback 실행 - id: {}, error: {}", id, ex.getMessage());
        return EventResponseDto.createEmptyResponse();
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **Feign Client 타임아웃 설정**: 외부 서비스 호출 시 적절한 타임아웃 설정 필요
- **Connection Pool 관리**: HTTP 클라이언트 연결 풀 설정 최적화
- **캐싱 전략**: 자주 조회되는 이벤트 정보에 대한 캐싱 고려

### 4.2 보안 측면  
- **인증/인가 검증**: userRole 파라미터에 대한 권한 검증 로직 필요
- **데이터 마스킹**: 로그에서 민감한 정보 마스킹 처리

### 4.3 운영 측면
- **헬스체크**: 외부 서비스 상태 모니터링 기능 추가
- **메트릭 수집**: 외부 서비스 호출 성공/실패율, 응답시간 등 수집
- **알람 설정**: 외부 서비스 장애 시 알람 기능

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 예외 처리 추가 | 높음 | 2시간 | 서비스 안정성 핵심 |
| 파라미터 검증 | 높음 | 1시간 | NPE 방지 필수 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| 불필요한 의존성 제거 | 낮음 | 10분 | 코드 정리 |
| Circuit Breaker 적용 | 중간 | 4시간 | 외부 서비스 장애 대응 |

**총 예상 소요 시간**: 8시간 10분
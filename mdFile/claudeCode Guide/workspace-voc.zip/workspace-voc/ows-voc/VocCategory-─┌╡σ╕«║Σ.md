# VocCategory.java 엔티티 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### Y/N 플래그의 Character 처리
**문제점**: Boolean으로 처리해야 할 Y/N 값을 Character로 처리하여 타입 안전성 부족
**라인**: 41, 64, 68번 라인
```java
@Column(name = "OPEN_YN", nullable = false)
private Character openYn; // Boolean이 적절

@Column(name = "CUSTMCT_YN", nullable = false) 
private Character customerCenterYn; // Boolean이 적절

@Column(name = "DEL_YN", nullable = false)
private Character deleteYn; // Boolean이 적절
```

#### 과도하게 긴 필드명
**문제점**: 필드명이 너무 길어 가독성과 유지보수성 저하
**라인**: 51, 56, 60번 라인
```java
private String registererCorporationDepartmentCode; // 너무 긴 필드명
private String registererCorporationEmployeeNumber; // 너무 긴 필드명  
private Instant vocCategoryRegistererCorporationDatetime; // 필드명과 의미 불일치
```

#### BigDecimal을 정렬 순서로 사용
**문제점**: 단순한 정렬 순서에 BigDecimal 사용은 과도하고 성능상 불리
**라인**: 72번 라인
```java
@Column(name = "SORT_ORD", nullable = false, precision = 10)
private BigDecimal sortOrder; // Integer로 충분함
```

### 1.2 심각도 중간 (High) - 🟡

#### 양방향 연관관계 설정 부재
**문제점**: 상위 카테고리와의 관계는 있지만 하위 카테고리 목록 관계가 없음
**라인**: 29-31번 라인
```java
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "UP_VOC_CTG_CD")
private VocCategory upVocCategoryCode; // 상위 카테고리만 있고 하위 카테고리 리스트 없음
```

#### 필드명과 타입 불일치
**문제점**: DateTime을 나타내는 필드가 Instant 타입이면서 필드명이 부정확
**라인**: 60번 라인
```java
@Column(name = "VOC_CTG_RGST_DTM", nullable = false)
private Instant vocCategoryRegistererCorporationDatetime; 
// 필드명이 등록 일시를 나타내는데 필드명에 registererCorporation이 포함됨
```

#### 비즈니스 로직 부재
**문제점**: 카테고리 관련 비즈니스 로직이 전혀 없음
**라인**: 전체 엔티티
```java
public class VocCategory extends BaseEntity {
    // 카테고리 활성화/비활성화, 정렬 순서 변경, 하위 카테고리 관리 등의 로직 없음
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 기본값 설정 방식
**문제점**: @ColumnDefault보다는 @Builder.Default가 더 명확할 수 있음
**라인**: 39-40번 라인
```java
@ColumnDefault("'Y'")
@Column(name = "OPEN_YN", nullable = false)
private Character openYn; // @Builder.Default 사용 고려
```

#### 연관관계 필드명 일관성 부족
**문제점**: 연관관계 필드명이 실제 관계를 명확히 표현하지 못함
**라인**: 30-31번 라인
```java
@JoinColumn(name = "UP_VOC_CTG_CD")
private VocCategory upVocCategoryCode; // parentCategory가 더 명확함
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "TB_VOC_CTG_C", indexes = {
    @Index(name = "idx_voc_category_parent", columnList = "UP_VOC_CTG_CD"),
    @Index(name = "idx_voc_category_sort", columnList = "SORT_ORD"),
    @Index(name = "idx_voc_category_active", columnList = "OPEN_YN, DEL_YN")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocCategory extends BaseEntity {

    // 상수 정의
    public static final String ACTIVE_YES = "Y";
    public static final String ACTIVE_NO = "N";
    public static final String DELETED_YES = "Y";
    public static final String DELETED_NO = "N";

    @Id
    @Size(max = 12, message = "VOC 카테고리 코드는 12자를 초과할 수 없습니다")
    @Column(name = "VOC_CTG_CD", nullable = false, length = 12)
    private String vocCategoryCode;

    // 양방향 자기 참조 관계 설정
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UP_VOC_CTG_CD")
    private VocCategory parentCategory;

    @OneToMany(mappedBy = "parentCategory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<VocCategory> childCategories = new ArrayList<>();

    @Size(max = 100, message = "VOC 카테고리명은 100자를 초과할 수 없습니다")
    @NotBlank(message = "VOC 카테고리명은 필수입니다")
    @Column(name = "VOC_CTG_NM", nullable = false, length = 100)
    private String vocCategoryName;

    @Column(name = "OPEN_YN", nullable = false, length = 1)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean active = true;

    // 등록자 정보 - Value Object로 분리 고려
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "corporationCode", column = @Column(name = "RGSTR_CPRN_CD", nullable = false, length = 3)),
        @AttributeOverride(name = "departmentCode", column = @Column(name = "RGSTR_DEPT_CD", nullable = false, length = 30)),
        @AttributeOverride(name = "employeeNumber", column = @Column(name = "RGSTR_EMP_NO", nullable = false, length = 60))
    })
    private RegistererInfo registererInfo;

    @NotNull(message = "VOC 카테고리 등록일시는 필수입니다")
    @Column(name = "VOC_CTG_RGST_DTM", nullable = false)
    private LocalDateTime registrationDateTime;

    @Column(name = "CUSTMCT_YN", nullable = false, length = 1)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean customerCenterVisible = false;

    @Column(name = "DEL_YN", nullable = false, length = 1)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean deleted = false;

    @NotNull(message = "정렬 순서는 필수입니다")
    @Column(name = "SORT_ORD", nullable = false)
    @Min(value = 1, message = "정렬 순서는 1 이상이어야 합니다")
    private Integer sortOrder;

    // 추가 필드들
    @Column(name = "CTG_DESC", length = 500)
    @Size(max = 500, message = "카테고리 설명은 500자를 초과할 수 없습니다")
    private String categoryDescription;

    @Column(name = "CTG_DEPTH")
    @Min(value = 1, message = "카테고리 깊이는 1 이상이어야 합니다")
    @Max(value = 5, message = "카테고리 깊이는 5 이하여야 합니다")
    private Integer categoryDepth;

    @Column(name = "CTG_PATH", length = 200)
    @Size(max = 200, message = "카테고리 경로는 200자를 초과할 수 없습니다")
    private String categoryPath; // 예: "ROOT > 제품문의 > 임플란트"

    /**
     * 카테고리를 활성화합니다.
     *
     * @param processorId 처리자 ID
     */
    public void activate(String processorId) {
        validateProcessorId(processorId);
        
        if (Boolean.TRUE.equals(this.deleted)) {
            throw new IllegalStateException("삭제된 카테고리는 활성화할 수 없습니다");
        }
        
        this.active = true;
        updateModificationInfo(processorId);
    }

    /**
     * 카테고리를 비활성화합니다.
     *
     * @param processorId 처리자 ID
     */
    public void deactivate(String processorId) {
        validateProcessorId(processorId);
        
        // 하위 카테고리가 있는 경우 비활성화 불가
        if (!childCategories.isEmpty()) {
            long activeChildCount = childCategories.stream()
                    .filter(child -> Boolean.TRUE.equals(child.active) && Boolean.FALSE.equals(child.deleted))
                    .count();
            
            if (activeChildCount > 0) {
                throw new IllegalStateException("활성화된 하위 카테고리가 있어 비활성화할 수 없습니다");
            }
        }
        
        this.active = false;
        updateModificationInfo(processorId);
    }

    /**
     * 카테고리를 논리적으로 삭제합니다.
     *
     * @param processorId 처리자 ID
     */
    public void markAsDeleted(String processorId) {
        validateProcessorId(processorId);
        
        // 하위 카테고리가 있는 경우 삭제 불가
        if (!childCategories.isEmpty()) {
            long activeChildCount = childCategories.stream()
                    .filter(child -> Boolean.FALSE.equals(child.deleted))
                    .count();
            
            if (activeChildCount > 0) {
                throw new IllegalStateException("하위 카테고리가 있어 삭제할 수 없습니다");
            }
        }
        
        this.deleted = true;
        this.active = false; // 삭제 시 자동으로 비활성화
        updateModificationInfo(processorId);
    }

    /**
     * 정렬 순서를 변경합니다.
     *
     * @param newSortOrder 새로운 정렬 순서
     * @param processorId 처리자 ID
     */
    public void changeSortOrder(Integer newSortOrder, String processorId) {
        validateSortOrder(newSortOrder);
        validateProcessorId(processorId);
        
        if (this.sortOrder.equals(newSortOrder)) {
            return; // 동일한 순서면 변경하지 않음
        }
        
        this.sortOrder = newSortOrder;
        updateModificationInfo(processorId);
    }

    /**
     * 카테고리명을 수정합니다.
     *
     * @param newName 새로운 카테고리명
     * @param processorId 처리자 ID
     */
    public void changeName(String newName, String processorId) {
        validateCategoryName(newName);
        validateProcessorId(processorId);
        
        if (this.vocCategoryName.equals(newName)) {
            return; // 동일한 이름이면 변경하지 않음
        }
        
        this.vocCategoryName = newName;
        updateCategoryPath(); // 카테고리 경로 업데이트
        updateModificationInfo(processorId);
    }

    /**
     * 상위 카테고리를 변경합니다.
     *
     * @param newParent 새로운 상위 카테고리
     * @param processorId 처리자 ID
     */
    public void changeParent(VocCategory newParent, String processorId) {
        validateProcessorId(processorId);
        
        // 순환 참조 검증
        if (newParent != null && isAncestorOf(newParent)) {
            throw new IllegalArgumentException("순환 참조가 발생합니다");
        }
        
        // 기존 부모에서 제거
        if (this.parentCategory != null) {
            this.parentCategory.childCategories.remove(this);
        }
        
        // 새로운 부모에 추가
        this.parentCategory = newParent;
        if (newParent != null) {
            newParent.childCategories.add(this);
            this.categoryDepth = newParent.categoryDepth + 1;
        } else {
            this.categoryDepth = 1;
        }
        
        updateCategoryPath(); // 경로 업데이트
        updateModificationInfo(processorId);
    }

    /**
     * 고객센터 노출 여부를 변경합니다.
     *
     * @param visible 노출 여부
     * @param processorId 처리자 ID
     */
    public void setCustomerCenterVisibility(Boolean visible, String processorId) {
        validateProcessorId(processorId);
        
        this.customerCenterVisible = visible;
        updateModificationInfo(processorId);
    }

    /**
     * 카테고리가 활성화 상태인지 확인합니다.
     *
     * @return 활성화 여부
     */
    public boolean isActive() {
        return Boolean.TRUE.equals(this.active) && Boolean.FALSE.equals(this.deleted);
    }

    /**
     * 카테고리가 삭제된 상태인지 확인합니다.
     *
     * @return 삭제 여부
     */
    public boolean isDeleted() {
        return Boolean.TRUE.equals(this.deleted);
    }

    /**
     * 루트 카테고리인지 확인합니다.
     *
     * @return 루트 카테고리 여부
     */
    public boolean isRootCategory() {
        return this.parentCategory == null;
    }

    /**
     * 리프 카테고리인지 확인합니다.
     *
     * @return 리프 카테고리 여부
     */
    public boolean isLeafCategory() {
        return this.childCategories.isEmpty() || 
               this.childCategories.stream().allMatch(child -> Boolean.TRUE.equals(child.deleted));
    }

    /**
     * 고객센터에 노출되는지 확인합니다.
     *
     * @return 고객센터 노출 여부
     */
    public boolean isVisibleInCustomerCenter() {
        return Boolean.TRUE.equals(this.customerCenterVisible) && isActive();
    }

    /**
     * 특정 카테고리의 조상인지 확인합니다.
     *
     * @param candidate 확인할 카테고리
     * @return 조상 여부
     */
    public boolean isAncestorOf(VocCategory candidate) {
        if (candidate == null) {
            return false;
        }
        
        VocCategory current = candidate.parentCategory;
        while (current != null) {
            if (current.equals(this)) {
                return true;
            }
            current = current.parentCategory;
        }
        return false;
    }

    /**
     * 카테고리의 모든 하위 카테고리를 조회합니다.
     *
     * @return 하위 카테고리 리스트 (활성화된 것만)
     */
    public List<VocCategory> getActiveChildCategories() {
        return childCategories.stream()
                .filter(child -> Boolean.TRUE.equals(child.active) && Boolean.FALSE.equals(child.deleted))
                .sorted((a, b) -> a.sortOrder.compareTo(b.sortOrder))
                .toList();
    }

    @PrePersist
    protected void onCreate() {
        if (this.registrationDateTime == null) {
            this.registrationDateTime = LocalDateTime.now();
        }
        if (this.active == null) {
            this.active = true;
        }
        if (this.deleted == null) {
            this.deleted = false;
        }
        if (this.customerCenterVisible == null) {
            this.customerCenterVisible = false;
        }
        
        updateCategoryDepthAndPath();
    }

    // private 메서드들
    private void updateCategoryPath() {
        StringBuilder pathBuilder = new StringBuilder();
        List<String> pathComponents = new ArrayList<>();
        
        VocCategory current = this;
        while (current != null) {
            pathComponents.add(0, current.vocCategoryName);
            current = current.parentCategory;
        }
        
        this.categoryPath = String.join(" > ", pathComponents);
    }

    private void updateCategoryDepthAndPath() {
        // 카테고리 깊이 계산
        int depth = 1;
        VocCategory current = this.parentCategory;
        while (current != null) {
            depth++;
            current = current.parentCategory;
        }
        this.categoryDepth = depth;
        
        // 카테고리 경로 업데이트
        updateCategoryPath();
    }

    // 검증 메서드들
    private void validateProcessorId(String processorId) {
        if (processorId == null || processorId.trim().isEmpty()) {
            throw new IllegalArgumentException("처리자 ID는 필수입니다");
        }
    }

    private void validateSortOrder(Integer sortOrder) {
        if (sortOrder == null || sortOrder < 1) {
            throw new IllegalArgumentException("정렬 순서는 1 이상이어야 합니다");
        }
    }

    private void validateCategoryName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("카테고리명은 필수입니다");
        }
        if (name.length() > 100) {
            throw new IllegalArgumentException("카테고리명은 100자를 초과할 수 없습니다");
        }
    }

    private void updateModificationInfo(String processorId) {
        this.setModProcDtm(LocalDateTime.now());
        this.setModProcrId(processorId);
    }
}

// Value Object 클래스
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegistererInfo {
    
    @Size(max = 3, message = "회사 코드는 3자를 초과할 수 없습니다")
    @NotBlank(message = "회사 코드는 필수입니다")
    private String corporationCode;
    
    @Size(max = 30, message = "부서 코드는 30자를 초과할 수 없습니다") 
    @NotBlank(message = "부서 코드는 필수입니다")
    private String departmentCode;
    
    @Size(max = 60, message = "직원 번호는 60자를 초과할 수 없습니다")
    @NotBlank(message = "직원 번호는 필수입니다")
    private String employeeNumber;
}

// Y/N을 Boolean으로 변환하는 Converter (이미 Voc 엔티티에서 정의했음)
```

## 3. 다른 접근법

### 3.1 Nested Set Model을 이용한 트리 구조
```java
@Entity
public class VocCategory extends BaseEntity {
    
    @Column(name = "TREE_LEFT")
    private Integer treeLeft;
    
    @Column(name = "TREE_RIGHT") 
    private Integer treeRight;
    
    @Column(name = "TREE_LEVEL")
    private Integer treeLevel;
    
    /**
     * 하위 카테고리들을 효율적으로 조회
     */
    public List<VocCategory> getDescendants() {
        // SELECT * FROM TB_VOC_CTG_C WHERE TREE_LEFT > :left AND TREE_RIGHT < :right
        return vocCategoryRepository.findByTreeLeftGreaterThanAndTreeRightLessThan(this.treeLeft, this.treeRight);
    }
    
    /**
     * 카테고리 이동 시 트리 구조 업데이트
     */
    public void moveTo(VocCategory newParent) {
        // Nested Set Model 알고리즘으로 트리 구조 업데이트
    }
}
```

### 3.2 카테고리 타입을 이용한 전략 패턴
```java
public enum VocCategoryType {
    PRODUCT("제품 관련", new ProductCategoryHandler()),
    SERVICE("서비스 관련", new ServiceCategoryHandler()),
    COMPLAINT("불만 접수", new ComplaintCategoryHandler());
    
    private final String description;
    private final CategoryHandler handler;
    
    VocCategoryType(String description, CategoryHandler handler) {
        this.description = description;
        this.handler = handler;
    }
    
    public void handleVocCreation(Voc voc) {
        handler.handleVocCreation(voc);
    }
}

@Entity
public class VocCategory extends BaseEntity {
    
    @Enumerated(EnumType.STRING)
    @Column(name = "CTG_TYPE")
    private VocCategoryType categoryType;
    
    public void processNewVoc(Voc voc) {
        if (categoryType != null) {
            categoryType.handleVocCreation(voc);
        }
    }
}
```

### 3.3 카테고리 권한 관리
```java
@Entity
public class VocCategoryPermission {
    @Id
    @GeneratedValue
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "VOC_CTG_CD")
    private VocCategory vocCategory;
    
    @Column(name = "DEPT_CD")
    private String departmentCode;
    
    @Column(name = "ROLE_CD")
    private String roleCode;
    
    @Enumerated(EnumType.STRING)
    private PermissionType permissionType; // READ, WRITE, ADMIN
}

@Entity
public class VocCategory extends BaseEntity {
    
    @OneToMany(mappedBy = "vocCategory", cascade = CascadeType.ALL)
    private List<VocCategoryPermission> permissions = new ArrayList<>();
    
    /**
     * 특정 사용자가 이 카테고리에 접근 권한이 있는지 확인
     */
    public boolean hasPermission(String departmentCode, String roleCode, PermissionType requiredPermission) {
        return permissions.stream()
                .anyMatch(permission -> 
                    permission.getDepartmentCode().equals(departmentCode) &&
                    permission.getRoleCode().equals(roleCode) &&
                    permission.getPermissionType().ordinal() >= requiredPermission.ordinal());
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **트리 쿼리 최적화**: WITH RECURSIVE 또는 Nested Set Model 사용
- **캐싱**: 카테고리 트리는 자주 변경되지 않으므로 캐싱 적용
- **인덱싱**: 부모-자식 관계, 정렬 순서에 대한 복합 인덱스

### 4.2 데이터 일관성 측면
- **참조 무결성**: 상위-하위 카테고리 관계의 무결성 보장
- **순환 참조 방지**: 애플리케이션 레벨과 DB 레벨 모두에서 검증
- **트랜잭션**: 카테고리 이동 시 관련된 모든 데이터의 일관성 보장

### 4.3 사용성 측면
- **카테고리 경로**: 사용자가 현재 위치를 쉽게 파악할 수 있도록 breadcrumb 지원
- **드래그 앤 드롭**: 관리자 화면에서 카테고리 순서 변경 지원
- **다국어 지원**: 카테고리명의 다국어 버전 관리

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| Y/N Boolean 변환 | 높음 | 2시간 | 타입 안전성 핵심 |
| 필드명 개선 | 높음 | 3시간 | 가독성 향상 핵심 |
| BigDecimal을 Integer로 변경 | 높음 | 1시간 | 성능 개선 |
| 양방향 연관관계 설정 | 중간 | 3시간 | 객체지향 설계 개선 |
| 비즈니스 로직 추가 | 중간 | 6시간 | 도메인 로직 강화 |
| 카테고리 경로 관리 | 중간 | 4시간 | 사용성 개선 |
| Value Object 분리 | 낮음 | 2시간 | 코드 구조 개선 |

**총 예상 소요 시간**: 21시간
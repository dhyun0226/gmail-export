# ItemCodeMappingService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 하드코딩된 매핑 데이터
**문제점**: 품목 코드 매핑 정보가 소스코드에 하드코딩되어 운영 중 변경 불가
**라인**: 22-35번 라인
```java
@PostConstruct
public void init() {
    itemCodeToNameMap = new HashMap<>();
    
    // 하드코딩된 매핑 데이터 - 변경 시 서버 재시작 필요
    itemCodeToNameMap.put("implant","임플란트");
    itemCodeToNameMap.put("instrument","기구");
    // ... 더 많은 하드코딩된 데이터
}
```

#### 동시성 문제
**문제점**: HashMap은 thread-safe하지 않아 멀티스레드 환경에서 문제 발생 가능
**라인**: 12, 19번 라인
```java
private Map<String, String> itemCodeToNameMap; // HashMap은 thread-safe하지 않음

public void init() {
    itemCodeToNameMap = new HashMap<>(); // 동시성 문제 가능
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 45-46번 라인
```java
public String getItemNameByCode(String itemCode) {
    // itemCode null 검증 없음
    return itemCodeToNameMap.getOrDefault(itemCode, itemCode);
}
```

#### 로깅 부재
**문제점**: 매핑 실패나 초기화 과정을 추적할 수 없음
**라인**: 전체 클래스
```java
@Service
public class ItemCodeMappingService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 확장성 부족
**문제점**: 새로운 품목 코드 추가나 기존 코드 수정을 위한 관리 기능 부재
**라인**: 전체 클래스
```java
// 매핑 데이터 추가/수정/삭제 메서드 없음
// 동적 로딩 기능 없음
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 초기화 실패 처리 부재
**문제점**: @PostConstruct 메서드에서 초기화 실패 시 처리 로직 없음
**라인**: 17-37번 라인
```java
@PostConstruct
public void init() {
    // 초기화 실패에 대한 예외 처리 없음
    itemCodeToNameMap = new HashMap<>();
}
```

#### 테스트 가능성 부족
**문제점**: 하드코딩으로 인해 테스트 시 다양한 시나리오 검증 어려움
**라인**: 전체 클래스
```java
// 테스트를 위한 설정 주입 기능 없음
// Mock 데이터 설정 불가
```

## 2. 개선 코드 예시

### 2.1 설정 파일 기반 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jakarta.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
@EnableConfigurationProperties(ItemCodeMappingService.ItemCodeMappingProperties.class)
public class ItemCodeMappingService {

    private final ItemCodeMappingProperties properties;
    private volatile Map<String, String> itemCodeToNameMap;

    /**
     * 서비스 초기화 시 품목 코드와 이름 매핑 정보 로드
     */
    @PostConstruct
    public void init() {
        log.info("품목 코드 매핑 서비스 초기화 시작");
        
        try {
            // thread-safe한 ConcurrentHashMap 사용
            this.itemCodeToNameMap = new ConcurrentHashMap<>(properties.getMappings());
            
            log.info("품목 코드 매핑 서비스 초기화 완료 - 매핑 수: {}", itemCodeToNameMap.size());
            
            // 매핑 정보 로깅 (디버그 레벨)
            if (log.isDebugEnabled()) {
                itemCodeToNameMap.forEach((code, name) -> 
                    log.debug("품목 코드 매핑: {} -> {}", code, name));
            }
            
        } catch (Exception e) {
            log.error("품목 코드 매핑 서비스 초기화 실패", e);
            throw new BusinessException("itemCodeMapping.initialization.failed", e);
        }
    }

    /**
     * 품목 코드로부터 사용자 친화적인 이름 조회
     *
     * @param itemCode 품목 코드
     * @return 품목 이름 (매핑 정보가 없는 경우 품목 코드 그대로 반환)
     */
    public String getItemNameByCode(String itemCode) {
        log.debug("품목 코드 조회 요청 - itemCode: {}", itemCode);
        
        // 파라미터 검증
        if (!StringUtils.hasText(itemCode)) {
            log.warn("유효하지 않은 품목 코드 - itemCode: {}", itemCode);
            return itemCode;
        }
        
        try {
            String itemName = itemCodeToNameMap.getOrDefault(itemCode.trim(), itemCode);
            
            if (itemCode.equals(itemName)) {
                log.warn("매핑되지 않은 품목 코드 - itemCode: {}", itemCode);
            } else {
                log.debug("품목 코드 매핑 성공 - {} -> {}", itemCode, itemName);
            }
            
            return itemName;
        } catch (Exception e) {
            log.error("품목 코드 조회 중 오류 발생 - itemCode: {}, error: {}", itemCode, e.getMessage(), e);
            return itemCode; // fallback으로 원본 코드 반환
        }
    }

    /**
     * 품목 코드 매핑 정보 동적 추가
     *
     * @param itemCode 품목 코드
     * @param itemName 품목 이름
     */
    public void addItemCodeMapping(String itemCode, String itemName) {
        log.info("품목 코드 매핑 추가 요청 - itemCode: {}, itemName: {}", itemCode, itemName);
        
        // 파라미터 검증
        validateItemCodeAndName(itemCode, itemName);
        
        try {
            String previousName = itemCodeToNameMap.put(itemCode.trim(), itemName.trim());
            
            if (previousName != null) {
                log.info("품목 코드 매핑 업데이트 - itemCode: {}, 이전: {}, 새로운 값: {}", 
                        itemCode, previousName, itemName);
            } else {
                log.info("품목 코드 매핑 추가 완료 - itemCode: {}, itemName: {}", itemCode, itemName);
            }
            
        } catch (Exception e) {
            log.error("품목 코드 매핑 추가 실패 - itemCode: {}, itemName: {}, error: {}", 
                     itemCode, itemName, e.getMessage(), e);
            throw new BusinessException("itemCodeMapping.add.failed", e);
        }
    }

    /**
     * 품목 코드 매핑 정보 제거
     *
     * @param itemCode 품목 코드
     */
    public void removeItemCodeMapping(String itemCode) {
        log.info("품목 코드 매핑 제거 요청 - itemCode: {}", itemCode);
        
        // 파라미터 검증
        if (!StringUtils.hasText(itemCode)) {
            throw new BusinessException("itemCodeMapping.invalid.code");
        }
        
        try {
            String removedName = itemCodeToNameMap.remove(itemCode.trim());
            
            if (removedName != null) {
                log.info("품목 코드 매핑 제거 완료 - itemCode: {}, itemName: {}", itemCode, removedName);
            } else {
                log.warn("제거할 품목 코드 매핑이 존재하지 않음 - itemCode: {}", itemCode);
            }
            
        } catch (Exception e) {
            log.error("품목 코드 매핑 제거 실패 - itemCode: {}, error: {}", itemCode, e.getMessage(), e);
            throw new BusinessException("itemCodeMapping.remove.failed", e);
        }
    }

    /**
     * 모든 품목 코드 매핑 정보 조회
     *
     * @return 품목 코드 매핑 정보
     */
    public Map<String, String> getAllItemCodeMappings() {
        log.debug("전체 품목 코드 매핑 정보 조회 요청");
        
        try {
            // 복사본 반환하여 원본 데이터 보호
            return new ConcurrentHashMap<>(itemCodeToNameMap);
        } catch (Exception e) {
            log.error("품목 코드 매핑 정보 조회 실패 - error: {}", e.getMessage(), e);
            throw new BusinessException("itemCodeMapping.retrieval.failed", e);
        }
    }

    // 검증 메서드
    private void validateItemCodeAndName(String itemCode, String itemName) {
        if (!StringUtils.hasText(itemCode)) {
            throw new BusinessException("itemCodeMapping.invalid.code");
        }
        if (!StringUtils.hasText(itemName)) {
            throw new BusinessException("itemCodeMapping.invalid.name");
        }
    }

    @ConfigurationProperties(prefix = "voc.item-code-mapping")
    public static class ItemCodeMappingProperties {
        private Map<String, String> mappings = new ConcurrentHashMap<>();

        public Map<String, String> getMappings() {
            return mappings;
        }

        public void setMappings(Map<String, String> mappings) {
            this.mappings = mappings;
        }
    }
}
```

### 2.2 application.yml 설정 파일
```yaml
voc:
  item-code-mapping:
    mappings:
      implant: "임플란트"
      instrument: "기구"
      endodontic: "보존/근관"
      restorative: "수복/접착"
      impression: "인상/보철"
      cutting: "절삭/연마"
      gbr: "GBR"
      hygiene: "위생용품"
      equipment: "장비"
      orthodontic: "교정용기구"
      prevention: "예방/구강"
      dentalLab: "기공용품"
      medicine: "의약품"
      appliance: "생활가전"
```

## 3. 다른 접근법

### 3.1 데이터베이스 기반 매핑
```java
@Entity
@Table(name = "item_code_mapping")
public class ItemCodeMapping {
    @Id
    private String itemCode;
    private String itemName;
    private boolean isActive;
    
    // getters, setters
}

@Repository
public interface ItemCodeMappingRepository extends JpaRepository<ItemCodeMapping, String> {
    List<ItemCodeMapping> findByIsActiveTrue();
}

@Service
@RequiredArgsConstructor
public class ItemCodeMappingService {
    
    private final ItemCodeMappingRepository repository;
    
    @Cacheable(value = "itemCodeMappings", key = "#itemCode")
    public String getItemNameByCode(String itemCode) {
        return repository.findById(itemCode)
                .map(ItemCodeMapping::getItemName)
                .orElse(itemCode);
    }
}
```

### 3.2 Redis 캐시 기반 매핑
```java
@Service
@RequiredArgsConstructor
public class ItemCodeMappingService {
    
    private final RedisTemplate<String, String> redisTemplate;
    private static final String CACHE_KEY_PREFIX = "item_code_mapping:";
    
    @PostConstruct
    public void init() {
        // Redis에 초기 매핑 데이터 로드
        loadInitialMappings();
    }
    
    public String getItemNameByCode(String itemCode) {
        String cacheKey = CACHE_KEY_PREFIX + itemCode;
        String itemName = redisTemplate.opsForValue().get(cacheKey);
        return itemName != null ? itemName : itemCode;
    }
    
    public void updateItemCodeMapping(String itemCode, String itemName) {
        String cacheKey = CACHE_KEY_PREFIX + itemCode;
        redisTemplate.opsForValue().set(cacheKey, itemName);
    }
}
```

### 3.3 외부 API 기반 매핑
```java
@Service
@RequiredArgsConstructor
public class ItemCodeMappingService {
    
    private final WebClient webClient;
    private final Map<String, String> localCache = new ConcurrentHashMap<>();
    
    @Cacheable(value = "itemCodeMappings", key = "#itemCode")
    public String getItemNameByCode(String itemCode) {
        // 로컬 캐시 먼저 확인
        String cachedName = localCache.get(itemCode);
        if (cachedName != null) {
            return cachedName;
        }
        
        // 외부 API 호출
        try {
            String itemName = webClient.get()
                    .uri("/api/item-codes/{itemCode}", itemCode)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
                    
            localCache.put(itemCode, itemName);
            return itemName;
        } catch (Exception e) {
            log.warn("외부 API 호출 실패, 기본값 반환 - itemCode: {}", itemCode);
            return itemCode;
        }
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **캐싱 전략**: 자주 조회되는 매핑 정보에 대한 L1/L2 캐시 적용
- **배치 로딩**: 초기화 시 한 번에 모든 매핑 정보 로드
- **메모리 최적화**: 불필요한 매핑 정보 정리 작업

### 4.2 운영 측면  
- **모니터링**: 매핑되지 않은 코드 사용량 추적
- **알람**: 새로운 품목 코드 사용 시 알람 발송
- **통계**: 품목 코드별 사용 빈도 수집

### 4.3 확장성 측면
- **다국어 지원**: 언어별 품목 이름 매핑
- **계층 구조**: 품목 카테고리의 계층 구조 지원
- **동적 로딩**: 운영 중 매핑 정보 업데이트 기능

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 동시성 문제 해결 | 높음 | 30분 | ConcurrentHashMap 적용 |
| 하드코딩 제거 | 높음 | 2시간 | 설정 파일로 이동 |
| 파라미터 검증 | 중간 | 30분 | null 체크 추가 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| 관리 기능 추가 | 낮음 | 3시간 | 동적 매핑 관리 |
| 데이터베이스 연동 | 낮음 | 4시간 | 영구 저장소 연동 |

**총 예상 소요 시간**: 11시간
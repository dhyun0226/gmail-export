# Table 패키지 DTO 클래스들 코드 리뷰
## (ServiceCategoryDto.java, ServiceChargePersonDto.java, VocAnswerDetailDto.java, VocChangeHistoryDto.java, VocChargePersonDto.java)

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 중복된 구조의 클래스들 (Code Duplication)
**문제점**: 매우 유사한 구조를 가진 클래스들이 중복으로 존재
**파일**: ServiceCategoryDto vs VocCategoryDto / ServiceChargePersonDto vs VocChargePersonDto
```java
// ServiceCategoryDto
public class ServiceCategoryDto extends BaseDto {
    private String serviceCategoryCode;
    private String upServiceCategoryCode;
    private String serviceCategoryName;
    private Character openYn;
    private Character deleteYn;
    private BigDecimal sortOrder;
}

// VocCategoryDto (거의 동일한 구조)
public class VocCategoryDto extends BaseDto {
    private String vocCategoryCode;
    private String upVocCategoryCode;
    private String vocCategoryName;
    private Character openYn;
    private Character deleteYn;
    private BigDecimal sortOrder;
}
```

#### Y/N 필드의 일관성 없는 타입 사용
**문제점**: 같은 의미의 Y/N 필드가 Character와 String 타입으로 혼재
**파일**: 모든 DTO 클래스들
```java
// ServiceCategoryDto - Character 타입
private Character openYn;
private Character deleteYn;

// ServiceChargePersonDto - String 타입
private String serviceDesignationThePersonInChargeYn; // 35자 필드명
private String deleteYn;

// VocChargePersonDto - String 타입  
private String vocDesignationThePersonInChargeYn;
private String deleteYn;
```

#### 과도하게 긴 필드명으로 인한 가독성 저하
**문제점**: 필드명이 너무 길어 코드 가독성과 유지보수성 저하
**파일**: ServiceChargePersonDto.java 58번 라인 / VocChargePersonDto.java 58번 라인
```java
// 35자 필드명
private String serviceDesignationThePersonInChargeYn; // ServiceChargePersonDto
private String vocDesignationThePersonInChargeYn;     // VocChargePersonDto

// 25자 이상의 긴 필드명들
private String serviceCategoryRegistererCorporationDatetime;
private String serviceChargePersonCorporationCode;
private String changeProcessorEmployeeNumber;
```

#### VocChangeHistoryDto의 과도한 책임 (God Object)
**문제점**: 100라인에 걸쳐 26개 필드를 가진 거대한 클래스
**파일**: VocChangeHistoryDto.java 전체
```java
@Schema(description = "VOC 변경 이력 DTO")
public class VocChangeHistoryDto extends BaseDto {
    private Long vocNumber;
    private LocalDateTime vocChangeDateTime;
    private String vocCategoryCode;
    // ... 총 26개의 필드들
    private String vocDetailsItemName;
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 부적절한 외부 모델 의존성
**문제점**: DTO가 외부 모듈의 Request 클래스에 직접 의존
**파일**: VocAnswerDetailDto.java 48번 라인
```java
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;

@Schema(description = "파일 리스트")
private List<TxmFileSaveRequest> fileList; // Request 클래스를 DTO에서 직접 사용
```

#### 검증 어노테이션의 불일치
**문제점**: 일부 클래스는 상세한 검증, 일부는 검증 누락
**파일**: ServiceCategoryDto vs ServiceChargePersonDto
```java
// ServiceCategoryDto - 검증 어노테이션 전혀 없음
public class ServiceCategoryDto extends BaseDto {
    private String serviceCategoryCode; // 필수값임에도 검증 없음
}

// ServiceChargePersonDto - 상세한 검증
@NotBlank
@Size(max = 12)
@Schema(description = "서비스 카테고리 코드")
private String serviceCategoryCode;
```

#### Swagger 문서화와 실제 검증의 불일치
**문제점**: @Schema의 required와 실제 검증 어노테이션이 불일치
**파일**: VocAnswerDetailDto.java 50-57번 라인
```java
@Schema(description = "답변자 법인 코드", example = "123456", required = true)
private String answererCorporationCode; // required=true이지만 @NotBlank 없음

@Schema(description = "답변자 부서 코드", example = "123456", required = true)  
private String answererDepartmentCode; // required=true이지만 @NotBlank 없음
```

#### 관련 정보의 분산 저장
**문제점**: 논리적으로 연관된 필드들이 개별 필드로 분산됨
**파일**: VocAnswerDetailDto.java 50-57번 라인
```java
// 답변자 정보가 개별 필드로 분산
private String answererCorporationCode;
private String answererDepartmentCode; 
private String answererEmployeeNumber;

// 변경 처리자 정보가 개별 필드로 분산 (VocChangeHistoryDto)
private String changeProcessorCorporationCode;
private String changeProcessorDepartmentCode;
private String changeProcessorEmployeeNumber;
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 타입 선택의 일관성 부족
**문제점**: 유사한 용도의 필드가 서로 다른 타입 사용
**파일**: ServiceCategoryDto.java 27번 라인
```java
private BigDecimal sortOrder; // 정렬 순서에 BigDecimal 사용 (Integer가 더 적절)
```

#### Lombok 어노테이션 일관성 부족
**문제점**: 일부는 @Data, 일부는 @Getter/@Setter 분리 사용
**파일**: ServiceCategoryDto vs 다른 DTO들
```java
// ServiceCategoryDto
@Data  // getter, setter, toString, equals, hashCode 모두 생성

// 다른 DTO들  
@Getter
@Setter (일부 필드에만)
```

## 2. 개선 코드 예시

### 2.1 공통 카테고리 기본 클래스
```java
package com.osstem.ow.voc.model.base;

import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * 카테고리 정보를 위한 기본 클래스
 */
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@MappedSuperclass
public abstract class BaseCategoryDto extends BaseDto {

    @Schema(description = "카테고리 코드")
    @NotBlank(message = "카테고리 코드는 필수입니다")
    @Size(max = 12, message = "카테고리 코드는 12자 이하여야 합니다")
    protected String categoryCode;

    @Schema(description = "상위 카테고리 코드")
    @Size(max = 12, message = "상위 카테고리 코드는 12자 이하여야 합니다")
    protected String parentCategoryCode;

    @Schema(description = "상위 카테고리명")
    @Size(max = 100, message = "상위 카테고리명은 100자 이하여야 합니다")
    protected String parentCategoryName;

    @Schema(description = "카테고리명")
    @NotBlank(message = "카테고리명은 필수입니다")
    @Size(max = 100, message = "카테고리명은 100자 이하여야 합니다")
    protected String categoryName;

    @Schema(description = "공개 여부")
    @Builder.Default
    protected Boolean isOpen = true;

    @Schema(description = "삭제 여부")
    @Builder.Default
    protected Boolean isDeleted = false;

    @Schema(description = "정렬 순서")
    @Min(value = 0, message = "정렬 순서는 0 이상이어야 합니다")
    @Max(value = 9999, message = "정렬 순서는 9999 이하여야 합니다")
    @Builder.Default
    protected Integer sortOrder = 0;

    @Schema(description = "등록자 정보")
    @Embedded
    protected RegistrationInfo registrationInfo;

    /**
     * 최상위 카테고리인지 확인합니다.
     */
    public boolean isRootCategory() {
        return parentCategoryCode == null || parentCategoryCode.trim().isEmpty();
    }

    /**
     * 활성 상태인지 확인합니다.
     */
    public boolean isActive() {
        return Boolean.TRUE.equals(isOpen) && !Boolean.TRUE.equals(isDeleted);
    }
}
```

### 2.2 등록자 정보 Value Object
```java
package com.osstem.ow.voc.model.base;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

/**
 * 등록자 정보 Value Object
 */
@Embeddable
@Getter
@Builder
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode
@Schema(description = "등록자 정보")
public class RegistrationInfo {

    @Schema(description = "등록자 법인 코드")
    @Size(max = 3, message = "등록자 법인 코드는 3자 이하여야 합니다")
    private String corporationCode;

    @Schema(description = "등록자 부서 코드")
    @Size(max = 30, message = "등록자 부서 코드는 30자 이하여야 합니다")
    private String departmentCode;

    @Schema(description = "등록자 사원 번호")
    @Size(max = 60, message = "등록자 사원 번호는 60자 이하여야 합니다")
    private String employeeNumber;

    @Schema(description = "등록 일시")
    private LocalDateTime registrationDateTime;

    /**
     * 등록자 정보가 유효한지 확인합니다.
     */
    public boolean isValid() {
        return corporationCode != null && !corporationCode.trim().isEmpty() &&
               departmentCode != null && !departmentCode.trim().isEmpty() &&
               employeeNumber != null && !employeeNumber.trim().isEmpty();
    }

    /**
     * 등록자의 전체 코드를 반환합니다.
     */
    public String getFullCode() {
        if (!isValid()) {
            return "";
        }
        return String.format("%s-%s-%s", corporationCode, departmentCode, employeeNumber);
    }
}
```

### 2.3 개선된 ServiceCategoryDto
```java
package com.osstem.ow.voc.model.table;

import com.osstem.ow.voc.model.base.BaseCategoryDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

/**
 * 서비스 카테고리 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Schema(description = "서비스 카테고리 DTO")
public class ServiceCategoryDto extends BaseCategoryDto {

    /**
     * 서비스 카테고리 생성을 위한 팩토리 메서드
     */
    public static ServiceCategoryDto create(String categoryCode, String categoryName, Integer sortOrder) {
        return ServiceCategoryDto.builder()
                .categoryCode(categoryCode)
                .categoryName(categoryName)
                .sortOrder(sortOrder)
                .isOpen(true)
                .isDeleted(false)
                .build();
    }

    /**
     * 하위 서비스 카테고리 생성을 위한 팩토리 메서드
     */
    public static ServiceCategoryDto createSubCategory(String categoryCode, String categoryName, 
                                                      String parentCategoryCode, String parentCategoryName) {
        return ServiceCategoryDto.builder()
                .categoryCode(categoryCode)
                .categoryName(categoryName)
                .parentCategoryCode(parentCategoryCode)
                .parentCategoryName(parentCategoryName)
                .isOpen(true)
                .isDeleted(false)
                .build();
    }
}
```

### 2.4 담당자 정보 기본 클래스
```java
package com.osstem.ow.voc.model.base;

import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

/**
 * 담당자 정보를 위한 기본 클래스
 */
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
@MappedSuperclass
public abstract class BaseChargePersonDto extends BaseDto {

    @Schema(description = "담당자 번호")
    protected Long chargePersonNumber;

    @Schema(description = "담당자 이름")
    protected String chargePersonName;

    @Schema(description = "카테고리 코드")
    @NotBlank(message = "카테고리 코드는 필수입니다")
    @Size(max = 12, message = "카테고리 코드는 12자 이하여야 합니다")
    protected String categoryCode;

    @Schema(description = "품목 코드")
    @Size(max = 90, message = "품목 코드는 90자 이하여야 합니다")
    protected String itemCode;

    @Schema(description = "담당자 정보")
    @Embedded
    protected PersonInfo personInfo;

    @Schema(description = "지정 담당자 여부")
    @Builder.Default
    protected Boolean isDesignatedPerson = false;

    @Schema(description = "삭제 여부")
    @Builder.Default
    protected Boolean isDeleted = false;

    /**
     * 담당자가 활성 상태인지 확인합니다.
     */
    public boolean isActive() {
        return !Boolean.TRUE.equals(isDeleted);
    }

    /**
     * 지정된 담당자인지 확인합니다.
     */
    public boolean isDesignated() {
        return Boolean.TRUE.equals(isDesignatedPerson);
    }
}
```

### 2.5 담당자 개인 정보 Value Object
```java
package com.osstem.ow.voc.model.base;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

/**
 * 담당자 개인 정보 Value Object
 */
@Embeddable
@Getter
@Builder
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode
@Schema(description = "담당자 개인 정보")
public class PersonInfo {

    @Schema(description = "법인 코드")
    @NotBlank(message = "법인 코드는 필수입니다")
    @Size(max = 3, message = "법인 코드는 3자 이하여야 합니다")
    private String corporationCode;

    @Schema(description = "부서 코드")
    @NotBlank(message = "부서 코드는 필수입니다")
    @Size(max = 30, message = "부서 코드는 30자 이하여야 합니다")
    private String departmentCode;

    @Schema(description = "사원 번호")
    @Size(max = 60, message = "사원 번호는 60자 이하여야 합니다")
    private String employeeNumber;

    @Schema(description = "부서명")
    private String departmentName;

    @Schema(description = "사원명")
    private String employeeName;

    /**
     * 개인 정보가 완전한지 확인합니다.
     */
    public boolean isComplete() {
        return corporationCode != null && !corporationCode.trim().isEmpty() &&
               departmentCode != null && !departmentCode.trim().isEmpty() &&
               employeeNumber != null && !employeeNumber.trim().isEmpty();
    }

    /**
     * 표시명을 반환합니다.
     */
    public String getDisplayName() {
        if (employeeName != null && !employeeName.trim().isEmpty()) {
            return employeeName;
        }
        return employeeNumber;
    }

    /**
     * 소속 정보를 반환합니다.
     */
    public String getAffiliation() {
        if (departmentName != null && !departmentName.trim().isEmpty()) {
            return String.format("%s (%s)", departmentName, departmentCode);
        }
        return departmentCode;
    }
}
```

### 2.6 개선된 VocAnswerDetailDto
```java
package com.osstem.ow.voc.model.table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.base.PersonInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 답변 상세 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 답변 상세 DTO")
public class VocAnswerDetailDto extends BaseDto {

    @Schema(description = "VOC 번호")
    @NotNull(message = "VOC 번호는 필수입니다")
    private Long vocNumber;

    @Schema(description = "VOC 답변 일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private LocalDateTime vocAnswerDateTime;

    @Schema(description = "VOC 카테고리 코드")
    @NotBlank(message = "VOC 카테고리 코드는 필수입니다")
    @Size(max = 12, message = "VOC 카테고리 코드는 12자 이하여야 합니다")
    private String vocCategoryCode;

    @Schema(description = "답변 내용")
    @NotBlank(message = "답변 내용은 필수입니다")
    @Size(max = 1000, message = "답변 내용은 1000자 이하여야 합니다")
    private String vocAnswerContent;

    @Schema(description = "답변 파일 ID")
    @Size(max = 50, message = "파일 ID는 50자 이하여야 합니다")
    private String answerFileId;

    @Schema(description = "첨부 파일 목록")
    private List<FileAttachment> attachments;

    @Schema(description = "답변자 정보")
    @Valid
    @Embedded
    private PersonInfo answererInfo;

    /**
     * 답변이 완료된 상태인지 확인합니다.
     */
    public boolean isAnswerComplete() {
        return vocAnswerContent != null && !vocAnswerContent.trim().isEmpty() &&
               vocAnswerDateTime != null;
    }

    /**
     * 첨부 파일이 있는지 확인합니다.
     */
    public boolean hasAttachments() {
        return attachments != null && !attachments.isEmpty();
    }

    /**
     * 답변자 정보가 유효한지 확인합니다.
     */
    public boolean hasValidAnswerer() {
        return answererInfo != null && answererInfo.isComplete();
    }
}
```

### 2.7 파일 첨부 정보 Value Object
```java
package com.osstem.ow.voc.model.base;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

/**
 * 파일 첨부 정보 Value Object
 */
@Getter
@Builder
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode
@Schema(description = "파일 첨부 정보")
public class FileAttachment {

    @Schema(description = "파일 ID")
    @NotBlank(message = "파일 ID는 필수입니다")
    @Size(max = 50, message = "파일 ID는 50자 이하여야 합니다")
    private String fileId;

    @Schema(description = "원본 파일명")
    @Size(max = 255, message = "파일명은 255자 이하여야 합니다")
    private String originalFileName;

    @Schema(description = "파일 크기 (bytes)")
    private Long fileSize;

    @Schema(description = "파일 타입")
    @Size(max = 100, message = "파일 타입은 100자 이하여야 합니다")
    private String contentType;

    /**
     * 이미지 파일인지 확인합니다.
     */
    public boolean isImageFile() {
        return contentType != null && contentType.startsWith("image/");
    }

    /**
     * 파일 크기를 읽기 쉬운 형태로 반환합니다.
     */
    public String getReadableFileSize() {
        if (fileSize == null || fileSize <= 0) {
            return "0 B";
        }
        
        String[] units = {"B", "KB", "MB", "GB"};
        int unitIndex = 0;
        double size = fileSize.doubleValue();
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return String.format("%.1f %s", size, units[unitIndex]);
    }
}
```

## 3. 다른 접근법

### 3.1 Composition over Inheritance 패턴
```java
// 상속 대신 컴포지션을 사용한 접근
public class CategoryInfo {
    private String categoryCode;
    private String categoryName;
    private String parentCategoryCode;
    private Boolean isActive;
    private Integer sortOrder;
}

public class ServiceCategoryDto {
    private CategoryInfo categoryInfo;
    private RegistrationInfo registrationInfo;
    
    // 위임 메서드들
    public String getCategoryCode() {
        return categoryInfo.getCategoryCode();
    }
}
```

### 3.2 Strategy 패턴을 통한 검증 로직 분리
```java
public interface ValidationStrategy {
    void validate(Object dto);
}

public class CategoryValidationStrategy implements ValidationStrategy {
    @Override
    public void validate(Object dto) {
        if (dto instanceof BaseCategoryDto) {
            BaseCategoryDto category = (BaseCategoryDto) dto;
            // 카테고리 특화 검증 로직
        }
    }
}

public class ChargePersonValidationStrategy implements ValidationStrategy {
    @Override
    public void validate(Object dto) {
        if (dto instanceof BaseChargePersonDto) {
            BaseChargePersonDto person = (BaseChargePersonDto) dto;
            // 담당자 특화 검증 로직
        }
    }
}
```

### 3.3 Record를 활용한 불변 Value Object
```java
// Java 17+ 환경에서 Record 사용
public record EmployeeInfo(
    @NotBlank String corporationCode,
    @NotBlank String departmentCode,
    @Size(max = 60) String employeeNumber,
    String departmentName,
    String employeeName
) {
    public EmployeeInfo {
        // 검증 로직
        Objects.requireNonNull(corporationCode, "법인 코드는 필수입니다");
        Objects.requireNonNull(departmentCode, "부서 코드는 필수입니다");
    }
    
    public String getDisplayName() {
        return employeeName != null ? employeeName : employeeNumber;
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **DTO 분리**: 큰 DTO를 작은 단위로 분리하여 네트워크 전송량 최적화
- **지연 로딩**: 관련 정보는 필요할 때만 조회하도록 설계
- **인덱싱**: 자주 조회되는 필드에 적절한 인덱스 적용

### 4.2 유지보수 측면
- **중복 제거**: 공통된 구조를 기본 클래스로 추출하여 중복 최소화
- **타입 안전성**: String 대신 Enum이나 Boolean 사용으로 타입 안전성 확보
- **네이밍 일관성**: 필드명 규칙을 정하고 일관성 있게 적용

### 4.3 확장성 측면
- **인터페이스 분리**: 기능별로 인터페이스를 분리하여 의존성 최소화
- **이벤트 기반**: 상태 변경 시 이벤트 발행으로 확장성 확보
- **버전 관리**: API 변경 시 하위 호환성 고려한 설계

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 중복 클래스 통합 | 높음 | 6시간 | 아키텍처 개선 핵심 |
| Y/N 필드 Boolean 통일 | 높음 | 3시간 | 타입 일관성 확보 |
| 필드명 리팩토링 | 높음 | 4시간 | 가독성 대폭 개선 |
| Value Object 분리 | 중간 | 5시간 | 객체지향 설계 개선 |
| 검증 어노테이션 통일 | 중간 | 3시간 | 데이터 품질 향상 |
| 외부 의존성 제거 | 중간 | 2시간 | 모듈 독립성 확보 |
| Swagger 문서화 개선 | 낮음 | 2시간 | API 문서화 |

**총 예상 소요 시간**: 25시간
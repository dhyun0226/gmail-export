# Voc.java 엔티티 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 과도하게 긴 필드명
**문제점**: 필드명이 너무 길어 가독성과 유지보수성 저하
**라인**: 87번 라인
```java
@Column(name = "INDV_INFO_CLCT_TOU_AGRE_YN", length = 1)
private String individualInformationCollectionTermsOfUseAgreementYesOrNo;
// 필드명이 너무 길어 코드 가독성 극도로 저하
```

#### Y/N 플래그의 String 처리
**문제점**: Boolean으로 처리해야 할 Y/N 값을 String으로 처리하여 타입 안전성 부족
**라인**: 87, 108, 122번 라인
```java
private String individualInformationCollectionTermsOfUseAgreementYesOrNo; // Boolean이 적절
private String deleteYesOrNo; // Boolean이 적절

public void markAsDeleted(String processorId) {
    this.deleteYesOrNo = "Y"; // 하드코딩된 String 값
}
```

#### 사용되지 않는 메서드 파라미터
**문제점**: markAsDeleted 메서드의 processorId 파라미터가 사용되지 않음
**라인**: 121-123번 라인
```java
public void markAsDeleted(String processorId) {
    this.deleteYesOrNo = "Y";
    // processorId 파라미터가 전혀 사용되지 않음
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 연관관계 설정 부재
**문제점**: 외래키 필드만 있고 JPA 연관관계 설정이 없어 객체지향적 접근 제한
**라인**: 26, 29번 라인
```java
@Column(name = "VOC_CHPR_NO", nullable = false)
private Long vocChargePersonNumber; // VocChargePerson과의 연관관계 설정 필요

@Column(name = "VOC_CTG_CD", length = 12, nullable = false)
private String vocCategoryCode; // VocCategory와의 연관관계 설정 필요
```

#### 필드 검증 부재
**문제점**: 중요한 필드들에 대한 validation 어노테이션이 없음
**라인**: 72, 74번 라인
```java
@Column(name = "VOC_TTL", length = 100, nullable = false)
private String vocTitle; // @NotBlank, @Size 검증 없음

@Column(name = "VOC_CN", length = 2000, nullable = false)
private String vocContent; // @NotBlank, @Size 검증 없음
```

#### 엔티티 복잡도 과다
**문제점**: 30개 이상의 필드를 가진 대형 엔티티로 단일 책임 원칙 위반 가능성
**라인**: 전체 엔티티
```java
public class Voc extends BaseEntity {
    // 30개 이상의 필드로 구성된 복잡한 엔티티
    // 고객 정보, 등록자 정보, 판매 담당자 정보, VOC 정보 등이 모두 섞여있음
}
```

#### 비즈니스 로직 부족
**문제점**: 엔티티에 의미있는 비즈니스 로직이 거의 없음
**라인**: 121-123번 라인
```java
public void markAsDeleted(String processorId) {
    this.deleteYesOrNo = "Y"; // 단순한 상태 변경만 있음
}
// VOC 상태 변경, 완료 처리, 담당자 할당 등의 비즈니스 로직 부재
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 컬럼명과 필드명 불일치
**문제점**: 일부 컬럼명과 필드명의 네이밍 패턴이 일관성 부족
**라인**: 59-60번 라인
```java
@Column(name = "VOC_CTMR_NM", length = 50)
private String vocCustomerName;

@Column(name = "VOC_CTMR_CUST_NM", length = 100)
private String vocCustomerCustomerName; // Customer가 중복됨
```

#### 하드코딩된 상수
**문제점**: markAsDeleted 메서드에서 "Y" 값이 하드코딩됨
**라인**: 122번 라인
```java
this.deleteYesOrNo = "Y"; // 상수로 분리 필요
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_M", indexes = {
    @Index(name = "idx_voc_category", columnList = "VOC_CTG_CD"),
    @Index(name = "idx_voc_state", columnList = "VOC_STACD"),
    @Index(name = "idx_voc_registration", columnList = "VOC_RGST_DTM")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Voc extends BaseEntity {

    // 상수 정의
    public static final String DELETED_YES = "Y";
    public static final String DELETED_NO = "N";
    
    public static final String STATE_REGISTERED = "01";
    public static final String STATE_IN_PROGRESS = "02";
    public static final String STATE_COMPLETED = "03";

    @Id
    @Column(name = "VOC_NO", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vocNumber;

    // 연관관계 설정
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_CHPR_NO", nullable = false)
    private VocChargePerson vocChargePerson;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_CTG_CD", nullable = false)
    private VocCategory vocCategory;

    // 기본 VOC 정보
    @Column(name = "DNAL_VOC_NO")
    private Long denallVocNumber;

    @Column(name = "ITM_CD", length = 90)
    @Size(max = 90, message = "아이템 코드는 90자를 초과할 수 없습니다")
    private String itemCode;

    @Column(name = "VOC_ITM_NM", length = 100)
    @Size(max = 100, message = "VOC 아이템명은 100자를 초과할 수 없습니다")
    private String vocItemName;

    @Column(name = "VOC_RGSTR_DVCD", length = 2, nullable = false)
    @NotBlank(message = "VOC 등록자 구분코드는 필수입니다")
    @Size(max = 2, message = "VOC 등록자 구분코드는 2자를 초과할 수 없습니다")
    private String vocRegistererDivisionCode;

    // 등록자 정보 - Value Object로 분리 고려
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "corporationCode", column = @Column(name = "RGSTR_CPRN_CD", length = 3)),
        @AttributeOverride(name = "departmentCode", column = @Column(name = "RGSTR_DEPT_CD", length = 30)),
        @AttributeOverride(name = "employeeNumber", column = @Column(name = "RGSTR_EMP_NO", length = 60)),
        @AttributeOverride(name = "memberId", column = @Column(name = "RGSTR_MEM_ID", length = 20))
    })
    private RegistererInfo registererInfo;

    // 고객 정보 - Value Object로 분리
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "name", column = @Column(name = "VOC_CTMR_NM", length = 50)),
        @AttributeOverride(name = "customerName", column = @Column(name = "VOC_CTMR_CUST_NM", length = 100)),
        @AttributeOverride(name = "emailAddress", column = @Column(name = "VOC_CTMR_EML_ADDR", length = 50)),
        @AttributeOverride(name = "telephoneNumber", column = @Column(name = "VOC_CTMR_TLNO", length = 20)),
        @AttributeOverride(name = "handPhoneNumber", column = @Column(name = "VOC_CTMR_HPNO", length = 20))
    })
    private CustomerInfo customerInfo;

    // VOC 핵심 내용
    @Column(name = "VOC_TTL", length = 100, nullable = false)
    @NotBlank(message = "VOC 제목은 필수입니다")
    @Size(max = 100, message = "VOC 제목은 100자를 초과할 수 없습니다")
    private String vocTitle;

    @Column(name = "VOC_CN", length = 2000, nullable = false)
    @NotBlank(message = "VOC 내용은 필수입니다")
    @Size(max = 2000, message = "VOC 내용은 2000자를 초과할 수 없습니다")
    private String vocContent;

    // 판매 담당자 정보 - Value Object로 분리
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "corporationCode", column = @Column(name = "VOC_SALE_CHPR_CPRN_CD", length = 3)),
        @AttributeOverride(name = "departmentCode", column = @Column(name = "VOC_SALE_CHPR_DEPT_CD", length = 30)),
        @AttributeOverride(name = "employeeNumber", column = @Column(name = "VOC_SALE_CHPR_EMP_NO", length = 60))
    })
    private SaleChargePersonInfo saleChargePersonInfo;

    // Boolean 필드로 개선
    @Column(name = "INDV_INFO_CLCT_TOU_AGRE_YN", length = 1)
    @Convert(converter = YesNoToBooleanConverter.class)
    private Boolean privacyPolicyAgreed;

    @Column(name = "FILE_ID", length = 50)
    @Size(max = 50, message = "파일 ID는 50자를 초과할 수 없습니다")
    private String fileId;

    @Column(name = "VOC_CMPL_TYCD", length = 2)
    @Size(max = 2, message = "VOC 완료 유형코드는 2자를 초과할 수 없습니다")
    private String vocCompletionTypeCode;

    @Column(name = "BIZ_RQST_NO")
    private Long businessRequestNumber;

    @Column(name = "ASGNMT_PRCS_NO")
    private Long assignmentProcedureNumber;

    @Column(name = "END_RSN", length = 500)
    @Size(max = 500, message = "종료 사유는 500자를 초과할 수 없습니다")
    private String endReason;

    @Column(name = "VOC_STACD", length = 2, nullable = false)
    @NotBlank(message = "VOC 상태코드는 필수입니다")
    @Size(max = 2, message = "VOC 상태코드는 2자를 초과할 수 없습니다")
    private String vocStateCode;

    @Column(name = "DEL_YN", length = 1, nullable = false)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean deleted = false;

    @Column(name = "VOC_RGST_DTM", nullable = false)
    @NotNull(message = "VOC 등록일시는 필수입니다")
    private LocalDateTime vocRegistrationDateTime;

    @Column(name = "VOC_DTLS_ITM_NM", length = 100)
    @Size(max = 100, message = "VOC 상세 아이템명은 100자를 초과할 수 없습니다")
    private String vocDetailsItemName;

    // 비즈니스 로직 개선
    /**
     * VOC를 논리적으로 삭제 처리합니다.
     *
     * @param processorId 처리자 ID
     */
    public void markAsDeleted(String processorId) {
        validateProcessorId(processorId);
        
        this.deleted = true;
        this.setProcPrgmId(processorId);
        this.setModProcDtm(LocalDateTime.now());
        this.setModProcrId(processorId);
    }

    /**
     * VOC 상태를 변경합니다.
     *
     * @param newState 새로운 상태코드
     * @param processorId 처리자 ID
     */
    public void changeState(String newState, String processorId) {
        validateStateCode(newState);
        validateProcessorId(processorId);
        
        String oldState = this.vocStateCode;
        this.vocStateCode = newState;
        
        updateModificationInfo(processorId);
        
        // 상태 변경 이벤트 발행 (도메인 이벤트 패턴)
        // DomainEventPublisher.publishEvent(new VocStateChangedEvent(this.vocNumber, oldState, newState, processorId));
    }

    /**
     * VOC를 완료 처리합니다.
     *
     * @param completionTypeCode 완료 유형코드
     * @param endReason 종료 사유
     * @param processorId 처리자 ID
     */
    public void complete(String completionTypeCode, String endReason, String processorId) {
        validateCompletionTypeCode(completionTypeCode);
        validateEndReason(endReason);
        validateProcessorId(processorId);
        
        this.vocStateCode = STATE_COMPLETED;
        this.vocCompletionTypeCode = completionTypeCode;
        this.endReason = endReason;
        
        updateModificationInfo(processorId);
    }

    /**
     * VOC 담당자를 변경합니다.
     *
     * @param newChargePerson 새로운 담당자
     * @param processorId 처리자 ID
     */
    public void assignChargePerson(VocChargePerson newChargePerson, String processorId) {
        validateChargePerson(newChargePerson);
        validateProcessorId(processorId);
        
        this.vocChargePerson = newChargePerson;
        updateModificationInfo(processorId);
    }

    /**
     * VOC가 삭제되었는지 확인합니다.
     *
     * @return 삭제 여부
     */
    public boolean isDeleted() {
        return Boolean.TRUE.equals(this.deleted);
    }

    /**
     * VOC가 완료 상태인지 확인합니다.
     *
     * @return 완료 여부
     */
    public boolean isCompleted() {
        return STATE_COMPLETED.equals(this.vocStateCode);
    }

    /**
     * VOC가 진행 중인지 확인합니다.
     *
     * @return 진행 중 여부
     */
    public boolean isInProgress() {
        return STATE_IN_PROGRESS.equals(this.vocStateCode);
    }

    // private 검증 메서드들
    private void validateProcessorId(String processorId) {
        if (processorId == null || processorId.trim().isEmpty()) {
            throw new IllegalArgumentException("처리자 ID는 필수입니다");
        }
    }

    private void validateStateCode(String stateCode) {
        if (stateCode == null || stateCode.trim().isEmpty()) {
            throw new IllegalArgumentException("상태코드는 필수입니다");
        }
        // 추가적인 상태코드 유효성 검증 로직
    }

    private void validateCompletionTypeCode(String completionTypeCode) {
        if (completionTypeCode == null || completionTypeCode.trim().isEmpty()) {
            throw new IllegalArgumentException("완료 유형코드는 필수입니다");
        }
    }

    private void validateEndReason(String endReason) {
        if (endReason == null || endReason.trim().isEmpty()) {
            throw new IllegalArgumentException("종료 사유는 필수입니다");
        }
        if (endReason.length() > 500) {
            throw new IllegalArgumentException("종료 사유는 500자를 초과할 수 없습니다");
        }
    }

    private void validateChargePerson(VocChargePerson chargePerson) {
        if (chargePerson == null) {
            throw new IllegalArgumentException("담당자는 필수입니다");
        }
    }

    private void updateModificationInfo(String processorId) {
        this.setModProcDtm(LocalDateTime.now());
        this.setModProcrId(processorId);
    }
}

// Value Object 클래스들
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegistererInfo {
    private String corporationCode;
    private String departmentCode;
    private String employeeNumber;
    private String memberId;
}

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerInfo {
    private String name;
    private String customerName;
    
    @Email(message = "올바른 이메일 형식이어야 합니다")
    private String emailAddress;
    
    @Pattern(regexp = "^\\d{2,3}-\\d{3,4}-\\d{4}$", message = "올바른 전화번호 형식이어야 합니다")
    private String telephoneNumber;
    
    @Pattern(regexp = "^01[016789]-\\d{3,4}-\\d{4}$", message = "올바른 휴대폰번호 형식이어야 합니다")
    private String handPhoneNumber;
}

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaleChargePersonInfo {
    private String corporationCode;
    private String departmentCode;
    private String employeeNumber;
}

// Y/N을 Boolean으로 변환하는 Converter
@Converter
public class YesNoToBooleanConverter implements AttributeConverter<Boolean, String> {
    
    @Override
    public String convertToDatabaseColumn(Boolean attribute) {
        return Boolean.TRUE.equals(attribute) ? "Y" : "N";
    }

    @Override
    public Boolean convertToEntityAttribute(String dbData) {
        return "Y".equals(dbData);
    }
}
```

## 3. 다른 접근법

### 3.1 엔티티 분할 접근법
```java
// 메인 VOC 엔티티
@Entity
@Table(name = "TB_VOC_M")
public class Voc extends BaseEntity {
    @Id
    private Long vocNumber;
    
    private String vocTitle;
    private String vocContent;
    private String vocStateCode;
    
    @OneToOne(mappedBy = "voc", cascade = CascadeType.ALL)
    private VocDetail vocDetail;
    
    @OneToOne(mappedBy = "voc", cascade = CascadeType.ALL)
    private VocCustomer vocCustomer;
}

// VOC 상세 정보
@Entity
@Table(name = "TB_VOC_DETAIL")
public class VocDetail {
    @Id
    private Long vocNumber;
    
    @OneToOne
    @JoinColumn(name = "VOC_NO")
    private Voc voc;
    
    private String itemCode;
    private String vocItemName;
    private String fileId;
    // ... 기타 상세 정보
}

// VOC 고객 정보
@Entity
@Table(name = "TB_VOC_CUSTOMER")
public class VocCustomer {
    @Id
    private Long vocNumber;
    
    @OneToOne
    @JoinColumn(name = "VOC_NO")
    private Voc voc;
    
    private String customerName;
    private String emailAddress;
    // ... 기타 고객 정보
}
```

### 3.2 상태 패턴 적용
```java
public abstract class VocState {
    public abstract void process(Voc voc);
    public abstract void complete(Voc voc);
    public abstract boolean canDelete(Voc voc);
}

public class RegisteredState extends VocState {
    @Override
    public void process(Voc voc) {
        voc.setVocStateCode(Voc.STATE_IN_PROGRESS);
        voc.setState(new InProgressState());
    }
    
    @Override
    public void complete(Voc voc) {
        throw new IllegalStateException("등록 상태에서는 바로 완료할 수 없습니다");
    }
    
    @Override
    public boolean canDelete(Voc voc) {
        return true;
    }
}

@Entity
public class Voc extends BaseEntity {
    @Transient
    private VocState state;
    
    public void processVoc() {
        state.process(this);
    }
    
    public void completeVoc() {
        state.complete(this);
    }
}
```

### 3.3 Builder 패턴 개선
```java
public class VocBuilder {
    private Voc voc;
    
    private VocBuilder() {
        this.voc = new Voc();
    }
    
    public static VocBuilder create() {
        return new VocBuilder();
    }
    
    public VocBuilder withBasicInfo(String title, String content) {
        voc.setVocTitle(title);
        voc.setVocContent(content);
        return this;
    }
    
    public VocBuilder withCustomer(CustomerInfo customerInfo) {
        voc.setCustomerInfo(customerInfo);
        return this;
    }
    
    public VocBuilder withRegisterer(RegistererInfo registererInfo) {
        voc.setRegistererInfo(registererInfo);
        return this;
    }
    
    public Voc build() {
        validate();
        voc.setVocRegistrationDateTime(LocalDateTime.now());
        voc.setVocStateCode(Voc.STATE_REGISTERED);
        voc.setDeleted(false);
        return voc;
    }
    
    private void validate() {
        if (voc.getVocTitle() == null || voc.getVocTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("VOC 제목은 필수입니다");
        }
        if (voc.getVocContent() == null || voc.getVocContent().trim().isEmpty()) {
            throw new IllegalArgumentException("VOC 내용은 필수입니다");
        }
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **지연 로딩**: 연관관계에서 적절한 FetchType.LAZY 사용
- **인덱싱**: 자주 조회되는 컬럼에 대한 데이터베이스 인덱스 설정
- **배치 크기**: @BatchSize를 통한 N+1 문제 해결

### 4.2 데이터 일관성 측면  
- **낙관적 락**: @Version을 통한 동시성 제어
- **제약조건**: 데이터베이스 레벨의 제약조건 설정
- **트랜잭션**: 비즈니스 로직 수행 시 적절한 트랜잭션 경계 설정

### 4.3 보안 측면
- **개인정보 마스킹**: 민감한 고객 정보에 대한 마스킹 처리
- **접근 제어**: 필드별 접근 권한 제어
- **감사 로그**: 중요한 상태 변경에 대한 감사 로그 기록

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| Y/N Boolean 변환 | 높음 | 2시간 | 타입 안전성 핵심 |
| 필드명 개선 | 높음 | 3시간 | 가독성 향상 핵심 |
| 파라미터 사용 수정 | 높음 | 30분 | 버그 수정 |
| 연관관계 설정 | 중간 | 4시간 | 객체지향 설계 개선 |
| 필드 검증 추가 | 중간 | 2시간 | 데이터 무결성 |
| 비즈니스 로직 추가 | 중간 | 5시간 | 도메인 로직 강화 |
| Value Object 분리 | 낮음 | 6시간 | 코드 구조 개선 |

**총 예상 소요 시간**: 22시간 30분
# VocChangeHistoryService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 트랜잭션 관리 부재
**문제점**: 데이터베이스 저장 작업에 트랜잭션 관리가 없어 데이터 일관성 문제 가능
**라인**: 20번 라인
```java
public VocChangeHistory save(Voc voc) {
    // @Transactional 애노테이션 없음
    // 저장 실패 시 롤백 처리 없음
    return vocChangeHistoryRepository.save(vocChangeHistory);
}
```

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 20-25번 라인
```java
public VocChangeHistory save(Voc voc) {
    VocChangeHistory vocChangeHistory = vocChangeHistoryStruct.toHistory(voc); // voc null 검증 없음
    LocalDateTime now = LocalDateTime.now();
    VocChangeHistoryId id = new VocChangeHistoryId(voc.getVocNumber(), now); // voc.getVocNumber() NPE 가능
}
```

#### 예외 처리 부재
**문제점**: 저장 과정에서 발생할 수 있는 예외에 대한 처리가 없음
**라인**: 20-29번 라인
```java
public VocChangeHistory save(Voc voc) {
    // MapStruct 변환 실패 예외 처리 없음
    VocChangeHistory vocChangeHistory = vocChangeHistoryStruct.toHistory(voc);
    // Repository 저장 실패 예외 처리 없음
    return vocChangeHistoryRepository.save(vocChangeHistory);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 단일 책임 원칙 위반
**문제점**: ID 생성과 엔티티 저장 책임이 한 메서드에 섞여있음
**라인**: 20-29번 라인
```java
public VocChangeHistory save(Voc voc) {
    VocChangeHistory vocChangeHistory = vocChangeHistoryStruct.toHistory(voc); // 변환 책임
    LocalDateTime now = LocalDateTime.now(); // 시간 생성 책임
    VocChangeHistoryId id = new VocChangeHistoryId(voc.getVocNumber(), now); // ID 생성 책임
    vocChangeHistory.setId(id); // 엔티티 설정 책임
    return vocChangeHistoryRepository.save(vocChangeHistory); // 저장 책임
}
```

#### 로깅 부재
**문제점**: 변경 이력 저장 과정을 추적할 수 없음
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class VocChangeHistoryService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 메서드 명명의 모호성
**문제점**: 'save' 메서드명이 너무 일반적이어서 의도를 파악하기 어려움
**라인**: 20번 라인
```java
public VocChangeHistory save(Voc voc) {
    // 메서드명이 구체적인 비즈니스 의도를 나타내지 못함
    // saveChangeHistory, recordVocChange 등이 더 명확함
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 부적절한 주석
**문제점**: 코드 주석이 기술적 구현에 치우쳐 있고 비즈니스 의도를 설명하지 않음
**라인**: 22-27번 라인
```java
// 1) java.util.Date 가 아니라 java.time.LocalDateTime 을 쓰세요
// 2) 복합키 VO 생성
// 3) 엔티티에 id 객체 통째로 세팅
// 기술적 구현 방법만 설명하고 비즈니스 의도는 설명하지 않음
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 변경 이력을 기록했는지 추적 불가
**라인**: 전체 메서드
```java
public VocChangeHistory save(Voc voc) {
    // 변경 이력 기록자 정보 없음
    // 감사 추적 불가
}
```

#### 반환값 활용도 낮음
**문제점**: 저장된 엔티티를 반환하지만 호출부에서 활용하지 않을 가능성 높음
**라인**: 20, 29번 라인
```java
public VocChangeHistory save(Voc voc) {
    // ...
    return vocChangeHistoryRepository.save(vocChangeHistory); // 반환값 활용도 불명확
}
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.entity.VocChangeHistoryId;
import com.osstem.ow.voc.repository.VocChangeHistoryRepository;
import com.osstem.ow.voc.structMapper.VocChangeHistoryStruct;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class VocChangeHistoryService {

    private final VocChangeHistoryStruct vocChangeHistoryStruct;
    private final VocChangeHistoryRepository vocChangeHistoryRepository;

    /**
     * VOC 변경 이력을 기록합니다.
     * VOC가 수정될 때마다 변경 전 상태를 이력으로 보존하여 추적 가능하도록 합니다.
     *
     * @param voc 변경 이력을 기록할 VOC 엔티티
     * @return 저장된 변경 이력 엔티티
     */
    @Transactional
    public VocChangeHistory recordVocChangeHistory(Voc voc) {
        log.info("VOC 변경 이력 기록 시작 - vocNumber: {}", voc != null ? voc.getVocNumber() : "null");
        
        // 파라미터 검증
        validateVocForHistory(voc);
        
        try {
            // 변경 이력 엔티티 생성
            VocChangeHistory changeHistory = createVocChangeHistory(voc);
            
            // 변경 이력 저장
            VocChangeHistory savedHistory = vocChangeHistoryRepository.save(changeHistory);
            
            log.info("VOC 변경 이력 기록 완료 - vocNumber: {}, historyId: {}", 
                    voc.getVocNumber(), savedHistory.getId());
                    
            return savedHistory;
            
        } catch (Exception e) {
            log.error("VOC 변경 이력 기록 실패 - vocNumber: {}, error: {}", 
                     voc != null ? voc.getVocNumber() : "null", e.getMessage(), e);
            throw new BusinessException("voc.changeHistory.save.failed", e);
        }
    }

    /**
     * VOC 변경 이력을 기록합니다 (반환값 없는 버전)
     * 저장 결과를 확인할 필요가 없는 경우 사용합니다.
     *
     * @param voc 변경 이력을 기록할 VOC 엔티티
     */
    @Transactional
    public void recordVocChangeHistoryAsync(Voc voc) {
        recordVocChangeHistory(voc);
    }

    /**
     * 특정 VOC의 모든 변경 이력을 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return 변경 이력 목록
     */
    @Transactional(readOnly = true)
    public List<VocChangeHistory> getVocChangeHistories(Long vocNumber) {
        log.info("VOC 변경 이력 조회 시작 - vocNumber: {}", vocNumber);
        
        validateVocNumber(vocNumber);
        
        try {
            List<VocChangeHistory> histories = vocChangeHistoryRepository.findByIdVocNumberOrderByIdChangeDateTime(vocNumber);
            log.info("VOC 변경 이력 조회 완료 - vocNumber: {}, count: {}", vocNumber, histories.size());
            return histories;
        } catch (Exception e) {
            log.error("VOC 변경 이력 조회 실패 - vocNumber: {}, error: {}", vocNumber, e.getMessage(), e);
            throw new BusinessException("voc.changeHistory.retrieval.failed", e);
        }
    }

    // private 메서드들
    private VocChangeHistory createVocChangeHistory(Voc voc) {
        // MapStruct를 통한 엔티티 변환
        VocChangeHistory changeHistory = vocChangeHistoryStruct.toHistory(voc);
        
        // 변경 이력 고유 ID 생성 (VOC 번호 + 현재 시간)
        VocChangeHistoryId historyId = createChangeHistoryId(voc.getVocNumber());
        changeHistory.setId(historyId);
        
        // 추가 메타데이터 설정 (필요한 경우)
        enrichChangeHistoryMetadata(changeHistory);
        
        return changeHistory;
    }

    private VocChangeHistoryId createChangeHistoryId(Long vocNumber) {
        LocalDateTime changeDateTime = LocalDateTime.now();
        return new VocChangeHistoryId(vocNumber, changeDateTime);
    }

    private void enrichChangeHistoryMetadata(VocChangeHistory changeHistory) {
        // 필요한 경우 추가 메타데이터 설정
        // 예: 변경자 정보, 변경 이유, 변경 타입 등
        
        // 현재 사용자 정보가 있다면 설정
        // String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
        // changeHistory.setChangeUser(currentUser);
    }

    // 검증 메서드들
    private void validateVocForHistory(Voc voc) {
        if (Objects.isNull(voc)) {
            throw new BusinessException("voc.changeHistory.invalid.voc");
        }
        
        validateVocNumber(voc.getVocNumber());
        
        // VOC 필수 정보 검증
        if (Objects.isNull(voc.getVocTitle()) && Objects.isNull(voc.getVocContent())) {
            throw new BusinessException("voc.changeHistory.invalid.voc.content");
        }
    }

    private void validateVocNumber(Long vocNumber) {
        if (Objects.isNull(vocNumber) || vocNumber <= 0) {
            throw new BusinessException("voc.changeHistory.invalid.vocNumber");
        }
    }
}
```

## 3. 다른 접근법

### 3.1 이벤트 기반 변경 이력 기록
```java
@EventListener
@Async
public void handleVocChangedEvent(VocChangedEvent event) {
    try {
        recordVocChangeHistory(event.getVoc());
    } catch (Exception e) {
        log.error("비동기 변경 이력 기록 실패", e);
        // 이벤트 재시도 또는 데드레터 큐로 전송
    }
}

@Service
public class VocService {
    @Autowired
    private ApplicationEventPublisher eventPublisher;
    
    public void updateVoc(Voc voc) {
        // VOC 업데이트 로직
        // ...
        
        // 변경 이벤트 발행
        eventPublisher.publishEvent(new VocChangedEvent(voc));
    }
}
```

### 3.2 AOP를 이용한 자동 이력 기록
```java
@Aspect
@Component
public class VocChangeHistoryAspect {
    
    @Autowired
    private VocChangeHistoryService vocChangeHistoryService;
    
    @AfterReturning(pointcut = "@annotation(RecordChangeHistory)", returning = "result")
    public void recordChangeHistory(JoinPoint joinPoint, Object result) {
        if (result instanceof Voc) {
            vocChangeHistoryService.recordVocChangeHistory((Voc) result);
        }
    }
}

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RecordChangeHistory {
}

@Service
public class VocService {
    
    @RecordChangeHistory
    public Voc updateVoc(Voc voc) {
        // VOC 업데이트 로직
        return vocRepository.save(voc);
    }
}
```

### 3.3 Factory 패턴을 이용한 이력 생성
```java
@Component
public class VocChangeHistoryFactory {
    
    private final VocChangeHistoryStruct vocChangeHistoryStruct;
    
    public VocChangeHistory createChangeHistory(Voc voc, ChangeHistoryType type) {
        VocChangeHistory history = vocChangeHistoryStruct.toHistory(voc);
        
        VocChangeHistoryId id = new VocChangeHistoryId(
            voc.getVocNumber(), 
            LocalDateTime.now()
        );
        history.setId(id);
        history.setChangeType(type);
        
        return history;
    }
}

@Service
@RequiredArgsConstructor
public class VocChangeHistoryService {
    
    private final VocChangeHistoryFactory changeHistoryFactory;
    private final VocChangeHistoryRepository vocChangeHistoryRepository;
    
    @Transactional
    public VocChangeHistory recordVocChangeHistory(Voc voc, ChangeHistoryType type) {
        VocChangeHistory history = changeHistoryFactory.createChangeHistory(voc, type);
        return vocChangeHistoryRepository.save(history);
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **배치 처리**: 여러 VOC의 변경 이력을 한 번에 저장하는 배치 처리 기능
- **비동기 처리**: 이력 기록을 비동기로 처리하여 메인 업무 처리 성능 향상
- **파티셔닝**: 대용량 이력 데이터에 대한 날짜별 파티셔닝 고려

### 4.2 데이터 관리 측면  
- **보관 정책**: 변경 이력 데이터의 보관 기간 및 아카이빙 정책
- **압축**: 오래된 이력 데이터에 대한 압축 저장
- **인덱싱**: 조회 성능 향상을 위한 적절한 인덱스 설계

### 4.3 감사 및 추적 측면
- **변경 타입**: 생성/수정/삭제/상태변경 등 변경 유형 분류
- **변경자 추적**: 누가 언제 무엇을 변경했는지 추적
- **변경 이유**: 변경 사유나 관련 업무 번호 기록

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 트랜잭션 관리 추가 | 높음 | 30분 | 데이터 일관성 핵심 |
| 파라미터 검증 | 높음 | 1시간 | NPE 방지 필수 |
| 예외 처리 추가 | 높음 | 1시간 | 서비스 안정성 핵심 |
| 메서드 책임 분리 | 중간 | 2시간 | 코드 구조 개선 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| 메서드명 개선 | 낮음 | 30분 | 가독성 향상 |
| 조회 기능 추가 | 낮음 | 2시간 | 기능 확장 |

**총 예상 소요 시간**: 8시간
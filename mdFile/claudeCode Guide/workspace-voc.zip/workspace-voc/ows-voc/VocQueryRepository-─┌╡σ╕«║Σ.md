# VocQueryRepository 클래스 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### God Object 패턴 (거대한 클래스)
**문제점**: 643라인에 20개 이상의 메서드를 가진 거대한 클래스로 단일 책임 원칙 위반
**파일**: VocQueryRepository.java 전체
```java
@Repository
@RequiredArgsConstructor
public class VocQueryRepository {
    // 1. 기본 조회 메서드들
    public Optional<VocResponseDto> findByIdWithAnswer(Long vocNumber)
    public Map<String, Long> findItemCodesWithCounts(...)
    public Map<String, Long> findRegistererDeptCodesWithCounts(...)
    
    // 2. 통계 관련 메서드들  
    public Map<String, Long> findChargePersonDeptCodesWithCounts(...)
    public Map<String, DepartmentInfo> getDepartmentInfoByDeptCodes(...)
    
    // 3. 검색 관련 메서드들
    public List<VocResponseDto> findVocsByRegistererDeptCodes(...)
    public List<VocResponseDto> findVocsByChargePersonDeptCodes(...)
    public List<VocResponseDto> search(...)
    
    // 4. 품목별 조회 메서드들
    public List<String> findDistinctItemCodes(...)
    public List<VocResponseDto> findVocsByItemCodes(...)
    
    // ... 총 20개 이상의 복잡한 메서드들
}
```

#### 중복된 쿼리 로직 (Code Duplication)
**문제점**: 유사한 구조의 쿼리가 여러 메서드에서 반복됨
**파일**: VocQueryRepository.java 74-91, 113-129, 151-168번 라인
```java
// findItemCodesWithCounts - 74-91라인
List<Tuple> results = queryFactory
        .select(voc.itemCode, voc.count())
        .from(voc)
        .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
        .where(
                voc.deleteYesOrNo.ne("Y"),
                voc.itemCode.isNotNull(),
                // ... 공통 조건들
        )
        .groupBy(voc.itemCode)
        .fetch();

// findRegistererDeptCodesWithCounts - 113-129라인 (거의 동일한 구조)
List<Tuple> results = queryFactory
        .select(voc.registererDepartmentCode, voc.count())
        .from(voc)
        .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
        .where(
                voc.deleteYesOrNo.ne("Y"), // 동일한 조건
                voc.registererDepartmentCode.isNotNull(),
                // ... 거의 동일한 조건들
        )
        .groupBy(voc.registererDepartmentCode)
        .fetch();
```

#### 하드코딩된 매직 넘버/문자열
**문제점**: 코드 전반에 하드코딩된 값들이 직접 사용됨
**파일**: VocQueryRepository.java 전체
```java
// 하드코딩된 문자열들
.where(voc.deleteYesOrNo.ne("Y"))                    // 67라인
.where(vocChargePerson.deleteYn.ne("Y"))            // 157라인  
.where(vocChargePerson.vocCategoryCode.like("%VOC%")) // 158라인
info.setCorpCode(corpCode != null ? corpCode : "KR1"); // 337, 352라인

// 하드코딩된 페이징
.offset((long) (vocRequestDto.getPageNo() - 1) * vocRequestDto.getPageSize()) // 453라인
.limit(vocRequestDto.getPageSize())                   // 454라인
```

#### 복잡한 비즈니스 로직이 Repository에 포함
**문제점**: 데이터 접근 로직이 아닌 비즈니스 규칙이 Repository 레이어에 존재
**파일**: VocQueryRepository.java 591-608번 라인
```java
private BooleanExpression vocStateCodeEquals(String code, boolean isDay) {
    if (code == null) {
        return null;
    }
    
    // 복잡한 비즈니스 규칙이 Repository에 포함됨
    if (StatusType.PROCESSING.getStatusCode().equals(code)) {
        if (isDay) {
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), 
                                     StatusType.PROCESSING.getStatusCode(), 
                                     StatusType.COMPLETE.getStatusCode());
        }
        return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), 
                                 StatusType.PROCESSING.getStatusCode());
    } else if (StatusType.RECEIPT.getStatusCode().equals(code)) {
        return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), 
                                 StatusType.COMPLETE.getStatusCode());
    }
    
    return voc.vocStateCode.eq(code);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 메서드의 과도한 매개변수 (Long Parameter List)
**문제점**: 여러 메서드가 5개 이상의 매개변수를 받아 가독성과 유지보수성 저하
**파일**: VocQueryRepository.java 73, 112, 150, 188번 라인
```java
// 5개 매개변수
public Map<String, Long> findItemCodesWithCounts(VocRequestDto vocRequestDto, 
                                                List<String> vocCategoryCodes, 
                                                List<String> chargerDepartmentCodes, 
                                                List<String> registererDepartmentCodes)

// 6개 매개변수  
public List<VocResponseDto> findVocsByRegistererDeptCodes(VocRequestDto vocRequestDto, 
                                                        List<String> deptCodes, 
                                                        List<String> vocCategoryCodes, 
                                                        List<String> chargerDepartmentCodes)
```

#### 메서드명의 일관성 부족 및 명확성 부족
**문제점**: 메서드명이 너무 길거나 의도가 불분명함
**파일**: VocQueryRepository.java 전체
```java
// 너무 긴 메서드명들
public Map<String, Long> findItemCodesWithCounts(...)                    // 품목별 개수
public Map<String, Long> findRegistererDeptCodesWithCounts(...)          // 등록자 부서별 개수
public Map<String, Long> findChargePersonDeptCodesWithCounts(...)        // 담당자 부서별 개수
public List<VocResponseDto> findVocsByRegistererDeptCodes(...)           // 등록자 부서별 VOC 조회
public List<VocResponseDto> findVocsByChargePersonDeptCodes(...)         // 담당자 부서별 VOC 조회

// 일관성 없는 명명 규칙
public List<String> findDistinctItemCodes(...)                          // Distinct 접두사
public List<String> findDistinctRegistererDepartmentCodes(...)          // Distinct 접두사
public List<String> findDistinctChargePersonDepartmentCodes(...)        // Distinct 접두사
```

#### 예외 처리 부재
**문제점**: 복잡한 쿼리 실행 중 발생할 수 있는 예외에 대한 처리가 전혀 없음
**파일**: VocQueryRepository.java 전체
```java
public Optional<VocResponseDto> findByIdWithAnswer(Long vocNumber) {
    VocResponseDto result = queryFactory
            .select(...)
            .from(voc)
            .fetchOne(); // SQLException, DataAccessException 등 예외 처리 없음
    
    return Optional.ofNullable(result);
}
```

#### 비효율적인 데이터 변환 로직
**문제점**: 쿼리 결과를 Java 코드에서 반복문으로 변환하는 비효율적 패턴
**파일**: VocQueryRepository.java 93-105, 131-143번 라인
```java
// 결과를 Map으로 변환하는 반복적인 코드
Map<String, Long> itemCodeCounts = new LinkedHashMap<>();
for (Tuple tuple : results) {
    String itemCode = tuple.get(voc.itemCode);
    Long count = tuple.get(voc.count());
    
    if (itemCode != null) {
        itemCodeCounts.put(itemCode, count); // 매번 동일한 변환 로직
    }
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 주석 부족 및 불충분한 문서화
**문제점**: 복잡한 쿼리 로직에 대한 설명이 부족하여 이해하기 어려움
**파일**: VocQueryRepository.java 전체
```java
// 복잡한 로직이지만 주석이 없음
public Map<String, DepartmentInfo> getDepartmentInfoByDeptCodes(List<String> deptCodes) {
    Map<String, DepartmentInfo> result = new HashMap<>();
    
    if (deptCodes == null || deptCodes.isEmpty()) {
        return result;
    }
    
    // 등록자 부서 목록 조회 (VOC 테이블 기준) - 유일한 주석
    List<Tuple> registererDeptInfos = queryFactory
            .select(...)
            // 복잡한 쿼리 로직이지만 설명 없음
```

#### 매직 넘버 사용
**문제점**: 의미가 불분명한 숫자들이 코드에 직접 사용됨
**파일**: VocQueryRepository.java 453-454번 라인
```java
.offset((long) (vocRequestDto.getPageNo() - 1) * vocRequestDto.getPageSize()) // -1 매직넘버
.limit(vocRequestDto.getPageSize())
```

## 2. 개선 코드 예시

### 2.1 Repository 분리 및 책임 재분배
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.model.request.VocSearchCriteria;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.repository.common.VocQueryConditions;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocAnswerDetail.vocAnswerDetail;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 기본 조회 Repository
 * 단순한 조회 및 검색 기능만 담당
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocSearchRepository {

    private final JPAQueryFactory queryFactory;

    /**
     * VOC 상세 정보 조회 (답변 정보 포함)
     * 
     * @param vocNumber VOC 번호
     * @return VOC 상세 정보 (Optional)
     */
    public Optional<VocResponseDto> findDetailWithAnswer(Long vocNumber) {
        log.debug("VOC 상세 조회 시작: vocNumber={}", vocNumber);
        
        try {
            VocResponseDto result = queryFactory
                    .select(Projections.bean(VocResponseDto.class,
                            voc.vocNumber,
                            voc.vocChargePersonNumber,
                            voc.vocCategoryCode,
                            voc.itemCode,
                            voc.vocItemName,
                            voc.vocDetailsItemName,
                            voc.denallVocNumber,
                            voc.vocRegistererDivisionCode,
                            voc.registererMemberId,
                            voc.vocCustomerName,
                            voc.vocCustomerCustomerName,
                            voc.vocCustomerEmailAddress,
                            voc.vocCustomerTelephoneNumber,
                            voc.vocCustomerHandPhoneNumber,
                            voc.vocTitle,
                            voc.vocContent,
                            voc.fileId.as("vocFileId"),
                            voc.vocCompletionTypeCode,
                            voc.vocStateCode,
                            voc.vocRegistrationDateTime,
                            vocChargePerson.vocChargePersonEmployeeNumber,
                            vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                            vocAnswerDetail.vocAnswerDateTime,
                            vocAnswerDetail.vocAnswerContent,
                            vocAnswerDetail.fileId.as("answerFileId"),
                            vocAnswerDetail.isNotNull().as("hasAnswer")
                    ))
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                    .where(voc.vocNumber.eq(vocNumber)
                            .and(VocQueryConditions.isNotDeleted()))
                    .fetchOne();

            log.debug("VOC 상세 조회 완료: vocNumber={}, found={}", vocNumber, result != null);
            return Optional.ofNullable(result);
            
        } catch (Exception e) {
            log.error("VOC 상세 조회 중 오류 발생: vocNumber={}", vocNumber, e);
            return Optional.empty();
        }
    }

    /**
     * VOC 검색 (페이징)
     * 
     * @param criteria 검색 조건
     * @param pageable 페이징 정보
     * @return 검색 결과 페이지
     */
    public Page<VocResponseDto> searchVocs(VocSearchCriteria criteria, Pageable pageable) {
        log.debug("VOC 검색 시작: criteria={}, pageable={}", criteria, pageable);
        
        try {
            List<VocResponseDto> content = queryFactory
                    .select(createVocResponseProjection())
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocCategoryCodeEquals(criteria.getVocCategoryCode()),
                            VocQueryConditions.itemCodeEquals(criteria.getItemCode()),
                            VocQueryConditions.vocStateCodeIn(criteria.getStateCodes()),
                            VocQueryConditions.registrationDateBetween(criteria.getStartDate(), criteria.getEndDate()),
                            VocQueryConditions.chargerDepartmentCodeIn(criteria.getChargerDepartmentCodes()),
                            VocQueryConditions.registererDepartmentCodeIn(criteria.getRegistererDepartmentCodes())
                    )
                    .orderBy(voc.vocRegistrationDateTime.desc())
                    .offset(pageable.getOffset())
                    .limit(pageable.getPageSize())
                    .fetch();

            long total = countVocs(criteria);
            
            log.debug("VOC 검색 완료: 조회건수={}, 총건수={}", content.size(), total);
            return new PageImpl<>(content, pageable, total);
            
        } catch (Exception e) {
            log.error("VOC 검색 중 오류 발생: criteria={}", criteria, e);
            return Page.empty(pageable);
        }
    }

    /**
     * 검색 조건에 맞는 VOC 총 개수 조회
     */
    private long countVocs(VocSearchCriteria criteria) {
        return queryFactory
                .selectFrom(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        VocQueryConditions.isNotDeleted(),
                        VocQueryConditions.vocCategoryCodeEquals(criteria.getVocCategoryCode()),
                        VocQueryConditions.itemCodeEquals(criteria.getItemCode()),
                        VocQueryConditions.vocStateCodeIn(criteria.getStateCodes()),
                        VocQueryConditions.registrationDateBetween(criteria.getStartDate(), criteria.getEndDate()),
                        VocQueryConditions.chargerDepartmentCodeIn(criteria.getChargerDepartmentCodes()),
                        VocQueryConditions.registererDepartmentCodeIn(criteria.getRegistererDepartmentCodes())
                )
                .fetchCount();
    }

    /**
     * VOC 응답 DTO 프로젝션 생성
     */
    private Projections.BeanExpression<VocResponseDto> createVocResponseProjection() {
        return Projections.bean(VocResponseDto.class,
                voc.vocNumber,
                voc.vocChargePersonNumber,
                voc.vocCategoryCode,
                voc.itemCode,
                voc.vocItemName,
                voc.vocDetailsItemName,
                voc.denallVocNumber,
                voc.vocRegistererDivisionCode,
                voc.registererMemberId,
                voc.vocCustomerName,
                voc.vocCustomerCustomerName,
                voc.vocCustomerEmailAddress,
                voc.vocCustomerTelephoneNumber,
                voc.vocCustomerHandPhoneNumber,
                voc.vocTitle,
                voc.vocContent,
                voc.fileId.as("vocFileId"),
                voc.vocCompletionTypeCode,
                voc.vocStateCode,
                voc.vocRegistrationDateTime,
                vocChargePerson.vocChargePersonEmployeeNumber,
                vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                vocAnswerDetail.vocAnswerDateTime,
                vocAnswerDetail.vocAnswerContent,
                vocAnswerDetail.fileId.as("answerFileId"),
                vocAnswerDetail.isNotNull().as("hasAnswer")
        );
    }
}
```

### 2.2 통계 전용 Repository 분리
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.model.statistic.VocCountByCategory;
import com.osstem.ow.voc.model.statistic.VocCountByDepartment;
import com.osstem.ow.voc.repository.common.VocQueryConditions;
import com.osstem.ow.voc.repository.util.QueryResultMapper;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 통계 및 집계 전용 Repository
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocAggregationRepository {

    private final JPAQueryFactory queryFactory;
    private final QueryResultMapper resultMapper;

    /**
     * 품목별 VOC 건수 조회
     * 
     * @param startDate 시작일
     * @param endDate 종료일
     * @param stateCodes 상태 코드 목록
     * @param categoryCodes 카테고리 코드 목록
     * @return 품목별 건수 맵
     */
    public Map<String, Long> getVocCountByItem(LocalDateTime startDate, 
                                             LocalDateTime endDate,
                                             List<String> stateCodes,
                                             List<String> categoryCodes) {
        log.debug("품목별 VOC 건수 조회 시작: startDate={}, endDate={}", startDate, endDate);
        
        try {
            List<Tuple> results = queryFactory
                    .select(voc.itemCode, voc.count())
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocStateCodeIn(stateCodes),
                            VocQueryConditions.vocCategoryCodeIn(categoryCodes),
                            VocQueryConditions.registrationDateBetween(startDate, endDate),
                            voc.itemCode.isNotNull()
                    )
                    .groupBy(voc.itemCode)
                    .orderBy(voc.count().desc())
                    .fetch();

            Map<String, Long> countMap = resultMapper.toCountMap(results, voc.itemCode, voc.count());
            log.debug("품목별 VOC 건수 조회 완료: 품목수={}", countMap.size());
            
            return countMap;
            
        } catch (Exception e) {
            log.error("품목별 VOC 건수 조회 중 오류 발생", e);
            return Map.of();
        }
    }

    /**
     * 부서별 VOC 건수 조회 (등록자 기준)
     * 
     * @param startDate 시작일
     * @param endDate 종료일
     * @param stateCodes 상태 코드 목록
     * @return 부서별 건수 목록
     */
    public List<VocCountByDepartment> getVocCountByRegistererDepartment(LocalDateTime startDate,
                                                                      LocalDateTime endDate,
                                                                      List<String> stateCodes) {
        log.debug("등록자 부서별 VOC 건수 조회 시작");
        
        try {
            List<VocCountByDepartment> results = queryFactory
                    .select(Projections.constructor(VocCountByDepartment.class,
                            voc.registererDepartmentCode,
                            voc.registererCorporationCode,
                            voc.count()))
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocStateCodeIn(stateCodes),
                            VocQueryConditions.registrationDateBetween(startDate, endDate),
                            voc.registererDepartmentCode.isNotNull()
                    )
                    .groupBy(voc.registererDepartmentCode, voc.registererCorporationCode)
                    .orderBy(voc.count().desc())
                    .fetch();

            log.debug("등록자 부서별 VOC 건수 조회 완료: 부서수={}", results.size());
            return results;
            
        } catch (Exception e) {
            log.error("등록자 부서별 VOC 건수 조회 중 오류 발생", e);
            return List.of();
        }
    }

    /**
     * 담당자 부서별 VOC 건수 조회
     * 
     * @param startDate 시작일
     * @param endDate 종료일
     * @param stateCodes 상태 코드 목록
     * @return 부서별 건수 목록
     */
    public List<VocCountByDepartment> getVocCountByChargePersonDepartment(LocalDateTime startDate,
                                                                        LocalDateTime endDate,
                                                                        List<String> stateCodes) {
        log.debug("담당자 부서별 VOC 건수 조회 시작");
        
        try {
            List<VocCountByDepartment> results = queryFactory
                    .select(Projections.constructor(VocCountByDepartment.class,
                            vocChargePerson.vocChargePersonDepartmentCode,
                            vocChargePerson.vocChargePersonCorporationCode,
                            voc.count()))
                    .from(voc)
                    .join(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.isChargePersonActive(),
                            VocQueryConditions.vocStateCodeIn(stateCodes),
                            VocQueryConditions.registrationDateBetween(startDate, endDate)
                    )
                    .groupBy(vocChargePerson.vocChargePersonDepartmentCode, vocChargePerson.vocChargePersonCorporationCode)
                    .orderBy(voc.count().desc())
                    .fetch();

            log.debug("담당자 부서별 VOC 건수 조회 완료: 부서수={}", results.size());
            return results;
            
        } catch (Exception e) {
            log.error("담당자 부서별 VOC 건수 조회 중 오류 발생", e);
            return List.of();
        }
    }

    /**
     * 고유한 품목 코드 목록 조회
     * 
     * @param startDate 시작일 (선택적)
     * @param endDate 종료일 (선택적)
     * @return 정렬된 품목 코드 목록
     */
    public List<String> getDistinctItemCodes(LocalDateTime startDate, LocalDateTime endDate) {
        log.debug("고유 품목 코드 조회 시작");
        
        try {
            List<String> itemCodes = queryFactory
                    .select(voc.itemCode)
                    .distinct()
                    .from(voc)
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.registrationDateBetween(startDate, endDate),
                            voc.itemCode.isNotNull()
                    )
                    .orderBy(voc.itemCode.asc())
                    .fetch();

            log.debug("고유 품목 코드 조회 완료: 품목수={}", itemCodes.size());
            return itemCodes;
            
        } catch (Exception e) {
            log.error("고유 품목 코드 조회 중 오류 발생", e);
            return List.of();
        }
    }
}
```

### 2.3 쿼리 결과 변환 유틸리티
```java
package com.osstem.ow.voc.repository.util;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.Expression;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * QueryDSL 결과를 다양한 형태로 변환하는 유틸리티
 */
@Component
public class QueryResultMapper {

    /**
     * Tuple 결과를 Map으로 변환 (순서 유지)
     * 
     * @param results 쿼리 결과
     * @param keyExpression 키로 사용할 표현식
     * @param valueExpression 값으로 사용할 표현식
     * @return 변환된 Map
     */
    public <K, V> Map<K, V> toCountMap(List<Tuple> results, 
                                      Expression<K> keyExpression, 
                                      Expression<V> valueExpression) {
        Map<K, V> resultMap = new LinkedHashMap<>();
        
        for (Tuple tuple : results) {
            K key = tuple.get(keyExpression);
            V value = tuple.get(valueExpression);
            
            if (key != null && value != null) {
                resultMap.put(key, value);
            }
        }
        
        return resultMap;
    }

    /**
     * 중첩된 그룹화 결과를 Map<String, Map<String, Long>> 형태로 변환
     * 
     * @param results 쿼리 결과
     * @param groupExpression 그룹 키 표현식
     * @param subGroupExpression 서브 그룹 키 표현식
     * @param countExpression 개수 표현식
     * @return 중첩된 Map
     */
    public Map<String, Map<String, Long>> toNestedCountMap(List<Tuple> results,
                                                          Expression<String> groupExpression,
                                                          Expression<String> subGroupExpression,
                                                          Expression<Long> countExpression) {
        Map<String, Map<String, Long>> resultMap = new LinkedHashMap<>();
        
        for (Tuple tuple : results) {
            String groupKey = tuple.get(groupExpression);
            String subGroupKey = tuple.get(subGroupExpression);
            Long count = tuple.get(countExpression);
            
            if (groupKey != null && subGroupKey != null && count != null) {
                resultMap
                        .computeIfAbsent(groupKey, k -> new LinkedHashMap<>())
                        .put(subGroupKey, count);
            }
        }
        
        return resultMap;
    }
}
```

### 2.4 검색 조건 DTO 개선
```java
package com.osstem.ow.voc.model.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 검색 조건 DTO (기존 VocRequestDto 개선)
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Schema(description = "VOC 검색 조건")
public class VocSearchCriteria {

    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Schema(description = "VOC 카테고리 코드")
    private String vocCategoryCode;

    @Schema(description = "품목 코드")
    private String itemCode;

    @Schema(description = "고객명")
    private String customerName;

    @Schema(description = "VOC 제목")
    private String vocTitle;

    @Schema(description = "VOC 상태 코드 목록")
    private List<String> stateCodes;

    @Schema(description = "검색 시작 일자")
    private LocalDateTime startDate;

    @Schema(description = "검색 종료 일자")
    private LocalDateTime endDate;

    @Schema(description = "담당자 부서 코드 목록")
    private List<String> chargerDepartmentCodes;

    @Schema(description = "등록자 부서 코드 목록")
    private List<String> registererDepartmentCodes;

    @Schema(description = "그룹핑 타입", allowableValues = {"REGISTERER", "CHARGE_PERSON", "ITEM"})
    @Builder.Default
    private GroupType groupByType = GroupType.REGISTERER;

    @Schema(description = "영업 담당자 법인 코드")
    private String salesCorporationCode;

    @Schema(description = "영업 담당자 부서 코드")
    private String salesDepartmentCode;

    @Schema(description = "영업 담당자 사원 번호")
    private String salesEmployeeNumber;

    /**
     * 그룹핑 타입 열거형
     */
    public enum GroupType {
        REGISTERER("등록자 부서 기준"),
        CHARGE_PERSON("담당자 부서 기준"),
        ITEM("품목 기준");

        private final String description;

        GroupType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;  
        }
    }

    /**
     * 검색 조건이 유효한지 확인
     */
    public boolean isValid() {
        return vocNumber != null || 
               hasTextSearch() || 
               hasDateRange() || 
               hasDepartmentFilter();
    }

    /**
     * 텍스트 검색 조건 존재 여부
     */
    public boolean hasTextSearch() {
        return hasValue(vocCategoryCode) || 
               hasValue(itemCode) || 
               hasValue(customerName) || 
               hasValue(vocTitle);
    }

    /**
     * 날짜 범위 검색 조건 존재 여부
     */
    public boolean hasDateRange() {
        return startDate != null || endDate != null;
    }

    /**
     * 부서 필터링 조건 존재 여부
     */
    public boolean hasDepartmentFilter() {
        return hasValues(chargerDepartmentCodes) || 
               hasValues(registererDepartmentCodes);
    }

    /**
     * 단일 날짜 검색 여부 (당일 검색)
     */
    public boolean isSingleDateSearch() {
        return startDate != null && endDate != null && 
               startDate.toLocalDate().isEqual(endDate.toLocalDate());
    }

    // 유틸리티 메서드들
    private boolean hasValue(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private boolean hasValues(List<String> values) {
        return values != null && !values.isEmpty();
    }
}
```

## 3. 다른 접근법

### 3.1 Builder 패턴을 활용한 동적 쿼리 생성
```java
package com.osstem.ow.voc.repository.query;

import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 쿼리 빌더
 */
@Component
@RequiredArgsConstructor
public class VocQueryBuilder {

    private final JPAQueryFactory queryFactory;

    /**
     * VOC 검색 쿼리 빌더
     */
    public static class SearchQueryBuilder {
        private final BooleanBuilder whereClause = new BooleanBuilder();
        private final JPAQuery<?> query;

        public SearchQueryBuilder(JPAQueryFactory queryFactory) {
            this.query = queryFactory.selectFrom(voc);
            // 기본 조건: 삭제되지 않은 것만
            whereClause.and(voc.deleteYesOrNo.ne("Y"));
        }

        public SearchQueryBuilder withVocNumber(Long vocNumber) {
            if (vocNumber != null) {
                whereClause.and(voc.vocNumber.eq(vocNumber));
            }
            return this;
        }

        public SearchQueryBuilder withStateCode(String stateCode) {
            if (stateCode != null && !stateCode.trim().isEmpty()) {
                whereClause.and(voc.vocStateCode.eq(stateCode));
            }
            return this;
        }

        public SearchQueryBuilder withDateRange(LocalDateTime start, LocalDateTime end) {
            if (start != null && end != null) {
                whereClause.and(voc.vocRegistrationDateTime.between(start, end));
            } else if (start != null) {
                whereClause.and(voc.vocRegistrationDateTime.goe(start));
            } else if (end != null) {
                whereClause.and(voc.vocRegistrationDateTime.loe(end));
            }
            return this;
        }

        public SearchQueryBuilder withChargePerson() {
            query.innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber));
            return this;
        }

        public SearchQueryBuilder withChargePersonDepartments(List<String> departmentCodes) {
            if (departmentCodes != null && !departmentCodes.isEmpty()) {
                whereClause.and(vocChargePerson.vocChargePersonDepartmentCode.in(departmentCodes));
            }
            return this;
        }

        public JPAQuery<?> build() {
            return query.where(whereClause);
        }
    }

    public SearchQueryBuilder createSearchQuery() {
        return new SearchQueryBuilder(queryFactory);
    }
}

// 사용법
public List<VocResponseDto> searchVocs(VocSearchCriteria criteria) {
    return vocQueryBuilder.createSearchQuery()
            .withVocNumber(criteria.getVocNumber())
            .withStateCode(criteria.getVocStateCode())
            .withDateRange(criteria.getStartDate(), criteria.getEndDate())
            .withChargePerson()
            .withChargePersonDepartments(criteria.getChargerDepartmentCodes())
            .build()
            .orderBy(voc.vocRegistrationDateTime.desc())
            .fetch();
}
```

### 3.2 Template Method 패턴 적용
```java
package com.osstem.ow.voc.repository.template;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.Expression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * VOC 통계 쿼리 템플릿
 */
@RequiredArgsConstructor
public abstract class VocStatisticsQueryTemplate<K, V> {

    protected final JPAQueryFactory queryFactory;

    /**
     * 통계 조회 템플릿 메서드
     */
    public final Map<K, V> getStatistics(VocSearchCriteria criteria) {
        List<Tuple> rawResults = executeQuery(criteria);
        return transformResults(rawResults);
    }

    /**
     * 실제 쿼리 실행 (하위 클래스에서 구현)
     */
    protected abstract List<Tuple> executeQuery(VocSearchCriteria criteria);

    /**
     * 결과 변환 (하위 클래스에서 구현)
     */
    protected abstract Map<K, V> transformResults(List<Tuple> results);

    /**
     * 그룹핑 키 표현식 (하위 클래스에서 구현)
     */
    protected abstract Expression<K> getGroupByExpression();

    /**
     * 집계 표현식 (하위 클래스에서 구현)
     */
    protected abstract Expression<V> getAggregateExpression();
}

/**
 * 품목별 통계 조회 구현체
 */
@Component
public class ItemStatisticsQuery extends VocStatisticsQueryTemplate<String, Long> {

    public ItemStatisticsQuery(JPAQueryFactory queryFactory) {
        super(queryFactory);
    }

    @Override
    protected List<Tuple> executeQuery(VocSearchCriteria criteria) {
        return queryFactory
                .select(voc.itemCode, voc.count())
                .from(voc)
                .where(
                        VocQueryConditions.isNotDeleted(),
                        VocQueryConditions.vocStateCodeIn(criteria.getStateCodes()),
                        VocQueryConditions.registrationDateBetween(criteria.getStartDate(), criteria.getEndDate()),
                        voc.itemCode.isNotNull()
                )
                .groupBy(voc.itemCode)
                .orderBy(voc.count().desc())
                .fetch();
    }

    @Override
    protected Map<String, Long> transformResults(List<Tuple> results) {
        return results.stream()
                .collect(Collectors.toMap(
                        tuple -> tuple.get(voc.itemCode),
                        tuple -> tuple.get(voc.count()),
                        (existing, replacement) -> existing,
                        LinkedHashMap::new
                ));
    }

    @Override
    protected Expression<String> getGroupByExpression() {
        return voc.itemCode;
    }

    @Override
    protected Expression<Long> getAggregateExpression() {
        return voc.count();
    }
}
```

### 3.3 Repository Composition 패턴
```java
package com.osstem.ow.voc.repository.composite;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

/**
 * 여러 Repository를 조합하여 복합적인 기능 제공
 */
@Repository
@RequiredArgsConstructor
public class VocCompositeRepository {

    private final VocSearchRepository vocSearchRepository;
    private final VocAggregationRepository vocAggregationRepository;
    private final VocStatisticsRepository vocStatisticsRepository;

    /**
     * VOC 대시보드 데이터 조회 (여러 Repository 조합)
     */
    public VocDashboardData getDashboardData(VocSearchCriteria criteria) {
        // 기본 통계
        long totalCount = vocAggregationRepository.getTotalVocCount(criteria);
        Map<String, Long> statusCounts = vocAggregationRepository.getVocCountByStatus(criteria);
        
        // 부서별 통계
        List<VocCountByDepartment> departmentStats = vocAggregationRepository
                .getVocCountByRegistererDepartment(criteria.getStartDate(), criteria.getEndDate(), criteria.getStateCodes());
        
        // 최근 VOC 목록
        List<VocResponseDto> recentVocs = vocSearchRepository
                .searchVocs(criteria.withLimit(10), Pageable.unpaged())
                .getContent();
        
        // 트렌드 데이터
        Map<String, Integer> trendData = vocStatisticsRepository
                .getVocTrendByPeriod(criteria.getStartDate(), criteria.getEndDate(), StatisticsPeriod.DAILY);

        return VocDashboardData.builder()
                .totalCount(totalCount)
                .statusCounts(statusCounts)
                .departmentStats(departmentStats)
                .recentVocs(recentVocs)
                .trendData(trendData)
                .build();
    }

    /**
     * VOC 상세 분석 데이터 조회
     */
    public VocAnalysisData getAnalysisData(VocSearchCriteria criteria) {
        // 여러 Repository의 결과를 조합하여 분석 데이터 생성
        return VocAnalysisData.builder()
                .itemAnalysis(vocAggregationRepository.getVocCountByItem(criteria.getStartDate(), criteria.getEndDate(), criteria.getStateCodes(), criteria.getCategoryCodes()))
                .departmentAnalysis(vocAggregationRepository.getVocCountByRegistererDepartment(criteria.getStartDate(), criteria.getEndDate(), criteria.getStateCodes()))
                .timeAnalysis(vocStatisticsRepository.getVocStatisticsByHour(criteria.getStartDate(), criteria.getEndDate(), criteria.getStateCodes()))
                .build();
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **인덱스 최적화**: 자주 사용되는 조건(deleteYesOrNo, vocStateCode, vocRegistrationDateTime)에 복합 인덱스 적용
- **쿼리 캐싱**: 변경이 적은 통계 데이터에 캐싱 적용
- **배치 처리**: 대량 데이터 조회 시 청크 단위 처리
- **Connection Pool**: 복잡한 쿼리 실행 시 커넥션 풀 모니터링

### 4.2 유지보수 측면
- **책임 분리**: 검색/통계/집계 기능을 별도 Repository로 분리
- **코드 중복 제거**: 공통 쿼리 조건을 유틸리티 클래스로 추출
- **예외 처리**: 각 Repository별 적절한 예외 처리 및 로깅
- **테스트**: Repository 별 단위 테스트 및 통합 테스트 작성

### 4.3 확장성 측면
- **동적 쿼리**: 검색 조건에 따른 유연한 쿼리 생성
- **다중 데이터소스**: 읽기 전용 복제본 활용
- **비동기 처리**: 무거운 통계 쿼리의 비동기 실행
- **파티셔닝**: 대용량 데이터 처리를 위한 테이블 파티셔닝 고려

### 4.4 모니터링 측면
- **쿼리 성능**: 슬로우 쿼리 모니터링 및 최적화
- **리소스 사용량**: 메모리 및 CPU 사용량 추적
- **에러 발생률**: Repository 별 에러 발생 패턴 분석
- **사용 패턴**: 어떤 조회 패턴이 많은지 분석하여 최적화

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| Repository 분리 (검색/통계/집계) | 높음 | 12시간 | 아키텍처 개선 핵심 |
| 공통 쿼리 조건 유틸리티 분리 | 높음 | 4시간 | 코드 중복 제거 |
| 하드코딩 상수화 | 높음 | 2시간 | 유지보수성 향상 |
| 예외 처리 및 로깅 추가 | 높음 | 6시간 | 안정성 확보 |
| 매개변수 객체화 (VocSearchCriteria) | 중간 | 3시간 | 가독성 향상 |
| 쿼리 결과 변환 유틸리티 | 중간 | 2시간 | 코드 품질 향상 |
| 복잡한 비즈니스 로직 서비스 이동 | 중간 | 4시간 | 책임 분리 |
| Builder 패턴 동적 쿼리 적용 | 낮음 | 6시간 | 고급 기능 |
| Template Method 패턴 적용 | 낮음 | 4시간 | 코드 재사용성 |

**총 예상 소요 시간**: 43시간
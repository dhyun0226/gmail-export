# VocStatisticsService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 극심한 코드 중복
**문제점**: 8개의 메서드가 거의 동일한 로직을 가지고 있어 유지보수성 극도로 저하
**라인**: 98-119, 127-145, 153-174, 182-203, 213-237, 245-269, 277-301, 309-333번 라인
```java
public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);
    List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
    List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());
    // 거의 동일한 패턴이 8번 반복됨
}
```

#### Type Safety 위반
**문제점**: Unsafe cast로 인한 런타임 ClassCastException 위험
**라인**: 40번 라인
```java
List<OrganizationVocStatisticsDto> result = (List<OrganizationVocStatisticsDto>) response.getData();
// Unchecked cast - 타입 안전성 보장 불가
```

#### 예외 처리 부재
**문제점**: 복잡한 비즈니스 로직에서 예외 처리가 전혀 없어 장애 시 추적 불가
**라인**: 전체 메서드
```java
public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // 외부 서비스 호출, 데이터베이스 조회, 복잡한 통계 처리에서 예외 처리 없음
    OrganizationResponseDto response = commonServiceClient.getDepartment(corporationCode,rootDepartmentCode);
    Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository.getVocStatisticsByDayWithConditions(...);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 파라미터 검증 부재  
**문제점**: null 파라미터나 유효하지 않은 조건에 대한 검증이 없음
**라인**: 98, 127, 153, 182, 213, 245, 277, 309번 라인
```java
public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // condition null 검증 없음
    // condition의 내부 필드들 유효성 검증 없음
    List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);
}
```

#### 하드코딩된 값
**문제점**: 설정 가능해야 할 값들이 하드코딩되어 있음
**라인**: 33, 35, 55번 라인
```java
String corporationCode = StringUtils.hasText(condition.getCorporationCode())
        ? condition.getCorporationCode() : "KR1"; // "KR1" 하드코딩

String rootDepartmentCode = StringUtils.hasText(condition.getRootDepartmentCode())
        ? condition.getRootDepartmentCode() : "O000000914"; // "O000000914" 하드코딩

OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode); // "KR1" 하드코딩
```

#### 로깅 부재
**문제점**: 복잡한 통계 처리 과정을 추적할 수 없음
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class VocStatisticsService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 정렬 로직 중복
**문제점**: sortByTotalDesc와 sortChildrenByTotalDesc가 거의 동일한 정렬 로직 중복
**라인**: 341-363, 370-390번 라인
```java
// sortByTotalDesc 메서드
list.sort((o1, o2) -> {
    Integer total1 = Optional.ofNullable(o1.getStatistics())
            .map(stats -> stats.getOrDefault("total", 0))
            .orElse(0);
    // ... 동일한 정렬 로직
});

// sortChildrenByTotalDesc 메서드  
node.getItems().sort((o1, o2) -> {
    Integer total1 = Optional.ofNullable(o1.getStatistics())
            .map(stats -> stats.getOrDefault("total", 0))
            .orElse(0);
    // ... 동일한 정렬 로직
});
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 읽기 전용 트랜잭션 설정이 없어 성능 최적화 부족
**라인**: 전체 public 메서드
```java
// @Transactional(readOnly = true) 애노테이션 없음
public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 통계를 조회했는지 추적 불가
**라인**: 전체 메서드
```java
public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // 사용자 정보 로깅 없음
}
```

#### 미사용 메서드
**문제점**: updateParentIds 메서드가 정의되어 있지만 사용되지 않음
**라인**: 74-88번 라인
```java
private void updateParentIds(List<OrganizationVocStatisticsDto> list, String oldParentId, String newParentId) {
    // 메서드가 정의되어 있지만 어디서도 호출되지 않음
}
```

## 2. 개선 코드 예시

### 2.1 중복 제거 및 구조 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.model.common.OrganizationResponseDto;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import com.osstem.ow.voc.model.statistic.OrganizationVocStatisticsDto;
import com.osstem.ow.voc.repository.VocStatisticsQueryRepository;
import com.osstem.ow.voc.util.VocStatisticsUtil;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class VocStatisticsService {

    private final VocStatisticsQueryRepository vocStatisticsQueryRepository;
    private final CommonServiceClient commonServiceClient;
    
    @Value("${voc.statistics.default-corporation-code:KR1}")
    private String defaultCorporationCode;
    
    @Value("${voc.statistics.default-root-department-code:O000000914}")
    private String defaultRootDepartmentCode;

    // ===== VOC 등록자 기준 통계 메소드 =====

    /**
     * 일별 VOC 통계 조회 (등록자 기준)
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.DAY, StatisticsType.REGISTERER);
    }

    /**
     * 주별 VOC 통계 조회 (등록자 기준)
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocStatisticsByWeek(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.WEEK, StatisticsType.REGISTERER);
    }

    /**
     * 월별 VOC 통계 조회 (등록자 기준)
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocStatisticsByMonth(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.MONTH, StatisticsType.REGISTERER);
    }

    /**
     * 연도별 VOC 통계 조회 (등록자 기준)
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocStatisticsByYear(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.YEAR, StatisticsType.REGISTERER);
    }

    // ===== VOC 담당자 기준 통계 메소드 =====

    /**
     * 일별 VOC 담당자 통계 조회
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByDay(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.DAY, StatisticsType.CHARGE_PERSON);
    }

    /**
     * 주별 VOC 담당자 통계 조회
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByWeek(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.WEEK, StatisticsType.CHARGE_PERSON);
    }

    /**
     * 월별 VOC 담당자 통계 조회
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByMonth(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.MONTH, StatisticsType.CHARGE_PERSON);
    }

    /**
     * 연별 VOC 담당자 통계 조회
     */
    @Transactional(readOnly = true)
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByYear(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.YEAR, StatisticsType.CHARGE_PERSON);
    }

    /**
     * 통합된 통계 조회 메서드
     */
    private List<OrganizationVocStatisticsDto> getVocStatistics(VocStatisticsRequestDto condition, 
                                                               StatisticsPeriod period, 
                                                               StatisticsType type) {
        log.info("VOC 조직 통계 조회 시작 - period: {}, type: {}, startDate: {}, endDate: {}", 
                period, type, condition.getStartDate(), condition.getEndDate());
        
        try {
            // 파라미터 검증
            validateStatisticsRequest(condition);
            
            // 1. 조직도 구조 데이터 조회
            List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);
            
            // 2. 부서 코드 조회
            StatisticsContext context = createStatisticsContext(condition);
            
            // 3. 통계 데이터 조회
            Map<String, Map<String, Integer>> departmentStatistics = getStatisticsData(condition, context, period, type);
            
            // 4. 조직도에 통계 정보 추가
            VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);
            
            // 5. total 값 기준 정렬
            List<OrganizationVocStatisticsDto> sortedResult = sortByTotalDesc(organizationStructure);
            
            log.info("VOC 조직 통계 조회 완료 - period: {}, type: {}, resultCount: {}", 
                    period, type, sortedResult.size());
            
            return sortedResult;
            
        } catch (Exception e) {
            log.error("VOC 조직 통계 조회 실패 - period: {}, type: {}, error: {}", period, type, e.getMessage(), e);
            throw new BusinessException("voc.organization.statistics.retrieval.failed", e);
        }
    }

    /**
     * 조직도 구조 데이터 조회 및 전처리
     */
    private List<OrganizationVocStatisticsDto> getOrganizationStructure(VocStatisticsRequestDto condition) {
        try {
            // 기본값 설정
            String corporationCode = StringUtils.hasText(condition.getCorporationCode())
                    ? condition.getCorporationCode() : defaultCorporationCode;
            String rootDepartmentCode = StringUtils.hasText(condition.getRootDepartmentCode())
                    ? condition.getRootDepartmentCode() : defaultRootDepartmentCode;

            // 외부 API 호출
            OrganizationResponseDto response = commonServiceClient.getDepartment(corporationCode, rootDepartmentCode);
            
            if (response == null || response.getData() == null) {
                log.warn("조직도 구조 데이터가 비어있음 - corporationCode: {}, rootDepartmentCode: {}", 
                        corporationCode, rootDepartmentCode);
                return new ArrayList<>();
            }

            // Type-safe 변환
            List<OrganizationVocStatisticsDto> result = response.getData().stream()
                    .filter(OrganizationVocStatisticsDto.class::isInstance)
                    .map(OrganizationVocStatisticsDto.class::cast)
                    .collect(Collectors.toList());

            log.debug("조직도 구조 데이터 조회 완료 - count: {}", result.size());
            return result;
            
        } catch (Exception e) {
            log.error("조직도 구조 데이터 조회 실패", e);
            throw new BusinessException("voc.organization.structure.retrieval.failed", e);
        }
    }

    /**
     * 통계 조회 컨텍스트 생성
     */
    private StatisticsContext createStatisticsContext(VocStatisticsRequestDto condition) {
        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());
        
        return new StatisticsContext(chargeDepartmentCodes, registerDepartmentCodes);
    }

    /**
     * 기간 및 타입별 통계 데이터 조회
     */
    private Map<String, Map<String, Integer>> getStatisticsData(VocStatisticsRequestDto condition, 
                                                               StatisticsContext context, 
                                                               StatisticsPeriod period, 
                                                               StatisticsType type) {
        
        StatisticsQueryStrategy strategy = createQueryStrategy(period, type);
        return strategy.getStatistics(condition, context);
    }

    /**
     * 통계 조회 전략 생성
     */
    private StatisticsQueryStrategy createQueryStrategy(StatisticsPeriod period, StatisticsType type) {
        String key = period.name() + "_" + type.name();
        
        switch (key) {
            case "DAY_REGISTERER":
                return (condition, context) -> vocStatisticsQueryRepository.getVocStatisticsByDayWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "WEEK_REGISTERER":
                return (condition, context) -> vocStatisticsQueryRepository.getVocStatisticsByWeekWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "MONTH_REGISTERER":
                return (condition, context) -> vocStatisticsQueryRepository.getVocStatisticsByMonthWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "YEAR_REGISTERER":
                return (condition, context) -> vocStatisticsQueryRepository.getVocStatisticsByYearWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "DAY_CHARGE_PERSON":
                return (condition, context) -> vocStatisticsQueryRepository.getVocChargePersonStatisticsByDayWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "WEEK_CHARGE_PERSON":
                return (condition, context) -> vocStatisticsQueryRepository.getVocChargePersonStatisticsByWeekWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "MONTH_CHARGE_PERSON":
                return (condition, context) -> vocStatisticsQueryRepository.getVocChargePersonStatisticsByMonthWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            case "YEAR_CHARGE_PERSON":
                return (condition, context) -> vocStatisticsQueryRepository.getVocChargePersonStatisticsByYearWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(),
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            
            default:
                throw new BusinessException("voc.statistics.unsupported.strategy");
        }
    }

    /**
     * 부서 코드 리스트 조회
     */
    private List<String> getDepartmentCodes(String departmentCode) {
        if (org.apache.commons.lang3.StringUtils.isEmpty(departmentCode)) {
            return new ArrayList<>();
        }
        
        try {
            OrganizationResponseDto result = commonServiceClient.getDepartment(defaultCorporationCode, departmentCode);

            if (result != null && result.getData() != null) {
                return result.getData().stream()
                        .map(org -> org.getData().getDepartmentCode())
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList());
            }

            return new ArrayList<>();
            
        } catch (Exception e) {
            log.error("부서 코드 조회 실패 - departmentCode: {}, error: {}", departmentCode, e.getMessage(), e);
            // 부서 코드 조회 실패 시 빈 리스트 반환
            return new ArrayList<>();
        }
    }

    /**
     * total 값을 기준으로 내림차순 정렬
     */
    private List<OrganizationVocStatisticsDto> sortByTotalDesc(List<OrganizationVocStatisticsDto> list) {
        if (list == null || list.isEmpty()) {
            return list;
        }

        // 정렬 수행
        list.sort(createTotalComparator());

        // 각 노드의 하위 항목들도 재귀적으로 정렬
        list.forEach(this::sortChildrenByTotalDesc);

        return list;
    }

    /**
     * 노드의 하위 항목들을 재귀적으로 total 값 기준으로 내림차순 정렬
     */
    private void sortChildrenByTotalDesc(OrganizationVocStatisticsDto node) {
        if (node.getItems() == null || node.getItems().isEmpty()) {
            return;
        }

        // 하위 항목들 정렬
        node.getItems().sort(createTotalComparator());

        // 각 하위 항목의 하위 항목들도 재귀적으로 정렬
        node.getItems().forEach(this::sortChildrenByTotalDesc);
    }

    /**
     * Total 값 기준 Comparator 생성 (중복 제거)
     */
    private Comparator<OrganizationVocStatisticsDto> createTotalComparator() {
        return (o1, o2) -> {
            Integer total1 = extractTotalValue(o1);
            Integer total2 = extractTotalValue(o2);
            return total2.compareTo(total1);
        };
    }

    /**
     * 노드에서 total 값 추출
     */
    private Integer extractTotalValue(OrganizationVocStatisticsDto node) {
        return Optional.ofNullable(node.getStatistics())
                .map(stats -> stats.getOrDefault("total", 0))
                .orElse(0);
    }

    // 검증 메서드
    private void validateStatisticsRequest(VocStatisticsRequestDto condition) {
        if (condition == null) {
            throw new BusinessException("voc.statistics.invalid.condition");
        }
        
        if (condition.getStartDate() == null || condition.getEndDate() == null) {
            throw new BusinessException("voc.statistics.invalid.dateRange");
        }
        
        if (condition.getStartDate().isAfter(condition.getEndDate())) {
            throw new BusinessException("voc.statistics.invalid.dateOrder");
        }
    }

    // 내부 클래스들 및 인터페이스
    private enum StatisticsPeriod {
        DAY, WEEK, MONTH, YEAR
    }

    private enum StatisticsType {
        REGISTERER, CHARGE_PERSON
    }

    @FunctionalInterface
    private interface StatisticsQueryStrategy {
        Map<String, Map<String, Integer>> getStatistics(VocStatisticsRequestDto condition, StatisticsContext context);
    }

    private static class StatisticsContext {
        private final List<String> chargeDepartmentCodes;
        private final List<String> registerDepartmentCodes;

        public StatisticsContext(List<String> chargeDepartmentCodes, List<String> registerDepartmentCodes) {
            this.chargeDepartmentCodes = chargeDepartmentCodes;
            this.registerDepartmentCodes = registerDepartmentCodes;
        }

        public List<String> getChargeDepartmentCodes() { return chargeDepartmentCodes; }
        public List<String> getRegisterDepartmentCodes() { return registerDepartmentCodes; }
    }
}
```

## 3. 다른 접근법

### 3.1 Factory Method 패턴을 이용한 통계 조회
```java
public abstract class VocStatisticsQueryFactory {
    
    public static VocStatisticsQuery createQuery(StatisticsPeriod period, StatisticsType type) {
        String key = period + "_" + type;
        
        switch (key) {
            case "DAY_REGISTERER":
                return new DayRegistererStatisticsQuery();
            case "WEEK_REGISTERER":
                return new WeekRegistererStatisticsQuery();
            // ... 다른 조합들
            default:
                throw new IllegalArgumentException("Unsupported combination: " + key);
        }
    }
}

public interface VocStatisticsQuery {
    Map<String, Map<String, Integer>> execute(VocStatisticsRequestDto condition, StatisticsContext context);
}
```

### 3.2 Command Pattern 적용
```java
public class VocStatisticsCommand {
    private final VocStatisticsRequestDto condition;
    private final StatisticsPeriod period;
    private final StatisticsType type;
    
    public VocStatisticsCommand(VocStatisticsRequestDto condition, StatisticsPeriod period, StatisticsType type) {
        this.condition = condition;
        this.period = period;
        this.type = type;
    }
    
    public List<OrganizationVocStatisticsDto> execute() {
        // 통계 조회 로직 실행
        return vocStatisticsService.getStatistics(condition, period, type);
    }
}
```

### 3.3 Decorator Pattern으로 정렬 기능 분리
```java
public interface StatisticsResultProcessor {
    List<OrganizationVocStatisticsDto> process(List<OrganizationVocStatisticsDto> data);
}

public class SortingStatisticsResultProcessor implements StatisticsResultProcessor {
    @Override
    public List<OrganizationVocStatisticsDto> process(List<OrganizationVocStatisticsDto> data) {
        return sortByTotalDesc(data);
    }
}

public class FilteringStatisticsResultProcessor implements StatisticsResultProcessor {
    private final int minTotalCount;
    
    @Override
    public List<OrganizationVocStatisticsDto> process(List<OrganizationVocStatisticsDto> data) {
        return data.stream()
                .filter(node -> extractTotalValue(node) >= minTotalCount)
                .collect(Collectors.toList());
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **캐싱**: 조직도 구조는 자주 변경되지 않으므로 캐싱 적용
- **병렬 처리**: 부서 코드 조회를 병렬로 처리하여 성능 개선
- **페이징**: 대용량 통계 데이터에 대한 페이징 처리
- **인덱싱**: 자주 사용되는 통계 조회 조건에 대한 DB 인덱스 최적화

### 4.2 데이터 일관성 측면  
- **트랜잭션**: 읽기 전용 트랜잭션으로 일관된 데이터 조회 보장
- **격리 수준**: 통계 조회 시 적절한 격리 수준 설정
- **데이터 검증**: 통계 계산 결과의 무결성 검증

### 4.3 확장성 측면
- **새로운 기간 단위**: 시간별, 분기별 통계 추가 시 확장 용이성
- **새로운 통계 타입**: 승인자 기준, 처리자 기준 등 새로운 타입 추가 용이성
- **다양한 집계 방식**: 평균, 최대값, 최소값 등 다양한 집계 함수 지원

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 극심한 코드 중복 제거 | 높음 | 6시간 | 유지보수성 핵심 |
| Type Safety 개선 | 높음 | 2시간 | 런타임 안정성 핵심 |
| 예외 처리 추가 | 높음 | 3시간 | 서비스 안정성 핵심 |
| 파라미터 검증 | 중간 | 2시간 | NPE 방지 |
| 하드코딩 제거 | 중간 | 1시간 | 설정 분리 |
| 정렬 로직 중복 제거 | 중간 | 2시간 | 코드 품질 향상 |
| 로깅 추가 | 중간 | 2시간 | 운영 모니터링 필요 |
| 미사용 메서드 제거 | 낮음 | 30분 | 코드 정리 |

**총 예상 소요 시간**: 18시간 30분
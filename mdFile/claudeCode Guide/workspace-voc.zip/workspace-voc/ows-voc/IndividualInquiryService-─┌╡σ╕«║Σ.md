# IndividualInquiryService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### DTO 직접 수정으로 인한 부작용
**문제점**: update 메서드에서 입력 파라미터 DTO를 직접 수정하여 부작용 발생 가능
**라인**: 31번 라인
```java
public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
    answerDto.setIndividualInquiryAnswerDatetime(LocalDateTime.now()); // 입력 파라미터를 직접 수정
    return individualInquiryServiceClient.update(inquiryNumber, answerDto);
}
```

#### 예외 처리 부재
**문제점**: Feign Client 호출 실패 시 예외 처리가 없어 장애 전파 가능
**라인**: 전체 메서드 (19-33번 라인)
```java
public ResultDto<IndividualInquiryResponseDto> search(IndividualInquiryRequestDto requestDto, String userId, String corporationCode) {
    return individualInquiryServiceClient.list(requestDto, userId, corporationCode); // 예외 처리 없음
}
```

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 19, 23, 27, 30번 라인
```java
public IndividualInquiryResponseDto getInquiryWithAnswer(Long inquiryNumber, String userId) {
    // inquiryNumber, userId null 검증 없음
    return individualInquiryServiceClient.getInquiryWithAnswer(userId, inquiryNumber);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 메서드 파라미터 순서 불일치
**문제점**: 같은 파라미터들의 순서가 메서드마다 일관성이 없음
**라인**: 23-24번 라인
```java
// 메서드 정의: inquiryNumber, userId 순서
public IndividualInquiryResponseDto getInquiryWithAnswer(Long inquiryNumber, String userId) {
    // Feign 호출: userId, inquiryNumber 순서 (반대)
    return individualInquiryServiceClient.getInquiryWithAnswer(userId, inquiryNumber);
}
```

#### 로깅 부재
**문제점**: 비즈니스 로직 추적과 디버깅이 어려움
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class IndividualInquiryService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 어떤 작업을 수행했는지 추적 불가
**라인**: 전체 메서드
```java
public IndividualInquiryAnswerDto createAnswer(IndividualInquiryAnswerDto answerDto) {
    // 사용자 정보 로깅 없음
    return individualInquiryServiceClient.createAnswer(answerDto);
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 외부 서비스 호출에 대한 트랜잭션 전략이 명확하지 않음
**라인**: 전체 메서드
```java
// @Transactional 애노테이션 없음
public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
    answerDto.setIndividualInquiryAnswerDatetime(LocalDateTime.now());
    return individualInquiryServiceClient.update(inquiryNumber, answerDto);
}
```

#### 시간 설정 로직 위치 부적절
**문제점**: 비즈니스 로직이 서비스 계층에 섞여있어 책임 분리가 불명확
**라인**: 31번 라인
```java
answerDto.setIndividualInquiryAnswerDatetime(LocalDateTime.now()); // 이 로직의 위치가 적절한지 검토 필요
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.IndividualInquiryServiceClient;
import com.osstem.ow.voc.model.event.IndividualInquiryAnswerDto;
import com.osstem.ow.voc.model.request.IndividualInquiryRequestDto;
import com.osstem.ow.voc.model.response.IndividualInquiryResponseDto;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class IndividualInquiryService {

    private final IndividualInquiryServiceClient individualInquiryServiceClient;

    /**
     * 개별 문의 목록 검색
     * @param requestDto 검색 조건
     * @param userId 사용자 ID
     * @param corporationCode 회사 코드
     * @return 검색 결과
     */
    public ResultDto<IndividualInquiryResponseDto> search(IndividualInquiryRequestDto requestDto, 
                                                         String userId, 
                                                         String corporationCode) {
        log.info("개별 문의 검색 시작 - userId: {}, corporationCode: {}", userId, corporationCode);
        
        // 파라미터 검증
        validateSearchRequest(requestDto, userId, corporationCode);
        
        try {
            ResultDto<IndividualInquiryResponseDto> result = 
                individualInquiryServiceClient.list(requestDto, userId, corporationCode);
            log.info("개별 문의 검색 완료 - count: {}, userId: {}", result.getList().size(), userId);
            return result;
        } catch (Exception e) {
            log.error("개별 문의 검색 실패 - userId: {}, error: {}", userId, e.getMessage(), e);
            throw new BusinessException("individualInquiry.search.failed", e);
        }
    }

    /**
     * 개별 문의 상세 조회 (답변 포함)
     * @param inquiryNumber 문의 번호
     * @param userId 사용자 ID
     * @return 문의 상세 정보
     */
    public IndividualInquiryResponseDto getInquiryWithAnswer(Long inquiryNumber, String userId) {
        log.info("개별 문의 상세 조회 시작 - inquiryNumber: {}, userId: {}", inquiryNumber, userId);
        
        // 파라미터 검증
        validateInquiryNumber(inquiryNumber);
        validateUserId(userId);
        
        try {
            IndividualInquiryResponseDto result = 
                individualInquiryServiceClient.getInquiryWithAnswer(userId, inquiryNumber);
            log.info("개별 문의 상세 조회 완료 - inquiryNumber: {}, userId: {}", inquiryNumber, userId);
            return result;
        } catch (Exception e) {
            log.error("개별 문의 상세 조회 실패 - inquiryNumber: {}, userId: {}, error: {}", 
                     inquiryNumber, userId, e.getMessage(), e);
            throw new BusinessException("individualInquiry.retrieval.failed", e);
        }
    }

    /**
     * 개별 문의 답변 생성
     * @param answerDto 답변 정보
     * @return 생성된 답변 정보
     */
    public IndividualInquiryAnswerDto createAnswer(IndividualInquiryAnswerDto answerDto) {
        log.info("개별 문의 답변 생성 시작 - inquiryNumber: {}", 
                answerDto != null ? answerDto.getIndividualInquiryNumber() : "null");
        
        // 파라미터 검증
        validateAnswerDto(answerDto);
        validateAnswerCreateRequest(answerDto);
        
        try {
            IndividualInquiryAnswerDto result = individualInquiryServiceClient.createAnswer(answerDto);
            log.info("개별 문의 답변 생성 완료 - inquiryNumber: {}", result.getIndividualInquiryNumber());
            return result;
        } catch (Exception e) {
            log.error("개별 문의 답변 생성 실패 - inquiryNumber: {}, error: {}", 
                     answerDto != null ? answerDto.getIndividualInquiryNumber() : "null", e.getMessage(), e);
            throw new BusinessException("individualInquiry.answer.creation.failed", e);
        }
    }

    /**
     * 개별 문의 답변 수정
     * @param inquiryNumber 문의 번호
     * @param answerDto 답변 정보
     * @return 수정된 답변 정보
     */
    public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
        log.info("개별 문의 답변 수정 시작 - inquiryNumber: {}", inquiryNumber);
        
        // 파라미터 검증
        validateInquiryNumber(inquiryNumber);
        validateAnswerDto(answerDto);
        validateAnswerUpdateRequest(answerDto);
        
        try {
            // 원본 DTO를 수정하지 않고 복사본 생성
            IndividualInquiryAnswerDto updatedAnswerDto = createUpdatedAnswerDto(answerDto);
            
            IndividualInquiryAnswerDto result = 
                individualInquiryServiceClient.update(inquiryNumber, updatedAnswerDto);
            log.info("개별 문의 답변 수정 완료 - inquiryNumber: {}", inquiryNumber);
            return result;
        } catch (Exception e) {
            log.error("개별 문의 답변 수정 실패 - inquiryNumber: {}, error: {}", inquiryNumber, e.getMessage(), e);
            throw new BusinessException("individualInquiry.answer.update.failed", e);
        }
    }

    // 검증 메서드들
    private void validateSearchRequest(IndividualInquiryRequestDto requestDto, String userId, String corporationCode) {
        if (Objects.isNull(requestDto)) {
            throw new BusinessException("individualInquiry.invalid.request");
        }
        validateUserId(userId);
        validateCorporationCode(corporationCode);
    }

    private void validateInquiryNumber(Long inquiryNumber) {
        if (Objects.isNull(inquiryNumber) || inquiryNumber <= 0) {
            throw new BusinessException("individualInquiry.invalid.inquiryNumber");
        }
    }

    private void validateUserId(String userId) {
        if (!StringUtils.hasText(userId)) {
            throw new BusinessException("individualInquiry.invalid.userId");
        }
    }

    private void validateCorporationCode(String corporationCode) {
        if (!StringUtils.hasText(corporationCode)) {
            throw new BusinessException("individualInquiry.invalid.corporationCode");
        }
    }

    private void validateAnswerDto(IndividualInquiryAnswerDto answerDto) {
        if (Objects.isNull(answerDto)) {
            throw new BusinessException("individualInquiry.invalid.answer");
        }
    }

    private void validateAnswerCreateRequest(IndividualInquiryAnswerDto answerDto) {
        if (Objects.isNull(answerDto.getIndividualInquiryNumber()) || 
            answerDto.getIndividualInquiryNumber() <= 0) {
            throw new BusinessException("individualInquiry.invalid.answer.inquiryNumber");
        }
        if (!StringUtils.hasText(answerDto.getIndividualInquiryAnswerContent())) {
            throw new BusinessException("individualInquiry.invalid.answer.content");
        }
    }

    private void validateAnswerUpdateRequest(IndividualInquiryAnswerDto answerDto) {
        if (!StringUtils.hasText(answerDto.getIndividualInquiryAnswerContent())) {
            throw new BusinessException("individualInquiry.invalid.answer.content");
        }
    }

    // DTO 복사 및 업데이트 처리
    private IndividualInquiryAnswerDto createUpdatedAnswerDto(IndividualInquiryAnswerDto original) {
        IndividualInquiryAnswerDto updated = new IndividualInquiryAnswerDto();
        
        // 원본 데이터 복사
        updated.setIndividualInquiryNumber(original.getIndividualInquiryNumber());
        updated.setIndividualInquiryAnswerContent(original.getIndividualInquiryAnswerContent());
        updated.setIndividualInquiryAnswererEmployeeNumber(original.getIndividualInquiryAnswererEmployeeNumber());
        
        // 수정 시간 설정
        updated.setIndividualInquiryAnswerDatetime(LocalDateTime.now());
        
        return updated;
    }
}
```

## 3. 다른 접근법

### 3.1 Builder 패턴을 이용한 DTO 생성
```java
@Service
@RequiredArgsConstructor
public class IndividualInquiryService {
    
    public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
        // Builder 패턴으로 새로운 DTO 생성
        IndividualInquiryAnswerDto updatedDto = IndividualInquiryAnswerDto.builder()
                .individualInquiryNumber(answerDto.getIndividualInquiryNumber())
                .individualInquiryAnswerContent(answerDto.getIndividualInquiryAnswerContent())
                .individualInquiryAnswererEmployeeNumber(answerDto.getIndividualInquiryAnswererEmployeeNumber())
                .individualInquiryAnswerDatetime(LocalDateTime.now())
                .build();
                
        return individualInquiryServiceClient.update(inquiryNumber, updatedDto);
    }
}
```

### 3.2 MapStruct를 이용한 DTO 매핑
```java
@Mapper(componentModel = "spring")
public interface IndividualInquiryMapper {
    
    @Mapping(target = "individualInquiryAnswerDatetime", expression = "java(java.time.LocalDateTime.now())")
    IndividualInquiryAnswerDto createUpdateDto(IndividualInquiryAnswerDto source);
}

@Service
@RequiredArgsConstructor
public class IndividualInquiryService {
    
    private final IndividualInquiryMapper mapper;
    
    public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
        IndividualInquiryAnswerDto updatedDto = mapper.createUpdateDto(answerDto);
        return individualInquiryServiceClient.update(inquiryNumber, updatedDto);
    }
}
```

### 3.3 Template Method 패턴 적용
```java
@Service
@RequiredArgsConstructor
public abstract class BaseInquiryService<T, R> {
    
    protected final R executeWithExceptionHandling(String operation, Supplier<R> supplier) {
        try {
            log.info("{} 시작", operation);
            R result = supplier.get();
            log.info("{} 완료", operation);
            return result;
        } catch (Exception e) {
            log.error("{} 실패 - error: {}", operation, e.getMessage(), e);
            throw new BusinessException(operation.toLowerCase().replace(" ", ".") + ".failed", e);
        }
    }
}

@Service
public class IndividualInquiryService extends BaseInquiryService<IndividualInquiryRequestDto, IndividualInquiryResponseDto> {
    
    public IndividualInquiryResponseDto getInquiryWithAnswer(Long inquiryNumber, String userId) {
        return executeWithExceptionHandling("개별 문의 조회", 
            () -> individualInquiryServiceClient.getInquiryWithAnswer(userId, inquiryNumber));
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **페이징 처리**: 검색 결과가 많을 경우 페이징 최적화
- **캐싱 전략**: 자주 조회되는 문의에 대한 캐싱 적용
- **비동기 처리**: 답변 생성/수정 시 알림 발송을 비동기로 처리

### 4.2 보안 측면  
- **권한 검증**: 사용자가 해당 문의에 대한 접근 권한이 있는지 확인
- **데이터 마스킹**: 민감한 개인정보가 포함된 경우 로그에서 마스킹
- **입력 검증**: XSS, SQL Injection 방지를 위한 입력값 검증

### 4.3 비즈니스 로직 측면
- **상태 관리**: 문의 상태(미답변, 답변완료 등) 자동 업데이트
- **알림 기능**: 답변 생성/수정 시 문의자에게 알림 발송
- **이력 관리**: 답변 수정 이력 추적 기능

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| DTO 부작용 제거 | 높음 | 1시간 | 데이터 무결성 핵심 |
| 예외 처리 추가 | 높음 | 2시간 | 서비스 안정성 핵심 |
| 파라미터 검증 | 높음 | 1.5시간 | NPE 방지 필수 |
| 파라미터 순서 일관성 | 중간 | 30분 | 코드 가독성 향상 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| MapStruct 매핑 | 낮음 | 2시간 | 코드 품질 향상 |

**총 예상 소요 시간**: 8시간
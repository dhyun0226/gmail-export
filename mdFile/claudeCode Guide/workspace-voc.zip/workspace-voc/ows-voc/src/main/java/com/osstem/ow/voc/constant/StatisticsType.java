package com.osstem.ow.voc.constant;

import java.time.YearMonth;

public enum StatisticsType {

    /**
     * 시간별 통계 (0-23시)
     */
    HOURLY("h", 0, 23) {
        @Override
        public int getMaxIndex() {
            return 23;
        }
    },

    /**
     * 일별 통계 (1-31일)
     */
    DAILY("d", 1, 31) {
        @Override
        public int getMaxIndex(int year, int month) {
            return YearMonth.of(year, month).lengthOfMonth();
        }
    },

    /**
     * 주별 통계 (1-53주)
     */
    WEEKLY("w", 1, 53),

    /**
     * 월별 통계 (1-12월)
     */
    MONTHLY("m", 1, 12) {
        @Override
        public int getMaxIndex() {
            return 12;
        }
    },

    /**
     * 분기별 통계 (1-4분기)
     */
    QUARTERLY("q", 1, 4) {
        @Override
        public int getMaxIndex() {
            return 4;
        }
    };

    private final String prefix;
    private final int minIndex;
    private final int maxIndex;

    /**
     * 기본 생성자
     *
     * @param prefix 필드 접두어 (예: 'd', 'm', 'h')
     * @param minIndex 최소 인덱스
     * @param maxIndex 기본 최대 인덱스
     */
    StatisticsType(String prefix, int minIndex, int maxIndex) {
        this.prefix = prefix;
        this.minIndex = minIndex;
        this.maxIndex = maxIndex;
    }

    /**
     * 필드 접두어 반환
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * 최소 인덱스 반환
     */
    public int getMinIndex() {
        return minIndex;
    }

    /**
     * 기본 최대 인덱스 반환
     */
    public int getMaxIndex() {
        return maxIndex;
    }

    /**
     * 연도와 월에 따른 최대 인덱스 반환 (일별 통계의 경우 월마다 일수가 다름)
     *
     * @param year 연도
     * @param month 월
     * @return 최대 인덱스
     */
    public int getMaxIndex(int year, int month) {
        return maxIndex; // 기본 구현은 고정 최대값 반환
    }

    /**
     * 접두어와 인덱스로 필드 키 생성
     *
     * @param index 인덱스
     * @return 필드 키 (예: "d15", "m6")
     */
    public String getFieldKey(int index) {
        return prefix + index;
    }
}
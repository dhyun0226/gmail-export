package com.osstem.ow.voc.model.request;

import com.osstem.ow.voc.model.base.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Schema(description = "VOC 요청 DTO")
public class VocRequestDto implements PagingDto {

    @Schema(description = "페이지 번호")
    private Integer pageNo;

    @Schema(description = "페이지 크기")
    private Integer pageSize;

    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Size(max = 12)
    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Size(max = 90)
    @Schema(description = "품목 코드")
    private String itemCode;

    @Size(max = 50)
    @Schema(description = "VOC 고객명")
    private String vocCustomerName;

    @Size(max = 100)
    @Schema(description = "VOC 제목")
    private String vocTitle;

    @Size(max = 2)
    @Schema(description = "VOC 상태 코드")
    private String vocStateCode;

    @Schema(description = "시작 일자")
    private LocalDateTime startDate;

    @Schema(description = "종료 일자")
    private LocalDateTime endDate;

    @Schema(description = "VOC 담당자 법인 코드")
    private String vocChargePersonDepartmentCode;

    @Schema(description = "VOC 등록자 법인 코드")
    private String vocRegistererDepartmentCode;

    @Schema(description = "그룹핑 타입 (REGISTERER: 등록자 부서 기준, CHARGE_PERSON: 담당자 부서 기준)", defaultValue = "REGISTERER")
    private String groupByType;

    @Size(max = 3)
    @Schema(description = "VOC 영업 담당자 법인 코드")
    private String vocSaleChargeCorporationCode;

    @Size(max = 30)
    @Schema(description = "VOC 영업 담당자 부서 코드")
    private String vocSaleChargeDepartmentCode;

    @Size(max = 60)
    @Schema(description = "VOC 영업 담당자 사원 번호")
    private String vocSaleChargeEmployeeNumber;

}
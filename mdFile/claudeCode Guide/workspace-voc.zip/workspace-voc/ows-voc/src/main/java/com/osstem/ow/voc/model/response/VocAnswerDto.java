package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 답변 정보 DTO
 */
@Value
@Builder
@Schema(description = "VOC 답변 정보")
public class VocAnswerDto {
    
    @Schema(description = "답변 번호")
    Long answerNumber;
    
    @Schema(description = "답변 내용")
    String answerContent;
    
    @Schema(description = "답변자 정보")
    AnswererInfo answererInfo;
    
    @Schema(description = "답변일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    LocalDateTime answerDateTime;
    
    @Schema(description = "첨부파일 목록")
    List<FileDto> attachments;
    
    /**
     * 답변자 정보
     */
    @Value
    @Builder
    public static class AnswererInfo {
        @Schema(description = "답변자 사원번호")
        String employeeNumber;
        
        @Schema(description = "답변자명")
        String answererName;
        
        @Schema(description = "부서코드")
        String departmentCode;
        
        @Schema(description = "부서명")
        String departmentName;
    }
}
package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.QnaService;
import com.osstem.ow.voc.model.event.QnaAnswerDetailDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/qna-answers")
@RequiredArgsConstructor
public class QnaAnswerController {

    private final QnaService qnaService;

    @Operation(summary = "QnA 답변 생성", description = "QnA 답변을 생성합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 답변 생성 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @PostMapping
    public ResponseEntity<QnaAnswerDetailDto> create(@RequestBody QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetailDto result = qnaService.createQnaAnswer(qnaAnswerDetailDto);
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "QnA 답변 수정", description = "QnA 답변을 수정합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 답변 수정 성공",
            content = @Content(schema = @Schema(implementation = QnaAnswerDetailDto.class)))
    @PutMapping("/{qnaNumber}/{qnaAnswerDetailNumber}")
    public ResponseEntity<QnaAnswerDetailDto> update(
            @PathVariable Long qnaNumber,
            @PathVariable Long qnaAnswerDetailNumber,
            @RequestBody QnaAnswerDetailDto qnaAnswerDetailDto) {
        QnaAnswerDetailDto result = qnaService.updateQnaAnswer(qnaNumber, qnaAnswerDetailNumber, qnaAnswerDetailDto);
        return ResponseEntity.ok(result);
    }
}
package com.osstem.ow.voc.model.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VocStatisticsRequestDto {
    // 조직도 관련 필드
    private String corporationCode;
    private String rootDepartmentCode;
    private List<String> expandingDepartmentCodes;

    // 통계 조회 조건 필드
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String vocStateCode;
    private String vocCategoryCode;
    private String groupCode;
    private String itemCode;
    private String departmentCode;
    @Schema(description = "VOC 담당자 법인 코드")
    private String vocChargePersonDepartmentCode;

    @Schema(description = "VOC 등록자 법인 코드")
    private String vocRegistererDepartmentCode;


    /**
     * 기본 검색 조건 생성
     *
     * @return 기본값이 설정된 검색 조건
     */
    public static VocStatisticsRequestDto createDefault() {
        return VocStatisticsRequestDto.builder()
                .corporationCode("KR1")
                .rootDepartmentCode("O000000914")
                .build();
    }
}
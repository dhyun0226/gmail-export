package com.osstem.ow.voc.structMapper;

import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.model.table.VocCategoryDto;
import com.osstem.ow.voc.repository.VocCategoryRepository;
import org.mapstruct.*;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,
        uses = {VocCategoryRepository.class})
public interface VocCategoryStruct extends StructMapper<VocCategory, VocCategoryDto> {

    @Override
    @Mapping(target = "upVocCategoryCode", source = "upVocCategoryCode.vocCategoryCode")
    @Mapping(target = "upVocCategoryName", source = "upVocCategoryCode.vocCategoryName")
    VocCategoryDto toDto(VocCategory entity);

    @Override
    @Mapping(target = "upVocCategoryCode", ignore = true) // 엔티티로 변환 시 상위 카테고리는 별도 처리 필요
    VocCategory toEntity(VocCategoryDto dto);

    /**
     * dto에서 상위 카테고리 코드가 있는 경우, 해당 코드로 상위 카테고리 엔티티를 설정합니다.
     * 이 메서드는 toEntity 메서드 후에 호출되어야 합니다.
     */
    @AfterMapping
    default void setUpVocCategoryCode(VocCategoryDto dto, @MappingTarget VocCategory entity,
                                      @Context VocCategoryRepository repository) {
        if (dto.getUpVocCategoryCode() != null && !dto.getUpVocCategoryCode().isEmpty()) {
            repository.findById(dto.getUpVocCategoryCode())
                    .ifPresent(entity::setUpVocCategoryCode);
        }
    }

    /**
     * 엔티티 목록을 DTO 목록으로 변환합니다.
     */
    @Override
    default List<VocCategoryDto> toDtoList(List<VocCategory> entityList) {
        if (entityList == null) {
            return null;
        }

        return entityList.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * DTO 목록을 엔티티 목록으로 변환합니다.
     */
    @Override
    default List<VocCategory> toEntityList(List<VocCategoryDto> dtoList) {
        if (dtoList == null) {
            return null;
        }

        return dtoList.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }
}

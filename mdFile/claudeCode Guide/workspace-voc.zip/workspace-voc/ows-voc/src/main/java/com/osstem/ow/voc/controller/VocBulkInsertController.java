package com.osstem.ow.voc.controller;


import com.osstem.ow.voc.domain.VocBulkInsertService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/voc")
@RequiredArgsConstructor
public class VocBulkInsertController {

    private final VocBulkInsertService vocBulkInsertService;

    /**
     * VOC 데이터 300개 일괄 생성 API
     * @param processorId 처리자 ID
     * @return 응답 엔티티
     */
    @PostMapping("/bulk-insert")
    public ResponseEntity<String> bulkInsertVocs(@RequestParam(defaultValue = "SYSTEM") String processorId) {
        try {
            vocBulkInsertService.bulkInsertVocs(processorId);
            return ResponseEntity.ok("300개의 VOC 데이터가 성공적으로 생성되었습니다.");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("VOC 데이터 생성 중 오류가 발생했습니다: " + e.getMessage());
        }
    }
}
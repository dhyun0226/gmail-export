package com.osstem.ow.voc.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskCategoryResponseDto {
    private String taskCode;      // enum의 taskCode
    private String taskType;      // enum의 이름 소문자
    private String categoryName;  // vocCategoryName
}

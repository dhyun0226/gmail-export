package com.osstem.ow.voc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Masked {
    MaskingType type();

    enum MaskingType {
        NAME,               // 성명 마스킹 (가운데 1자리, 예: 홍*동)
        ID,                 // ID 마스킹 (뒷 3자리, 예: honggil***)
        EMAIL,              // 이메일 마스킹 (뒷 3자리, 예: hong***@example.com)
        BIRTH_DATE,         // 생년월일 마스킹 (뒷 4자리, 예: 1990****, 1990-**-**)
        PHONE_NUMBER,       // 전화번호 마스킹 (가운데 자리, 예: 02-****-1234)
        MOBILE_NUMBER,      // 핸드폰 번호 마스킹 (가운데 자리, 예: 010-****-1234)
        RESIDENT_NUMBER,    // 주민등록번호 마스킹 (뒷 6자리, 예: 901231-******)
        ADDRESS,            // 주소 마스킹 (구 다음의 상세주소, 예: 서울시 강남구 ****)
        CUSTOM              // 커스텀 마스킹 (필요시 확장 가능)
    }
}
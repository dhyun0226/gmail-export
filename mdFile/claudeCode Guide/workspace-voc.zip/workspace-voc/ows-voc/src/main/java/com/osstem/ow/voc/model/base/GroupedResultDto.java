package com.osstem.ow.voc.model.base;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 그룹화된 VOC 결과를 페이지네이션과 함께 반환하기 위한 DTO
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GroupedResultDto<T> {
    private List<T> data;           // 현재 페이지 데이터
    private int pageNo;                // 현재 페이지 번호
    private int pageSize;              // 페이지 크기
    private int totalPages;            // 전체 페이지 수
    private long totalCount;        // 전체 항목 수 (헤더 포함)

    /**
     * 빈 결과를 생성
     */
    public static <T> GroupedResultDto<T> empty(int pageNo, int pageSize) {
        return new GroupedResultDto<>(
                List.of(),
                pageNo,
                pageSize,
                0,
                0
        );
    }
}

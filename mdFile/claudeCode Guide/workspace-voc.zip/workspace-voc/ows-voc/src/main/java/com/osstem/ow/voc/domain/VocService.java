package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.constant.GroupType;
import com.osstem.ow.voc.constant.TaskType;
import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.exception.BusinessException;
import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.feign.TxmServiceClient;
import com.osstem.ow.voc.model.base.GroupedResultDto;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.common.*;
import com.osstem.ow.voc.model.request.VocRequestDto;
import com.osstem.ow.voc.model.response.GroupedVocResponseDto;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.model.table.VocChangeHistoryDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import com.osstem.ow.voc.model.table.VocDto;
import com.osstem.ow.voc.model.txm.TxmFileListResponse;
import com.osstem.ow.voc.repository.VocChangeHistoryRepository;
import com.osstem.ow.voc.repository.VocQueryRepository;
import com.osstem.ow.voc.repository.VocRepository;
import com.osstem.ow.voc.structMapper.VocChangeHistoryStruct;
import com.osstem.ow.voc.structMapper.VocStruct;
import com.osstem.ow.voc.util.FileUtil;
import com.osstem.ow.voc.util.VocPaginationUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class VocService {

    private final VocRepository vocRepository;
    private final VocStruct vocStruct;
    private final VocChangeHistoryStruct vocChangeHistoryStruct;
    private final VocQueryRepository vocQueryRepository;
    private final TxmServiceClient txmServiceClient;
    private final CommonServiceClient commonServiceClient;
    private final VocChargePersonService vocChargePersonService;
    private final ItemCodeMappingService itemCodeMappingService;
    private final VocChangeHistoryService vocChangeHistoryService;
    private final VocChangeHistoryRepository vocChangeHistoryRepository;


    /**
     * VOC 번호로 단건 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return VOC 정보
     */
    @Transactional(readOnly = true)
    public VocDto findById(Long vocNumber) {
        Voc voc = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));
        return vocStruct.toDto(voc);
    }

    /**
     * VOC 번호로 VOC와 답변 정보를 함께 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return VOC 및 답변 정보
     */
    @Transactional(readOnly = true)
    public VocResponseDto findByIdWithAnswer(Long vocNumber) {
        // vocNumber로 데이터를 조회
        VocResponseDto responseDto = vocQueryRepository.findByIdWithAnswer(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        // 파일 ID가 존재할 경우 파일 목록 조회
        if (StringUtils.isNotEmpty(responseDto.getVocFileId())) {
            TxmFileListResponse txmFileListResponse = txmServiceClient.getFileList(
                    FileUtil.buildRequest(TaskType.VOC, responseDto.getDenallVocNumber().toString())
            );
            // 파일 조회 실패 시 예외 처리
            if (txmFileListResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            // 파일 목록을 응답 DTO에 설정
            responseDto.setFileList(txmFileListResponse);
        }
        return responseDto;
    }

    /**
     * VOC 번호로 VOC와 답변 정보, 이력 정보를 함께 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return VOC 및 답변 정보
     */
    @Transactional(readOnly = true)
    public VocResponseDto findByIdWithAnswersAndHistories(Long vocNumber) {
        VocResponseDto vocResponseDto = vocQueryRepository.findByIdWithAnswer(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        // 파일 ID가 존재할 경우 파일 목록 조회
        if (StringUtils.isNotEmpty(vocResponseDto.getVocFileId())) {
            TxmFileListResponse txmFileListResponse = txmServiceClient.getFileList(
                    FileUtil.buildRequest(TaskType.VOC, vocResponseDto.getDenallVocNumber().toString())
            );
            // 파일 조회 실패 시 예외 처리
            if (txmFileListResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            // 파일 목록을 응답 DTO에 설정
            vocResponseDto.setFileList(txmFileListResponse);
        }

        // 답변 파일 ID가 존재할 경우 답변 파일 목록 조회
        if (StringUtils.isNotEmpty(vocResponseDto.getAnswerFileId())) {
            TxmFileListResponse txmFileListResponse = txmServiceClient.getFileList(
                    FileUtil.buildRequest(TaskType.VOCANSWER, vocResponseDto.getVocNumber().toString())
            );
            // 파일 조회 실패 시 예외 처리
            if (txmFileListResponse.getStatus() != 200) {
                throw new BusinessException("error.file.found");
            }
            // 답변 파일 목록을 응답 DTO에 설정
            vocResponseDto.setAnswerFileList(txmFileListResponse);
        }


        List<VocChangeHistory> histories = vocChangeHistoryRepository.findById_VocNumber(vocNumber);

        List<VocChangeHistoryDto> vocChangeHistoryDto = vocChangeHistoryStruct.toDtoList(histories);

        vocResponseDto.setChangeHistories(vocChangeHistoryDto);

        return vocResponseDto;
    }

    /**
     * 신규 VOC를 등록합니다.
     *
     * @param vocDto VOC 정보
     * @return 등록된 VOC 정보
     */
    @Transactional
    public VocDto create(VocDto vocDto) {
        VocChargePersonDto vocChargePersonDto = vocChargePersonService.findRepresentativePersonInCharge(
                vocDto.getVocCategoryCode()
        );

        if (vocChargePersonDto == null) {
            throw new BusinessException("vocChargePerson.notFound");
        }

        //민봉기로 임시 세팅
        vocDto.setVocCategoryCode("DVOC_VOC_015");
        vocDto.setVocChargePersonNumber(2359L);


        EmployeeRequestDto employeeRequestDto = EmployeeRequestDto.builder()
                .corporationCode("KR1")
                .employeeNumber(vocDto.getRegistererEmployeeNumber())
                .build();

        // 3. 사원번호로 법인코드, 부서코드 조회
        EmployeeResponseDto employeeResponseDto = commonServiceClient.getEmployee(employeeRequestDto);

        if (employeeResponseDto == null || StringUtils.isEmpty(employeeResponseDto.getData().getCorporationCode())) {
            throw new BusinessException("employee.notFound");
        }

        // 4. vocDto에 법인코드, 부서코드 설정
        vocDto.setRegistererCorporationCode(employeeResponseDto.getData().getCorporationCode());
        vocDto.setRegistererDepartmentCode(employeeResponseDto.getData().getDepartmentCode());
        vocDto.setVocSaleChargeCorporationCode(employeeResponseDto.getData().getCorporationCode());
        vocDto.setVocSaleChargeDepartmentCode(employeeResponseDto.getData().getDepartmentCode());
        vocDto.setVocSaleChargeEmployeeNumber(vocDto.getRegistererEmployeeNumber());

        // DTO를 Entity로 변환
        Voc voc = vocStruct.toEntity(vocDto);

        // Entity 저장
        Voc savedVoc = vocRepository.save(voc);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocStruct.toDto(savedVoc);
    }

    /**
     * VOC 정보를 수정합니다.
     *
     * @param vocNumber VOC 번호
     * @param vocDto    수정할 VOC 정보
     * @return 수정된 VOC 정보
     */
    @Transactional
    public VocDto update(Long vocNumber, VocDto vocDto) {
        // 기존 VOC 조회
        Voc existingVoc = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        try {
            vocChangeHistoryService.save(existingVoc);
        } catch (Exception e) {
            throw new BusinessException("error.voc.changeHistory.save");
        }


        // Entity 저장
        Voc voc = vocStruct.toEntity(vocDto);
        Voc savedVoc = vocRepository.save(voc);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocStruct.toDto(savedVoc);
    }

    /**
     * VOC 정보를 수정합니다.
     *
     * @param vocNumber VOC 번호
     * @param vocDto    수정할 VOC 정보
     * @return 수정된 VOC 정보
     */
    @Transactional
    public VocDto updateDenall(Long vocNumber, VocDto vocDto) {
        // 기존 VOC 조회
        Voc existingVoc = vocRepository.findByDenallVocNumber(vocNumber);
        if (existingVoc == null) {
            throw new BusinessException("VOC #" + vocNumber + "을(를) 찾을 수 없습니다.");
        }


        try {
            vocChangeHistoryService.save(existingVoc);
        } catch (Exception e) {
            throw new BusinessException("error.voc.changeHistory.save");
        }

        if (!vocNumber.equals(existingVoc.getDenallVocNumber())) {
            throw new BusinessException("voc.invalidVocNumber");
        }

        // 새로 들어온 VOC를 저장
        existingVoc.setVocContent(vocDto.getVocContent());
        existingVoc.setVocCategoryCode(vocDto.getVocCategoryCode());
        existingVoc.setItemCode(vocDto.getItemCode());
        // Entity 저장
        Voc savedVoc = vocRepository.save(existingVoc);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocStruct.toDto(savedVoc);
    }

    /**
     * VOC 담당자 정보를 수정합니다.
     *
     * @param vocNumber             VOC 번호
     * @param vocChargePersonNumber 수정할 VOC 담당자 번호
     * @return 수정된 VOC 정보
     */
    @Transactional
    public VocDto updateChargePerson(Long vocNumber, Long vocChargePersonNumber) {
        // 기존 VOC 조회
        Voc existingVoc = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        try {
            vocChangeHistoryService.save(existingVoc);
        } catch (Exception e) {
            throw new BusinessException("error.voc.changeHistory.save");
        }

        // VOC 담당자 정보 수정
        existingVoc.setVocChargePersonNumber(vocChargePersonNumber);

        // Entity 저장
        Voc savedVoc = vocRepository.save(existingVoc);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocStruct.toDto(savedVoc);
    }

    /**
     * VOC를 논리적으로 삭제합니다.
     *
     * @param vocNumber   VOC 번호
     * @param processorId 처리자 ID
     */
    @Transactional
    public void delete(Long vocNumber, String processorId) {
        // 기존 VOC 조회
        Voc voc = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        // VOC 논리적 삭제 처리
        voc.markAsDeleted(processorId);

        // 변경사항 저장
        vocRepository.save(voc);
    }

    /**
     * 모든 VOC 목록을 조회합니다.
     *
     * @return VOC 목록
     */
    @Transactional(readOnly = true)
    public List<VocDto> findAll() {
        List<Voc> vocList = vocRepository.findAll();
        return vocList.stream()
                .map(vocStruct::toDto)
                .collect(Collectors.toList());
    }

    /**
     * 부서 코드 리스트를 조회하는 공통 메소드
     *
     * @param departmentCode 부서 코드
     * @return 부서 코드 리스트 (하위 부서 포함)
     */
    private List<String> getDepartmentCodes(String departmentCode) {
        if (StringUtils.isEmpty(departmentCode)) {
            return new ArrayList<>();
        }
        OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode);

        if (result != null && result.getData() != null) {
            return result.getData().stream()
                    .map(org -> org.getData().getDepartmentCode())
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }

    @Transactional(readOnly = true)
    public ResultDto<VocResponseDto> search(VocRequestDto vocRequestDto, String userId, String departmentCode) {
        List<String> vocCategoryCodes = vocChargePersonService.findByEmployeeNumber(userId);
        if (vocCategoryCodes.isEmpty()) {
            return new ResultDto<>(new ArrayList<>(), 0L); // 빈 결과 반환
        }

        // 부서 코드 리스트 조회 (공통 메소드 사용), 경영기획본부면 자기 부서코드도 추가해야 본인것도 가져옴
        List<String> chargeDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocRegistererDepartmentCode());
        if (!chargeDepartmentCodes.contains(departmentCode)) chargeDepartmentCodes.add(departmentCode);

        // VOC 목록 조회
        List<VocResponseDto> vocListResult = vocQueryRepository.search(vocRequestDto, vocCategoryCodes, chargeDepartmentCodes, registerDepartmentCodes);
        vocListResult.forEach(vocResponseDto -> {
            if(vocResponseDto.getVocSaleChargeEmployeeNumber() != null && !vocResponseDto.getVocSaleChargeEmployeeNumber().isEmpty()) {
                getEmployeeSafely(vocResponseDto.getVocSaleChargeCorporationCode(), vocResponseDto.getVocSaleChargeEmployeeNumber())
                        .filter(response -> response.getData() != null)
                        .ifPresent(response -> {
                            vocResponseDto.setVocSaleChargeDepartmentName(response.getData().getDepartmentName());
                            vocResponseDto.setVocSaleChargeEmployeeName(response.getData().getEmployeeName());
                        });
            }
        });

        // 조건에 맞는 총 목록 개수 조회
        long totalCount = vocQueryRepository.count(vocRequestDto, vocCategoryCodes, chargeDepartmentCodes, registerDepartmentCodes);

        // 결과 반환
        return new ResultDto<>(vocListResult, totalCount);
    }

    private Optional<EmployeeResponseDto> getEmployeeSafely(String corporationCode, String employeeNumber) {
        try {
            EmployeeResponseDto response = commonServiceClient.getEmployee(EmployeeRequestDto.builder()
                    .corporationCode(corporationCode)
                    .employeeNumber(employeeNumber)
                    .build());
            return Optional.ofNullable(response);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    /**
     * 조건에 맞는 VOC 목록을 품목별로 그룹화하여 조회합니다.
     *
     * @param vocRequestDto 검색 조건
     * @return 그룹화된 검색 결과
     */
    @Transactional(readOnly = true)
    public GroupedResultDto<GroupedVocResponseDto> searchGroupedByItem(VocRequestDto vocRequestDto, String userId) {
        List<String> vocCategoryCodes = vocChargePersonService.findByEmployeeNumber(userId);
        if (vocCategoryCodes.isEmpty()) {
            return GroupedResultDto.empty(vocRequestDto.getPageNo(), vocRequestDto.getPageSize());
        }

        // 부서 코드 리스트 조회 (공통 메소드 사용)
        List<String> chargeDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocRegistererDepartmentCode());

        int pageSize = vocRequestDto.getPageSize();
        int pageNo = vocRequestDto.getPageNo();

        Map<String, Long> itemCodeCounts =
                vocQueryRepository.findItemCodesWithCounts(vocRequestDto, vocCategoryCodes, chargeDepartmentCodes, registerDepartmentCodes);

        // 품목 코드가 없으면 빈 결과 반환
        if (itemCodeCounts.isEmpty()) {
            return GroupedResultDto.empty(pageNo, pageSize);
        }

        // 2. 품목 코드 목록 (정렬된 상태)
        List<String> allItemCodes = new ArrayList<>(itemCodeCounts.keySet());

        // 3. 전체 항목 수 계산 (헤더 + 상세 항목)
        long totalDetailItems = itemCodeCounts.values().stream().mapToLong(Long::longValue).sum();
        long totalItems = allItemCodes.size() + totalDetailItems; // 헤더 수 + 상세 항목 수

        // 4. 페이지네이션을 위한 경계 계산 (플랫 인덱스 기준)
        int startIndex = (pageNo - 1) * pageSize;
        int endIndex = Math.min(startIndex + pageSize, (int) totalItems);

        if (startIndex >= totalItems) {
            return GroupedResultDto.empty(pageNo, pageSize);
        }

        // 5. 필요한 범위의 아이템 코드와 해당 범위의 인덱스 계산
        List<String> neededItemCodes = new ArrayList<>();
        Map<String, Integer> itemStartIndices = new HashMap<>(); // 각 아이템 코드의 시작 인덱스
        Map<String, Integer> itemEndIndices = new HashMap<>();   // 각 아이템 코드의 끝 인덱스

        int currentIndex = 0;
        for (String itemCode : allItemCodes) {
            long count = itemCodeCounts.get(itemCode);
            int groupSize = 1 + (int) count; // 헤더 + 상세 항목 수

            int groupStartIndex = currentIndex;
            int groupEndIndex = groupStartIndex + groupSize;

            // 현재 페이지 범위와 이 그룹이 겹치는지 확인
            if (groupEndIndex > startIndex && groupStartIndex < endIndex) {
                neededItemCodes.add(itemCode);
                itemStartIndices.put(itemCode, groupStartIndex);
                itemEndIndices.put(itemCode, groupEndIndex);
            }

            currentIndex += groupSize;
        }

        // 6. 필요한 품목 코드에 대한 VOC 데이터만 조회
        List<VocResponseDto> vocData = vocQueryRepository.findVocsByItemCodes(vocRequestDto, neededItemCodes, vocCategoryCodes, chargeDepartmentCodes, registerDepartmentCodes);

        // 영업담당자 정보 조회
        vocData.forEach(vocResponseDto -> {
            if(vocResponseDto.getVocSaleChargeEmployeeNumber() != null && !vocResponseDto.getVocSaleChargeEmployeeNumber().isEmpty()) {
                getEmployeeSafely(vocResponseDto.getVocSaleChargeCorporationCode(), vocResponseDto.getVocSaleChargeEmployeeNumber())
                        .filter(response -> response.getData() != null)
                        .ifPresent(response -> {
                            vocResponseDto.setVocSaleChargeDepartmentName(response.getData().getDepartmentName());
                            vocResponseDto.setVocSaleChargeEmployeeName(response.getData().getEmployeeName());
                        });
            }
        });

        // 7. 품목별로 데이터 그룹화
        Map<String, List<VocResponseDto>> vocByItemCode = vocData.stream()
                .collect(Collectors.groupingBy(VocResponseDto::getItemCode));

        // 8. 페이지에 해당하는 결과 생성
        List<GroupedVocResponseDto> pagedResults = neededItemCodes.stream()
                .flatMap(itemCode -> {
                    int groupStartIndex = itemStartIndices.get(itemCode);
                    List<VocResponseDto> items = vocByItemCode.getOrDefault(itemCode, Collections.emptyList());

                    // 스트림 결과를 담을 리스트 (선택적 헤더 + 필터링된 상세 항목)
                    Stream<GroupedVocResponseDto> headerStream = (groupStartIndex >= startIndex && groupStartIndex < endIndex)
                            ? Stream.of(GroupedVocResponseDto.createHeader(
                            itemCode,
                            itemCodeMappingService.getItemNameByCode(itemCode),
                            (long) items.size()))
                            : Stream.empty();

                    // 상세 항목 스트림 생성
                    Stream<GroupedVocResponseDto> detailsStream = IntStream.range(0, items.size())
                            .mapToObj(i -> new AbstractMap.SimpleEntry<>(groupStartIndex + 1 + i, items.get(i)))
                            .filter(entry -> entry.getKey() >= startIndex && entry.getKey() < endIndex)
                            .map(entry -> GroupedVocResponseDto.createDetail(entry.getValue()));

                    // 헤더와 상세 항목 스트림 연결
                    return Stream.concat(headerStream, detailsStream);
                })
                .collect(Collectors.toList());

        // 9. 결과 반환
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);

        return new GroupedResultDto<>(
                pagedResults,
                pageNo,
                pageSize,
                totalPages,
                totalItems
        );
    }

    /**
     * 조건에 맞는 VOC 목록을 부서별로 그룹화하여 조회합니다.
     *
     * @param vocRequestDto 검색 조건
     * @return 그룹화된 검색 결과
     */
    @Transactional(readOnly = true)
    public GroupedResultDto<GroupedVocResponseDto> searchGroupedByDept(VocRequestDto vocRequestDto, String userId) {
        List<String> vocCategoryCodes = vocChargePersonService.findByEmployeeNumber(userId);
        if (vocCategoryCodes.isEmpty()) {
            return GroupedResultDto.empty(vocRequestDto.getPageNo(), vocRequestDto.getPageSize());
        }

        // 부서 코드 리스트 조회 (공통 메소드 사용)
        List<String> chargeDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(vocRequestDto.getVocRegistererDepartmentCode());

        int pageSize = vocRequestDto.getPageSize();
        int pageNo = vocRequestDto.getPageNo();

        // 그룹핑 타입 (등록자 부서 또는 처리담당자 부서)
        boolean isRegistererGroup = GroupType.REGISTER.getGroupCode().equals(vocRequestDto.getGroupByType());

        // 1. 필터 조건에 맞는 부서 코드와 각 부서의 VOC 건수를 한 번에 조회 (캐싱 적용)
        String countsCacheKey = VocPaginationUtil.generateCacheKey(vocRequestDto,
                isRegistererGroup ? GroupType.REGISTER.getCountCode() : GroupType.CHARGER.getCountCode());

        // 그룹핑 타입에 따라 다른 메서드 호출
        Map<String, Long> deptCodeCounts;
        if (isRegistererGroup) {
            deptCodeCounts =
                    vocQueryRepository.findRegistererDeptCodesWithCounts(vocRequestDto, vocCategoryCodes, chargeDepartmentCodes);
        } else {
            deptCodeCounts =
                    vocQueryRepository.findChargePersonDeptCodesWithCounts(vocRequestDto, vocCategoryCodes, registerDepartmentCodes);
        }

        if (deptCodeCounts.isEmpty()) {
            return GroupedResultDto.empty(pageNo, pageSize);
        }

        // 2. 부서 코드 목록 (카운트 기준 내림차순 정렬)
        List<String> allDeptCodes = new ArrayList<>(deptCodeCounts.keySet());
        allDeptCodes.sort((a, b) -> Long.compare(deptCodeCounts.get(b), deptCodeCounts.get(a))); // 건수 기준 내림차순 정렬

        // 3. 전체 항목 수 계산 (헤더 + 상세 항목)
        long totalDetailItems = deptCodeCounts.values().stream().mapToLong(Long::longValue).sum();
        long totalItems = allDeptCodes.size() + totalDetailItems; // 헤더 수 + 상세 항목 수

        // 4. 페이지네이션을 위한 경계 계산 (플랫 인덱스 기준)
        int startIndex = (pageNo - 1) * pageSize;
        int endIndex = Math.min(startIndex + pageSize, (int) totalItems);

        if (startIndex >= totalItems) {
            return GroupedResultDto.empty(pageNo, pageSize);
        }

        // 5. 필요한 범위의 부서 코드와 해당 범위의 인덱스 계산
        List<String> neededDeptCodes = new ArrayList<>();
        Map<String, Integer> deptStartIndices = new HashMap<>(); // 각 부서 코드의 시작 인덱스
        Map<String, Integer> deptEndIndices = new HashMap<>();   // 각 부서 코드의 끝 인덱스

        int currentIndex = 0;
        for (String deptCode : allDeptCodes) {
            long count = deptCodeCounts.get(deptCode);
            int groupSize = 1 + (int) count; // 헤더 + 상세 항목 수

            int groupStartIndex = currentIndex;
            int groupEndIndex = groupStartIndex + groupSize;

            // 현재 페이지 범위와 이 그룹이 겹치는지 확인
            if (groupEndIndex > startIndex && groupStartIndex < endIndex) {
                neededDeptCodes.add(deptCode);
                deptStartIndices.put(deptCode, groupStartIndex);
                deptEndIndices.put(deptCode, groupEndIndex);
            }

            currentIndex += groupSize;
        }

        // 6. 필요한 부서 코드에 대한 VOC 데이터만 조회
        List<VocResponseDto> vocData;
        if (isRegistererGroup) {
            vocData = vocQueryRepository.findVocsByRegistererDeptCodes(vocRequestDto, neededDeptCodes, vocCategoryCodes, chargeDepartmentCodes);
        } else {
            vocData = vocQueryRepository.findVocsByChargePersonDeptCodes(vocRequestDto, neededDeptCodes, vocCategoryCodes, registerDepartmentCodes);
        }

        // 등록자 정보 조회
        vocData.forEach(vocResponseDto -> {
            if(vocResponseDto.getRegistererEmployeeNumber() != null && !vocResponseDto.getRegistererEmployeeNumber().isEmpty()) {
                getEmployeeSafely(vocResponseDto.getRegistererCorporationCode(), vocResponseDto.getRegistererEmployeeNumber())
                        .filter(response -> response.getData() != null)
                        .ifPresent(response -> {
                            vocResponseDto.setVocSaleChargeDepartmentName(response.getData().getDepartmentName());
                            vocResponseDto.setVocSaleChargeEmployeeName(response.getData().getEmployeeName());
                        });
            }
        });

        // 7. 부서별로 데이터 그룹화
        Map<String, List<VocResponseDto>> vocByDeptCode = vocData.stream()
                .collect(Collectors.groupingBy(VocResponseDto::getDepartmentCode));

        // 8. 부서 정보 조회
        Map<String, String> deptNameMap = new HashMap<>();
        for (String deptCode : neededDeptCodes) {
            try {
                // commonServiceClient를 사용하여 부서 정보 조회
                ApiResponse<DepartmentDto> response = commonServiceClient.getDepartmentInfo("KR1", deptCode);

                if (response.getData() != null && response.getData().getUpDepartmentCode() != null) {
                    // upDepartmentCode를 부서명으로 사용
                    deptNameMap.put(deptCode, response.getData().getUpDepartmentCode());
                } else {
                    // 조회 실패 시 기본값 사용
                    deptNameMap.put(deptCode, deptCode);
                }
            } catch (Exception e) {
                // 예외 발생 시 기본값 사용
                deptNameMap.put(deptCode, deptCode);
            }
        }

        // 9. 페이지에 해당하는 결과 생성
        List<GroupedVocResponseDto> pagedResults = neededDeptCodes.stream()
                .flatMap(deptCode -> {
                    int groupStartIndex = deptStartIndices.get(deptCode);
                    List<VocResponseDto> items = vocByDeptCode.getOrDefault(deptCode, Collections.emptyList());

                    // 부서명 가져오기
                    String deptName = deptNameMap.getOrDefault(deptCode, deptCode);

                    // 스트림 결과를 담을 리스트 (선택적 헤더 + 필터링된 상세 항목)
                    Stream<GroupedVocResponseDto> headerStream = (groupStartIndex >= startIndex && groupStartIndex < endIndex)
                            ? Stream.of(GroupedVocResponseDto.createHeader(
                            deptCode,
                            deptName, // 부서명 (DepartmentDto의 upDepartmentCode)
                            (long) items.size()))
                            : Stream.empty();

                    // 상세 항목 스트림 생성
                    Stream<GroupedVocResponseDto> detailsStream = IntStream.range(0, items.size())
                            .mapToObj(i -> new AbstractMap.SimpleEntry<>(groupStartIndex + 1 + i, items.get(i)))
                            .filter(entry -> entry.getKey() >= startIndex && entry.getKey() < endIndex)
                            .map(entry -> GroupedVocResponseDto.createDetail(entry.getValue()));

                    // 헤더와 상세 항목 스트림 연결
                    return Stream.concat(headerStream, detailsStream);
                })
                .collect(Collectors.toList());

        // 10. 결과 반환
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);

        return new GroupedResultDto<>(
                pagedResults,
                pageNo,
                pageSize,
                totalPages,
                totalItems
        );
    }

    /**
     * VOC를 분류합니다.
     *
     * @param vocNumber VOC 번호
     * @param vocDto    수정할 VOC 정보
     * @return 수정된 VOC 정보
     */
    @Transactional
    public VocDto classifyVoc(Long vocNumber, VocDto vocDto) {
        // 기존 VOC 조회
        Voc existingVoc = vocRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("voc.notFound"));

        try {
            vocChangeHistoryService.save(existingVoc);
        } catch (Exception e) {
            throw new BusinessException("error.voc.changeHistory.save");
        }

        existingVoc.setVocCategoryCode(vocDto.getVocCategoryCode());
        existingVoc.setVocChargePersonNumber(vocDto.getVocChargePersonNumber());
        existingVoc.setItemCode(vocDto.getItemCode());
        existingVoc.setVocDetailsItemName(vocDto.getVocDetailsItemName());
        existingVoc.setItemCode(vocDto.getItemCode());

        // Entity 저장
        Voc savedVoc = vocRepository.save(existingVoc);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocStruct.toDto(savedVoc);
    }

}
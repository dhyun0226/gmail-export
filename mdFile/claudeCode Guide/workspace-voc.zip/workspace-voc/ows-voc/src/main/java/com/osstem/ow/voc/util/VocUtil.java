package com.osstem.ow.voc.util;

public final class VocUtil {

    /**
     * 생성자를 private으로 선언하여 인스턴스화 방지
     */
    private VocUtil() {
        throw new AssertionError("유틸리티 클래스는 인스턴스화할 수 없습니다.");
    }

    /**
     * VOC 등록 상세 구분 코드에서 중간 부분을 추출합니다.
     * 예: "D006_QNA_000" -> "QNA"
     *
     * @param detailCode 등록 상세 구분 코드
     * @return 추출된 중간 부분 문자열, 분리할 수 없는 경우 원래 문자열 반환
     */
    public static String extractDetailCodeMiddlePart(String detailCode) {
        if (detailCode == null || detailCode.isEmpty()) {
            return "";
        }

        String[] parts = detailCode.split("_");
        if (parts.length < 2) {
            return detailCode; // 언더스코어가 없으면 원래 문자열 반환
        }

        return parts[1]; // 중간 부분 반환
    }
}
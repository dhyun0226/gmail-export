package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.entity.VocAnswerDetail;
import com.osstem.ow.voc.exception.BusinessException;
import com.osstem.ow.voc.feign.TxmServiceClient;
import com.osstem.ow.voc.feign.VocAnswerServiceClient;
import com.osstem.ow.voc.model.request.VocAnswerRequestDto;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import com.osstem.ow.voc.model.table.VocDto;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import com.osstem.ow.voc.model.txm.TxmFileSaveResponse;
import com.osstem.ow.voc.repository.VocAnswerDetailRepository;
import com.osstem.ow.voc.repository.VocChangeHistoryRepository;
import com.osstem.ow.voc.structMapper.VocAnswerDetailStruct;
import com.osstem.ow.voc.structMapper.VocChangeHistoryStruct;
import com.osstem.ow.voc.structMapper.VocStruct;
import com.osstem.ow.voc.util.FileUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VocAnswerDetailService {

    private final VocService vocService;
    private final VocAnswerDetailRepository vocAnswerDetailRepository;
    private final VocChangeHistoryRepository vocChangeHistoryRepository;
    private final VocAnswerDetailStruct vocAnswerDetailStruct;
    private final VocAnswerServiceClient vocAnswerServiceClient;
    private final VocStruct vocStruct;
    private final TxmServiceClient txmServiceClient;
    private final VocChangeHistoryStruct vocChangeHistoryStruct;
    private final VocChargePersonService vocChargePersonService;


    /**
     * VOC 번호로 답변을 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return VOC 답변 정보
     */
    @Transactional(readOnly = true)
    public VocAnswerDetailDto findById(Long vocNumber) {
        VocAnswerDetail vocAnswerDetail = vocAnswerDetailRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("vocAnswerDetail.notFound"));
        return vocAnswerDetailStruct.toDto(vocAnswerDetail);
    }

    /**
     * VOC 답변을 등록합니다.
     *
     * @param vocAnswerDetailDto VOC 답변 정보
     * @return 등록된 VOC 답변 정보
     */
    @Transactional
    public VocAnswerDetailDto create(VocAnswerDetailDto vocAnswerDetailDto) {
        // VOC 존재 여부 확인
        VocDto vocDto = vocService.findById(vocAnswerDetailDto.getVocNumber());
        if (vocDto == null) {
            throw new BusinessException("voc.notFound");
        }

        Voc voc = vocStruct.toEntity(vocDto);

        // VOC 답변 등록 시 VOC 상태 변경
        vocDto.setVocStateCode("03");   // 답변완료

        vocService.update(vocDto.getVocNumber(), vocDto);


        // DTO를 Entity로 변환
        VocAnswerDetail vocAnswerDetail = vocAnswerDetailStruct.toEntity(vocAnswerDetailDto);

        // 답변시간 설정
        vocAnswerDetail.setVocAnswerDateTime(LocalDateTime.now());


        // 파일 저장 로직
        if (vocAnswerDetailDto.getFileList() != null && !vocAnswerDetailDto.getFileList().isEmpty()
                && vocAnswerDetail.getVocNumber() != null) {
            List<TxmFileSaveRequest> fileList = FileUtil.prepareVocAnswerFiles(
                    vocAnswerDetailDto.getFileList(),
                    vocAnswerDetail.getVocNumber().toString()
            );

            TxmFileSaveResponse txmFileSaveResponse = txmServiceClient.saveFile(fileList);

            if (txmFileSaveResponse.getStatus() != 200) {
                throw new BusinessException("error.file.save");
            }

            vocAnswerDetail.setFileId(vocAnswerDetail.getVocNumber().toString());
        }

        //vocDto를 vocAnswerRequestDto로 변환
        VocAnswerRequestDto vocAnswerRequestDto = vocAnswerDetailStruct.toVocAnswerRequestDto(vocAnswerDetail);

        //답변자 정보 설정
        vocAnswerRequestDto.setVocNumber(vocDto.getDenallVocNumber());
        vocAnswerRequestDto.setAnswererCorporationCode(vocAnswerDetailDto.getAnswererCorporationCode());
        vocAnswerRequestDto.setAnswererDepartmentCode(vocAnswerDetailDto.getAnswererDepartmentCode());
        vocAnswerRequestDto.setAnswererEmployeeNumber(vocAnswerDetailDto.getAnswererEmployeeNumber());

        try {
            vocAnswerServiceClient.createVocAnswer(vocAnswerRequestDto);
        } catch (Exception e) {
            throw new BusinessException("error.voc.answer.save");
        }

        // Entity 저장
        VocAnswerDetail savedVocAnswerDetail = vocAnswerDetailRepository.save(vocAnswerDetail);
        // 저장된 Entity를 DTO로 변환하여 반환
        VocAnswerDetailDto dto = vocAnswerDetailStruct.toDto(savedVocAnswerDetail);
//
//        if(VocUtil.extractDetailCodeMiddlePart(vocAnswerDetailDto.getVocCategoryCode()).equals(TaskType.QNA.getTaskCode())) {
//            qnaServiceClient.create(QnaAnswerDetailDto.composeVocAnswerEvent(vocDto.getDenallVocNumber(),dto,vocChargePersonService.findById(vocDto.getVocChargePersonNumber())));
//        } else if(VocUtil.extractDetailCodeMiddlePart(vocAnswerDetailDto.getVocCategoryCode()).equals(TaskType.INQUIRY.getTaskCode())) {
//            individualInquiryServiceClient.create(IndividualInquiryAnswerDto.composeVocAnswerEvent(vocDto.getDenallVocNumber(),dto,vocChargePersonService.findById(vocDto.getVocChargePersonNumber())));
//        }

        return dto;
    }

    /**
     * VOC 답변을 수정합니다.
     *
     * @param vocNumber          VOC 번호
     * @param vocAnswerDetailDto 수정할 VOC 답변 정보
     * @return 수정된 VOC 답변 정보
     */
    @Transactional
    public VocAnswerDetailDto update(Long vocNumber, VocAnswerDetailDto vocAnswerDetailDto) {
        // 기존 VOC 답변 조회
        VocAnswerDetail existingVocAnswerDetail = vocAnswerDetailRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("vocAnswerDetail.notFound"));

        // DTO를 Entity로 변환하여 업데이트
        VocAnswerDetail updatedVocAnswerDetail = vocAnswerDetailStruct.toEntity(vocAnswerDetailDto);

        // 중요 필드 검증 및 업데이트 처리
        if (!vocNumber.equals(updatedVocAnswerDetail.getVocNumber())) {
            throw new BusinessException("vocAnswerDetail.invalidVocNumber");
        }

        // Entity 저장
        VocAnswerDetail savedVocAnswerDetail = vocAnswerDetailRepository.save(updatedVocAnswerDetail);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocAnswerDetailStruct.toDto(savedVocAnswerDetail);
    }

    /**
     * VOC 답변을 삭제합니다.
     *
     * @param vocNumber VOC 번호
     */
    @Transactional
    public void delete(Long vocNumber) {
        // 기존 VOC 답변 조회
        VocAnswerDetail vocAnswerDetail = vocAnswerDetailRepository.findById(vocNumber)
                .orElseThrow(() -> new BusinessException("vocAnswerDetail.notFound"));

        // VOC 답변 삭제
        vocAnswerDetailRepository.delete(vocAnswerDetail);
    }
}
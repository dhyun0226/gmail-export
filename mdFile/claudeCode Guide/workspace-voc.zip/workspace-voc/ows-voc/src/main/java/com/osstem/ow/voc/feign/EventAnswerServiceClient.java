package com.osstem.ow.voc.feign;

import com.osstem.ow.voc.model.customer.EventAnswerRequestDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "eventAnswerServiceClient", url = "${voc.api.occ.root.uri}")
public interface EventAnswerServiceClient {

    @DeleteMapping("/event-answers")
    void deleteEvent(@RequestBody EventAnswerRequestDto eventAnswerRequestDto);

}
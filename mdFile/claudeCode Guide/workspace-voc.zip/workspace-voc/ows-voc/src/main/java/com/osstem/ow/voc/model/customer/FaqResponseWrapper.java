package com.osstem.ow.voc.model.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "FAQ 응답 래퍼 DTO")
public class FaqResponseWrapper {

    @Schema(description = "FAQ 데이터 목록")
    private List<FaqResponseDto> data;

    @Schema(description = "총 개수", example = "27")
    private int totalCount;
}
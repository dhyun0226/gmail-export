package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.Voc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VocRepository extends JpaRepository<Voc, Long> {
    Voc findByDenallVocNumber(Long denallVocNumber);
}
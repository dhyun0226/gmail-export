package com.osstem.ow.voc.model.request;

import com.osstem.ow.voc.model.base.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Getter
@NoArgsConstructor
@Schema(description = "VOC 변경 이력 요청 DTO")
public class VocChangeHistoryRequestDto implements PagingDto {

    @Schema(description = "페이지 번호")
    private Integer pageNo;

    @Schema(description = "페이지 크기")
    private Integer pageSize;

    @NotNull
    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "시작 일자")
    private LocalDate startDate;

    @Schema(description = "종료 일자")
    private LocalDate endDate;
}
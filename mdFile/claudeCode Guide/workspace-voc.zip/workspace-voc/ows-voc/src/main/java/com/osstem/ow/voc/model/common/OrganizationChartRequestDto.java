package com.osstem.ow.voc.model.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OrganizationChartRequestDto {

    @Schema(description = "회사코드")
    private String corpCode;

    @Schema(description = "부서코드")
    private String deptCode;

    private boolean root;

    private boolean hierarchical;

    private boolean showExpandingEmployee;

    private List<String> expandingDeptCode;

}

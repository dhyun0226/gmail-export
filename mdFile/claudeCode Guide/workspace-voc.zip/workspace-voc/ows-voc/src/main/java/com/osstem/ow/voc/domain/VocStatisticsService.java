package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.model.common.OrganizationChartRequestDto;
import com.osstem.ow.voc.model.common.OrganizationResponseDto;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import com.osstem.ow.voc.model.statistic.OrganizationVocStatisticsDto;
import com.osstem.ow.voc.repository.VocStatisticsQueryRepository;
import com.osstem.ow.voc.util.VocStatisticsUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VocStatisticsService {

    private final VocStatisticsQueryRepository vocStatisticsQueryRepository;
    private final CommonServiceClient commonServiceClient;

    /**
     * 조직도 구조 데이터 조회 및 전처리
     *
     * @param condition 검색 조건
     * @return 전처리된 조직도 구조 데이터
     */
    private List<OrganizationVocStatisticsDto> getOrganizationStructure(VocStatisticsRequestDto condition) {
        // 기본값 설정
        String corporationCode = StringUtils.hasText(condition.getCorporationCode())
                ? condition.getCorporationCode() : "KR1";
        String rootDepartmentCode = StringUtils.hasText(condition.getRootDepartmentCode())
                ? condition.getRootDepartmentCode() : "O000000914";

        // 외부 API 호출
        OrganizationResponseDto response = commonServiceClient.getDepartment(corporationCode,rootDepartmentCode);

        List<OrganizationVocStatisticsDto> result = (List<OrganizationVocStatisticsDto>) response.getData();

        return result;
    }

    /**
     * 부서 코드 리스트를 조회하는 공통 메소드
     *
     * @param departmentCode 부서 코드
     * @return 부서 코드 리스트 (하위 부서 포함)
     */
    private List<String> getDepartmentCodes(String departmentCode) {
        if (org.apache.commons.lang3.StringUtils.isEmpty(departmentCode)) {
            return new ArrayList<>();
        }
        OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode);

        if (result != null && result.getData() != null) {
            return result.getData().stream()
                    .map(org -> org.getData().getDepartmentCode())
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }

    /**
     * parentId가 특정 값인 항목들의 parentId를 새로운 값으로 변경
     *
     * @param list 변경할 리스트
     * @param oldParentId 이전 parentId 값
     * @param newParentId 새로운 parentId 값
     */
    private void updateParentIds(List<OrganizationVocStatisticsDto> list, String oldParentId, String newParentId) {
        if (list == null || list.isEmpty()) {
            return;
        }

        // 현재 레벨의 노드들 처리
        list.stream()
                .filter(node -> oldParentId.equals(node.getParentId()))
                .forEach(node -> node.setParentId(newParentId));

        // 하위 항목들 재귀적으로 처리
        list.stream()
                .filter(node -> node.getItems() != null && !node.getItems().isEmpty())
                .forEach(node -> updateParentIds(node.getItems(), oldParentId, newParentId));
    }

    // ===== VOC 등록자 기준 통계 메소드 =====

    /**
     * 일별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 조건에 따른 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics;

        // 고급 조건이 있는 경우 조건부 조회 수행
        departmentStatistics = vocStatisticsQueryRepository.getVocStatisticsByDayWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(), condition.getVocCategoryCode(), condition.getItemCode()
                ,chargeDepartmentCodes, registerDepartmentCodes
        );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 주별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocStatisticsByWeek(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 주별 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository.getVocStatisticsByWeekWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(), condition.getVocCategoryCode(), condition.getItemCode()
                ,chargeDepartmentCodes, registerDepartmentCodes
        );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 월별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocStatisticsByMonth(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 조건에 따른 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics;

        // 고급 조건이 있는 경우 조건부 조회 수행
        departmentStatistics = vocStatisticsQueryRepository.getVocStatisticsByMonthWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(), condition.getVocCategoryCode(), condition.getItemCode()
                ,chargeDepartmentCodes, registerDepartmentCodes
        );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 연도별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocStatisticsByYear(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 조건에 따른 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics;

        // 고급 조건이 있는 경우 조건부 조회 수행
        departmentStatistics = vocStatisticsQueryRepository.getVocStatisticsByYearWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(), condition.getVocCategoryCode(), condition.getItemCode()
                ,chargeDepartmentCodes, registerDepartmentCodes
        );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    // ===== VOC 담당자 기준 통계 메소드 =====

    /**
     * 일별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByDay(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 담당자 부서별 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository
                .getVocChargePersonStatisticsByDayWithConditions(
                        condition.getStartDate(),
                        condition.getEndDate(),
                        condition.getVocStateCode(),
                        condition.getVocCategoryCode(),
                        condition.getItemCode(),
                        chargeDepartmentCodes,
                        registerDepartmentCodes
                );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 주별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByWeek(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 담당자 부서별 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository
                .getVocChargePersonStatisticsByWeekWithConditions(
                        condition.getStartDate(),
                        condition.getEndDate(),
                        condition.getVocStateCode(),
                        condition.getVocCategoryCode(),
                        condition.getItemCode(),
                        chargeDepartmentCodes,
                        registerDepartmentCodes
                );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 월별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByMonth(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 담당자 부서별 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository
                .getVocChargePersonStatisticsByMonthWithConditions(
                        condition.getStartDate(),
                        condition.getEndDate(),
                        condition.getVocStateCode(),
                        condition.getVocCategoryCode(),
                        condition.getItemCode(),
                        chargeDepartmentCodes,
                        registerDepartmentCodes
                );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * 연별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 노드 리스트
     */
    public List<OrganizationVocStatisticsDto> getVocChargePersonStatisticsByYear(VocStatisticsRequestDto condition) {
        // 조직도 구조 데이터 조회 및 전처리
        List<OrganizationVocStatisticsDto> organizationStructure = getOrganizationStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 담당자 부서별 통계 조회
        Map<String, Map<String, Integer>> departmentStatistics = vocStatisticsQueryRepository
                .getVocChargePersonStatisticsByYearWithConditions(
                        condition.getStartDate(),
                        condition.getEndDate(),
                        condition.getVocStateCode(),
                        condition.getVocCategoryCode(),
                        condition.getItemCode(),
                        chargeDepartmentCodes,
                        registerDepartmentCodes
                );

        // 조직도에 통계 정보 추가
        VocStatisticsUtil.enrichOrganizationStructureWithStatistics(organizationStructure, departmentStatistics);

        // total 값 기준으로 내림차순 정렬
        return sortByTotalDesc(organizationStructure);
    }

    /**
     * total 값을 기준으로 내림차순 정렬
     *
     * @param list 정렬할 리스트
     * @return 정렬된 리스트
     */
    private List<OrganizationVocStatisticsDto> sortByTotalDesc(List<OrganizationVocStatisticsDto> list) {
        if (list == null || list.isEmpty()) {
            return list;
        }

        // total 값 기준으로 내림차순 정렬
        list.sort((o1, o2) -> {
            Integer total1 = Optional.ofNullable(o1.getStatistics())
                    .map(stats -> stats.getOrDefault("total", 0))
                    .orElse(0);

            Integer total2 = Optional.ofNullable(o2.getStatistics())
                    .map(stats -> stats.getOrDefault("total", 0))
                    .orElse(0);

            return total2.compareTo(total1);
        });

        // 각 노드의 하위 항목들도 재귀적으로 정렬
        list.forEach(this::sortChildrenByTotalDesc);

        return list;
    }

    /**
     * 노드의 하위 항목들을 재귀적으로 total 값 기준으로 내림차순 정렬
     *
     * @param node 정렬할 노드
     */
    private void sortChildrenByTotalDesc(OrganizationVocStatisticsDto node) {
        if (node.getItems() == null || node.getItems().isEmpty()) {
            return;
        }

        // 하위 항목들 정렬
        node.getItems().sort((o1, o2) -> {
            Integer total1 = Optional.ofNullable(o1.getStatistics())
                    .map(stats -> stats.getOrDefault("total", 0))
                    .orElse(0);

            Integer total2 = Optional.ofNullable(o2.getStatistics())
                    .map(stats -> stats.getOrDefault("total", 0))
                    .orElse(0);

            return total2.compareTo(total1);
        });

        // 각 하위 항목의 하위 항목들도 재귀적으로 정렬
        node.getItems().forEach(this::sortChildrenByTotalDesc);
    }
}
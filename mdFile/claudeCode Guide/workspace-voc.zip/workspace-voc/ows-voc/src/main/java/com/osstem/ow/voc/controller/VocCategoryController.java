package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocCategoryService;
import com.osstem.ow.voc.model.response.TaskCategoryResponseDto;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.model.table.VocCategoryDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vocCategories")
@RequiredArgsConstructor
public class VocCategoryController {

    private final VocCategoryService vocCategoryService;

    /**
     * 모든 VOC 카테고리 조회
     */
    @GetMapping
    public ResponseEntity<List<VocCategoryDto>> getAllVocCategoryCodes() {
        List<VocCategoryDto> vocCategoryCodes = vocCategoryService.getAllVocCategories();
        return ResponseEntity.ok(vocCategoryCodes);
    }

    /**
     * 특정 VOC 카테고리 조회
     */
    @GetMapping("/{vocCategoryCode}")
    public ResponseEntity<VocCategoryDto> getVocCategoryById(@PathVariable String vocCategoryCode) {
        VocCategoryDto vocCategoryDto = vocCategoryService.getVocCategoryById(vocCategoryCode);
        return ResponseEntity.ok(vocCategoryDto);
    }

    /**
     * 최상위 카테고리 목록 조회
     */
    @GetMapping("/root")
    public ResponseEntity<List<VocCategoryDto>> getRootCategories( @RequestParam(required = false) Character openYn) {
        List<VocCategoryDto> rootCategories = vocCategoryService.getRootCategoriesByOpenYn(openYn);
        return ResponseEntity.ok(rootCategories);
    }

    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     * @param categoryCode 카테고리 코드
     * @return 해당 카테고리의 최상위 카테고리
     */
    @GetMapping("/{categoryCode}/root")
    public ResponseEntity<VocCategoryDto> getRootCategoryByCategoryCode(
            @PathVariable String categoryCode) {
        VocCategoryDto rootCategory = vocCategoryService.findRootCategory(categoryCode);
        if (rootCategory != null) {
            return ResponseEntity.ok(rootCategory);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
     */
    @GetMapping("/{parentCategoryCode}/children")
    public ResponseEntity<List<VocCategoryDto>> getChildCategories(@PathVariable String parentCategoryCode) {
        List<VocCategoryDto> childCategories = vocCategoryService.getChildCategories(parentCategoryCode);
        return ResponseEntity.ok(childCategories);
    }

    /**
     * 2레벨 카테고리 목록 조회 (distinct 적용)
     */
    @GetMapping("/second-level")
    public ResponseEntity<List<TaskCategoryResponseDto>> getSecondLevelCategories(
            @RequestParam(required = false) Character openYn) {
        List<TaskCategoryResponseDto> categories = vocCategoryService.getMatchingTaskCategories(openYn);
        return ResponseEntity.ok(categories);
    }

    /**
     * taskName으로 해당하는 2레벨 카테고리가 존재하는 1레벨 카테고리들을 조회
     * @param taskName 작업명
     * @param openYn 공개 여부 (기본값: 'Y')
     * @return 1레벨 카테고리 리스트
     */
    @GetMapping("/root/by-task")
    public ResponseEntity<List<VocCategoryDto>> getRootCategoriesByTaskName(
            @RequestParam String taskName,
            @RequestParam(defaultValue = "Y") Character openYn) {

        try {
            List<VocCategoryDto> categories = vocCategoryService
                    .getRootCategoriesByTaskNameAndOpenYn(taskName, openYn);
            return ResponseEntity.ok(categories);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
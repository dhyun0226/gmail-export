package com.osstem.ow.voc.model.statistic;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationVocStatisticsDto {
    private String key;
    private String parentId;
    private String display;
    private List<OrganizationVocStatisticsDto> items;
    private boolean expanded;
    private boolean internal;
    private boolean leaf;
    private int degree;
    private OrganizationData data;

    // 통계 데이터를 저장하는 맵
    // 일별 통계: d1, d2, ..., d31
    // 월별 통계: m1, m2, ..., m12
    // 시간대별 통계: h0, h1, ..., h23
    private Map<String, Integer> statistics = new HashMap<>();
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrganizationData {
        @JsonProperty("corpCode")
        private String corporationCode;
        @JsonProperty("deptCode")
        private String departmentCode;
        @JsonProperty("deptName")
        private String departmentName;
        @JsonProperty("empNo")
        private String employeeNumber;
        @JsonProperty("empName")
        private String employeeName;
        private String dutyCode;
        private String dutyName;
        private String gradeCode;
        private String gradeName;
        @JsonProperty("upDeptCd")
        private String upperDepartmentCode;
        private int subDepartmentCount;
        private int employeeCount;
    }

    /**
     * 특정 통계 키에 대한 카운트 증가
     *
     * @param key 통계 키 (d1, m2, h12 등)
     * @param count 추가할 카운트
     */
    public void addStatistic(String key, int count) {
        statistics.put(key, statistics.getOrDefault(key, 0) + count);
    }

    /**
     * 하위 부서 통계를 상위 부서에 집계
     *
     * @param child 하위 부서 통계
     */
    public void aggregateChildStatistics(OrganizationVocStatisticsDto child) {
        for (Map.Entry<String, Integer> entry : child.getStatistics().entrySet()) {
            addStatistic(entry.getKey(), entry.getValue());
        }
    }
}
package com.osstem.ow.voc.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Embeddable
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocChangeHistoryId {

    @Column(name = "VOC_NO", nullable = false, updatable = false)
    private Long vocNumber;

    @Column(name = "VOC_CHG_DTM", nullable = false, updatable = false)
    private LocalDateTime vocChangeDateTime;

    public VocChangeHistoryId(Long vocNumber, LocalDateTime vocChangeDateTime) {
        this.vocNumber = vocNumber;
        this.vocChangeDateTime = vocChangeDateTime;
    }
}
package com.osstem.ow.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "개인문의 DTO")
public class IndividualInquiryDto extends BaseDto {

    @Schema(description = "개인문의번호")
    private Long individualInquiryNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "개인문의등록상세구분코드")
    private String serviceCategoryCode;

    @Size(max = 90)
    @Schema(description = "품목코드")
    private String itemCode;

    @NotBlank
    @Size(max = 1)
    @Schema(description = "회원여부")
    private String memberYn;

    @Size(max = 20)
    @Schema(description = "작성자회원ID")
    private String writerMemberId;

    @Size(max = 50)
    @Schema(description = "VOC작성자명")
    private String vocWriterName;

    @Email
    @Size(max = 50)
    @Schema(description = "작성자이메일주소")
    private String writerEmailAddress;

    @Size(max = 20)
    @Schema(description = "작성자전화번호")
    private String writerTelephoneNumber;

    @Size(max = 20)
    @Schema(description = "작성자휴대전화번호")
    private String writerHandPhoneNumber;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "개인문의제목")
    private String individualInquiryTitle;

    @NotBlank
    @Size(max = 2000)
    @Schema(description = "개인문의내용")
    private String individualInquiryContent;

    @Schema(description = "개인문의등록일시")
    private LocalDateTime individualInquiryRegistrationDatetime;

    @Schema(description = "개인문의변경일시")
    private LocalDateTime individualInquiryChangeDatetime;

    @NotBlank
    @Size(max = 1)
    @Schema(description = "개인정보수집이용약관동의여부")
    private String individualInformationCollectionTermsOfUseAgreementYesOrNo;

    @Size(max = 50)
    @Schema(description = "파일ID")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<TxmFileSaveRequest> fileList;

}
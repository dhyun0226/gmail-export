package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.QnaServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.QnaAnswerDetailDto;
import com.osstem.ow.voc.model.event.QnaDto;
import com.osstem.ow.voc.model.request.QnaRequestDto;
import com.osstem.ow.voc.model.response.QnaResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class QnaService {

    private final QnaServiceClient qnaServiceClient;

    public QnaAnswerDetailDto createQnaAnswer(QnaAnswerDetailDto qnaAnswerDetailDto) {
        return qnaServiceClient.createQnaAnswer(qnaAnswerDetailDto);
    }

    public ResultDto<QnaResponseDto> getQnaList(QnaRequestDto requestDto, String processStatus) {
        return qnaServiceClient.getQnaList(requestDto, processStatus);
    }

    public QnaResponseDto getQnaById(Long qnaNumber, String channelCode, String serviceCategoryCode, String userId, String corporationCode) {
        return qnaServiceClient.getQnaById(userId, corporationCode, qnaNumber, channelCode, serviceCategoryCode);
    }

    public QnaAnswerDetailDto updateQnaAnswer(Long qnaNumber, Long qnaAnswerDetailNumber, QnaAnswerDetailDto dto) {
        return qnaServiceClient.updateQnaAnswer(qnaNumber, qnaAnswerDetailNumber, dto);
    }

    public QnaResponseDto updateQna(Long qnaNumber, QnaDto requestDto, String userId, String corporationCode) {
        return qnaServiceClient.updateQna(qnaNumber, requestDto, userId, corporationCode);
    }
}
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.constant.StatusType;
import com.osstem.ow.voc.model.request.VocRequestDto;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.model.statistic.DepartmentInfo;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.*;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocAnswerDetail.vocAnswerDetail;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

@Repository
@RequiredArgsConstructor
public class VocQueryRepository {

    private final JPAQueryFactory queryFactory;

    /**
     * VOC 번호로 VOC와 답변 정보를 함께 조회합니다.
     *
     * @param vocNumber VOC 번호
     * @return VOC 및 답변 정보
     */
    public Optional<VocResponseDto> findByIdWithAnswer(Long vocNumber) {
        VocResponseDto result = queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.vocItemName,
                        voc.vocDetailsItemName,
                        voc.denallVocNumber,
                        voc.vocRegistererDivisionCode,
                        voc.registererMemberId,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                        vocAnswerDetail.vocAnswerDateTime,
                        vocAnswerDetail.vocAnswerContent,
                        vocAnswerDetail.fileId.as("answerFileId"),
                        vocAnswerDetail.isNotNull().as("hasAnswer")
                ))
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                .where(voc.vocNumber.eq(vocNumber)
                        .and(voc.deleteYesOrNo.ne("Y")))
                .fetchOne();

        return Optional.ofNullable(result);
    }

    public Map<String, Long> findItemCodesWithCounts(VocRequestDto vocRequestDto, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes, List<String> registererDepartmentCodes) {
        List<Tuple> results = queryFactory
                .select(voc.itemCode, voc.count())
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.itemCode.isNotNull(),
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.itemCode)
                .orderBy(voc.count().desc())
                .fetch();

        // 결과를 Map으로 변환
        Map<String, Long> itemCodeCounts = new LinkedHashMap<>(); // 순서 유지를 위해 LinkedHashMap 사용

        for (Tuple tuple : results) {
            String itemCode = tuple.get(voc.itemCode);
            Long count = tuple.get(voc.count());

            if (itemCode != null) {
                itemCodeCounts.put(itemCode, count);
            }
        }

        return itemCodeCounts;
    }

    /**
     * 등록자 부서코드별 VOC 건수 조회
     * registererDepartmentCodes 필터만 적용 (chargerDepartmentCodes는 미적용)
     */
    public Map<String, Long> findRegistererDeptCodesWithCounts(VocRequestDto vocRequestDto, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes) {
        List<Tuple> results = queryFactory
                .select(voc.registererDepartmentCode, voc.count())
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.registererDepartmentCode.isNotNull(),
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes) // 등록자 부서 필터만 적용
                )
                .groupBy(voc.registererDepartmentCode)
                .orderBy(voc.count().desc())
                .fetch();

        // 결과를 Map으로 변환
        Map<String, Long> deptCodeCounts = new LinkedHashMap<>(); // 순서 유지를 위해 LinkedHashMap 사용

        for (Tuple tuple : results) {
            String deptCode = tuple.get(voc.registererDepartmentCode);
            Long count = tuple.get(voc.count());

            if (deptCode != null) {
                deptCodeCounts.put(deptCode, count);
            }
        }

        return deptCodeCounts;
    }

    /**
     * 처리담당자 부서코드별 VOC 건수 조회
     * chargerDepartmentCodes 필터만 적용 (registererDepartmentCodes는 미적용)
     */
    public Map<String, Long> findChargePersonDeptCodesWithCounts(VocRequestDto vocRequestDto, List<String> vocCategoryCodes, List<String> registerDepartmentCodes) {
        List<Tuple> results = queryFactory
                .select(vocChargePerson.vocChargePersonDepartmentCode, voc.count())
                .from(voc)
                .join(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        vocChargePerson.deleteYn.ne("Y"),
                        vocChargePerson.vocCategoryCode.like("%VOC%"), // VOC가 포함된 카테고리 코드만 필터링
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        registerDepartmentCodeIn(registerDepartmentCodes) // 처리담당자 부서 필터만 적용
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode)
                .orderBy(voc.count().desc())
                .fetch();

        // 결과를 Map으로 변환
        Map<String, Long> deptCodeCounts = new LinkedHashMap<>(); // 순서 유지를 위해 LinkedHashMap 사용

        for (Tuple tuple : results) {
            String deptCode = tuple.get(vocChargePerson.vocChargePersonDepartmentCode);
            Long count = tuple.get(voc.count());

            if (deptCode != null) {
                deptCodeCounts.put(deptCode, count);
            }
        }

        return deptCodeCounts;
    }

    /**
     * 특정 등록자 부서코드 목록에 해당하는 VOC 데이터 조회
     */
    public List<VocResponseDto> findVocsByRegistererDeptCodes(VocRequestDto vocRequestDto, List<String> deptCodes, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes) {
        return queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.denallVocNumber,
                        voc.vocRegistererDivisionCode,
                        voc.registererDepartmentCode.as("departmentCode"),
                        voc.registererMemberId,
                        voc.registererCorporationCode,
                        voc.registererEmployeeNumber,
                        voc.vocSaleChargeCorporationCode,
                        voc.vocSaleChargeEmployeeNumber,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                        vocAnswerDetail.vocAnswerContent,
                        vocAnswerDetail.vocAnswerDateTime
                ))
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.registererDepartmentCode.in(deptCodes),
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes)
                )
                .orderBy(voc.registererDepartmentCode.asc(), voc.vocRegistrationDateTime.desc())
                .fetch();
    }

    /**
     * 특정 처리담당자 부서코드 목록에 해당하는 VOC 데이터 조회
     */
    public List<VocResponseDto> findVocsByChargePersonDeptCodes(VocRequestDto vocRequestDto, List<String> deptCodes, List<String> vocCategoryCodes, List<String> registererDepartmentCodes) {
        return queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.denallVocNumber,
                        voc.vocRegistererDivisionCode,
                        vocChargePerson.vocChargePersonDepartmentCode.as("departmentCode"),
                        voc.registererMemberId,
                        voc.registererCorporationCode,
                        voc.registererEmployeeNumber,
                        voc.vocSaleChargeCorporationCode,
                        voc.vocSaleChargeEmployeeNumber,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                        vocAnswerDetail.vocAnswerContent,
                        vocAnswerDetail.vocAnswerDateTime
                ))
                .from(voc)
                .join(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocChargePerson.deleteYn.ne("Y"),
                        vocChargePerson.vocCategoryCode.like("%VOC%"), // VOC가 포함된 카테고리 코드만 필터링
                        vocChargePerson.vocChargePersonDepartmentCode.in(deptCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .orderBy(vocChargePerson.vocChargePersonDepartmentCode.asc(), voc.vocRegistrationDateTime.desc())
                .fetch();
    }

    /**
     * 부서 코드 정보만 조회 (서비스 레이어에서 부서명을 처리할 수 있도록)
     *
     * @param deptCodes 부서 코드 목록
     * @return 부서 코드별 기본 정보 Map
     */
    public Map<String, DepartmentInfo> getDepartmentInfoByDeptCodes(List<String> deptCodes) {
        Map<String, DepartmentInfo> result = new HashMap<>();

        if (deptCodes == null || deptCodes.isEmpty()) {
            return result;
        }

        // 등록자 부서 목록 조회 (VOC 테이블 기준)
        List<Tuple> registererDeptInfos = queryFactory
                .select(
                        voc.registererDepartmentCode,
                        voc.registererCorporationCode
                )
                .from(voc)
                .where(
                        voc.registererDepartmentCode.in(deptCodes),
                        voc.deleteYesOrNo.ne("Y")
                )
                .groupBy(voc.registererDepartmentCode, voc.registererCorporationCode)
                .fetch();

        // 담당자 부서 목록 조회 (VOC가 포함된 카테고리 코드를 가진 담당자 테이블 기준)
        List<Tuple> chargePersonDeptInfos = queryFactory
                .select(
                        vocChargePerson.vocChargePersonDepartmentCode,
                        vocChargePerson.vocChargePersonCorporationCode
                )
                .from(vocChargePerson)
                .where(
                        vocChargePerson.vocChargePersonDepartmentCode.in(deptCodes),
                        vocChargePerson.vocCategoryCode.like("%VOC%"),
                        vocChargePerson.deleteYn.ne("Y")
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode, vocChargePerson.vocChargePersonCorporationCode)
                .fetch();

        // 등록자 부서 정보 처리
        for (Tuple tuple : registererDeptInfos) {
            String deptCode = tuple.get(voc.registererDepartmentCode);
            String corpCode = tuple.get(voc.registererCorporationCode);

            if (deptCode != null && !result.containsKey(deptCode)) {
                DepartmentInfo info = new DepartmentInfo();
                info.setDeptCode(deptCode);
                info.setCorpCode(corpCode != null ? corpCode : "KR1");
                // 부서명은 서비스 레이어에서 설정합니다

                result.put(deptCode, info);
            }
        }

        // 담당자 부서 정보 처리
        for (Tuple tuple : chargePersonDeptInfos) {
            String deptCode = tuple.get(vocChargePerson.vocChargePersonDepartmentCode);
            String corpCode = tuple.get(vocChargePerson.vocChargePersonCorporationCode);

            if (deptCode != null && !result.containsKey(deptCode)) {
                DepartmentInfo info = new DepartmentInfo();
                info.setDeptCode(deptCode);
                info.setCorpCode(corpCode != null ? corpCode : "KR1");
                // 부서명은 서비스 레이어에서 설정합니다

                result.put(deptCode, info);
            }
        }

        // 조회 결과가 없는 부서 코드에 대한 기본 정보 설정
        for (String deptCode : deptCodes) {
            if (!result.containsKey(deptCode)) {
                DepartmentInfo info = new DepartmentInfo();
                info.setDeptCode(deptCode);
                info.setCorpCode("KR1");
                // 부서명은 서비스 레이어에서 설정합니다

                result.put(deptCode, info);
            }
        }

        return result;
    }

    /**
     * 고유한 VOC 담당자 부서 코드 조회 (VOC 카테고리 코드가 포함된 데이터만)
     */
    public List<String> findDistinctChargePersonDepartmentCodes() {
        return queryFactory
                .select(vocChargePerson.vocChargePersonDepartmentCode)
                .from(vocChargePerson)
                .where(
                        vocChargePerson.vocChargePersonDepartmentCode.isNotNull(),
                        vocChargePerson.vocCategoryCode.like("%VOC%"),
                        vocChargePerson.deleteYn.ne("Y")
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode)
                .orderBy(vocChargePerson.vocChargePersonDepartmentCode.asc())
                .fetch();
    }

    /**
     * 고유한 VOC 등록자 부서 코드 조회
     */
    public List<String> findDistinctRegistererDepartmentCodes() {
        return queryFactory
                .select(voc.registererDepartmentCode)
                .from(voc)
                .where(
                        voc.registererDepartmentCode.isNotNull(),
                        voc.deleteYesOrNo.ne("Y")
                )
                .groupBy(voc.registererDepartmentCode)
                .orderBy(voc.registererDepartmentCode.asc())
                .fetch();
    }

    /**
     * VOC 검색 및 페이징 처리
     */
    public List<VocResponseDto> search(VocRequestDto vocRequestDto, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes, List<String> registererDepartmentCodes) {
        return queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.vocItemName,
                        voc.vocDetailsItemName,
                        voc.vocRegistererDivisionCode,
                        voc.registererMemberId,
                        voc.vocSaleChargeCorporationCode,
                        voc.vocSaleChargeEmployeeNumber,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                        vocAnswerDetail.vocAnswerContent,
                        vocAnswerDetail.vocAnswerDateTime
                ))
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.vocCategoryCode.in(vocCategoryCodes), // VOC 카테고리 코드가 포함된 데이터만 필터링
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .orderBy(voc.vocRegistrationDateTime.desc())
                .offset((long) (vocRequestDto.getPageNo() - 1) * vocRequestDto.getPageSize())
                .limit(vocRequestDto.getPageSize())
                .fetch();
    }

    /**
     * 조건에 맞는 총 VOC 개수를 조회합니다.
     */
    public long count(VocRequestDto vocRequestDto, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes, List<String> registererDepartmentCodes) {
        return queryFactory
                .selectFrom(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .fetchCount();
    }

    /**
     * 품목별 그룹화를 위한 고유한 품목 코드 목록을 조회
     *
     * @param vocRequestDto 검색 조건
     * @return 알파벳 순으로 정렬된 고유한 품목 코드 목록
     */
    public List<String> findDistinctItemCodes(VocRequestDto vocRequestDto) {
        return queryFactory
                .select(voc.itemCode)
                .distinct()
                .from(voc)
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.itemCode.isNotNull(), // null 값 제외 조건 추가
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        itemCodeEquals(vocRequestDto.getItemCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())
                )
                .orderBy(voc.itemCode.asc()) // 품목 코드 알파벳 순 정렬
                .fetch();
    }

    /**
     * 특정 품목 코드에 대한 VOC 데이터만 조회
     *
     * @param vocRequestDto             검색 조건
     * @param itemCodes                 조회할 품목 코드 목록
     * @param vocCategoryCodes          VOC 카테고리 코드 목록
     * @param chargerDepartmentCodes    처리담당자 부서 코드 목록
     * @param registererDepartmentCodes 등록자 부서 코드 목록
     * @return 품목별로 정렬된 VOC 목록 (각 품목 내에서는 등록일시 내림차순)
     */
    public List<VocResponseDto> findVocsByItemCodes(VocRequestDto vocRequestDto, List<String> itemCodes, List<String> vocCategoryCodes, List<String> chargerDepartmentCodes, List<String> registererDepartmentCodes) {
        return queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.denallVocNumber,
                        voc.vocRegistererDivisionCode,
                        voc.registererMemberId,
                        voc.registererCorporationCode,
                        voc.registererEmployeeNumber,
                        voc.vocSaleChargeCorporationCode,
                        voc.vocSaleChargeEmployeeNumber,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName")
                ))
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        voc.itemCode.in(itemCodes), // 지정된 품목 코드들만 조회
                        voc.vocCategoryCode.in(vocCategoryCodes),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate()),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .orderBy(voc.itemCode.asc(), voc.vocRegistrationDateTime.desc()) // 품목별, 등록일시 내림차순 정렬
                .fetch();
    }

    /**
     * 특정 품목 코드의 VOC 건수 조회
     *
     * @param vocRequestDto 검색 조건
     * @param itemCode      품목 코드
     * @return 해당 품목의 VOC 건수
     */
    public long countVocsByItemCode(VocRequestDto vocRequestDto, String itemCode) {
        return queryFactory
                .select(voc.count())
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        voc.deleteYesOrNo.ne("Y"),
                        itemCodeEquals(itemCode),
                        vocCategoryCodeEquals(vocRequestDto.getVocCategoryCode()),
                        vocStateCodeEquals(vocRequestDto.getVocStateCode(), isDay(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())),
                        registrationDateBetween(vocRequestDto.getStartDate(), vocRequestDto.getEndDate())
                )
                .fetchOne();
    }

    private BooleanExpression vocCategoryCodeEquals(String code) {
        return code != null ? voc.vocCategoryCode.eq(code) : null;
    }

    private boolean isDay(LocalDateTime startDate, LocalDateTime endDate) {
        boolean categoryEquals = false;

        if (startDate != null && endDate != null) {
            categoryEquals = startDate.toLocalDate().isEqual(endDate.toLocalDate());
        }

        return categoryEquals;
    }

    private BooleanExpression vocStateCodeEquals(String code, boolean isDay) {
        if (code == null) {
            return null;
        }

        // 만약 vocStateCode가 "02"이면 "01"과 "02" 둘 다 검색, 만약 일이면 접수, 처리중, 처리완료를 다 가져온다
        if (StatusType.PROCESSING.getStatusCode().equals(code)) {
            if (isDay) {
                return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.PROCESSING.getStatusCode(), StatusType.COMPLETE.getStatusCode());
            }
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.PROCESSING.getStatusCode());
        } else if (StatusType.RECEIPT.getStatusCode().equals(code)) {
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.COMPLETE.getStatusCode());
        }

        // 그 외 경우에는 정확히 일치하는 코드만 검색
        return voc.vocStateCode.eq(code);
    }

    private BooleanExpression itemCodeEquals(String itemCode) {
        // 1. null 체크 + 빈 문자열 체크
        if (itemCode == null || itemCode.isEmpty()) {
            return null;
        }

        return voc.itemCode.eq(itemCode);
    }

    private BooleanExpression chargerDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return vocChargePerson.vocChargePersonDepartmentCode.in(departmentCodes);
    }

    private BooleanExpression registerDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return voc.registererDepartmentCode.in(departmentCodes);
    }

    private BooleanExpression registrationDateBetween(LocalDateTime startDate, LocalDateTime endDate) {
        if (startDate != null && endDate != null) {
            return voc.vocRegistrationDateTime.between(startDate, endDate);
        } else if (startDate != null) {
            return voc.vocRegistrationDateTime.goe(startDate);
        } else if (endDate != null) {
            return voc.vocRegistrationDateTime.loe(endDate);
        }
        return null;
    }
}
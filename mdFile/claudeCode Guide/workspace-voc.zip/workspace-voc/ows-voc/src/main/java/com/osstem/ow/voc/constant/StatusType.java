package com.osstem.ow.voc.constant;

public enum StatusType {
    RECEIPT("01"),
    PROCESSING("02"),
    COMPLETE("03");

    private final String statusCode;

    StatusType(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusCode() {
        return statusCode;
    }


}

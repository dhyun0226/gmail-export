package com.osstem.ow.voc.repository;


import com.osstem.ow.voc.entity.QVocCategory;
import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.model.table.VocCategoryDto;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.osstem.ow.voc.entity.QVocCategory.vocCategory;

@Repository
@RequiredArgsConstructor
public class VocCategoryQueryRepository {

    private final JPAQueryFactory queryFactory;


    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     * @param categoryCode 카테고리 코드
     * @return 최상위 카테고리
     */
    public VocCategory findRootCategory(String categoryCode) {
        QVocCategory vocCategory = QVocCategory.vocCategory;

        // 현재 카테고리 조회
        VocCategory category = queryFactory
                .selectFrom(vocCategory)
                .where(vocCategory.vocCategoryCode.eq(categoryCode))
                .fetchOne();

        if (category == null) {
            return null;
        }

        // 상위 카테고리가 없는 경우 현재 카테고리가 최상위
        if (category.getUpVocCategoryCode() == null) {
            return category;
        }

        // 최상위 카테고리를 찾을 때까지 반복
        VocCategory current = category;
        while (current.getUpVocCategoryCode() != null) {
            current = queryFactory
                    .selectFrom(vocCategory)
                    .where(vocCategory.vocCategoryCode.eq(current.getUpVocCategoryCode().getVocCategoryCode()))
                    .fetchOne();

            if (current == null) {
                break;
            }
        }

        return current;
    }

    public List<VocCategory> findRootCategoriesByTaskCodeAndOpenYn(String taskCode, Character openYn) {
        QVocCategory parent = new QVocCategory("parent");
        QVocCategory child = new QVocCategory("child");

        return queryFactory
                .selectDistinct(parent)
                .from(parent)
                .innerJoin(child).on(child.upVocCategoryCode.eq(parent))
                .where(
                        parent.upVocCategoryCode.isNull(), // 1레벨 (부모가 null)
                        parent.openYn.eq(openYn),
                        parent.deleteYn.eq('N'),
                        child.vocCategoryCode.like("%" + taskCode + "%"), // 2레벨이 taskCode로 시작
                        child.openYn.eq(openYn),
                        child.deleteYn.eq('N')
                )
                .orderBy(parent.sortOrder.asc())
                .fetch();
    }


    /**
     * 특정 루트 카테고리 코드 하위의 최하위 카테고리 목록 조회
     * @param rootCategoryCode 루트 카테고리 코드
     * @return 최하위 카테고리 목록
     */
    public List<VocCategory> findLowestLevelCategoriesByRootCode(String rootCategoryCode) {

        // 1. 해당 루트 카테고리로 시작하는 모든 카테고리 조회
        List<VocCategory> allCategories = queryFactory
                .selectFrom(vocCategory)
                .where(vocCategory.vocCategoryCode.like(rootCategoryCode + "%"))
                .fetch();

        // 2. 루트 카테고리로 시작하지만 다른 카테고리의 부모인 카테고리 코드 목록 조회
        List<String> parentCategoryCodes = queryFactory
                .select(vocCategory.upVocCategoryCode.vocCategoryCode)
                .from(vocCategory)
                .where(vocCategory.upVocCategoryCode.vocCategoryCode.like(rootCategoryCode + "%"))
                .distinct()
                .fetch();

        // 3. 부모가 아닌 카테고리만 필터링 (최하위 카테고리)
        return allCategories.stream()
                .filter(category -> !parentCategoryCodes.contains(category.getVocCategoryCode()))
                .toList();
    }

    public List<VocCategoryDto> findSecondLevelCategories(Character openYn) {
        QVocCategory vocCategory = QVocCategory.vocCategory;
        QVocCategory parentCategory = new QVocCategory("parentCategory");

        return queryFactory
                .select(Projections.fields(
                        VocCategoryDto.class,
                        vocCategory.vocCategoryCode,
                        vocCategory.vocCategoryName
                ))
                .from(vocCategory)
                .join(vocCategory.upVocCategoryCode, parentCategory)
                .where(
                        eqOpenYn(openYn),
                        parentCategory.upVocCategoryCode.isNull() // 부모의 부모가 null인 경우(즉, 부모가 1레벨)
                )
                .orderBy(vocCategory.sortOrder.asc())
                .fetch();
    }

    private BooleanExpression eqOpenYn(Character openYn) {
        return openYn != null ? QVocCategory.vocCategory.openYn.eq(openYn) : null;
    }

    public List<VocCategory> findRootCategoriesByOpenYn(Character openYn) {
        QVocCategory vocCategory = QVocCategory.vocCategory;

        return queryFactory
                .selectFrom(vocCategory)
                .where(
                        vocCategory.upVocCategoryCode.isNull(),
                        eqOpenYn(openYn)
                )
                .orderBy(vocCategory.sortOrder.asc())
                .fetch();
    }

}
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocChargePerson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VocChargePersonRepository extends JpaRepository<VocChargePerson, Long> {

    List<VocChargePerson> findByVocCategoryCode(String vocCategoryCode);
    Optional<VocChargePerson> findByVocCategoryCodeAndVocDesignationThePersonInChargeYn(String vocCategoryCode, String vocDesignationThePersonInChargeYn);
    List<VocChargePerson> findByVocChargePersonEmployeeNumber(String vocChargePersonEmployeeNumber);
}
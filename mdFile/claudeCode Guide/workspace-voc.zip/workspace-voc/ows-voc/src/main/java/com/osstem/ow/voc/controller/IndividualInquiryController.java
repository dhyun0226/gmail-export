package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.IndividualInquiryAnswerDto;
import com.osstem.ow.voc.model.request.IndividualInquiryRequestDto;
import com.osstem.ow.voc.model.response.IndividualInquiryResponseDto;
import com.osstem.ow.voc.domain.IndividualInquiryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/individual-inquiries")
@RequiredArgsConstructor
public class IndividualInquiryController {

    private final IndividualInquiryService individualInquiryService;

    @GetMapping
    @Operation(summary = "개인문의 목록 조회", description = "개인문의 목록을 페이징 처리하여 조회합니다.")
    @ApiResponse(responseCode = "200", description = "개인문의 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    public ResponseEntity<ResultDto<IndividualInquiryResponseDto>> list(
            IndividualInquiryRequestDto requestDto, @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode) {
        ResultDto<IndividualInquiryResponseDto> result = individualInquiryService.search(requestDto, userId, corporationCode);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{inquiryNumber}")
    @Operation(summary = "내부 개인문의 상세 조회", description = "외부 서버의 개인문의 상세 정보를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "조회 성공")
    @ApiResponse(responseCode = "404", description = "개인문의를 찾을 수 없음")
    public ResponseEntity<IndividualInquiryResponseDto> getInquiryWithAnswer(
            @Parameter(description = "개인문의 번호", required = true)
            @PathVariable Long inquiryNumber,
            @RequestHeader(name = "X-USER-ID", required = false) String userId) {
        IndividualInquiryResponseDto inquiryDto = individualInquiryService.getInquiryWithAnswer(inquiryNumber, userId);
        return ResponseEntity.ok(inquiryDto);
    }

}
package com.osstem.ow.voc.filter;

import com.osstem.ow.voc.util.SensitiveDataMaskingUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.util.Collections;
import java.util.stream.Collectors;

/**
 * HTTP 요청/응답 로깅 필터 (민감정보 마스킹 적용)
 */
@Slf4j
@Component
public class LoggingFilter extends OncePerRequestFilter {
    
    private static final String[] SENSITIVE_HEADERS = {
        "Authorization", "Cookie", "Set-Cookie", "X-Auth-Token"
    };
    
    private static final String[] SENSITIVE_PARAMS = {
        "password", "pwd", "secret", "token", "ssn", "주민등록번호",
        "phone", "phoneNumber", "전화번호", "휴대폰번호",
        "email", "이메일", "emailAddress"
    };
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                  FilterChain filterChain) throws ServletException, IOException {
        
        ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(response);
        
        long startTime = System.currentTimeMillis();
        
        try {
            filterChain.doFilter(wrappedRequest, wrappedResponse);
        } finally {
            logRequest(wrappedRequest);
            logResponse(wrappedResponse, System.currentTimeMillis() - startTime);
            wrappedResponse.copyBodyToResponse();
        }
    }
    
    private void logRequest(ContentCachingRequestWrapper request) {
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String queryString = maskQueryString(request.getQueryString());
        String headers = maskHeaders(request);
        
        log.info("REQUEST: {} {} {}", method, uri, 
            queryString != null ? "?" + queryString : "");
        log.debug("REQUEST HEADERS: {}", headers);
    }
    
    private void logResponse(ContentCachingResponseWrapper response, long duration) {
        int status = response.getStatus();
        log.info("RESPONSE: {} ({}ms)", status, duration);
    }
    
    private String maskQueryString(String queryString) {
        if (queryString == null) {
            return null;
        }
        
        return queryString.lines()
            .map(param -> {
                String[] parts = param.split("=", 2);
                if (parts.length == 2 && isSensitiveParam(parts[0])) {
                    return parts[0] + "=***";
                }
                return param;
            })
            .collect(Collectors.joining("&"));
    }
    
    private String maskHeaders(HttpServletRequest request) {
        return Collections.list(request.getHeaderNames()).stream()
            .map(name -> {
                if (isSensitiveHeader(name)) {
                    return name + ": ***";
                }
                return name + ": " + request.getHeader(name);
            })
            .collect(Collectors.joining(", "));
    }
    
    private boolean isSensitiveHeader(String headerName) {
        for (String sensitive : SENSITIVE_HEADERS) {
            if (sensitive.equalsIgnoreCase(headerName)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isSensitiveParam(String paramName) {
        for (String sensitive : SENSITIVE_PARAMS) {
            if (paramName.toLowerCase().contains(sensitive.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
}
package com.osstem.ow.voc.model.response;

import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.txm.File;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(name = "VocAnswerResponseDto", description = "VOC 답변 응답 DTO")
public class VocAnswerResponseDto extends BaseDto {

    @Schema(description = "VOC 번호", example = "1")
    private Long vocNumber;

    @Schema(description = "답변자 법인 코드", example = "123456")
    private String answererCorporationCode;

    @Schema(description = "답변자 부서 코드", example = "123456")
    private String answererDepartmentCode;

    @Schema(description = "답변자 사원 번호", example = "123456")
    private String answererEmployeeNumber;

    @Schema(description = "VOC 답변 내용", example = "답변 내용을 입력하세요")
    private String vocAnswerContent;

    @Schema(description = "VOC 답변 일시", example = "2025-04-04T10:30:00")
    private LocalDateTime vocAnswerDateTime;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file123")
    private String fileId;

    @Schema(description = "첨부 파일 리스트")
    private List<File> fileList;
}

package com.osstem.ow.voc.model.response;

import com.osstem.ow.voc.model.txm.File;
import com.osstem.ow.voc.model.txm.TxmFileListResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "QnA 답변 상세 응답 DTO")
public class QnaAnswerDetailResponseDto {

    @Schema(description = "QnA 번호", example = "1")
    private Long qnaNumber;

    @Schema(description = "QnA 답변 상세 번호", example = "1001")
    private Long qnaAnswerDetailNumber;

    @Schema(description = "QnA 부모 답변 번호", example = "1001")
    private Long parentAnswerDetailNumber;

    @Schema(description = "QnA 답변 일시", example = "2025-04-04T14:30:00")
    private LocalDateTime qnaAnswerDatetime;

    @Schema(description = "답변자 회원 ID", example = "admin123")
    private String answererMemberId;

    @Schema(description = "답변 내용", example = "문의하신 내용에 대한 답변드립니다. 해당 제품은...")
    private String qnaAnswerContent;

    @Schema(description = "파일 ID", example = "file456")
    private String answerFileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "삭제 여부", example = "N")
    private String deleteYn;

}
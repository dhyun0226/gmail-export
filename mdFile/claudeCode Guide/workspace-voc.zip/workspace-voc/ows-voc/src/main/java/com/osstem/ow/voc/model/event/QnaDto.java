package com.osstem.ow.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import com.osstem.ow.voc.model.txm.File;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "QnA DTO")
public class QnaDto extends BaseDto {

    @Schema(description = "QnA 번호", example = "1")
    private Long qnaNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @NotBlank
    @Size(max = 20)
    @Schema(description = "작성자 회원 ID", example = "user123")
    private String writerMemberId;

    @Size(max = 90)
    @Schema(description = "품목 코드", example = "ITM001")
    private String itemCode;

    @NotBlank
    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "공개 여부", example = "Y")
    private String openYn;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "QnA 제목", example = "제품 사용 문의드립니다")
    private String qnaTitle;

    @NotBlank
    @Size(max = 2000)
    @Schema(description = "QnA 내용", example = "제품을 사용하는 중 문제가 발생하였습니다. 어떻게 해결할 수 있을까요?")
    private String qnaContent;

    @Schema(description = "QnA 등록 일시", example = "2025-04-04T10:30:00")
    private LocalDateTime qnaRegistrationDatetime;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file123")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<TxmFileSaveRequest> fileList;

    @Schema(description = "답변 건수", example = "2")
    private Short answerCount;

    @Schema(description = "조회수")
    private Short inquiryCount;

    public void initInquiryCount(){
        this.inquiryCount = 0;
    }


}
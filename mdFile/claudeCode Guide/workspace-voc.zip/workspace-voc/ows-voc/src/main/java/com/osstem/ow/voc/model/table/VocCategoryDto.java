package com.osstem.ow.voc.model.table;

import com.osstem.ow.model.BaseDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VocCategoryDto extends BaseDto {
    private String vocCategoryCode;
    private String upVocCategoryCode; // 상위 카테고리의 코드 값만 포함
    private String upVocCategoryName; // 상위 카테고리의 이름 (필요한 경우)
    private String vocCategoryName;
    private Character openYn;
    private String registererCorporationCode;
    private String registererCorporationDepartmentCode;
    private String registererCorporationEmployeeNumber;
    private Instant vocCategoryRegistererCorporationDatetime;
    private Character customerCenterYn;
    private Character deleteYn;
    private BigDecimal sortOrder;

}

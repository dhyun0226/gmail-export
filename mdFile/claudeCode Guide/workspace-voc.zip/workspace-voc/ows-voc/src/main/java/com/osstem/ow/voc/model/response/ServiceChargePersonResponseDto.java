package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.voc.model.common.EmployeeResponseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "서비스 담당자 변경 응답 DTO")
public class ServiceChargePersonResponseDto {

    @Schema(description = "서비스 담당자 번호")
    private Long serviceChargePersonNumber;

    @Schema(description = "서비스 카테고리 코드")
    private String serviceCategoryCode;

    @Schema(description = "품목 코드")
    private String itemCode;

    @Schema(description = "서비스 담당자 법인 코드")
    private String serviceChargePersonCorporationCode;

    @Schema(description = "서비스 담당자 부서 코드")
    private String serviceChargePersonDepartmentCode;

    @Schema(description = "서비스 담당자 사원 번호")
    private String serviceChargePersonEmployeeNumber;

    @Schema(description = "서비스 지정 담당자 여부")
    private String serviceDesignationThePersonInChargeYn;

    @Schema(description = "서비스 담당자 부서명")
    private String serviceChargePersonDepartmentName;

    @Schema(description = "서비스 담당자 사원명")
    private String serviceChargePersonEmployeeName;
}
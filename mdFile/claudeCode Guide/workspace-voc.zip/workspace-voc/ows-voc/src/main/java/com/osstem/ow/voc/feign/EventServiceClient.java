package com.osstem.ow.voc.feign;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.EventRequestDto;
import com.osstem.ow.voc.model.customer.EventResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "eventServiceClient", url = "${voc.api.occ.root.uri}")
public interface EventServiceClient {

    @GetMapping("/events/{eventNumber}")
    EventResponseDto getEventById(
            @PathVariable("eventNumber") Long eventNumber,
            @RequestParam("serviceCategoryCode") String serviceCategoryCode,
            @RequestHeader("X-User-Role") String userRole
    );

    @PostMapping("/events")
    EventResponseDto createEvent(@RequestBody EventRequestDto eventRequestDto);

    @PutMapping("/events/{eventNumber}")
    EventResponseDto updateEvent(
            @PathVariable("eventNumber") Long eventNumber,
            @RequestBody EventRequestDto eventRequestDto
    );

    @DeleteMapping("/events/{eventNumber}")
    void deleteEvent(@PathVariable("eventNumber") Long eventNumber);

    @GetMapping("/events/search")
    ResultDto<EventResponseDto> searchEvents(@SpringQueryMap EventRequestDto eventRequestDto);
}
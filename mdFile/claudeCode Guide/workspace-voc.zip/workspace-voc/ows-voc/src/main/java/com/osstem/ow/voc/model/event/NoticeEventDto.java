package com.osstem.ow.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "공지 이벤트 DTO")
public class NoticeEventDto {
    @Schema(description = "공지 번호", example = "1")
    private Long noticeNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "공지 등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @NotBlank
    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "공개 여부", example = "Y")
    private String openYn;

    @NotBlank
    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "상단 고정 여부", example = "N")
    private String topFixedYn;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "공지 제목", example = "시스템 점검 안내")
    private String noticeTitle;

    @NotBlank
    @Schema(description = "공지 내용", example = "안녕하세요. 시스템 점검이 예정되어 있습니다. 자세한 내용은...")
    private String noticeContent;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @NotBlank
    @Size(max = 30)
    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @NotBlank
    @Size(max = 60)
    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "공지 등록 일시", example = "2025-04-04T09:00:00")
    private LocalDateTime noticeRegistrationDatetime;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file789")
    private String fileId;

    @Schema(description = "조회 건수", example = "157")
    private Short inquiryCount;
}

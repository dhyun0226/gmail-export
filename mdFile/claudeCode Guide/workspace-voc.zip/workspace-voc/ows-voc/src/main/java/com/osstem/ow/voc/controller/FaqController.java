package com.osstem.ow.voc.controller;


import com.osstem.ow.voc.domain.FaqService;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.FaqRequestDto;
import com.osstem.ow.voc.model.customer.FaqResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/faqs")
@RequiredArgsConstructor
public class FaqController {

    private final FaqService faqService;

    @GetMapping
    public ResponseEntity<ResultDto<FaqResponseDto>> getAllFaqs(FaqRequestDto dto) {
        return ResponseEntity.ok(faqService.getAllFaqs(dto));
    }


    @GetMapping("/{id}")
    public ResponseEntity<FaqResponseDto> getFaqById(@PathVariable Long id) {
        return ResponseEntity.ok(faqService.getFaqById(id));
    }

    @PostMapping
    public ResponseEntity<FaqResponseDto> createFaq(@RequestBody FaqRequestDto dto) {
        return ResponseEntity.ok(faqService.create(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FaqResponseDto> updateFaq(
            @PathVariable Long id,
            @RequestBody FaqRequestDto dto) {
        return ResponseEntity.ok(faqService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ResultDto<?>> deleteFaq(@PathVariable Long id) {
        faqService.delete(id);
        return ResponseEntity.ok(new ResultDto<>());
    }

//    @GetMapping("/search")
//    public ResponseEntity<ResultDto<FaqResponseDto>> searchFaqs(FaqRequestDto dto) {
//        return ResponseEntity.ok(faqService.search(dto));
//    }
}

package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "TB_VOC_CTG_C")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocCategory extends BaseEntity {
    @Id
    @Size(max = 12)
    @Column(name = "VOC_CTG_CD", nullable = false, length = 12)
    private String vocCategoryCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UP_VOC_CTG_CD")
    private VocCategory upVocCategoryCode;

    @Size(max = 100)
    @NotNull
    @Column(name = "VOC_CTG_NM", nullable = false, length = 100)
    private String vocCategoryName;

    @NotNull
    @ColumnDefault("'Y'")
    @Column(name = "OPEN_YN", nullable = false)
    private Character openYn;

    @Size(max = 3)
    @NotNull
    @Column(name = "RGSTR_CPRN_CD", nullable = false, length = 3)
    private String registererCorporationCode;

    @Size(max = 30)
    @NotNull
    @Column(name = "RGSTR_DEPT_CD", nullable = false, length = 30)
    private String registererCorporationDepartmentCode;

    @Size(max = 60)
    @NotNull
    @Column(name = "RGSTR_EMP_NO", nullable = false, length = 60)
    private String registererCorporationEmployeeNumber;

    @NotNull
    @Column(name = "VOC_CTG_RGST_DTM", nullable = false)
    private Instant vocCategoryRegistererCorporationDatetime;

    @NotNull
    @Column(name = "CUSTMCT_YN", nullable = false)
    private Character customerCenterYn;

    @NotNull
    @Column(name = "DEL_YN", nullable = false)
    private Character deleteYn;

    @NotNull
    @Column(name = "SORT_ORD", nullable = false, precision = 10)
    private BigDecimal sortOrder;

}
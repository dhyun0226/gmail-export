package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.table.VocChangeHistoryDto;
import com.osstem.ow.voc.model.txm.File;
import com.osstem.ow.voc.model.txm.TxmFileListResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 응답 정보 (답변 상세 포함)")
public class VocResponseDto extends BaseDto {

    // VOC 기본 정보
    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Schema(description = "VOC 담당자 이름")
    private String vocChargePersonName;

    private String registererCorporationCode;

    private String vocSaleChargeDepartmentName;


    private String registererEmployeeNumber;

    private String vocSaleChargeEmployeeName;

    @Schema(description = "VOC 담당자 사원번호")
    private String vocChargePersonEmployeeNumber;

    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Schema(description = "덴올 VOC 번호")
    private Long denallVocNumber;

    @Schema(description = "품목 코드")
    private String itemCode;

    @Schema(description = "품목 코드")
    private String vocItemName;

    @Schema(description = "부서 코드")
    private String departmentCode;

    @Schema(description = "VOC 등록자 구분 코드")
    private String vocRegistererDivisionCode;

    @Schema(description = "등록자 회원 ID")
    private String registererMemberId;

    @Schema(description = "VOC 고객명")
    private String vocCustomerName;

    @Schema(description = "VOC 고객 거래처명")
    private String vocCustomerCustomerName;

    @Schema(description = "VOC 고객 이메일 주소")
    private String vocCustomerEmailAddress;

    @Schema(description = "VOC 고객 전화번호")
    private String vocCustomerTelephoneNumber;

    @Schema(description = "VOC 고객 휴대전화번호")
    private String vocCustomerHandPhoneNumber;

    @Schema(description = "VOC 제목")
    private String vocTitle;

    @Schema(description = "VOC 내용")
    private String vocContent;

    @Schema(description = "VOC 영업 담당자 법인 코드")
    private String vocSaleChargeCorporationCode;

    @Schema(description = "VOC 영업 담당자 부서 코드")
    private String vocSaleChargeDepartmentCode;

    @Schema(description = "VOC 영업 담당자 사원 번호")
    private String vocSaleChargeEmployeeNumber;

    @Schema(description = "VOC 파일 ID")
    private String vocFileId;

    @Schema(description = "VOC 완료유형 코드")
    private String vocCompletionTypeCode;

    @Schema(description = "VOC 상태 코드")
    private String vocStateCode;

    @Schema(description = "VOC 등록 일시")
    private LocalDateTime vocRegistrationDateTime;

    // VOC 답변 상세 정보
    @Schema(description = "VOC 답변 일시")
    private LocalDateTime vocAnswerDateTime;

    @Schema(description = "답변 내용")
    private String vocAnswerContent;

    @Schema(description = "답변 파일 ID")
    private String answerFileId;

    @Schema(description = "답변 존재 여부")
    private Boolean hasAnswer;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "답변 파일 리스트")
    private List<File> answerFileList;

    @Schema(description = "voc 이력 리스트")
    private List<VocChangeHistoryDto> changeHistories;

    @Schema(description = "voc 세부 품목명")
    private String vocDetailsItemName;


    public void setFileList(TxmFileListResponse txmFileListResponse) {
        this.fileList = txmFileListResponse.getData();
    }

    public void setAnswerFileList(TxmFileListResponse txmFileListResponse) {
        this.answerFileList = txmFileListResponse.getData();
    }

    public void setChangeHistories(List<VocChangeHistoryDto> changeHistories) {
        this.changeHistories = changeHistories;
    }

}
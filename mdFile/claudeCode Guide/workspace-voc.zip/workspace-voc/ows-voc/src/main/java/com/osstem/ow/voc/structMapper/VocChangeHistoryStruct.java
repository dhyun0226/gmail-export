package com.osstem.ow.voc.structMapper;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.model.table.VocChangeHistoryDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface VocChangeHistoryStruct extends StructMapper<VocChangeHistory, VocChangeHistoryDto> {

    @Mapping(target = "vocNumber", source = "id.vocNumber")
    @Mapping(target = "vocChangeDateTime", source = "id.vocChangeDateTime")
    VocChangeHistoryDto toDto(VocChangeHistory entity);

    @Mapping(target = "id.vocNumber", source = "vocNumber")
    @Mapping(target = "id.vocChangeDateTime", source = "vocChangeDateTime")
    VocChangeHistory toEntity(VocChangeHistoryDto dto);

    List<VocChangeHistoryDto> toDtoList(List<VocChangeHistory> entities);

    List<VocChangeHistory> toEntityList(List<VocChangeHistoryDto> dtos);

    /**
     * Voc 엔티티를 기반으로 변경 이력 엔티티로 변환합니다.
     */
    @Mapping(target = "id",
            expression = "java(new VocChangeHistoryId(voc.getVocNumber(), voc.getVocRegistrationDateTime()))")
    VocChangeHistory toHistory(Voc voc);

}
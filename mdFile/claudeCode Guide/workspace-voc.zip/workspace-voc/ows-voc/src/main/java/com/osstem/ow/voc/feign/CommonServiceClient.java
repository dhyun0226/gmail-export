package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.common.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "commonClient", url = "${voc.api.com.root.uri}", configuration = FeignClientConfig.class)
public interface CommonServiceClient {
    @GetMapping("/v2/department")
    OrganizationResponseDto getDepartment(@RequestParam String corporationCode, @RequestParam String departmentCode);

    @GetMapping("/employee/get")
    EmployeeResponseDto getEmployee(@SpringQueryMap EmployeeRequestDto requests);

    @GetMapping("/department/get")
    ApiResponse<DepartmentDto> getDepartmentInfo(@RequestParam String corporationCode, @RequestParam String departmentCode);
}

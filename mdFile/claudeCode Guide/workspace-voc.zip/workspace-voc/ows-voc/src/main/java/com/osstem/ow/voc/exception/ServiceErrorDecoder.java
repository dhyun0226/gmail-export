package com.osstem.ow.voc.exception;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.io.InputStream;

public class ServiceErrorDecoder implements ErrorDecoder{
    private final ErrorDecoder defaultDecoder = new ErrorDecoder.Default();

    @Override
    public Exception decode(String methodKey, Response response) {
        // 2xx 상태 코드가 아닌 경우에 대한 처리
        if (response.status() != HttpStatus.OK.value() &&
                response.status() != HttpStatus.CREATED.value()) {

            String responseBody = getResponseBody(response);

            return new BusinessException(
                    String.format("VOC 서비스 요청 실패 - 상태 코드: %d, 응답: %s",
                            response.status(), responseBody),
                    response.status());
        }

        // 기본 에러 디코더로 폴백
        return defaultDecoder.decode(methodKey, response);
    }

    private String getResponseBody(Response response) {
        try {
            if (response.body() != null) {
                try (InputStream bodyIs = response.body().asInputStream()) {
                    return new String(bodyIs.readAllBytes());
                }
            }
            return "응답 본문 없음";
        } catch (IOException e) {
            return "응답 본문을 읽는 중 오류 발생: " + e.getMessage();
        }
    }
}

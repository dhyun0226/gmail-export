package com.osstem.ow.voc.model.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "FAQ DTO")
public class FaqResponseDto {

    @Schema(description = "FAQ 번호", example = "1")
    private Long faqNumber;

    @Schema(description = "FAQ 등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Schema(description = "FAQ 제목", example = "회원가입은 어떻게 하나요?")
    private String faqTitle;

    @Schema(description = "FAQ 내용", example = "회원가입은 홈페이지 우측 상단의 회원가입 버튼을 클릭한 뒤...")
    private String faqContent;

    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "파일 ID", example = "file012")
    private String fileId;

    @Schema(description = "정렬 순서", example = "10")
    private BigDecimal sortOrder;

    @Schema(description = "사용 여부", example = "Y")
    private String useYn;

    @Schema(description = "등록 처리 일시", example = "2025-06-30T12:34:56")
    private LocalDateTime rgstProcDtm;

    @Schema(description = "FAQ 목록")
    private List<FaqResponseDto> faqs;
}
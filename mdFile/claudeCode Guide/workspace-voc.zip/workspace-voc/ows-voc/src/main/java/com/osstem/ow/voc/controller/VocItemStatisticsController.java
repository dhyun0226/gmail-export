package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocItemStatisticsService;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import com.osstem.ow.voc.model.statistic.ProductCategoryVocStatisticsDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/statistics/item")
@RequiredArgsConstructor
@Tag(name = "VOC 품목별 통계", description = "VOC 품목별 통계 조회 API")
public class VocItemStatisticsController {

    private final VocItemStatisticsService vocItemStatisticsService;

    /**
     * 일별 품목 VOC 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 구조
     */
    @GetMapping("/daily/search")
    @Operation(summary = "일별 품목별 VOC 통계 조회", description = "일별 품목별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<ProductCategoryVocStatisticsDto>> getDailyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<ProductCategoryVocStatisticsDto> result = vocItemStatisticsService.getVocStatisticsByDay(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 주별 품목 VOC 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 구조
     */
    @GetMapping("/weekly/search")
    @Operation(summary = "주별 품목별 VOC 통계 조회", description = "주별 품목별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<ProductCategoryVocStatisticsDto>> getWeeklyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<ProductCategoryVocStatisticsDto> result = vocItemStatisticsService.getVocStatisticsByWeek(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 월별 품목 VOC 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 구조
     */
    @GetMapping("/monthly/search")
    @Operation(summary = "월별 품목별 VOC 통계 조회", description = "월별 품목별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<ProductCategoryVocStatisticsDto>> getMonthlyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<ProductCategoryVocStatisticsDto> result = vocItemStatisticsService.getVocStatisticsByMonth(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 연도별 품목 VOC 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 구조
     */
    @GetMapping("/yearly/search")
    @Operation(summary = "연도별 품목별 VOC 통계 조회", description = "연도별 품목별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<ProductCategoryVocStatisticsDto>> getYearlyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<ProductCategoryVocStatisticsDto> result = vocItemStatisticsService.getVocStatisticsByYear(condition);
        return ResponseEntity.ok(result);
    }

}

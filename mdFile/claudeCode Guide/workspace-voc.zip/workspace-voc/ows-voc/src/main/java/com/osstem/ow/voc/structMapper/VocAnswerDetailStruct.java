package com.osstem.ow.voc.structMapper;

import com.osstem.ow.voc.entity.VocAnswerDetail;
import com.osstem.ow.voc.model.request.VocAnswerRequestDto;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface VocAnswerDetailStruct extends StructMapper<VocAnswerDetail, VocAnswerDetailDto> {
    VocAnswerRequestDto toVocAnswerRequestDto(VocAnswerDetail vocAnswerDetail);
}
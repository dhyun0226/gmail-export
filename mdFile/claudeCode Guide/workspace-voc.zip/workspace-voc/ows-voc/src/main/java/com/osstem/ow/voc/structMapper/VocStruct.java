package com.osstem.ow.voc.structMapper;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.model.table.VocDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface VocStruct extends StructMapper<Voc, VocDto> {

}
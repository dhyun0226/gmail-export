package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "TB_VOC_CHG_H")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocChangeHistory extends BaseEntity {

    @EmbeddedId
    private VocChangeHistoryId id;

    @Column(name = "VOC_CTG_CD", length = 12, nullable = false)
    private String vocCategoryCode;

    @Column(name = "VOC_CHPR_NO")
    private Long vocChargePersonNumber;

    @Column(name = "ITM_CD", length = 90)
    private String itemCode;

    @Column(name = "VOC_ITM_NM", length = 100)
    private String vocItemName;

    @Column(name = "VOC_TTL", length = 100, nullable = false)
    private String vocTitle;

    @Column(name = "VOC_CN", length = 2000, nullable = false)
    private String vocContent;

    @Column(name = "VOC_SALE_CHPR_CPRN_CD", length = 3)
    private String vocSaleChargeCorporationCode;

    @Column(name = "VOC_SALE_CHPR_DEPT_CD", length = 30)
    private String vocSaleChargeDepartmentCode;

    @Column(name = "VOC_SALE_CHPR_EMP_NO", length = 60)
    private String vocSaleChargeEmployeeNumber;

    @Column(name = "BIZ_RQST_NO")
    private Long businessRequestNumber;

    @Column(name = "ASGNMT_PRCS_NO")
    private Long assignmentProcedureNumber;

    @Column(name = "END_RSN", length = 500)
    private String endReason;

    @Column(name = "VOC_STACD", length = 2, nullable = false)
    private String vocStateCode;


    @Column(name = "VOC_CMPL_TYCD", length = 2)
    private String vocCompletionTypeCode;

    @Column(name = "CHG_PROCR_CPRN_CD", length = 3)
    private String changeProcessorCorporationCode;

    @Column(name = "CHG_PROCR_DEPT_CD", length = 30)
    private String changeProcessorDepartmentCode;

    @Column(name = "CHG_PROCR_EMP_NO", length = 60)
    private String changeProcessorEmployeeNumber;

    @Column(name = "VOC_DTLS_ITM_NM", length = 100)
    private String vocDetailsItemName;
}
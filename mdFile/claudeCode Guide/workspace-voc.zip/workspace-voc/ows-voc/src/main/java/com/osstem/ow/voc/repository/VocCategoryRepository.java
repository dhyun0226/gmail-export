package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VocCategoryRepository extends JpaRepository<VocCategory, String> {

    // 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
    List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);

    List<VocCategory> findAllByOrderBySortOrderAsc();

    // 특정 카테고리를 상위 카테고리로 갖는 하위 카테고리 존재 여부 확인
    boolean existsByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
}
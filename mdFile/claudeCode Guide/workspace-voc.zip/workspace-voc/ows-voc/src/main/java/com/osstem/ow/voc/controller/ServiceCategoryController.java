package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.feign.ServiceCategoryServiceClient;
import com.osstem.ow.voc.model.response.TaskCategoryResponseDto;
import com.osstem.ow.voc.model.table.ServiceCategoryDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/serviceCategories")
@RequiredArgsConstructor
public class ServiceCategoryController {

    private final ServiceCategoryServiceClient serviceCategoryServiceClient;

    /**
     * 모든 VOC 카테고리 조회
     */
    @GetMapping
    public ResponseEntity<List<ServiceCategoryDto>> getAllserviceCategoryCodes() {
        List<ServiceCategoryDto> serviceCategoryCodes = serviceCategoryServiceClient.getAllServiceCategoryCodes();
        return ResponseEntity.ok(serviceCategoryCodes);
    }

    /**
     * 특정 VOC 카테고리 조회
     */
    @GetMapping("/{serviceCategoryCode}")
    public ResponseEntity<ServiceCategoryDto> getVocCategoryById(@PathVariable String serviceCategoryCode) {
        ServiceCategoryDto ServiceCategoryDto = serviceCategoryServiceClient.getVocCategoryById(serviceCategoryCode);
        return ResponseEntity.ok(ServiceCategoryDto);
    }

    /**
     * 최상위 카테고리 목록 조회
     */
    @GetMapping("/root")
    public ResponseEntity<List<ServiceCategoryDto>> getRootCategories(@RequestParam(required = false) Character openYn) {
        List<ServiceCategoryDto> rootCategories = serviceCategoryServiceClient.getRootCategories(openYn);
        return ResponseEntity.ok(rootCategories);
    }

    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     * @param categoryCode 카테고리 코드
     * @return 해당 카테고리의 최상위 카테고리
     */
    @GetMapping("/{categoryCode}/root")
    public ResponseEntity<ServiceCategoryDto> getRootCategoryByCategoryCode(
            @PathVariable String categoryCode) {
        ServiceCategoryDto rootCategory = serviceCategoryServiceClient.getRootCategoryByCategoryCode(categoryCode);
        if (rootCategory != null) {
            return ResponseEntity.ok(rootCategory);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
     */
    @GetMapping("/{parentCategoryCode}/children")
    public ResponseEntity<List<ServiceCategoryDto>> getChildCategories(@PathVariable String parentCategoryCode) {
        List<ServiceCategoryDto> childCategories = serviceCategoryServiceClient.getChildCategories(parentCategoryCode);
        return ResponseEntity.ok(childCategories);
    }

    /**
     * 2레벨 카테고리 목록 조회 (distinct 적용)
     */
    @GetMapping("/second-level")
    public ResponseEntity<List<TaskCategoryResponseDto>> getSecondLevelCategories(
            @RequestParam(required = false) Character openYn) {
        List<TaskCategoryResponseDto> categories = serviceCategoryServiceClient.getSecondLevelCategories(openYn);
        return ResponseEntity.ok(categories);
    }

    /**
     * taskName으로 해당하는 2레벨 카테고리가 존재하는 1레벨 카테고리들을 조회
     * @param taskName 작업명
     * @param openYn 공개 여부 (기본값: 'Y')
     * @return 1레벨 카테고리 리스트
     */
    @GetMapping("/root/by-task")
    public ResponseEntity<List<ServiceCategoryDto>> getRootCategoriesByTaskName(
            @RequestParam String taskName,
            @RequestParam(defaultValue = "Y") Character openYn) {

        try {
            List<ServiceCategoryDto> categories = serviceCategoryServiceClient
                    .getRootCategoriesByTaskName(taskName, openYn);
            return ResponseEntity.ok(categories);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 사원 번호로 해당하는 서비스 카테고리 목록 조회
     * @return 서비스 카테고리 리스트
     */
    @GetMapping("/top-level/by-employee")
    public ResponseEntity<List<ServiceCategoryDto>> getTopLevelServiceCategoriesByEmployeeNumber(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestParam(required = false) String category){
        List<ServiceCategoryDto> serviceCategories = serviceCategoryServiceClient.getTopLevelServiceCategoriesByEmployeeNumber(userId, category);
        return ResponseEntity.ok(serviceCategories);
    }

    /**
     * 사원 번호로 해당하는 서비스 카테고리 목록 조회
     * @return 서비스 카테고리 리스트
     */
    @GetMapping("/by-employee")
    public ResponseEntity<List<ServiceCategoryDto>> getServiceCategoriesByEmployeeNumber(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestParam(required = false) String category) {
        List<ServiceCategoryDto> serviceCategories = serviceCategoryServiceClient.getServiceCategoriesByEmployeeNumber(userId, category);
        return ResponseEntity.ok(serviceCategories);
    }

}
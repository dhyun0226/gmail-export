package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.feign.NoticeServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.NoticeRequestDto;
import com.osstem.ow.voc.model.customer.NoticeResponseDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notices")
@RequiredArgsConstructor
public class NoticeController {

    private final NoticeServiceClient noticeServiceClient;

    @Operation(summary = "공지 생성", description = "새로운 공지를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "공지 생성 성공",
            content = @Content(schema = @Schema(implementation = NoticeResponseDto.class)))
    @PostMapping
    public ResponseEntity<NoticeResponseDto> create(
            @Parameter(description = "공지 생성 정보", required = true)
            @Valid @RequestBody NoticeRequestDto noticeRequestDto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(noticeServiceClient.createNotice(noticeRequestDto));
    }

    @Operation(summary = "공지 조회", description = "ID로 공지를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "공지 조회 성공",
            content = @Content(schema = @Schema(implementation = NoticeResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @GetMapping("/{noticeNumber}")
    public ResponseEntity<NoticeResponseDto> get(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber) {
        NoticeResponseDto noticeResponseDto = noticeServiceClient.getNoticeById(noticeNumber, "ADMIN");
        return ResponseEntity.ok(noticeResponseDto);
    }

    @Operation(summary = "공지 수정", description = "ID로 공지를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "공지 수정 성공",
            content = @Content(schema = @Schema(implementation = NoticeResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @PutMapping("/{noticeNumber}")
    public ResponseEntity<NoticeResponseDto> update(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber,
            @Parameter(description = "공지 수정 정보", required = true)
            @Valid @RequestBody NoticeRequestDto noticeRequestDto) {
        NoticeResponseDto updatedNotice = noticeServiceClient.updateNotice(noticeNumber, noticeRequestDto);
        return ResponseEntity.ok(updatedNotice);
    }

    @Operation(summary = "공지 삭제", description = "ID로 공지를 삭제합니다.")
    @ApiResponse(responseCode = "200", description = "공지 삭제 성공")
    @ApiResponse(responseCode = "404", description = "공지 없음")
    @DeleteMapping("/{noticeNumber}")
    public ResponseEntity<ResultDto<?>> delete(
            @Parameter(description = "공지 번호", required = true)
            @PathVariable Long noticeNumber) {
        noticeServiceClient.deleteNotice(noticeNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }


    @Operation(summary = "공지 검색", description = "조건에 맞는 공지 목록을 검색합니다.")
    @ApiResponse(responseCode = "200", description = "공지 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping
    public ResponseEntity<ResultDto<NoticeResponseDto>> search(NoticeRequestDto requestDto) {
        ResultDto<NoticeResponseDto> result = noticeServiceClient.search(requestDto);
        return ResponseEntity.ok(result);
    }
}

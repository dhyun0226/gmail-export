package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.CustomerEventService;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.EventRequestDto;
import com.osstem.ow.voc.model.customer.EventResponseDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/events")
@RequiredArgsConstructor
@Tag(name = "이벤트", description = "이벤트 API")
public class EventController {

    private final CustomerEventService customerEventService;

    @Operation(summary = "이벤트 조회", description = "ID로 이벤트를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 조회 성공",
            content = @Content(schema = @Schema(implementation = EventResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @GetMapping("/{eventNumber}")
    public ResponseEntity<EventResponseDto> getEvent(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber,
            @RequestParam String serviceCategoryCode) {
        EventResponseDto response = customerEventService.getEvent(eventNumber, serviceCategoryCode,"ADMIN");
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "이벤트 생성", description = "새로운 이벤트를 생성합니다.")
    @ApiResponse(responseCode = "201", description = "이벤트 생성 성공",
            content = @Content(schema = @Schema(implementation = EventResponseDto.class)))
    @PostMapping
    public ResponseEntity<EventResponseDto> createEvent(
            @Parameter(description = "이벤트 생성 정보", required = true)
            @Valid @RequestBody EventRequestDto requestDto) {
        EventResponseDto response = customerEventService.create(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @Operation(summary = "이벤트 수정", description = "ID로 이벤트를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 수정 성공",
            content = @Content(schema = @Schema(implementation = EventResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @PutMapping("/{eventNumber}")
    public ResponseEntity<EventResponseDto> updateEvent(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber,
            @Parameter(description = "이벤트 수정 정보", required = true)
            @Valid @RequestBody EventRequestDto requestDto) {
        EventResponseDto response = customerEventService.update(eventNumber, requestDto);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "이벤트 삭제", description = "ID로 이벤트를 삭제합니다.")
    @ApiResponse(responseCode = "204", description = "이벤트 삭제 성공")
    @ApiResponse(responseCode = "404", description = "이벤트 없음")
    @DeleteMapping("/{eventNumber}")
    public ResponseEntity<ResultDto<?>> deleteEvent(
            @Parameter(description = "이벤트 ID", required = true)
            @PathVariable Long eventNumber) {
        customerEventService.delete(eventNumber);
        return ResponseEntity.ok(new ResultDto<>());
    }

    @Operation(summary = "이벤트 검색", description = "조건에 맞는 이벤트 목록을 검색합니다.")
    @ApiResponse(responseCode = "200", description = "이벤트 검색 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping
    public ResponseEntity<ResultDto<EventResponseDto>> searchEvents(
            @Parameter(description = "이벤트 검색 조건", required = true)
            @Valid EventRequestDto requestDto) {
        ResultDto<EventResponseDto> response = customerEventService.search(requestDto);
        return ResponseEntity.ok(response);
    }
}
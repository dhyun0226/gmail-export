package com.osstem.ow.voc.constant;

public enum GroupType {
    REGISTER("REGISTERER","registererDeptCounts"),
    CHARGER("CHARGER","chargeDeptCounts" );

    private final String groupCode;
    private final String countCode;
    GroupType(String groupCode,String countCode) {
        this.groupCode = groupCode;
        this.countCode = countCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public String getCountCode() {
        return countCode;
    }
}

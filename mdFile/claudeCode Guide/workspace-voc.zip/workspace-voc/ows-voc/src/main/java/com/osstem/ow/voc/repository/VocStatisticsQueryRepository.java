package com.osstem.ow.voc.repository;
import com.osstem.ow.voc.constant.StatusType;
import com.osstem.ow.voc.entity.QVoc;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

@Repository
@RequiredArgsConstructor
public class VocStatisticsQueryRepository {

    private final JPAQueryFactory queryFactory;

    private static final String VOC_STATE_RECEIVED = "01"; // VOC 접수 상태 코드
    private final QVoc voc = QVoc.voc;

    public Map<String, Map<String, Integer>> getVocStatisticsByDayWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {


        // 부서별, 시간별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.registererDepartmentCode,
                        Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.registererDepartmentCode, Expressions.stringTemplate("hour({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    public Map<String, Map<String, Integer>> getVocStatisticsByWeekWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes
    ) {

        // 부서별, 요일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.registererDepartmentCode,
                        Expressions.stringTemplate("concat('d', weekday({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.registererDepartmentCode, Expressions.stringTemplate("weekday({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }


    public Map<String, Map<String, Integer>> getVocStatisticsByMonthWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.registererDepartmentCode,
                        Expressions.stringTemplate("concat('d', dayofmonth({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.registererDepartmentCode, Expressions.stringTemplate("dayofmonth({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    public Map<String, Map<String, Integer>> getVocStatisticsByYearWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 월별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.registererDepartmentCode,
                        Expressions.stringTemplate("concat('m', month({0}))", voc.vocRegistrationDateTime).as("monthKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.registererDepartmentCode, Expressions.stringTemplate("month({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 아이템 코드별 VOC 통계 (시간별)
     */
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndDayWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 아이템별, 시간별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.itemCode,
                        Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        voc.itemCode.isNotNull(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.itemCode, Expressions.stringTemplate("hour({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 아이템 코드별 VOC 통계 (요일별)
     */
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndWeekWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 아이템별, 요일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.itemCode,
                        Expressions.stringTemplate("concat('d', weekday({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        voc.itemCode.isNotNull(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.itemCode, Expressions.stringTemplate("weekday({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 아이템 코드별 VOC 통계 (일별)
     */
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndMonthWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 아이템별, 일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.itemCode,
                        Expressions.stringTemplate("concat('d', dayofmonth({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        voc.itemCode.isNotNull(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.itemCode, Expressions.stringTemplate("dayofmonth({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 아이템 코드별 VOC 통계 (월별)
     */
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndYearWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes
            ) {

        // 아이템별, 월별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        voc.itemCode,
                        Expressions.stringTemplate("concat('m', month({0}))", voc.vocRegistrationDateTime).as("monthKey"),
                        voc.count()
                )
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        voc.itemCode.isNotNull(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(voc.itemCode, Expressions.stringTemplate("month({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 시간별 VOC 담당자 통계 조회 (조건부)
     */
    public Map<String, Map<String, Integer>> getVocChargePersonStatisticsByDayWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 시간별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        vocChargePerson.vocChargePersonDepartmentCode,
                        Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"),
                        voc.count()
                )
                .from(voc)
                .leftJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode, Expressions.stringTemplate("hour({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 요일별 VOC 담당자 통계 조회 (조건부)
     */
    public Map<String, Map<String, Integer>> getVocChargePersonStatisticsByWeekWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 요일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        vocChargePerson.vocChargePersonDepartmentCode,
                        Expressions.stringTemplate("concat('d', weekday({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .leftJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode, Expressions.stringTemplate("weekday({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 일별 VOC 담당자 통계 조회 (조건부)
     */
    public Map<String, Map<String, Integer>> getVocChargePersonStatisticsByMonthWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 일별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        vocChargePerson.vocChargePersonDepartmentCode,
                        Expressions.stringTemplate("concat('d', dayofmonth({0}))", voc.vocRegistrationDateTime).as("dayKey"),
                        voc.count()
                )
                .from(voc)
                .leftJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode, Expressions.stringTemplate("dayofmonth({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }

    /**
     * 월별 VOC 담당자 통계 조회 (조건부)
     */
    public Map<String, Map<String, Integer>> getVocChargePersonStatisticsByYearWithConditions(
            LocalDateTime startDate,
            LocalDateTime endDate,
            String vocStateCode,
            String vocCategoryCode,
            String itemCode,
            List<String> chargerDepartmentCodes,
            List<String> registererDepartmentCodes) {

        // 부서별, 월별 VOC 건수 조회
        List<Tuple> results = queryFactory
                .select(
                        vocChargePerson.vocChargePersonDepartmentCode,
                        Expressions.stringTemplate("concat('m', month({0}))", voc.vocRegistrationDateTime).as("monthKey"),
                        voc.count()
                )
                .from(voc)
                .leftJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .where(
                        itemCodeEquals(itemCode),
                        vocStateCodeEquals(vocStateCode,isDay(startDate, endDate)),
                        registrationDateBetween(startDate, endDate),
                        vocCategoryCodeEquals(vocCategoryCode),
                        isNotDeleted(),
                        chargerDepartmentCodeIn(chargerDepartmentCodes),
                        registerDepartmentCodeIn(registererDepartmentCodes)
                )
                .groupBy(vocChargePerson.vocChargePersonDepartmentCode, Expressions.stringTemplate("month({0})", voc.vocRegistrationDateTime))
                .fetch();

        return mapResultsToStatistics(results);
    }



    /**
     * 쿼리 결과를 부서코드별 통계 맵으로 변환
     */
    private Map<String, Map<String, Integer>> mapResultsToStatistics(List<Tuple> results) {
        Map<String, Map<String, Integer>> departmentStatistics = new HashMap<>();

        for (Tuple tuple : results) {
            String departmentCode = tuple.get(0, String.class);
            String timeKey = tuple.get(1, String.class);
            Long count = tuple.get(2, Long.class);

            departmentStatistics
                    .computeIfAbsent(departmentCode, k -> new HashMap<>())
                    .put(timeKey, count.intValue());
        }

        return departmentStatistics;
    }

    /**
     * VOC 등록 상세 구분 코드 조건
     */
    private BooleanExpression vocCategoryCodeEquals(String code) {
        return code != null ? voc.vocCategoryCode.eq(code) : null;
    }

    private BooleanExpression itemCodeEquals(String itemCode) {
        // 1. null 체크 + 빈 문자열 체크
        if (itemCode == null || itemCode.isEmpty()) {
            return null;
        }

        return voc.itemCode.eq(itemCode);
    }

    private boolean isDay(LocalDateTime startDate, LocalDateTime endDate){
        boolean categoryEquals = false;

        if (startDate != null && endDate != null) {
            categoryEquals = startDate.toLocalDate().isEqual(endDate.toLocalDate());
        }

        return categoryEquals;
    }

    /**
     * VOC 상태 코드 조건
     */
    private BooleanExpression vocStateCodeEquals(String code, boolean isDay) {
        if (code == null) {
            return null;
        }

        // 만약 vocStateCode가 "02"이면 "01"과 "02" 둘 다 검색, 만약 일이면 접수, 처리중, 처리완료를 다 가져온다
        if (StatusType.PROCESSING.getStatusCode().equals(code)) {
            if(isDay){
                return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.PROCESSING.getStatusCode(), StatusType.COMPLETE.getStatusCode());
            }
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.PROCESSING.getStatusCode());
        }else if(StatusType.RECEIPT.getStatusCode().equals(code)){
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), StatusType.COMPLETE.getStatusCode());
        }

        // 그 외 경우에는 정확히 일치하는 코드만 검색
        return voc.vocStateCode.eq(code);
    }


    /**
     * 등록일자 범위 조건
     */
    private BooleanExpression registrationDateBetween(LocalDateTime startDate, LocalDateTime endDate) {
        return (startDate != null && endDate != null) ? voc.vocRegistrationDateTime.between(startDate, endDate) : null;
    }

    /**
     * 삭제되지 않은 VOC 조건
     */
    private BooleanExpression isNotDeleted() {
        return voc.deleteYesOrNo.ne("Y");
    }

    private BooleanExpression chargerDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return vocChargePerson.vocChargePersonDepartmentCode.in(departmentCodes);
    }

    private BooleanExpression registerDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return voc.registererDepartmentCode.in(departmentCodes);
    }
}
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_ANS_D")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocAnswerDetail extends BaseEntity {

    @Id
    @Column(name = "VOC_NO", nullable = false, updatable = false)
    private Long vocNumber;

    @Column(name = "VOC_ANS_DTM", nullable = false)
    private LocalDateTime vocAnswerDateTime;

    @Column(name = "VOC_ANS_CN", length = 1000)
    private String vocAnswerContent;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    @PrePersist
    protected void onCreate() {
        if (vocAnswerDateTime == null) {
            vocAnswerDateTime = LocalDateTime.now();
        }
    }
}
package com.osstem.ow.voc.domain;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ItemCodeMappingService {

    private Map<String, String> itemCodeToNameMap;

    /**
     * 서비스 초기화 시 품목 코드와 이름 매핑 정보 로드
     */
    @PostConstruct
    public void init() {
        itemCodeToNameMap = new HashMap<>();

        // 품목 코드와 한글 이름 매핑 설정
        itemCodeToNameMap.put("implant","임플란트");
        itemCodeToNameMap.put("instrument","기구");
        itemCodeToNameMap.put("endodontic","보존/근관");
        itemCodeToNameMap.put("restorative","수복/접착");
        itemCodeToNameMap.put("impression","인상/보철");
        itemCodeToNameMap.put("cutting", "절삭/연마");
        itemCodeToNameMap.put("gbr", "GBR");
        itemCodeToNameMap.put("hygiene", "위생용품");
        itemCodeToNameMap.put("equipment", "장비");
        itemCodeToNameMap.put("orthodontic", "교정용기구");
        itemCodeToNameMap.put("prevention", "예방/구강");
        itemCodeToNameMap.put("dentalLab", "기공용품");
        itemCodeToNameMap.put("medicine", "의약품");
        itemCodeToNameMap.put("appliance", "생활가전");

    }

    /**
     * 품목 코드로부터 사용자 친화적인 이름 조회
     *
     * @param itemCode 품목 코드
     * @return 품목 이름 (매핑 정보가 없는 경우 품목 코드 그대로 반환)
     */
    public String getItemNameByCode(String itemCode) {
        return itemCodeToNameMap.getOrDefault(itemCode, itemCode);
    }
}

package com.osstem.ow.voc.feign;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.FaqRequestDto;
import com.osstem.ow.voc.model.customer.FaqResponseDto;
import com.osstem.ow.voc.model.customer.FaqResponseWrapper;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "faqServiceClient", url = "${voc.api.occ.root.uri}")
public interface FaqServiceClient {

    @GetMapping("/faqs")
    ResultDto<FaqResponseDto> getAllFaqs(@SpringQueryMap FaqRequestDto dto);

    @GetMapping("/faqs/{id}")
    FaqResponseDto getFaqById(@PathVariable("id") Long id);

    @PostMapping("/faqs")
    FaqResponseDto createFaq(@RequestBody FaqRequestDto dto);

    @PutMapping("/faqs/{id}")
    FaqResponseDto updateFaq(@PathVariable("id") Long id, @RequestBody FaqRequestDto dto);

    @DeleteMapping("/faqs/{id}")
    void deleteFaq(@PathVariable("id") Long id);
}
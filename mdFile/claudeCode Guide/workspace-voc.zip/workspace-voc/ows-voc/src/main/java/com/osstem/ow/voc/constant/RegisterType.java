package com.osstem.ow.voc.constant;

public enum RegisterType {
    EMPLOYEE("01"),
    MEMBER("02"),
    NONMEMBER("03");

    private final String registerCode;

    RegisterType(String registerCode) {
        this.registerCode = registerCode;
    }

    public String getStatusCode() {
        return registerCode;
    }
}

package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.entity.VocChargePerson;
import com.osstem.ow.voc.exception.BusinessException;
import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.model.common.EmployeeRequestDto;
import com.osstem.ow.voc.model.common.EmployeeResponseDto;
import com.osstem.ow.voc.model.response.VocChargePersonResponseDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import com.osstem.ow.voc.repository.VocChargePersonRepository;
import com.osstem.ow.voc.structMapper.VocChargePersonStruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VocChargePersonService {

    private final VocChargePersonRepository vocChargePersonRepository;
    private final VocChargePersonStruct vocChargePersonStruct;
    private final CommonServiceClient commonServiceClient;

    /**
     * VOC 담당자 번호로 단건 조회합니다.
     *
     * @param vocChargePersonNumber VOC 담당자 번호
     * @return VOC 담당자 정보
     */
    @Transactional(readOnly = true)
    public VocChargePersonDto findById(Long vocChargePersonNumber) {
        VocChargePerson vocChargePerson = vocChargePersonRepository.findById(vocChargePersonNumber)
                .orElseThrow(() -> new BusinessException("vocChargePerson.notFound"));
        return vocChargePersonStruct.toDto(vocChargePerson);
    }

    @Transactional(readOnly = true)
    public List<String> findByEmployeeNumber(String employeeNumber) {
        List<VocChargePerson> vocChargePersons = vocChargePersonRepository.findByVocChargePersonEmployeeNumber(employeeNumber);
        return vocChargePersons.stream()
                .map(VocChargePerson::getVocCategoryCode)
                .toList();
    }


    @Transactional(readOnly = true)
    public VocChargePersonDto findRepresentativePersonInCharge(String vocCategoryCode) {
        VocChargePerson vocChargePerson = vocChargePersonRepository.findByVocCategoryCodeAndVocDesignationThePersonInChargeYn
                        ("DVOC_VOC_015", "T")
                .orElseThrow(() -> new BusinessException("vocChargePerson.notFound"));
        return vocChargePersonStruct.toDto(vocChargePerson);
    }

    /**
     * 신규 VOC 담당자를 등록합니다.
     *
     * @param vocChargePersonDto VOC 담당자 정보
     * @return 등록된 VOC 담당자 정보
     */
    @Transactional
    public VocChargePersonDto create(VocChargePersonDto vocChargePersonDto) {
        // DTO를 Entity로 변환
        VocChargePerson vocChargePerson = vocChargePersonStruct.toEntity(vocChargePersonDto);

        // Entity 저장
        VocChargePerson savedVocChargePerson = vocChargePersonRepository.save(vocChargePerson);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocChargePersonStruct.toDto(savedVocChargePerson);
    }

    /**
     * VOC 담당자 정보를 수정합니다.
     *
     * @param vocChargePersonNumber VOC 담당자 번호
     * @param vocChargePersonDto    수정할 VOC 담당자 정보
     * @return 수정된 VOC 담당자 정보
     */
    @Transactional
    public VocChargePersonDto update(Long vocChargePersonNumber, VocChargePersonDto vocChargePersonDto) {
        // 기존 VOC 담당자 조회
        VocChargePerson existingVocChargePerson = vocChargePersonRepository.findById(vocChargePersonNumber)
                .orElseThrow(() -> new BusinessException("vocChargePerson.notFound"));

        // DTO를 Entity로 변환하여 업데이트
        VocChargePerson updatedVocChargePerson = vocChargePersonStruct.toEntity(vocChargePersonDto);

        // 중요 필드 검증 및 업데이트 처리
        if (!vocChargePersonNumber.equals(updatedVocChargePerson.getVocChargePersonNumber())) {
            throw new BusinessException("vocChargePerson.invalidVocChargePersonNumber");
        }

        // Entity 저장
        VocChargePerson savedVocChargePerson = vocChargePersonRepository.save(updatedVocChargePerson);

        // 저장된 Entity를 DTO로 변환하여 반환
        return vocChargePersonStruct.toDto(savedVocChargePerson);
    }

    @Transactional
    public void updateVocChargePersons(List<VocChargePersonDto> vocChargePersonDtos) {
        for (VocChargePersonDto dto : vocChargePersonDtos) {
            // 기존 VOC 담당자 조회
            VocChargePerson existingVocChargePerson = vocChargePersonRepository.findById(dto.getVocChargePersonNumber())
                    .orElseThrow(() -> new BusinessException("vocChargePerson.notFound"));

            // Entity 업데이트
            existingVocChargePerson.setVocDesignationThePersonInChargeYn(dto.getVocDesignationThePersonInChargeYn());

            // 변경된 Entity 저장
            vocChargePersonRepository.save(existingVocChargePerson);
        }
    }

    /**
     * VOC 담당자를 삭제합니다.
     *
     * @param vocChargePersonNumber VOC 담당자 번호
     */
    @Transactional
    public void delete(Long vocChargePersonNumber) {
        // 기존 VOC 담당자 조회
        VocChargePerson vocChargePerson = vocChargePersonRepository.findById(vocChargePersonNumber)
                .orElseThrow(() -> new BusinessException("vocChargePerson.notFound"));

        // VOC 담당자 삭제
        vocChargePersonRepository.delete(vocChargePerson);
    }


    @Transactional(readOnly = true)
    public List<VocChargePersonResponseDto> findByVocCategoryCode(String vocCategoryCode) {
        List<VocChargePerson> vocChargePersons = vocChargePersonRepository.findByVocCategoryCode(vocCategoryCode);
        return vocChargePersonStruct.toResponseDtoList(vocChargePersons);
    }
}
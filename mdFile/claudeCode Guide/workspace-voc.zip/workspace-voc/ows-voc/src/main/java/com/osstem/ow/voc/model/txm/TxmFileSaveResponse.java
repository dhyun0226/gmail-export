package com.osstem.ow.voc.model.txm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TxmFileSaveResponse {
    private boolean data;
    private Integer status;
    private String code;
    private String message;
}

package com.osstem.ow.voc.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.osstem.ow.voc.model.statistic.OrganizationVocStatisticsDto;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrganizationResponseDto {
    private List<OrganizationVocStatisticsDto> data;
    private Integer status;
    private String code;
    private String message;

}

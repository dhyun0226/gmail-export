package com.osstem.ow.voc.model.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "공지 DTO")
public class NoticeRequestDto extends BaseDto {

    @Schema(description = "공지 번호", example = "1")
    private Long noticeNumber;

    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "공지 등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @NotBlank
    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "공개 여부", example = "Y")
    private String openYn;

    @NotBlank
    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "상단 고정 여부", example = "N")
    private String topFixedYn;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "공지 제목", example = "시스템 점검 안내")
    private String noticeTitle;

    @NotBlank
    @Schema(description = "공지 내용", example = "안녕하세요. 시스템 점검이 예정되어 있습니다. 자세한 내용은...")
    private String noticeContent;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @NotBlank
    @Size(max = 30)
    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @NotBlank
    @Size(max = 60)
    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "공지 등록 일시", example = "2025-04-04T09:00:00")
    private LocalDateTime noticeRegistrationDatetime;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file789")
    private String fileId;

    @Schema(description = "조회 건수", example = "157")
    private Short inquiryCount;

    @Schema(description = "파일 리스트")
    private List<TxmFileSaveRequest> fileList;

    @Schema(description = "시작일", example = "2025-01-01")
    private LocalDateTime fromDate;

    @Schema(description = "종료일", example = "2025-04-04")
    private LocalDateTime toDate;

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @Schema(description = "검색 타입 (title:제목, content:내용, both:제목+내용)", example = "both")
    private String searchType;

    @Schema(description = "검색 키워드", example = "문의합니다")
    private String keyword;

}

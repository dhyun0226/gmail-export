package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.voc.model.common.EmployeeResponseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 담당자 변경 응답 DTO")
public class VocChargePersonResponseDto {

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Schema(description = "품목 코드")
    private String itemCode;

    @Schema(description = "VOC 담당자 법인 코드")
    private String vocChargePersonCorporationCode;

    @Schema(description = "VOC 담당자 부서 코드")
    private String vocChargePersonDepartmentCode;

    @Schema(description = "VOC 담당자 사원 번호")
    private String vocChargePersonEmployeeNumber;

    @Schema(description = "VOC 지정 담당자 여부")
    private String vocDesignationThePersonInChargeYn;

    @Schema(description = "VOC 담당자 부서명")
    private String vocChargePersonDepartmentName;

    @Schema(description = "VOC 담당자 사원명")
    private String vocChargePersonEmployeeName;
}
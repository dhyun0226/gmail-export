package com.osstem.ow.voc.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "서비스 담당자 요청 DTO")
public class ServiceChargePersonRequestDto {

    @Schema(description = "서비스 담당자 번호")
    private Long serviceChargePersonNumber;

    @Schema(description = "서비스 담당자 이름")
    private String serviceChargePersonName;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "서비스 카테고리 코드")
    private String serviceCategoryCode;

    @Size(max = 90)
    @Schema(description = "품목 코드")
    private String itemCode;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "서비스 담당자 법인 코드")
    private String serviceChargePersonCorporationCode;

    @NotBlank
    @Size(max = 30)
    @Schema(description = "서비스 담당자 부서 코드")
    private String serviceChargePersonDepartmentCode;

    @Size(max = 60)
    @Schema(description = "서비스 담당자 사원 번호")
    private String serviceChargePersonEmployeeNumber;

    @Schema(description = "서비스 담당자 부서명")
    private String serviceChargePersonDepartmentName;

    @Schema(description = "서비스 담당자 사원명")
    private String serviceChargePersonEmployeeName;

    @NotBlank
    @Size(max = 1)
    @Schema(description = "지정 담당자 여부")
    private String serviceDesignationThePersonInChargeYn;

    @Size(max = 1)
    @Schema(description = "삭제 여부")
    private String deleteYn;
}
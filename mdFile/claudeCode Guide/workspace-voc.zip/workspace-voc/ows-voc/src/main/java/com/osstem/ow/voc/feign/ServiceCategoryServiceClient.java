
package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.response.TaskCategoryResponseDto;
import com.osstem.ow.voc.model.table.ServiceCategoryDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "serviceCategoryServiceClient", url = "${voc.api.occ.root.uri}", configuration = FeignClientConfig.class)
public interface ServiceCategoryServiceClient {

    /**
     * 모든 VOC 카테고리 조회
     */
    @GetMapping("/serviceCategories")
    List<ServiceCategoryDto> getAllServiceCategoryCodes();

    /**
     * 특정 VOC 카테고리 조회
     */
    @GetMapping("/serviceCategories/{serviceCategoryCode}")
    ServiceCategoryDto getVocCategoryById(@PathVariable("serviceCategoryCode") String serviceCategoryCode);

    /**
     * 최상위 카테고리 목록 조회
     */
    @GetMapping("/serviceCategories/root")
    List<ServiceCategoryDto> getRootCategories(@RequestParam(required = false) Character openYn);

    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     */
    @GetMapping("/serviceCategories/{categoryCode}/root")
    ServiceCategoryDto getRootCategoryByCategoryCode(@PathVariable("categoryCode") String categoryCode);

    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
     */
    @GetMapping("/serviceCategories/{parentCategoryCode}/children")
    List<ServiceCategoryDto> getChildCategories(@PathVariable("parentCategoryCode") String parentCategoryCode);

    /**
     * 2레벨 카테고리 목록 조회 (distinct 적용)
     */
    @GetMapping("/serviceCategories/second-level")
    List<TaskCategoryResponseDto> getSecondLevelCategories(@RequestParam(required = false) Character openYn);

    /**
     * taskName으로 해당하는 2레벨 카테고리가 존재하는 1레벨 카테고리들을 조회
     */
    @GetMapping("/serviceCategories/root/by-task")
    List<ServiceCategoryDto> getRootCategoriesByTaskName(
            @RequestParam String taskName,
            @RequestParam(defaultValue = "Y") Character openYn);

    @GetMapping("/serviceCategories/top-level/by-employee/{employeeNumber}")
    List<ServiceCategoryDto> getTopLevelServiceCategoriesByEmployeeNumber(@PathVariable("employeeNumber") String employeeNumber, @RequestParam(required = false) String category);

    @GetMapping("/serviceCategories/by-employee/{employeeNumber}")
    List<ServiceCategoryDto> getServiceCategoriesByEmployeeNumber(@PathVariable("employeeNumber") String employeeNumber,
                                                                 @RequestParam(required = false) String category);

}
package com.osstem.ow.voc.model.statistic;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
public class ProductCategoryVocStatisticsDto {

    // 트리 구조 관련 필드
    private String key;                 // 노드 키
    private String parentId;            // 부모 노드 ID
    private String display;             // 화면 표시명
    private boolean expanded = false;   // 확장 여부

    // 제품 카테고리 정보
    private String deptCode;            // 부서 코드
    private String deptName;            // 부서 이름
    private String itemCode;            // 아이템 코드

    // 통계 정보
    private Map<String, Integer> statistics = new HashMap<>();  // 통계 데이터 (시간/요일/일/월별 VOC 건수)
    private int totalCount = 0;         // 총 VOC 건수
}
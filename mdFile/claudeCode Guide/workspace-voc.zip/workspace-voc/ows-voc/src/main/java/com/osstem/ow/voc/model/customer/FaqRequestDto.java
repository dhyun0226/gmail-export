package com.osstem.ow.voc.model.customer;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "FAQ 요청 DTO")
public class FaqRequestDto {

    @Schema(description = "FAQ 번호", example = "1")
    private Long faqNumber;

    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @Size(max = 12)
    @Schema(description = "FAQ 등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Size(max = 100)
    @Schema(description = "FAQ 제목", example = "회원가입은 어떻게 하나요?")
    private String faqTitle;

    @Size(max = 2000)
    @Schema(description = "FAQ 내용", example = "회원가입은 홈페이지 우측 상단의 회원가입 버튼을 클릭한 뒤...")
    private String faqContent;

    @Size(max = 3)
    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Size(max = 30)
    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file012")
    private String fileId;

    @Schema(description = "정렬 순서", example = "10")
    private BigDecimal sortOrder;

    @Pattern(regexp = "[YN]")
    @Size(max = 1)
    @Schema(description = "사용 여부", example = "Y")
    private String useYn;

    @Schema(description = "시작일", example = "2025-01-01")
    private LocalDateTime fromDate;

    @Schema(description = "종료일", example = "2025-04-04")
    private LocalDateTime toDate;

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @Schema(description = "검색 타입 (title:제목, content:내용, both:제목+내용)", example = "both")
    private String searchType;

    @Schema(description = "검색 키워드", example = "문의합니다")
    private String keyword;

}
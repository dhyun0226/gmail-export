package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.IndividualInquiryServiceClient;
import com.osstem.ow.voc.model.event.IndividualInquiryAnswerDto;
import com.osstem.ow.voc.model.request.IndividualInquiryRequestDto;
import com.osstem.ow.voc.model.response.IndividualInquiryResponseDto;
import com.osstem.ow.voc.model.base.ResultDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class IndividualInquiryService {

    private final IndividualInquiryServiceClient individualInquiryServiceClient;

    public ResultDto<IndividualInquiryResponseDto> search( IndividualInquiryRequestDto requestDto, String userId, String corporationCode) {
        return individualInquiryServiceClient.list(requestDto, userId, corporationCode);
    }

    public IndividualInquiryResponseDto getInquiryWithAnswer(Long inquiryNumber, String userId) {
        return individualInquiryServiceClient.getInquiryWithAnswer(userId, inquiryNumber);
    }

    public IndividualInquiryAnswerDto createAnswer(IndividualInquiryAnswerDto answerDto) {
        return individualInquiryServiceClient.createAnswer(answerDto);
    }
    public IndividualInquiryAnswerDto update(Long inquiryNumber, IndividualInquiryAnswerDto answerDto) {
        answerDto.setIndividualInquiryAnswerDatetime(LocalDateTime.now());
        return individualInquiryServiceClient.update(inquiryNumber, answerDto);
    }
}
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.EventServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.EventRequestDto;
import com.osstem.ow.voc.model.customer.EventResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerEventService {

    private final EventServiceClient eventServiceClient;

    private final VocChargePersonService vocChargePersonService;

    public EventResponseDto getEvent(Long id, String serviceCategoryCode,  String userRole) {
        return eventServiceClient.getEventById(id, serviceCategoryCode,userRole);
    }

    public EventResponseDto create(EventRequestDto dto) {
        return eventServiceClient.createEvent(dto);
    }

    public EventResponseDto update(Long id, EventRequestDto dto) {
        return eventServiceClient.updateEvent(id, dto);
    }

    public void delete(Long id) {
        eventServiceClient.deleteEvent(id);
    }

    public ResultDto<EventResponseDto> search(EventRequestDto dto) {
        return eventServiceClient.searchEvents(dto);
    }
}

package com.osstem.ow.voc.model.customer;


import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Schema(description = "이벤트 답변 요청 DTO")
public class EventAnswerRequestDto {

    @Schema(description = "이벤트 번호", example = "1")
    private Long eventNumber;

    @Schema(description = "이벤트 참여 일시", example = "2024-01-01T10:00:00")
    private LocalDateTime eventParticipationDatetime;

    @Size(max = 20)
    @Schema(description = "참여자 회원 ID", example = "user123")
    private String participantMemberId;

    @Size(max = 1000)
    @Schema(description = "이벤트 참여 내용", example = "이벤트에 참여합니다.")
    private String eventParticipationContent;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file123")
    private String fileId;

    @Schema(description = "삭제 여부", example = "Y")
    private String deleteYesOrNo;

}
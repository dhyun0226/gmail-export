package com.osstem.ow.voc.model.statistic;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentInfo {
    private String deptCode;    // 부서 코드
    private String deptName;    // 부서명
    private String corpCode;    // 법인 코드
}

package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.txm.TxmFileListRequest;
import com.osstem.ow.voc.model.txm.TxmFileListResponse;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import com.osstem.ow.voc.model.txm.TxmFileSaveResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@FeignClient(name = "txmClient", url = "${voc.api.txm.root.uri}", configuration = FeignClientConfig.class)
public interface TxmServiceClient {
    @PostMapping("/file/save")
    TxmFileSaveResponse saveFile(List<TxmFileSaveRequest> request);

    @PostMapping("/file/removeByReference")
    TxmFileSaveResponse deleteFile(TxmFileSaveRequest request);

    @GetMapping("/file/getList")
    TxmFileListResponse getFileList(@SpringQueryMap TxmFileListRequest requests);

    @PostMapping("/file/removeByReference")
    TxmFileSaveResponse removeByReference(List<TxmFileListRequest> request);

    @PostMapping("/file/removeByFileId")
    TxmFileSaveResponse removeByFileId(List<TxmFileListRequest> request);
}

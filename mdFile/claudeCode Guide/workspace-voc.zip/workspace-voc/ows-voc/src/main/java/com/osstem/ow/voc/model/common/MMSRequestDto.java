package com.osstem.ow.voc.model.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class MMSRequestDto {

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private LocalDateTime dateClientRequest;

    private String recipientNum;  // 수신자 번호

    private String callback;      // 발신자 번호

    private String subject;       // MMS 제목

    private String content;       // MMS 내용

    private String msgStatus;     // 메시지 상태 코드

    private String serviceType;   // 서비스 타입 코드
}
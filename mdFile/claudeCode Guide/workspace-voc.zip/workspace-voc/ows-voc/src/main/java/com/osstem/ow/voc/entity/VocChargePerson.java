package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "TB_VOC_CHPR_M")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocChargePerson extends BaseEntity {

    @Id
    @Column(name = "VOC_CHPR_NO", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vocChargePersonNumber;

    @NotNull
    @Size(max = 12)
    @Column(name = "VOC_CTG_CD", length = 12, nullable = false)
    private String vocCategoryCode;

    @Setter
    @Size(max = 90)
    @Column(name = "ITM_CD", length = 90)
    private String itemCode;

    @Setter
    @NotNull
    @Size(max = 3)
    @Column(name = "VOC_CHPR_CPRN_CD", length = 3, nullable = false)
    private String vocChargePersonCorporationCode;

    @Setter
    @NotNull
    @Size(max = 30)
    @Column(name = "VOC_CHPR_DEPT_CD", length = 30, nullable = false)
    private String vocChargePersonDepartmentCode;

    @Setter
    @Size(max = 60)
    @Column(name = "VOC_CHPR_EMP_NO", length = 60)
    private String vocChargePersonEmployeeNumber;

    @Setter
    @NotNull
    @Size(max = 30)
    @Column(name = "VOC_CHPR_DEPT_NM", length = 500, nullable = false)
    private String vocChargePersonDepartmentName;

    @Setter
    @Size(max = 60)
    @Column(name = "VOC_CHPR_EMP_NM", length = 100)
    private String vocChargePersonEmployeeName;

    @Setter
    @Size(max = 1)
    @Column(name = "VOC_DSNT_CHPR_YN", length = 1)
    private String vocDesignationThePersonInChargeYn;

    @Setter
    @Size(max = 1)
    @Column(name = "DEL_YN", length = 1)
    private String deleteYn;


}
package com.osstem.ow.voc.model.response;

import com.osstem.ow.voc.model.txm.File;
import com.osstem.ow.voc.model.txm.TxmFileListResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "개인문의 응답")
public class IndividualInquiryResponseDto {

    @Schema(description = "개인문의 번호", example = "1000")
    private Long individualInquiryNumber;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Schema(description = "품목 코드", example = "ITEM001")
    private String itemCode;

    @Schema(description = "회원 여부", example = "Y")
    private String memberYn;

    @Schema(description = "작성자 회원 ID", example = "user123")
    private String writerMemberId;

    @Schema(description = "VOC 작성자명", example = "홍길동")
    private String vocWriterName;

    @Schema(description = "작성자 이메일 주소", example = "user@example.com")
    private String writerEmailAddress;

    @Schema(description = "작성자 전화번호", example = "02-1234-5678")
    private String writerTelephoneNumber;

    @Schema(description = "작성자 휴대전화번호", example = "010-1234-5678")
    private String writerHandPhoneNumber;

    @Schema(description = "개인문의 제목", example = "서비스 이용 문의")
    private String individualInquiryTitle;

    @Schema(description = "개인문의 내용", example = "서비스 이용 중 문제가 발생했습니다.")
    private String individualInquiryContent;

    @Schema(description = "개인문의 등록 일시", example = "2024.01.11")
    private LocalDateTime individualInquiryRegistrationDatetime;

    @Schema(description = "개인문의 변경 일시", example = "2024.01.11 15:30:00")
    private LocalDateTime individualInquiryChangeDatetime;

    @Schema(description = "개인정보 수집 이용 약관 동의 여부", example = "Y")
    private String individualInformationCollectionTermsOfUseAgreementYesOrNo;

    @Schema(description = "파일 ID", example = "FILE001")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;

    @Schema(description = "처리 상태", example = "true")
    private Boolean processStatus;

    // 답변 정보 필드
    @Schema(description = "답변자 법인 코드", example = "C001")
    private String answererCorporationCode;

    @Schema(description = "답변자 부서 코드", example = "D001")
    private String answererDepartmentCode;

    @Schema(description = "답변자 사원 번호", example = "E001")
    private String answererEmployeeNumber;

    @Schema(description = "개인문의 답변 내용", example = "문의 내용에 대한 답변입니다.")
    private String individualInquiryAnswerContent;

    @Schema(description = "개인문의 답변 일시", example = "2024.01.12 10:30")
    private LocalDateTime individualInquiryAnswerDatetime;

    @Schema(description = "답변 파일 ID", example = "FILE002")
    private String answerFileId;

    @Schema(description = "파일 리스트")
    private List<File> answerFileList;

    public void setFileList(TxmFileListResponse txmFileListResponse) {
        if (txmFileListResponse != null) {
            this.fileList = txmFileListResponse.getData();
        } else {
            this.fileList = List.of(); // 빈 리스트로 초기화
        }
    }

    public void setAnswerFileList(TxmFileListResponse txmFileListResponse) {
        if (txmFileListResponse != null) {
            this.answerFileList = txmFileListResponse.getData();
        } else {
            this.answerFileList = List.of(); // 빈 리스트로 초기화
        }
    }

    public void setProcessStatus(Boolean processStatus) {
        this.processStatus = processStatus;
    }

}

package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GroupedVocResponseDto {

    private boolean isHeader;                        // 헤더 여부 (true: 헤더, false: VOC 데이터)
    private String itemCode;                         // 코드
    private String itemName;                         // 이름 (사용자가 읽기 쉬운 형태)
    private Long itemCount;                          // VOC 건수 (헤더일 경우만 사용)

    // VOC 필드 (isHeader=true일 경우 null)
    private Long vocNumber;                          // VOC 번호
    private Long vocChargePersonNumber;              // VOC 담당자 번호
    private String vocChargePersonName;              // VOC 담당자 이름
    private String vocChargePersonEmployeeNumber;    // VOC 담당자 사번
    private String vocChargePersonEmployeeName;
    private String serviceCategoryCode;                  // VOC 등록 상세 구분 코드
    private String vocRegistererDivisionCode;        // VOC 등록자 구분 코드
    private String registererMemberId;               // 등록자 회원 ID
    private String vocCustomerName;                  // VOC 고객 이름
    private String vocCustomerEmailAddress;          // VOC 고객 이메일 주소
    private String vocCustomerTelephoneNumber;       // VOC 고객 전화번호
    private String vocCustomerHandPhoneNumber;       // VOC 고객 휴대폰 번호
    private String vocTitle;                         // VOC 제목
    private String vocContent;                       // VOC 내용
    private String vocSaleChargeCorporationCode;     // VOC 영업 담당자 법인 코드
    private String vocSaleChargeDepartmentCode;      // VOC 영업 담당자 부서 코드
    private String vocSaleChargeEmployeeNumber;      // VOC 영업 담당자 사원 번호
    private String vocFileId;                        // VOC 파일 ID
    private String vocCompletionTypeCode;            // VOC 완료 유형 코드
    private String vocStateCode;                     // VOC 상태 코드
    private LocalDateTime vocRegistrationDateTime;   // VOC 등록 일시
    private Long denallVocNumber;                    // 원천 VOC 번호
    private String registererCorporationCode;         // 등록자 법인 코드
    private String registererEmployeeNumber;          // 등록자 사원 번호
    private String vocSaleChargeDepartmentName;          // 등록자 부서명
    private String vocSaleChargeEmployeeName;            // 등록자 사원명

    // 헤더용 생성자
    // 헤더용 생성자
    private GroupedVocResponseDto(String itemCode, String itemName, Long itemCount) {
        this.isHeader = true;
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.itemCount = itemCount;
    }

    // VOC 데이터용 생성자
    private GroupedVocResponseDto(VocResponseDto vocResponseDto) {
        this.isHeader = false;
        this.itemCode = vocResponseDto.getItemCode();
        this.vocNumber = vocResponseDto.getVocNumber();
        this.vocChargePersonNumber = vocResponseDto.getVocChargePersonNumber();
        this.vocChargePersonName = vocResponseDto.getVocChargePersonName();
        this.vocChargePersonEmployeeNumber = vocResponseDto.getVocChargePersonEmployeeNumber();
        this.serviceCategoryCode = vocResponseDto.getVocCategoryCode();
        this.vocRegistererDivisionCode = vocResponseDto.getVocRegistererDivisionCode();
        this.registererMemberId = vocResponseDto.getRegistererMemberId();
        this.vocCustomerName = vocResponseDto.getVocCustomerName();
        this.vocCustomerEmailAddress = vocResponseDto.getVocCustomerEmailAddress();
        this.vocCustomerTelephoneNumber = vocResponseDto.getVocCustomerTelephoneNumber();
        this.vocCustomerHandPhoneNumber = vocResponseDto.getVocCustomerHandPhoneNumber();
        this.vocTitle = vocResponseDto.getVocTitle();
        this.vocContent = vocResponseDto.getVocContent();
        this.vocSaleChargeCorporationCode = vocResponseDto.getVocSaleChargeCorporationCode();
        this.vocSaleChargeDepartmentCode = vocResponseDto.getVocSaleChargeDepartmentCode();
        this.vocSaleChargeEmployeeNumber = vocResponseDto.getVocSaleChargeEmployeeNumber();
        this.vocFileId = vocResponseDto.getVocFileId();
        this.vocCompletionTypeCode = vocResponseDto.getVocCompletionTypeCode();
        this.vocStateCode = vocResponseDto.getVocStateCode();
        this.vocRegistrationDateTime = vocResponseDto.getVocRegistrationDateTime();
        this.denallVocNumber = vocResponseDto.getDenallVocNumber();
        this.registererCorporationCode = vocResponseDto.getRegistererCorporationCode();
        this.registererEmployeeNumber = vocResponseDto.getRegistererEmployeeNumber();
        this.vocSaleChargeDepartmentName = vocResponseDto.getVocSaleChargeDepartmentName();
        this.vocSaleChargeEmployeeName = vocResponseDto.getVocSaleChargeEmployeeName();
    }

    // 헤더 생성을 위한 정적 팩토리 메서드
    public static GroupedVocResponseDto createHeader(String itemCode, String itemName, Long itemCount) {
        return new GroupedVocResponseDto(itemCode, itemName, itemCount);
    }

    // 상세 항목 생성을 위한 정적 팩토리 메서드
    public static GroupedVocResponseDto createDetail(VocResponseDto vocResponseDto) {
        return new GroupedVocResponseDto(vocResponseDto);
    }
}

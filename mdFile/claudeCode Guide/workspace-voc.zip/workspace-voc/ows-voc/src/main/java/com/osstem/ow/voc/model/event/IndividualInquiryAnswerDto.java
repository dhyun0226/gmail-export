package com.osstem.ow.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "개인문의답변 DTO")
public class IndividualInquiryAnswerDto extends BaseDto {

    @NotNull
    @Schema(description = "개인문의번호")
    private Long individualInquiryNumber;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "답변자법인코드")
    private String answererCorporationCode;

    @NotBlank
    @Size(max = 30)
    @Schema(description = "답변자부서코드")
    private String answererDepartmentCode;

    @NotBlank
    @Size(max = 60)
    @Schema(description = "답변자사원번호")
    private String answererEmployeeNumber;

    @NotBlank
    @Size(max = 1000)
    @Schema(description = "개인문의답변내용")
    private String individualInquiryAnswerContent;

    @Schema(description = "개인문의답변일시")
    private LocalDateTime individualInquiryAnswerDatetime;

    @Size(max = 50)
    @Schema(description = "파일ID")
    private String fileId;

    public IndividualInquiryAnswerDto setFromDenallVocNumber(Long individualInquiryNumber) {
        if (individualInquiryNumber == null) {
            return this;
        }
        this.individualInquiryNumber = individualInquiryNumber;
        return this;
    }

    public IndividualInquiryAnswerDto setFromAnswerDetail(VocAnswerDetailDto answerDetailDto) {
        if (answerDetailDto == null) {
            return this;
        }
        this.individualInquiryAnswerDatetime = answerDetailDto.getVocAnswerDateTime();
        this.individualInquiryAnswerContent = answerDetailDto.getVocAnswerContent();
        this.fileId = answerDetailDto.getAnswerFileId();

        return this;
    }

    public IndividualInquiryAnswerDto setFromChargePerson(VocChargePersonDto chargePersonDto) {
        if (chargePersonDto == null) {
            return this;
        }

        this.answererCorporationCode = chargePersonDto.getVocChargePersonCorporationCode();
        this.answererDepartmentCode = chargePersonDto.getVocChargePersonDepartmentCode();
        this.answererEmployeeNumber = chargePersonDto.getVocChargePersonEmployeeNumber();

        return this;
    }

    public static IndividualInquiryAnswerDto composeVocAnswerEvent(Long individualInquiryNumber, VocAnswerDetailDto answerDetailDto, VocChargePersonDto chargePersonDto) {
        return new IndividualInquiryAnswerDto().setFromDenallVocNumber(individualInquiryNumber).setFromAnswerDetail(answerDetailDto).setFromChargePerson(chargePersonDto);
    }
}
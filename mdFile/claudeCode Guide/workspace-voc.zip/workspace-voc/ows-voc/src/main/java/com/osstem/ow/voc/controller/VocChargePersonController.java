package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocChargePersonService;
import com.osstem.ow.voc.model.response.VocChargePersonResponseDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/voc-charge-persons")
@RequiredArgsConstructor
@Tag(name = "VOC 담당자 관리", description = "VOC 담당자 관리 API")
public class VocChargePersonController {

    private final VocChargePersonService vocChargePersonService;

    @GetMapping("/{vocChargePersonNumber}")
    @Operation(summary = "VOC 담당자 조회", description = "VOC 담당자 번호로 VOC 담당자 정보를 조회합니다.")
    public ResponseEntity<VocChargePersonDto> findById(@PathVariable Long vocChargePersonNumber) {
        VocChargePersonDto vocChargePersonDto = vocChargePersonService.findById(vocChargePersonNumber);
        return ResponseEntity.ok(vocChargePersonDto);
    }

    @PostMapping
    @Operation(summary = "VOC 담당자 등록", description = "새로운 VOC 담당자를 등록합니다.")
    public ResponseEntity<VocChargePersonDto> create(@Valid @RequestBody VocChargePersonDto vocChargePersonDto) {
        VocChargePersonDto createdVocChargePersonDto = vocChargePersonService.create(vocChargePersonDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdVocChargePersonDto);
    }

    @GetMapping("/channels/{vocChargePersonEmployeeNumber}")
    @Operation(summary = "VOC 담당자 채널 조회", description = "VOC 담당자의 담당 채널을 조회합니다.")
    public ResponseEntity<List<String>> getChannelsByEmployeeNumber(@PathVariable String vocChargePersonEmployeeNumber) {
        return ResponseEntity.ok(vocChargePersonService.findByEmployeeNumber(vocChargePersonEmployeeNumber));
    }

    @PutMapping("/{vocChargePersonNumber}")
    @Operation(summary = "VOC 담당자 수정", description = "기존 VOC 담당자 정보를 수정합니다.")
    public ResponseEntity<VocChargePersonDto> update(
            @PathVariable Long vocChargePersonNumber,
            @Valid @RequestBody VocChargePersonDto vocChargePersonDto) {
        VocChargePersonDto updatedVocChargePersonDto = vocChargePersonService.update(vocChargePersonNumber, vocChargePersonDto);
        return ResponseEntity.ok(updatedVocChargePersonDto);
    }

    @PutMapping("/update")
    @Operation(summary = "VOC 담당자 일괄 업데이트", description = "VOC 담당자 데이터를 일괄 업데이트합니다.")
    public ResponseEntity<Void> updateVocChargePersons(@Valid @RequestBody List<VocChargePersonDto> vocChargePersonDtos) {
        vocChargePersonService.updateVocChargePersons(vocChargePersonDtos);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{vocChargePersonNumber}")
    @Operation(summary = "VOC 담당자 삭제", description = "VOC 담당자를 삭제합니다.")
    public ResponseEntity<Void> delete(@PathVariable Long vocChargePersonNumber) {
        vocChargePersonService.delete(vocChargePersonNumber);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    @Operation(summary = "VOC 담당자 목록 조회", description = "vocCategoryCode로 VOC 담당자 정보를 조회합니다.")
    public ResponseEntity<List<VocChargePersonResponseDto>> findByVocRegistrationDetailDivisionCode(
            @RequestParam String vocCategoryCode) {
        List<VocChargePersonResponseDto> vocChargePersonResponseDto = vocChargePersonService.findByVocCategoryCode(vocCategoryCode);
        return ResponseEntity.ok(vocChargePersonResponseDto);
    }
}
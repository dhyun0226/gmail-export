package com.osstem.ow.voc.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.osstem.ow.voc.model.base.PagingDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * VOC 검색 조건 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "VOC 검색 조건")
public class VocSearchDto implements PagingDto {
    
    @Min(1)
    @Schema(description = "페이지 번호", example = "1", defaultValue = "1")
    private final Integer pageNo;
    
    @Min(1)
    @Max(100)
    @Schema(description = "페이지 크기", example = "10", defaultValue = "10")
    private final Integer pageSize;
    
    @Size(max = 12)
    @Schema(description = "VOC 카테고리 코드", example = "VOC001")
    private final String vocCategoryCode;
    
    @Size(max = 90)
    @Schema(description = "품목 코드", example = "ITEM001")
    private final String itemCode;
    
    @Size(max = 50)
    @Schema(description = "VOC 고객명", example = "홍길동")
    private final String vocCustomerName;
    
    @Size(max = 100)
    @Schema(description = "VOC 제목 (부분 검색)", example = "제품 문의")
    private final String vocTitle;
    
    @Size(max = 2)
    @Schema(description = "VOC 상태 코드", example = "01")
    private final String vocStateCode;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Schema(description = "검색 시작일", example = "2025-01-01")
    private final LocalDate startDate;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Schema(description = "검색 종료일", example = "2025-01-31")
    private final LocalDate endDate;
    
    @Schema(description = "VOC 담당자 부서 코드")
    private final String vocChargePersonDepartmentCode;
    
    @Schema(description = "VOC 등록자 부서 코드")
    private final String vocRegistererDepartmentCode;
    
    // PagingDto 인터페이스 구현에 필요한 기본값 처리
    @Override
    public Integer getPageNo() {
        return pageNo != null ? pageNo : DEFAULT_PAGE_NO;
    }
    
    @Override
    public Integer getPageSize() {
        return pageSize != null ? pageSize : DEFAULT_PAGE_SIZE;
    }
}
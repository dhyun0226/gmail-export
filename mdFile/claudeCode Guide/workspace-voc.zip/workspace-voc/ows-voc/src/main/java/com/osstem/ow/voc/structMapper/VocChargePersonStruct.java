package com.osstem.ow.voc.structMapper;

import com.osstem.ow.voc.entity.VocChargePerson;
import com.osstem.ow.voc.model.response.VocChargePersonResponseDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface VocChargePersonStruct extends StructMapper<VocChargePerson, VocChargePersonDto> {
    VocChargePersonResponseDto toResponseDto(VocChargePerson vocChargePerson);

    // 엔티티 리스트를 DTO 리스트로 변환
    List<VocChargePersonDto> toDtoList(List<VocChargePerson> vocChargePersonList);

    // 엔티티 리스트를 응답 DTO 리스트로 변환
    List<VocChargePersonResponseDto> toResponseDtoList(List<VocChargePerson> vocChargePersonList);

    // DTO 리스트를 엔티티 리스트로 변환
    List<VocChargePerson> toEntityList(List<VocChargePersonDto> vocChargePersonDtoList);
}
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.FaqServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.FaqRequestDto;
import com.osstem.ow.voc.model.customer.FaqResponseDto;
import com.osstem.ow.voc.model.customer.FaqResponseWrapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FaqService {

    private final FaqServiceClient faqServiceClient;

    public ResultDto<FaqResponseDto> getAllFaqs(FaqRequestDto dto) {
        return faqServiceClient.getAllFaqs(dto);
    }

    public FaqResponseDto create(FaqRequestDto dto) {
        return faqServiceClient.createFaq(dto);
    }

    public FaqResponseDto update(Long id, FaqRequestDto dto) {
        return faqServiceClient.updateFaq(id, dto);
    }

    public void delete(Long id) {
        faqServiceClient.deleteFaq(id);
    }

//    public ResultDto<FaqResponseDto> search(FaqRequestDto dto) {
//        return faqServiceClient.searchFaqs(dto);
//    }

    public FaqResponseDto getFaqById(Long id) {
        return faqServiceClient.getFaqById(id);
    }
}
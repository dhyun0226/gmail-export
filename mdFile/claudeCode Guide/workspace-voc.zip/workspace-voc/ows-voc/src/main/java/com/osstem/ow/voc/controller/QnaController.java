package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.QnaDto;
import com.osstem.ow.voc.model.request.QnaRequestDto;
import com.osstem.ow.voc.model.response.QnaResponseDto;
import com.osstem.ow.voc.domain.QnaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/qnas")
@RequiredArgsConstructor
public class QnaController {

    private final QnaService qnaService;

    @Operation(summary = "QnA 목록 조회", description = "QnA 목록을 페이징 처리하여 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 목록 조회 성공",
            content = @Content(schema = @Schema(implementation = ResultDto.class)))
    @GetMapping
    public ResponseEntity<ResultDto<QnaResponseDto>> getQnaList(
            QnaRequestDto requestDto,
            @RequestParam(name = "processStatus", required = false, defaultValue = "") String processStatus
    ) {
        ResultDto<QnaResponseDto> result = qnaService.getQnaList(requestDto, processStatus);
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "QnA 조회", description = "ID로 QnA를 조회합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 조회 성공",
            content = @Content(schema = @Schema(implementation = QnaResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "QnA 없음")
    @GetMapping("/{qnaNumber}")
    public ResponseEntity<QnaResponseDto> getQnaById(
            @PathVariable Long qnaNumber,
            @RequestParam String channelCode,
            @RequestParam String serviceCategoryCode,
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode) {
        QnaResponseDto qnaResponseDto = qnaService.getQnaById(qnaNumber, channelCode, serviceCategoryCode, userId, corporationCode);
        return ResponseEntity.ok(qnaResponseDto);
    }

    @Operation(summary = "QnA 수정", description = "QnA 정보를 수정합니다.")
    @ApiResponse(responseCode = "200", description = "QnA 수정 성공",
            content = @Content(schema = @Schema(implementation = QnaResponseDto.class)))
    @PutMapping("/{qnaNumber}")
    public ResponseEntity<QnaResponseDto> updateQna(
            @PathVariable Long qnaNumber,
            @RequestBody QnaDto requestDto,
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode) {
        QnaResponseDto updatedQna = qnaService.updateQna(qnaNumber, requestDto, userId, corporationCode);
        return ResponseEntity.ok(updatedQna);
    }
}
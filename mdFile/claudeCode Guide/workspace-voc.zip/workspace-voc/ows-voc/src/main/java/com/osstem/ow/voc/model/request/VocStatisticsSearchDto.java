package com.osstem.ow.voc.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * VOC 통계 조회 조건 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "VOC 통계 조회 조건")
public class VocStatisticsSearchDto {
    
    /**
     * 그룹핑 타입 열거형
     */
    public enum GroupByType {
        REGISTERER("등록자 부서 기준"),
        CHARGE_PERSON("담당자 부서 기준");
        
        private final String description;
        
        GroupByType(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    @NotNull(message = "그룹핑 타입은 필수입니다")
    @Schema(description = "그룹핑 타입", example = "REGISTERER", defaultValue = "REGISTERER")
    private final GroupByType groupByType;
    
    @NotNull(message = "시작일은 필수입니다")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Schema(description = "통계 시작일", example = "2025-01-01")
    private final LocalDate startDate;
    
    @NotNull(message = "종료일은 필수입니다")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Schema(description = "통계 종료일", example = "2025-01-31")
    private final LocalDate endDate;
    
    @Size(max = 3)
    @Schema(description = "VOC 영업 담당자 법인 코드")
    private final String vocSaleChargeCorporationCode;
    
    @Size(max = 30)
    @Schema(description = "VOC 영업 담당자 부서 코드")
    private final String vocSaleChargeDepartmentCode;
    
    @Size(max = 60)
    @Schema(description = "VOC 영업 담당자 사원 번호")
    private final String vocSaleChargeEmployeeNumber;
    
    /**
     * 기본 통계 조회 조건 생성
     * 
     * @param startDate 시작일
     * @param endDate 종료일
     * @return VocStatisticsSearchDto
     */
    public static VocStatisticsSearchDto defaultSearch(LocalDate startDate, LocalDate endDate) {
        return VocStatisticsSearchDto.builder()
                .groupByType(GroupByType.REGISTERER)
                .startDate(startDate)
                .endDate(endDate)
                .build();
    }
}
package com.osstem.ow.voc.util;

import com.osstem.ow.voc.model.statistic.OrganizationVocStatisticsDto;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class VocStatisticsUtil {

    private static final String TOTAL_KEY = "total";

    /**
     * 조직도에 통계 정보를 추가하고 부모-자식 관계에 따라 집계
     *
     * @param organizationStructure 조직도 구조
     * @param departmentStatistics 부서별 통계 정보
     */
    public static void enrichOrganizationStructureWithStatistics(
            List<OrganizationVocStatisticsDto> organizationStructure,
            Map<String, Map<String, Integer>> departmentStatistics) {

        // 모든 조직 노드를 키로 쉽게 조회할 수 있도록 맵으로 변환
        Map<String, OrganizationVocStatisticsDto> organizationNodeMap = new HashMap<>();
        flattenOrganizationStructure(organizationStructure, organizationNodeMap);

        // 부모-자식 관계 맵 구성
        Map<String, List<String>> parentChildMap = buildParentChildMap(organizationNodeMap);

        // 부서 코드 기반으로 직접적인 통계 정보 추가
        addDirectStatistics(organizationNodeMap, departmentStatistics);

        // 자식에서 부모로 통계 정보 집계 (상향식 집계)
        aggregateStatisticsBottomUp(organizationNodeMap, parentChildMap);

        // 각 노드에 통계 총합 추가
        addTotalStatistics(organizationNodeMap);
    }

    /**
     * 조직도 구조를 평면화하여 맵으로 변환
     *
     * @param organizationNodes 조직도 노드 리스트
     * @param result 결과를 저장할 맵
     */
    public static void flattenOrganizationStructure(
            List<OrganizationVocStatisticsDto> organizationNodes,
            Map<String, OrganizationVocStatisticsDto> result) {

        organizationNodes.forEach(node -> {
            result.put(node.getKey(), node);
            Optional.ofNullable(node.getItems())
                    .filter(items -> !items.isEmpty())
                    .ifPresent(items -> flattenOrganizationStructure(items, result));
        });
    }

    /**
     * 부모-자식 관계 맵 구성
     *
     * @param organizationNodeMap 조직 노드 맵
     * @return 부모 키를 키로, 자식 키 리스트를 값으로 갖는 맵
     */
    private static Map<String, List<String>> buildParentChildMap(Map<String, OrganizationVocStatisticsDto> organizationNodeMap) {
        return organizationNodeMap.values().stream()
                .filter(node -> node.getParentId() != null)
                .collect(Collectors.groupingBy(
                        OrganizationVocStatisticsDto::getParentId,
                        Collectors.mapping(OrganizationVocStatisticsDto::getKey, Collectors.toList())
                ));
    }

    /**
     * 각 부서에 직접적인 통계 정보 추가
     *
     * @param organizationNodeMap 조직 노드 맵
     * @param departmentStatistics 부서별 통계 정보
     */
    private static void addDirectStatistics(
            Map<String, OrganizationVocStatisticsDto> organizationNodeMap,
            Map<String, Map<String, Integer>> departmentStatistics) {

        organizationNodeMap.values().stream()
                .filter(node -> node.getData() != null && node.getData().getDepartmentCode() != null)
                .forEach(node -> {
                    String departmentCode = node.getData().getDepartmentCode();
                    Optional.ofNullable(departmentStatistics.get(departmentCode))
                            .ifPresent(stats -> node.setStatistics(new HashMap<>(stats)));
                });
    }

    /**
     * 하위에서 상위로 통계 정보를 집계하는 상향식 처리
     *
     * @param organizationNodeMap 조직 노드 맵
     * @param parentChildMap 부모-자식 관계 맵
     */
    private static void aggregateStatisticsBottomUp(
            Map<String, OrganizationVocStatisticsDto> organizationNodeMap,
            Map<String, List<String>> parentChildMap) {

        // 처리 완료된 노드 추적
        Set<String> processedNodes = organizationNodeMap.values().stream()
                .filter(node -> node.isLeaf() || !parentChildMap.containsKey(node.getKey()))
                .map(OrganizationVocStatisticsDto::getKey)
                .collect(Collectors.toSet());



        // 나머지를 상향식으로 처리
        while (processedNodes.size() < organizationNodeMap.size()) {
            Map<String, OrganizationVocStatisticsDto> readyToProcess = organizationNodeMap.keySet().stream()
                    .filter(nodeKey -> !processedNodes.contains(nodeKey))
                    .filter(nodeKey -> {
                        List<String> childKeys = parentChildMap.getOrDefault(nodeKey, Collections.emptyList());
                        return processedNodes.containsAll(childKeys);
                    })
                    .collect(Collectors.toMap(
                            nodeKey -> nodeKey,
                            nodeKey -> organizationNodeMap.get(nodeKey)
                    ));

            readyToProcess.forEach((nodeKey, parentNode) -> {
                parentChildMap.getOrDefault(nodeKey, Collections.emptyList()).stream()
                        .map(organizationNodeMap::get)
                        .forEach(parentNode::aggregateChildStatistics);
            });

            processedNodes.addAll(readyToProcess.keySet());
        }
    }

    /**
     * 각 노드의 통계에 total 값 추가
     * 각 통계 유형(일별, 월별, 시간별)에 따라 모든 값의 합을 'total' 키로 저장
     *
     * @param organizationNodeMap 조직 노드 맵
     */
    private static void addTotalStatistics(Map<String, OrganizationVocStatisticsDto> organizationNodeMap) {
        organizationNodeMap.values().stream()
                .map(OrganizationVocStatisticsDto::getStatistics)
                .filter(stats -> stats != null && !stats.isEmpty())
                .forEach(statistics -> {
                    int total = statistics.entrySet().stream()
                            .filter(entry -> !TOTAL_KEY.equals(entry.getKey()))
                            .mapToInt(Map.Entry::getValue)
                            .sum();

                    statistics.put(TOTAL_KEY, total);
                });
    }

    /**
     * 일별 시간대 통계 초기화 (0~23시 통계를 모두 0으로 설정)
     *
     * @param statistics 초기화할 통계 맵
     */
    public static void initializeHourlyStatistics(Map<String, Integer> statistics) {
        IntStream.range(0, 24)
                .forEach(hour -> statistics.put("h" + hour, 0));
    }

    /**
     * 월별 일자 통계 초기화 (1~31일 통계를 모두 0으로 설정)
     *
     * @param statistics 초기화할 통계 맵
     */
    public static void initializeMonthlyDayStatistics(Map<String, Integer> statistics) {
        IntStream.rangeClosed(1, 31)
                .forEach(day -> statistics.put("d" + day, 0));
    }

    /**
     * 연도별 월 통계 초기화 (1~12월 통계를 모두 0으로 설정)
     *
     * @param statistics 초기화할 통계 맵
     */
    public static void initializeYearlyMonthStatistics(Map<String, Integer> statistics) {
        IntStream.rangeClosed(1, 12)
                .forEach(month -> statistics.put("m" + month, 0));
    }

    /**
     * 주별 요일 통계 초기화 (1~7 요일별 통계를 모두 0으로 설정)
     *
     * @param statistics 초기화할 통계 맵
     */
    public static void initializeWeeklyDayStatistics(Map<String, Integer> statistics) {
        IntStream.rangeClosed(1, 7)
                .forEach(day -> statistics.put("d" + day, 0));
    }
}
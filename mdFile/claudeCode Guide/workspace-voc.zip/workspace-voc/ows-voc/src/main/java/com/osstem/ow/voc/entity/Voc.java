package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "TB_VOC_M")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Voc extends BaseEntity {

    @Id
    @Column(name = "VOC_NO", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vocNumber;

    @Column(name = "VOC_CHPR_NO", nullable = false)
    private Long vocChargePersonNumber;

    @Column(name = "VOC_CTG_CD", length = 12, nullable = false)
    private String vocCategoryCode;

    @Column(name = "DNAL_VOC_NO")
    private Long denallVocNumber;

    @Column(name = "ITM_CD", length = 90)
    private String itemCode;

    @Column(name = "VOC_ITM_NM", length = 100)
    private String vocItemName;

    @Column(name = "VOC_RGSTR_DVCD", length = 2, nullable = false)
    private String vocRegistererDivisionCode;

    @Column(name = "RGSTR_CPRN_CD", length = 3)
    private String registererCorporationCode;

    @Column(name = "RGSTR_DEPT_CD", length = 30)
    private String registererDepartmentCode;

    @Column(name = "RGSTR_EMP_NO", length = 60)
    private String registererEmployeeNumber;

    @Column(name = "RGSTR_MEM_ID", length = 20)
    private String registererMemberId;

    @Column(name = "VOC_CTMR_NM", length = 50)
    private String vocCustomerName;

    @Column(name = "VOC_CTMR_CUST_NM", length = 100)
    private String vocCustomerCustomerName;

    @Column(name = "VOC_CTMR_EML_ADDR", length = 50)
    private String vocCustomerEmailAddress;

    @Column(name = "VOC_CTMR_TLNO", length = 20)
    private String vocCustomerTelephoneNumber;

    @Column(name = "VOC_CTMR_HPNO", length = 20)
    private String vocCustomerHandPhoneNumber;

    @Column(name = "VOC_TTL", length = 100, nullable = false)
    private String vocTitle;

    @Column(name = "VOC_CN", length = 2000, nullable = false)
    private String vocContent;

    @Column(name = "VOC_SALE_CHPR_CPRN_CD", length = 3)
    private String vocSaleChargeCorporationCode;

    @Column(name = "VOC_SALE_CHPR_DEPT_CD", length = 30)
    private String vocSaleChargeDepartmentCode;

    @Column(name = "VOC_SALE_CHPR_EMP_NO", length = 60)
    private String vocSaleChargeEmployeeNumber;

    @Column(name = "INDV_INFO_CLCT_TOU_AGRE_YN", length = 1)
    private String individualInformationCollectionTermsOfUseAgreementYesOrNo;

    @Column(name = "FILE_ID", length = 50)
    private String fileId;

    @Column(name = "VOC_CMPL_TYCD", length = 2)
    private String vocCompletionTypeCode;

    @Column(name = "BIZ_RQST_NO")
    private Long businessRequestNumber;

    @Column(name = "ASGNMT_PRCS_NO")
    private Long assignmentProcedureNumber;

    @Column(name = "END_RSN", length = 500)
    private String endReason;

    @Column(name = "VOC_STACD", length = 2, nullable = false)
    private String vocStateCode;

    @Column(name = "DEL_YN", length = 1, nullable = false)
    private String deleteYesOrNo;

    @Column(name = "VOC_RGST_DTM", nullable = false)
    private LocalDateTime vocRegistrationDateTime;

    @Column(name = "VOC_DTLS_ITM_NM", length = 100)
    private String vocDetailsItemName;

    /**
     * 논리적 삭제 처리
     *
     * @param processorId 처리자 ID
     */
    public void markAsDeleted(String processorId) {
        this.deleteYesOrNo = "Y";
    }


}
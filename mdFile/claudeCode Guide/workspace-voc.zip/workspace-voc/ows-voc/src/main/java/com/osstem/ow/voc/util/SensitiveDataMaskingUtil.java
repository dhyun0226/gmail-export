package com.osstem.ow.voc.util;

import java.util.regex.Pattern;

/**
 * 민감정보 마스킹 처리를 위한 유틸리티 클래스
 */
public final class SensitiveDataMaskingUtil {
    
    private static final String MASK_CHAR = "*";
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{2,3}-\\d{3,4}-\\d{4}$");
    private static final Pattern MOBILE_PATTERN = Pattern.compile("^01[0-9]-\\d{3,4}-\\d{4}$");
    
    private SensitiveDataMaskingUtil() {
        throw new AssertionError("유틸리티 클래스는 인스턴스화할 수 없습니다");
    }
    
    /**
     * 이름을 마스킹합니다. (첫 글자와 마지막 글자만 표시)
     * 
     * @param name 원본 이름
     * @return 마스킹된 이름
     */
    public static String maskName(String name) {
        if (name == null || name.length() <= 1) {
            return name;
        }
        
        if (name.length() == 2) {
            return name.charAt(0) + MASK_CHAR;
        }
        
        StringBuilder masked = new StringBuilder();
        masked.append(name.charAt(0));
        for (int i = 1; i < name.length() - 1; i++) {
            masked.append(MASK_CHAR);
        }
        masked.append(name.charAt(name.length() - 1));
        return masked.toString();
    }
    
    /**
     * 이메일을 마스킹합니다. (앞 3자리와 도메인만 표시)
     * 
     * @param email 원본 이메일
     * @return 마스킹된 이메일
     */
    public static String maskEmail(String email) {
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            return email;
        }
        
        String[] parts = email.split("@");
        String localPart = parts[0];
        String domain = parts[1];
        
        if (localPart.length() <= 3) {
            return MASK_CHAR + "@" + domain;
        }
        
        return localPart.substring(0, 3) + "***@" + domain;
    }
    
    /**
     * 전화번호를 마스킹합니다. (가운데 번호 마스킹)
     * 
     * @param phone 원본 전화번호
     * @return 마스킹된 전화번호
     */
    public static String maskPhone(String phone) {
        if (phone == null) {
            return null;
        }
        
        // 하이픈 제거
        String numbers = phone.replaceAll("-", "");
        
        if (numbers.length() < 8) {
            return phone;
        }
        
        // 휴대폰 번호 (01X-XXXX-XXXX)
        if (numbers.startsWith("01")) {
            return numbers.substring(0, 3) + "-****-" + numbers.substring(numbers.length() - 4);
        }
        
        // 일반 전화번호 (0X-XXX-XXXX 또는 0XX-XXXX-XXXX)
        if (numbers.startsWith("02")) {
            return "02-***-" + numbers.substring(numbers.length() - 4);
        } else {
            return numbers.substring(0, 3) + "-****-" + numbers.substring(numbers.length() - 4);
        }
    }
    
    /**
     * 주민등록번호를 마스킹합니다. (앞 6자리와 첫 번째 자리만 표시)
     * 
     * @param ssn 원본 주민등록번호
     * @return 마스킹된 주민등록번호
     */
    public static String maskSsn(String ssn) {
        if (ssn == null || ssn.length() < 13) {
            return ssn;
        }
        
        String cleaned = ssn.replaceAll("[^0-9]", "");
        if (cleaned.length() != 13) {
            return ssn;
        }
        
        return cleaned.substring(0, 6) + "-" + cleaned.charAt(6) + "******";
    }
    
    /**
     * 로그용 문자열을 생성합니다. (민감정보 마스킹)
     * 
     * @param format 포맷 문자열
     * @param args 인자들
     * @return 마스킹된 로그 문자열
     */
    public static String toLogString(String format, Object... args) {
        if (args == null || args.length == 0) {
            return format;
        }
        
        Object[] maskedArgs = new Object[args.length];
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof String) {
                String str = (String) args[i];
                if (EMAIL_PATTERN.matcher(str).matches()) {
                    maskedArgs[i] = maskEmail(str);
                } else if (PHONE_PATTERN.matcher(str).matches() || MOBILE_PATTERN.matcher(str).matches()) {
                    maskedArgs[i] = maskPhone(str);
                } else {
                    maskedArgs[i] = str;
                }
            } else {
                maskedArgs[i] = args[i];
            }
        }
        
        return String.format(format, maskedArgs);
    }
}
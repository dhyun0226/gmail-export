package com.osstem.ow.voc.util;

import org.springframework.web.util.HtmlUtils;

/**
 * XSS(Cross-Site Scripting) 공격 방지를 위한 유틸리티 클래스
 */
public final class XssProtectionUtil {
    
    private XssProtectionUtil() {
        throw new AssertionError("유틸리티 클래스는 인스턴스화할 수 없습니다");
    }
    
    /**
     * HTML 특수문자를 이스케이프 처리합니다.
     * 
     * @param input 원본 문자열
     * @return 이스케이프 처리된 문자열
     */
    public static String escapeHtml(String input) {
        if (input == null) {
            return null;
        }
        return HtmlUtils.htmlEscape(input);
    }
    
    /**
     * 여러 문자열을 일괄적으로 이스케이프 처리합니다.
     * 
     * @param inputs 원본 문자열 배열
     * @return 이스케이프 처리된 문자열 배열
     */
    public static String[] escapeHtmlBatch(String... inputs) {
        if (inputs == null) {
            return null;
        }
        
        String[] escaped = new String[inputs.length];
        for (int i = 0; i < inputs.length; i++) {
            escaped[i] = escapeHtml(inputs[i]);
        }
        return escaped;
    }
    
    /**
     * 이스케이프된 HTML을 원본으로 복원합니다.
     * 
     * @param escaped 이스케이프된 문자열
     * @return 원본 문자열
     */
    public static String unescapeHtml(String escaped) {
        if (escaped == null) {
            return null;
        }
        return HtmlUtils.htmlUnescape(escaped);
    }
}
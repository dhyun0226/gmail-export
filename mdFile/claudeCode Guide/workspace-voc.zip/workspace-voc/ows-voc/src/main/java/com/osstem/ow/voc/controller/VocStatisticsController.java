package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocStatisticsService;
import com.osstem.ow.voc.model.statistic.OrganizationVocStatisticsDto;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/statistics")
@RequiredArgsConstructor
@Tag(name = "VOC 통계", description = "VOC 통계 조회 API")
public class VocStatisticsController {

    private final VocStatisticsService vocStatisticsService;

    // ===== VOC 등록자 기준 통계 API =====

    /**
     * 상세 조건으로 일별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/daily/search")
    @Operation(summary = "상세 조건으로 일별 VOC 통계 조회", description = "상세 조건을 적용하여 일별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchDailyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocStatisticsByDay(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 주별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/weekly/search")
    @Operation(summary = "상세 조건으로 주별 VOC 통계 조회", description = "상세 조건을 적용하여 주별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchWeekVocStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocStatisticsByWeek(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 월별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/monthly/search")
    @Operation(summary = "상세 조건으로 월별 VOC 통계 조회", description = "상세 조건을 적용하여 월별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchMonthlyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocStatisticsByMonth(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 연도별 VOC 통계 조회 (등록자 기준)
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/yearly/search")
    @Operation(summary = "상세 조건으로 연도별 VOC 통계 조회", description = "상세 조건을 적용하여 연도별 VOC 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchYearlyVocStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocStatisticsByYear(condition);
        return ResponseEntity.ok(result);
    }

    // ===== VOC 담당자 기준 통계 API =====

    /**
     * 상세 조건으로 시간별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/charge-person/daily/search")
    @Operation(summary = "상세 조건으로 시간별 VOC 담당자 통계 조회", description = "상세 조건을 적용하여 시간별 VOC 담당자 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchHourlyVocChargePersonStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocChargePersonStatisticsByDay(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 요일별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/charge-person/weekly/search")
    @Operation(summary = "상세 조건으로 요일별 VOC 담당자 통계 조회", description = "상세 조건을 적용하여 요일별 VOC 담당자 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchWeeklyVocChargePersonStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocChargePersonStatisticsByWeek(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 일별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/charge-person/monthly/search")
    @Operation(summary = "상세 조건으로 일별 VOC 담당자 통계 조회", description = "상세 조건을 적용하여 일별 VOC 담당자 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchDailyVocChargePersonStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocChargePersonStatisticsByMonth(condition);
        return ResponseEntity.ok(result);
    }

    /**
     * 상세 조건으로 월별 VOC 담당자 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 조직도 구조
     */
    @GetMapping("/charge-person/yearly/search")
    @Operation(summary = "상세 조건으로 월별 VOC 담당자 통계 조회", description = "상세 조건을 적용하여 월별 VOC 담당자 통계를 조회합니다.")
    public ResponseEntity<List<OrganizationVocStatisticsDto>> searchMonthlyVocChargePersonStatistics(
            VocStatisticsRequestDto condition) {
        List<OrganizationVocStatisticsDto> result = vocStatisticsService.getVocChargePersonStatisticsByYear(condition);
        return ResponseEntity.ok(result);
    }
}
package com.osstem.ow.voc.constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 제품 카테고리 트리 구조를 생성하고 관리하는 유틸리티 클래스
 */
public class ProductCategoryUtil {

    private static final Random random = new Random();

    /**
     * 제품 카테고리의 기본 정보를 담는 클래스
     */
    public static class ProductCategory {
        private String value;
        private String text;

        public ProductCategory(String value, String text) {
            this.value = value;
            this.text = text;
        }

        public String getValue() {
            return value;
        }

        public String getText() {
            return text;
        }
    }

    /**
     * 트리 구조를 위한 부서 데이터 클래스
     */
    public static class DepartmentData {
        private String key;
        private String parentId;
        private String display;
        private Object items;
        private boolean expanded;
        private boolean internal;
        private boolean leaf;
        private int degree;
        private Map<String, Object> data;

        public DepartmentData() {
            this.data = new HashMap<>();
        }

        // Getters and Setters
        public String getKey() { return key; }
        public void setKey(String key) { this.key = key; }

        public String getParentId() { return parentId; }
        public void setParentId(String parentId) { this.parentId = parentId; }

        public String getDisplay() { return display; }
        public void setDisplay(String display) { this.display = display; }

        public Object getItems() { return items; }
        public void setItems(Object items) { this.items = items; }

        public boolean isExpanded() { return expanded; }
        public void setExpanded(boolean expanded) { this.expanded = expanded; }

        public boolean isInternal() { return internal; }
        public void setInternal(boolean internal) { this.internal = internal; }

        public boolean isLeaf() { return leaf; }
        public void setLeaf(boolean leaf) { this.leaf = leaf; }

        public int getDegree() { return degree; }
        public void setDegree(int degree) { this.degree = degree; }

        public Map<String, Object> getData() { return data; }
        public void setData(Map<String, Object> data) { this.data = data; }

        @Override
        public String toString() {
            return "DepartmentData{" +
                    "key='" + key + '\'' +
                    ", parentId='" + parentId + '\'' +
                    ", display='" + display + '\'' +
                    ", expanded=" + expanded +
                    ", internal=" + internal +
                    ", leaf=" + leaf +
                    ", degree=" + degree +
                    ", data=" + data +
                    '}';
        }
    }

    /**
     * 모든 제품 카테고리 목록을 반환하는 메서드
     *
     * @return 제품 카테고리 목록
     */
    public static List<ProductCategory> getAllProductCategories() {
        List<ProductCategory> categories = new ArrayList<>();
        categories.add(new ProductCategory("implant", "임플란트"));
        categories.add(new ProductCategory("instrument", "기구"));
        categories.add(new ProductCategory("endodontic", "보존/근관"));
        categories.add(new ProductCategory("restorative", "수복/접착"));
        categories.add(new ProductCategory("impression", "인상/보철"));
        categories.add(new ProductCategory("cutting", "절삭/연마"));
        categories.add(new ProductCategory("gbr", "GBR"));
        categories.add(new ProductCategory("hygiene", "위생용품"));
        categories.add(new ProductCategory("equipment", "장비"));
        categories.add(new ProductCategory("orthodontic", "교정용기구"));
        categories.add(new ProductCategory("prevention", "예방/구강"));
        categories.add(new ProductCategory("dentalLab", "기공용품"));
        categories.add(new ProductCategory("medicine", "의약품"));
        categories.add(new ProductCategory("appliance", "생활가전"));
        return categories;
    }

    /**
     * 트리 구조로 변환된 제품 카테고리 데이터를 반환하는 메서드
     *
     * @return 트리 구조의 제품 카테고리 데이터 목록
     */
    public static List<DepartmentData> getProductCategoryTreeList() {
        List<ProductCategory> categories = getAllProductCategories();
        return transformToTreeListFormat(categories);
    }

    /**
     * 임의의 제품 카테고리 값을 반환하는 메서드
     *
     * @return 랜덤 제품 카테고리 값
     */
    public static String getRandomProductCategoryValue() {
        List<ProductCategory> categories = getAllProductCategories();
        if (categories.isEmpty()) {
            return null;
        }

        // 10%의 확률로 null 반환
        if (random.nextDouble() < 0.1) {
            return null;
        }

        int randomIndex = random.nextInt(categories.size());
        return categories.get(randomIndex).getValue();
    }

    /**
     * 임의의 제품 카테고리 객체를 반환하는 메서드
     *
     * @return 랜덤 제품 카테고리 객체
     */
    public static ProductCategory getRandomProductCategory() {
        List<ProductCategory> categories = getAllProductCategories();
        if (categories.isEmpty()) {
            return null;
        }

        int randomIndex = random.nextInt(categories.size());
        return categories.get(randomIndex);
    }

    /**
     * 제품 카테고리를 트리 구조 형식으로 변환하는 내부 메서드
     *
     * @param categories 제품 카테고리 목록
     * @return 트리 구조 형식의 데이터 목록
     */
    private static List<DepartmentData> transformToTreeListFormat(List<ProductCategory> categories) {
        List<DepartmentData> result = new ArrayList<>();
        String corpCode = "KR1";

        // 부모 노드 추가 (루트 노드)
        DepartmentData rootDept = new DepartmentData();
        rootDept.setKey(corpCode + "_0000");
        rootDept.setParentId(null);
        rootDept.setDisplay("전체");
        rootDept.setItems(null);
        rootDept.setExpanded(false);
        rootDept.setInternal(true);
        rootDept.setLeaf(false);
        rootDept.setDegree(52);

        Map<String, Object> rootData = new HashMap<>();
        rootData.put("corpCode", corpCode);
        rootData.put("deptCode", "0000");
        rootData.put("deptName", "전체");
        rootData.put("empNo", null);
        rootData.put("empName", null);
        rootData.put("dutyCode", null);
        rootData.put("dutyName", null);
        rootData.put("gradeCode", null);
        rootData.put("gradeName", null);
        rootData.put("upDeptCd", null);
        rootData.put("subDeptCnt", 49);
        rootData.put("empCnt", 3);

        rootDept.setData(rootData);
        result.add(rootDept);

        // 자식 노드들 추가 (카테고리 노드들)
        for (int i = 0; i < categories.size(); i++) {
            ProductCategory category = categories.get(i);
            String deptCode = String.format("%04d", i + 1);

            DepartmentData dept = new DepartmentData();
            dept.setKey(corpCode + "_" + deptCode);
            dept.setParentId(corpCode + "_0000"); // 루트 노드의 자식으로 설정
            dept.setDisplay(category.getText());
            dept.setItems(null);
            dept.setExpanded(false);
            dept.setInternal(true);
            dept.setLeaf(false);
            dept.setDegree(10 + random.nextInt(61)); // 10-70 사이 임의의 값

            Map<String, Object> data = new HashMap<>();
            data.put("corpCode", corpCode);
            data.put("deptCode", deptCode);
            data.put("deptName", category.getText());
            data.put("empNo", null);
            data.put("empName", null);
            data.put("dutyCode", null);
            data.put("dutyName", null);
            data.put("gradeCode", null);
            data.put("gradeName", null);
            data.put("upDeptCd", "0000"); // 루트 노드의 deptCode
            data.put("subDeptCnt", 1 + random.nextInt(50)); // 1-50 사이 임의의 값
            data.put("empCnt", 1 + random.nextInt(10)); // 1-10 사이 임의의 값

            dept.setData(data);
            result.add(dept);
        }

        return result;
    }

    /**
     * ID로 제품 카테고리를 찾는 메서드
     *
     * @param value 찾을 카테고리 ID
     * @return 찾은 카테고리 객체, 없으면 null
     */
    public static ProductCategory findCategoryByValue(String value) {
        if (value == null) {
            return null;
        }

        for (ProductCategory category : getAllProductCategories()) {
            if (value.equals(category.getValue())) {
                return category;
            }
        }
        return null;
    }

    /**
     * 텍스트로 제품 카테고리를 찾는 메서드
     *
     * @param text 찾을 카테고리 텍스트
     * @return 찾은 카테고리 객체, 없으면 null
     */
    public static ProductCategory findCategoryByText(String text) {
        if (text == null) {
            return null;
        }

        for (ProductCategory category : getAllProductCategories()) {
            if (text.equals(category.getText())) {
                return category;
            }
        }
        return null;
    }
}

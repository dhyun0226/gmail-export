package com.osstem.ow.voc.model.table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 담당자 DTO")
public class VocChargePersonDto extends BaseDto {

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Setter
    @Schema(description = "VOC 담당자 이름")
    private String vocChargePersonName;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Size(max = 90)
    @Schema(description = "품목 코드")
    private String itemCode;

    @NotBlank
    @Size(max = 3)
    @Schema(description = "VOC 담당자 법인 코드")
    private String vocChargePersonCorporationCode;

    @NotBlank
    @Size(max = 30)
    @Schema(description = "VOC 담당자 부서 코드")
    private String vocChargePersonDepartmentCode;

    @Size(max = 60)
    @Schema(description = "VOC 담당자 사원 번호")
    private String vocChargePersonEmployeeNumber;

    @Schema(description = "VOC 담당자 부서명")
    private String vocChargePersonDepartmentName;

    @Schema(description = "VOC 담당자 사원명")
    private String vocChargePersonEmployeeName;

    @NotBlank
    @Size(max = 1)
    @Schema(description = "지정 담당자 여부")
    private String vocDesignationThePersonInChargeYn ;

    @Size(max = 1)
    @Schema(description = "삭제 여부")
    private String deleteYn ;

}
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.entity.VocChangeHistoryId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VocChangeHistoryRepository extends JpaRepository<VocChangeHistory, VocChangeHistoryId> {
    List<VocChangeHistory> findById_VocNumber(Long vocNumber);
}
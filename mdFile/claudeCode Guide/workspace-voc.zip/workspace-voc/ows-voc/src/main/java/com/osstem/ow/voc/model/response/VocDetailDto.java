package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 상세 정보 DTO
 */
@Value
@Builder
@Schema(description = "VOC 상세 정보")
public class VocDetailDto {
    
    // 기본 정보
    @Schema(description = "VOC 번호")
    Long vocNumber;
    
    @Schema(description = "VOC 제목")
    String vocTitle;
    
    @Schema(description = "VOC 내용")
    String vocContent;
    
    @Schema(description = "VOC 카테고리 코드")
    String vocCategoryCode;
    
    @Schema(description = "VOC 카테고리명")
    String vocCategoryName;
    
    @Schema(description = "VOC 상태 코드")
    String vocStateCode;
    
    @Schema(description = "VOC 상태명")
    String vocStateName;
    
    // 고객 정보
    @Schema(description = "고객 정보")
    CustomerInfo customerInfo;
    
    // 제품 정보
    @Schema(description = "품목 코드")
    String itemCode;
    
    @Schema(description = "품목명")
    String itemName;
    
    @Schema(description = "제품 상세명")
    String itemDetailName;
    
    // 담당자 정보
    @Schema(description = "담당자 정보")
    ChargePersonInfo chargePersonInfo;
    
    // 등록자 정보
    @Schema(description = "등록자 정보")
    RegistrantInfo registrantInfo;
    
    // 날짜 정보
    @Schema(description = "등록일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    LocalDateTime registrationDateTime;
    
    @Schema(description = "수정일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    LocalDateTime modificationDateTime;
    
    // 답변 정보
    @Schema(description = "답변 목록")
    List<VocAnswerDto> answers;
    
    // 첨부파일
    @Schema(description = "첨부파일 목록")
    List<FileDto> attachments;
    
    // 변경 이력
    @Schema(description = "변경 이력")
    List<VocChangeHistoryDto> changeHistories;
    
    /**
     * 고객 정보
     */
    @Value
    @Builder
    public static class CustomerInfo {
        @Schema(description = "고객명")
        String customerName;
        
        @Schema(description = "고객사명")
        String companyName;
        
        @Schema(description = "이메일")
        String email;
        
        @Schema(description = "전화번호")
        String phoneNumber;
        
        @Schema(description = "휴대폰번호")
        String mobileNumber;
    }
    
    /**
     * 담당자 정보
     */
    @Value
    @Builder
    public static class ChargePersonInfo {
        @Schema(description = "담당자 번호")
        Long chargePersonNumber;
        
        @Schema(description = "담당자명")
        String chargePersonName;
        
        @Schema(description = "담당자 사원번호")
        String employeeNumber;
        
        @Schema(description = "부서코드")
        String departmentCode;
        
        @Schema(description = "부서명")
        String departmentName;
    }
    
    /**
     * 등록자 정보
     */
    @Value
    @Builder
    public static class RegistrantInfo {
        @Schema(description = "등록자 사원번호")
        String employeeNumber;
        
        @Schema(description = "등록자명")
        String registrantName;
        
        @Schema(description = "법인코드")
        String corporationCode;
        
        @Schema(description = "부서코드")
        String departmentCode;
        
        @Schema(description = "부서명")
        String departmentName;
    }
}
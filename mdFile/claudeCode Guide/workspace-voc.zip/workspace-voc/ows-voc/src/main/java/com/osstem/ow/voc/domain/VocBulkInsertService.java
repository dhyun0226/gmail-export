package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.repository.VocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class VocBulkInsertService {

    private final VocRepository vocRepository;
    private final Random random = new Random();

    // 제품 카테고리 정의
    private final List<ProductCategory> productCategories = List.of(
            new ProductCategory("implant", "임플란트"),
            new ProductCategory("instrument", "기구"),
            new ProductCategory("endodontic", "보존/근관"),
            new ProductCategory("restorative", "수복/접착"),
            new ProductCategory("impression", "인상/보철"),
            new ProductCategory("cutting", "절삭/연마"),
            new ProductCategory("gbr", "GBR"),
            new ProductCategory("hygiene", "위생용품"),
            new ProductCategory("equipment", "장비"),
            new ProductCategory("orthodontic", "교정용기구"),
            new ProductCategory("prevention", "예방/구강"),
            new ProductCategory("dentalLab", "기공용품"),
            new ProductCategory("medicine", "의약품"),
            new ProductCategory("appliance", "생활가전")
    );

    // 제품 카테고리 클래스
    static class ProductCategory {
        private String value;
        private String text;

        public ProductCategory(String value, String text) {
            this.value = value;
            this.text = text;
        }

        public String getValue() {
            return value;
        }

        public String getText() {
            return text;
        }
    }

    /**
     * VOC 데이터 300개 생성 및 저장
     *
     * @param processorId 처리자 ID
     */
    @Transactional
    public void bulkInsertVocs(String processorId) {
        List<Voc> vocList = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            vocList.add(createRandomVoc(processorId));
        }

        vocRepository.saveAll(vocList);
    }

    /**
     * 랜덤 VOC 엔티티 생성
     *
     * @param processorId 처리자 ID
     * @return 생성된 VOC 엔티티
     */
    private Voc createRandomVoc(String processorId) {
        Voc voc = new Voc();

        // 규칙에 따른 컬럼 값 설정
        voc.setVocChargePersonNumber(1025L);
        voc.setVocCategoryCode(getRandomValue(new String[]{"DVOC_VOC_001", "DVOC_VOC_002","DVOC_VOC_003","DVOC_VOC_004","DVOC_VOC_005","DVOC_VOC_006"}));

        // 랜덤으로 null 가능한 필드 설정

        voc.setDenallVocNumber(getRandomLong(1000, 9999));


        String randomCategory = productCategories.get(random.nextInt(productCategories.size())).value;
        voc.setItemCode(randomCategory);


        voc.setVocRegistererDivisionCode("02"); // 고정값


        voc.setRegistererCorporationCode("KR1"); // 고정값
        voc.setRegistererDepartmentCode(getRandomValue(new String[]{"4500", "3500", "0000001516", "0000001522", "0000001525", "0000001527", "3000", "4700"
                , "O000000553", "O000000400", "O000000375", "O000000374", "O000000373", "O000000122", "O000000243", "O000000253", "O000000371", "O000000372"})); // 고정값


        voc.setRegistererEmployeeNumber(getRandomString(8));


        voc.setRegistererMemberId(getRandomString(10));


        // 고객 정보
        voc.setVocCustomerName(getRandomName());
        voc.setVocCustomerEmailAddress(getRandomEmail());
        voc.setVocCustomerTelephoneNumber(getRandomPhoneNumber());
        voc.setVocCustomerHandPhoneNumber(getRandomPhoneNumber());

        // VOC 정보
        voc.setVocTitle(getRandomTitle());
        voc.setVocContent(getRandomContent());

        voc.setIndividualInformationCollectionTermsOfUseAgreementYesOrNo(
                random.nextBoolean() ? "Y" : "N");


        voc.setFileId(UUID.randomUUID().toString().substring(0, 10));


        voc.setVocCompletionTypeCode(getRandomValue(new String[]{"01", "02", "03", "04"}));


        voc.setBusinessRequestNumber(getRandomLong(1000, 9999));


        voc.setAssignmentProcedureNumber(getRandomLong(1000, 9999));


        voc.setEndReason(getRandomEndReason());


        voc.setVocStateCode("01"); // 고정값
        voc.setDeleteYesOrNo("N"); // 초기값 N

        // 2025년 1월~4월 사이의 랜덤 날짜 설정
//        voc.setVocRegistrationDateTime(getRandomDateBetween2025JanToApr());
        voc.setVocRegistrationDateTime(getRandomDateTimeFromTodayToMay31());
        voc.setProcPrgmId("testUser");
        voc.setRgstProcDtm(LocalDateTime.now());
        voc.setRgstProcrId("testUser");
        return voc;
    }

    /**
     * 2025년 1월부터 4월 사이의 랜덤 날짜시간 생성
     */
    private LocalDateTime getRandomDateBetween2025JanToApr() {
        int year = 2025;
        Month month = Month.of(5); // 1-4월

        // 해당 연도와 월의 실제 최대 일수 계산 (윤년 고려)
        int maxDays = month.length(Year.of(year).isLeap());
        int day = random.nextInt(maxDays) + 1;

        int hour = random.nextInt(24);
        int minute = random.nextInt(60);
        int second = random.nextInt(60);

        return LocalDateTime.of(year, month, day, hour, minute, second);
    }

    /**
     * 오늘부터 2025년 5월 31일까지의 랜덤 날짜시간 생성
     */
    private LocalDateTime getRandomDateTimeFromTodayToMay31() {
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = LocalDate.of(2025, 5, 31);

        long startEpochDay = startDate.toEpochDay();
        long endEpochDay = endDate.toEpochDay();

        long randomDay = ThreadLocalRandom.current().nextLong(startEpochDay, endEpochDay + 1);
        LocalDate randomDate = LocalDate.ofEpochDay(randomDay);

        int randomHour = ThreadLocalRandom.current().nextInt(24);
        int randomMinute = ThreadLocalRandom.current().nextInt(60);
        int randomSecond = ThreadLocalRandom.current().nextInt(60);

        return LocalDateTime.of(randomDate, LocalTime.of(randomHour, randomMinute, randomSecond));
    }

    /**
     * 랜덤 Long 값 생성
     */
    private Long getRandomLong(long min, long max) {
        return min + (long) (random.nextDouble() * (max - min));
    }

    /**
     * 랜덤 문자열 생성
     */
    private String getRandomString(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    /**
     * 배열에서 랜덤 값 선택
     */
    private <T> T getRandomValue(T[] array) {
        return array[random.nextInt(array.length)];
    }

    /**
     * 랜덤 이름 생성
     */
    private String getRandomName() {
        String[] firstNames = {"김", "이", "박", "최", "정", "강", "조", "윤", "장", "임"};
        String[] lastNames = {"준", "민", "서", "지", "연", "영", "석", "수", "진", "호", "현"};

        return getRandomValue(firstNames) + getRandomValue(lastNames) + getRandomValue(lastNames);
    }

    /**
     * 랜덤 이메일 생성
     */
    private String getRandomEmail() {
        String[] domains = {"gmail.com", "naver.com", "daum.net", "hotmail.com", "yahoo.com"};
        return getRandomString(8).toLowerCase() + "@" + getRandomValue(domains);
    }

    /**
     * 랜덤 전화번호 생성
     */
    private String getRandomPhoneNumber() {
        return "010-" + (1000 + random.nextInt(9000)) + "-" + (1000 + random.nextInt(9000));
    }

    /**
     * 랜덤 VOC 제목 생성
     */
    private String getRandomTitle() {
        String[] titles = {
                "제품 사용 중 문제가 발생했습니다",
                "배송 관련 문의드립니다",
                "제품 교환 요청드립니다",
                "환불 관련 문의",
                "사용 방법 질문",
                "제품 구매 관련 문의",
                "서비스 이용 불편 사항",
                "앱 사용 중 오류 발생",
                "계정 관련 문의",
                "결제 관련 문의"
        };

        return getRandomValue(titles);
    }

    /**
     * 랜덤 VOC 내용 생성
     */
    private String getRandomContent() {
        String[] contents = {
                "제품을 사용하던 중 오류가 발생하여 문의드립니다. 자세한 내용은 첨부파일을 확인해주세요.",
                "주문한 제품이 아직 배송되지 않아 확인 부탁드립니다. 주문번호는 다음과 같습니다.",
                "구매한 제품에 결함이 있어 교환을 요청드립니다. 교환 절차 안내 부탁드립니다.",
                "결제 후 제품 재고가 없다고 연락을 받았습니다. 환불 처리 부탁드립니다.",
                "구매한 제품의 사용 방법이 설명서와 다른 것 같습니다. 정확한 사용법 안내 부탁드립니다.",
                "제품 구매를 원하는데 몇 가지 궁금한 점이 있어 문의드립니다.",
                "서비스 이용 중 불편한 점이 있어 개선 요청드립니다.",
                "앱에서 특정 기능 사용 시 계속 오류가 발생합니다. 확인 부탁드립니다.",
                "계정 정보 변경 관련하여 도움이 필요합니다.",
                "결제 오류가 발생하여 확인 요청드립니다."
        };

        return getRandomValue(contents);
    }

    /**
     * 랜덤 종료 사유 생성
     */
    private String getRandomEndReason() {
        String[] reasons = {
                "고객 요청에 의해 종료",
                "문제 해결 완료",
                "담당자 확인 후 처리 완료",
                "중복 접수되어 종료",
                "타 부서 이관 후 종료"
        };

        return getRandomValue(reasons);
    }
}
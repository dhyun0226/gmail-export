package com.osstem.ow.voc.model.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "VocAnswerRequestDto", description = "VOC 답변 요청 DTO")
public class VocAnswerRequestDto {

    @NotNull
    @Schema(description = "VOC 번호", example = "1", required = true)
    private Long vocNumber;

    @NotNull
    @Schema(description = "답변자 법인 코드", example = "123456", required = true)
    private String answererCorporationCode;

    @NotNull
    @Schema(description = "답변자 부서 코드", example = "123456", required = true)
    private String answererDepartmentCode;

    @NotNull
    @Schema(description = "답변자 사원 번호", example = "123456", required = true)
    private String answererEmployeeNumber;

    @NotNull
    @Schema(description = "VOC 답변 내용", example = "답변 내용을 입력하세요", required = true)
    private String vocAnswerContent;

    @NotNull
    @Schema(description = "VOC 답변 일시", example = "2025-04-04T10:30:00", required = true)
    private LocalDateTime vocAnswerDateTime;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file123")
    private String fileId;
}

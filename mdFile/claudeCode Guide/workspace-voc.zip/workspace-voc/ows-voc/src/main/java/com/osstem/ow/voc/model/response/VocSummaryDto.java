package com.osstem.ow.voc.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;

/**
 * VOC 요약 정보 DTO (목록 조회용)
 */
@Value
@Builder
@Schema(description = "VOC 요약 정보")
public class VocSummaryDto {
    
    @Schema(description = "VOC 번호", example = "1001")
    Long vocNumber;
    
    @Schema(description = "VOC 제목", example = "제품 사용 문의")
    String vocTitle;
    
    @Schema(description = "VOC 카테고리 코드", example = "VOC001")
    String vocCategoryCode;
    
    @Schema(description = "VOC 카테고리명", example = "제품문의")
    String vocCategoryName;
    
    @Schema(description = "VOC 상태 코드", example = "01")
    String vocStateCode;
    
    @Schema(description = "VOC 상태명", example = "접수")
    String vocStateName;
    
    @Schema(description = "고객명", example = "홍길동")
    String customerName;
    
    @Schema(description = "담당자명", example = "김직원")
    String chargePersonName;
    
    @Schema(description = "등록일시", example = "2025-01-23T10:30:00")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    LocalDateTime registrationDateTime;
    
    @Schema(description = "답변 여부", example = "true")
    boolean answered;
    
    @Schema(description = "답변일시", example = "2025-01-24T15:20:00")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    LocalDateTime answerDateTime;
}
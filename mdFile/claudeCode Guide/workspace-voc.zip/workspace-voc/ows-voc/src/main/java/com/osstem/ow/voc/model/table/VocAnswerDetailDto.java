package com.osstem.ow.voc.model.table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 답변 상세 DTO")
public class VocAnswerDetailDto extends BaseDto {

    @NotNull
    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "VOC 답변 일시")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private LocalDateTime vocAnswerDateTime;

    @NotBlank
    @Size(max = 12)
    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Size(max = 1000)
    @Schema(description = "답변 내용")
    private String vocAnswerContent;

    @Size(max = 50)
    @Schema(description = "파일 ID")
    private String answerFileId;

    @Schema(description = "파일 리스트")
    private List<TxmFileSaveRequest> fileList;

    @Schema(description = "답변자 법인 코드", example = "123456", required = true)
    private String answererCorporationCode;

    @Schema(description = "답변자 부서 코드", example = "123456", required = true)
    private String answererDepartmentCode;

    @Schema(description = "답변자 사원 번호", example = "123456", required = true)
    private String answererEmployeeNumber;

}
package com.osstem.ow.voc.model.table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 변경 이력 DTO")
public class VocChangeHistoryDto extends BaseDto {

    @NotNull
    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @NotNull
    @Schema(description = "VOC 변경 일시")
    private LocalDateTime vocChangeDateTime;

    @Size(max = 12)
    @Schema(description = "VOC 등록 상세 구분 코드")
    private String vocCategoryCode;

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Size(max = 90)
    @Schema(description = "품목 코드")
    private String itemCode;

    @Size(max = 100)
    @Schema(description = "VOC 품목명")
    private String vocItemName;

    @Size(max = 100)
    @Schema(description = "VOC 제목")
    private String vocTitle;

    @NotBlank
    @Size(max = 2000)
    @Schema(description = "VOC 내용")
    private String vocContent;

    @Size(max = 3)
    @Schema(description = "VOC 영업 담당자 법인 코드")
    private String vocSaleChargeCorporationCode;

    @Size(max = 30)
    @Schema(description = "VOC 영업 담당자 부서 코드")
    private String vocSaleChargeDepartmentCode;

    @Size(max = 60)
    @Schema(description = "VOC 영업 담당자 사원 번호")
    private String vocSaleChargeEmployeeNumber;

    @Schema(description = "업무 요청 번호")
    private Long businessRequestNumber;

    @Schema(description = "과제 절차 번호")
    private Long assignmentProcedureNumber;

    @Size(max = 500)
    @Schema(description = "종료 사유")
    private String endReason;

    @NotBlank
    @Size(max = 2)
    @Schema(description = "VOC 상태 코드")
    private String vocStateCode;

    @Size(max = 2)
    @Schema(description = "VOC 완료 유형 코드")
    private String vocCompletionTypeCode;

    @Size(max = 3)
    @Schema(description = "변경 처리자 법인 코드")
    private String changeProcessorCorporationCode;

    @Size(max = 30)
    @Schema(description = "변경 처리자 부서 코드")
    private String changeProcessorDepartmentCode;

    @Size(max = 60)
    @Schema(description = "변경 처리자 사원 번호")
    private String changeProcessorEmployeeNumber;

    @Schema(description = "voc 세부 품목명")
    private String vocDetailsItemName;

}
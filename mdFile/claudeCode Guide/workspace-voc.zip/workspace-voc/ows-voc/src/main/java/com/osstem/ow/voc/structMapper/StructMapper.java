package com.osstem.ow.voc.structMapper;

import com.osstem.ow.model.BaseDto;
import com.osstem.ow.model.BaseEntity;
import org.mapstruct.AfterMapping;
import org.mapstruct.MappingTarget;

import java.util.List;

public interface StructMapper<E extends BaseEntity, D extends BaseDto> {

    D toDto(E entity);

    E toEntity(D dto);

    default List<D> toDtoList(List<E> entityList) {
        return entityList.stream()
                .map(this::toDto)
                .toList();
    }

    default List<E> toEntityList(List<D> dtoList) {
        return dtoList.stream()
                .map(this::toEntity)
                .toList();
    }

    @AfterMapping
    default void afterMapping(E entity, @MappingTarget D dto) {
        dto.setProcPrgmId(entity.getProcPrgmId());
        dto.setRgstProcrId(entity.getRgstProcrId());
        dto.setRgstProcDtm(entity.getRgstProcDtm());
        dto.setUpdtProcrId(entity.getUpdtProcrId());
        dto.setUpdtProcDtm(entity.getUpdtProcDtm());
    }

    @AfterMapping
    default void afterMapping(D dto, @MappingTarget E entity) {
        entity.setProcPrgmId(dto.getProcPrgmId());
        entity.setRgstProcrId(dto.getRgstProcrId());
        entity.setRgstProcDtm(dto.getRgstProcDtm());
        entity.setUpdtProcrId(dto.getUpdtProcrId());
        entity.setUpdtProcDtm(dto.getUpdtProcDtm());
    }


}
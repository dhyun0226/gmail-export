package com.osstem.ow.voc.model.common;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EmployeeRequestDto {

    private String corporationCode;

    private String employeeNumber;
}

package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.QnaAnswerDetailDto;
import com.osstem.ow.voc.model.request.QnaRequestDto;
import com.osstem.ow.voc.model.response.QnaResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;
import com.osstem.ow.voc.model.event.QnaDto;

@FeignClient(name = "qnaClient", url = "${voc.api.occ.root.uri}", configuration = FeignClientConfig.class)
public interface QnaServiceClient {
    @PostMapping("/qna-answers")
    QnaAnswerDetailDto createQnaAnswer(QnaAnswerDetailDto qnaAnswerDetailDto);

    @GetMapping("/qnas")
    ResultDto<QnaResponseDto> getQnaList(
            @SpringQueryMap QnaRequestDto requestDto,
            @RequestParam(name = "processStatus", required = false, defaultValue = "") String processStatus);

    @GetMapping("/qnas/{qnaNumber}")
    QnaResponseDto getQnaById(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode,
            @PathVariable("qnaNumber") Long qnaNumber,
            @RequestParam("channelCode") String channelCode,
            @RequestParam("serviceCategoryCode") String serviceCategoryCode);

    @PutMapping("/qna-answers/{qnaNumber}/{qnaAnswerDetailNumber}")
    QnaAnswerDetailDto updateQnaAnswer(
            @PathVariable("qnaNumber") Long qnaNumber,
            @PathVariable("qnaAnswerDetailNumber") Long qnaAnswerDetailNumber,
            @RequestBody QnaAnswerDetailDto qnaAnswerDetailDto
    );

    @PutMapping("/qnas/{qnaNumber}")
    QnaResponseDto updateQna(
            @PathVariable("qnaNumber") Long qnaNumber,
            @RequestBody QnaDto requestDto,
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode
    );
}
package com.osstem.ow.voc.util;

import com.osstem.ow.voc.model.request.VocRequestDto;
import com.osstem.ow.voc.model.response.GroupedVocResponseDto;
import com.osstem.ow.voc.model.response.VocResponseDto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class VocPaginationUtil {

    /**
     * 품목 코드 기준으로 현재 페이지에 해당하는 품목 코드 목록을 계산
     * 플랫 인덱스 기반으로 정확한 페이지네이션 지원
     *
     * @param allItemCodes 모든 품목 코드 목록 (알파벳 순 정렬)
     * @param itemCodeCounts 품목 코드별 VOC 건수
     * @param pageNo 현재 페이지 번호
     * @param pageSize 페이지 크기
     * @return 현재 페이지에 해당하는 품목 코드 목록
     */
    public static List<String> calculateRelevantItemCodes(
            List<String> allItemCodes,
            Map<String, Long> itemCodeCounts,
            int pageNo,
            int pageSize) {

        int startIndex = (pageNo - 1) * pageSize;
        int endIndex = startIndex + pageSize;
        List<String> relevantItemCodes = new ArrayList<>();

        // 전체 플랫 리스트에서의 각 품목 그룹의 위치와 크기 계산
        List<GroupInfo> groupInfos = calculateGroupPositions(allItemCodes, itemCodeCounts);

        // 현재 페이지 범위에 포함되거나 걸쳐있는 품목 코드 찾기
        for (GroupInfo info : groupInfos) {
            // 그룹의 끝이 시작 인덱스보다 크고, 그룹의 시작이 끝 인덱스보다 작으면 이 그룹은 현재 페이지와 겹침
            if (info.endIndex > startIndex && info.startIndex < endIndex) {
                relevantItemCodes.add(info.itemCode);
            }
        }

        return relevantItemCodes;
    }

    /**
     * 모든 그룹(헤더+항목)의 플랫 인덱스상 위치 정보 계산
     *
     * @param allItemCodes 모든 품목 코드 목록
     * @param itemCodeCounts 품목 코드별 VOC 건수
     * @return 각 그룹의 위치 정보 목록
     */
    private static List<GroupInfo> calculateGroupPositions(
            List<String> allItemCodes,
            Map<String, Long> itemCodeCounts) {

        List<GroupInfo> groupInfos = new ArrayList<>();
        int currentIndex = 0;

        for (String itemCode : allItemCodes) {
            // 각 그룹은 헤더(1)와 VOC 항목으로 구성됨
            long itemCount = itemCodeCounts.getOrDefault(itemCode, 0L);
            int groupSize = 1 + (int)itemCount; // 헤더 + VOC 항목 수

            int startIndex = currentIndex;
            int endIndex = startIndex + groupSize;

            groupInfos.add(new GroupInfo(itemCode, startIndex, endIndex));
            currentIndex = endIndex;
        }

        return groupInfos;
    }

    /**
     * 플랫 리스트에서 현재 페이지에 해당하는 항목들 추출
     *
     * @param allItems 플랫화된 전체 항목 리스트 (헤더 + 상세 항목)
     * @param pageNo 현재 페이지 번호
     * @param pageSize 페이지 크기
     * @return 현재 페이지에 해당하는 항목 리스트
     */
    public static <T> List<T> getPageItems(List<T> allItems, int pageNo, int pageSize) {
        int startIndex = (pageNo - 1) * pageSize;
        int endIndex = Math.min(startIndex + pageSize, allItems.size());

        if (startIndex >= allItems.size()) {
            return Collections.emptyList();
        }

        return allItems.subList(startIndex, endIndex);
    }

    /**
     * 품목별 VOC 데이터에 헤더를 추가하여 그룹화된 결과 생성
     * 새로운 createHeader, createDetail 팩토리 메서드 사용
     *
     * @param relevantItemCodes 현재 페이지 관련 품목 코드 목록
     * @param vocData VOC 데이터 목록
     * @param itemNameGetter 품목 코드에서 이름을 얻기 위한 함수
     * @param itemCodeCounts 품목 코드별 VOC 건수
     * @return 헤더가 포함된 그룹화된 결과 목록
     */
    public static List<GroupedVocResponseDto> buildGroupedResults(
            List<String> relevantItemCodes,
            List<VocResponseDto> vocData,
            Function<String, String> itemNameGetter,
            Map<String, Long> itemCodeCounts) {

        if (relevantItemCodes.isEmpty()) {
            return Collections.emptyList();
        }

        List<GroupedVocResponseDto> groupedResults = new ArrayList<>();

        // 품목 코드별로 VOC 데이터 그룹화
        Map<String, List<VocResponseDto>> vocsByItem = vocData.stream()
                .collect(Collectors.groupingBy(VocResponseDto::getItemCode));

        // 각 품목별로 헤더 추가 및 데이터 조합
        for (String itemCode : relevantItemCodes) {
            // 품목별 VOC 건수 조회
            long count = itemCodeCounts.getOrDefault(itemCode, 0L);

            // 품목 헤더 추가 (팩토리 메서드 사용)
            groupedResults.add(GroupedVocResponseDto.createHeader(
                    itemCode,
                    itemNameGetter.apply(itemCode),
                    count
            ));

            // 해당 품목의 VOC 데이터 추가 (팩토리 메서드 사용)
            List<VocResponseDto> itemVocs = vocsByItem.getOrDefault(itemCode, Collections.emptyList());
            for (VocResponseDto voc : itemVocs) {
                groupedResults.add(GroupedVocResponseDto.createDetail(voc));
            }
        }

        return groupedResults;
    }

    /**
     * 대용량 데이터를 위한 메모리 효율적인 페이징 처리
     * 전체 결과 대신 필요한 페이지 범위의 결과만 생성
     *
     * @param allItemCodes 모든 품목 코드 목록
     * @param itemCodeCounts 품목 코드별 VOC 건수
     * @param vocByItemCode 품목 코드별 VOC 데이터 맵
     * @param itemNameGetter 품목 코드에서 이름을 얻기 위한 함수
     * @param pageNo 현재 페이지 번호
     * @param pageSize 페이지 크기
     * @return 현재 페이지에 해당하는 결과
     */
    public static List<GroupedVocResponseDto> getPagedResults(
            List<String> allItemCodes,
            Map<String, Long> itemCodeCounts,
            Map<String, List<VocResponseDto>> vocByItemCode,
            Function<String, String> itemNameGetter,
            int pageNo,
            int pageSize) {

        int startIndex = (pageNo - 1) * pageSize;
        int currentIndex = 0;
        List<GroupedVocResponseDto> pagedResults = new ArrayList<>();

        // 각 품목 그룹의 위치 확인 및 현재 페이지 범위에 해당하는 항목 추가
        for (String itemCode : allItemCodes) {
            long count = itemCodeCounts.getOrDefault(itemCode, 0L);
            List<VocResponseDto> itemVocs = vocByItemCode.getOrDefault(itemCode, Collections.emptyList());
            int groupSize = 1 + itemVocs.size(); // 헤더 + 항목 수

            int groupStartIndex = currentIndex;
            int groupEndIndex = groupStartIndex + groupSize;

            // 현재 그룹이 페이지 범위와 겹치는지 확인
            if (groupEndIndex > startIndex && groupStartIndex < startIndex + pageSize) {
                // 헤더가 페이지 범위에 포함되는지 확인
                if (groupStartIndex >= startIndex && groupStartIndex < startIndex + pageSize) {
                    pagedResults.add(GroupedVocResponseDto.createHeader(
                            itemCode,
                            itemNameGetter.apply(itemCode),
                            count
                    ));
                }

                // 각 상세 항목이 페이지 범위에 포함되는지 확인하고 추가
                for (int i = 0; i < itemVocs.size(); i++) {
                    int itemIndex = groupStartIndex + 1 + i; // 헤더 다음부터 시작
                    if (itemIndex >= startIndex && itemIndex < startIndex + pageSize) {
                        pagedResults.add(GroupedVocResponseDto.createDetail(itemVocs.get(i)));
                    }
                }
            }

            currentIndex = groupEndIndex;
        }

        return pagedResults;
    }

    /**
     * 헤더를 포함한 전체 항목 수 계산
     *
     * @param itemCodeCounts 품목 코드별 VOC 건수
     * @return 전체 항목 수
     */
    public static long calculateTotalItems(Map<String, Long> itemCodeCounts) {
        // 헤더 수 (품목 코드 수) + 모든 VOC 항목 수
        return itemCodeCounts.size() + itemCodeCounts.values().stream().mapToLong(Long::longValue).sum();
    }

    /**
     * 캐시 키 생성
     *
     * @param requestDto 요청 DTO
     * @param prefix 캐시 키 접두어
     * @return 캐시 키
     */
    public static String generateCacheKey(VocRequestDto requestDto, String prefix) {
        StringBuilder key = new StringBuilder(prefix);
        key.append("_").append(requestDto.getVocCategoryCode())
                .append("_").append(requestDto.getItemCode())
                .append("_").append(requestDto.getVocStateCode())
                .append("_").append(requestDto.getStartDate())
                .append("_").append(requestDto.getEndDate());
        return key.toString();
    }

    /**
     * 그룹 정보를 저장하는 내부 클래스
     */
    private static class GroupInfo {
        final String itemCode;
        final int startIndex;
        final int endIndex;

        GroupInfo(String itemCode, int startIndex, int endIndex) {
            this.itemCode = itemCode;
            this.startIndex = startIndex;
            this.endIndex = endIndex;
        }
    }
}
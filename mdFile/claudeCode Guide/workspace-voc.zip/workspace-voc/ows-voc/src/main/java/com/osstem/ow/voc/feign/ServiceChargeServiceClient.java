package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.response.ServiceChargePersonResponseDto;
import com.osstem.ow.voc.model.table.ServiceChargePersonDto;
import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "serviceChargeServiceClient", url = "${voc.api.occ.root.uri}", configuration = FeignClientConfig.class)
public interface ServiceChargeServiceClient {

    /**
     * 서비스 담당자 조회
     */
    @GetMapping("/service-charge-persons/{serviceChargePersonNumber}")
    ServiceChargePersonDto findById(@PathVariable("serviceChargePersonNumber") Long serviceChargePersonNumber);

    /**
     * 서비스 담당자 채널 조회
     */
    @GetMapping("/service-charge-persons/channels/{serviceChargePersonEmployeeNumber}")
    List<String> getChannelsByEmployeeNumber(@PathVariable("serviceChargePersonEmployeeNumber") String serviceChargePersonEmployeeNumber);

    /**
     * 서비스 담당자 등록
     */
    @PostMapping("/service-charge-persons")
    ServiceChargePersonDto create(@Valid @RequestBody ServiceChargePersonDto serviceChargePersonDto);

    /**
     * 서비스 담당자 수정
     */
    @PutMapping("/service-charge-persons/{serviceChargePersonNumber}")
    ServiceChargePersonDto update(
            @PathVariable("serviceChargePersonNumber") Long serviceChargePersonNumber,
            @Valid @RequestBody ServiceChargePersonDto serviceChargePersonDto);

    /**
     * 서비스 담당자 일괄 업데이트
     */
    @PutMapping("/service-charge-persons/update")
    void updateServiceChargePersons(@RequestBody List<ServiceChargePersonDto> serviceChargePersonDtos);

    /**
     * 서비스 담당자 삭제
     */
    @DeleteMapping("/service-charge-persons/{serviceChargePersonNumber}")
    void delete(@PathVariable("serviceChargePersonNumber") Long serviceChargePersonNumber);

    /**
     * 서비스 담당자 목록 조회
     */
    @GetMapping("/service-charge-persons")
    List<ServiceChargePersonResponseDto> findByServiceCategoryCode(@RequestParam String serviceCategoryCode);
}
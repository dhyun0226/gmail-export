package com.osstem.ow.voc.feign;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.request.VocAnswerRequestDto;
import com.osstem.ow.voc.model.response.VocAnswerResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "vocAnswerServiceClient", url = "${voc.api.occ.root.uri}")
public interface VocAnswerServiceClient {

    /**
     * 전체 VOC 답변 조회
     */
    @GetMapping("/voc-answers")
    ResultDto<VocAnswerResponseDto> getAllVocAnswers(
            @SpringQueryMap VocAnswerRequestDto dto,
            @RequestHeader("X-USER-ID") String userId,
            @RequestHeader("X-CORPORATION-CODE") String corporationCode
    );

    /**
     * 단일 VOC 답변 조회
     */
    @GetMapping("/voc-answers/{id}")
    VocAnswerResponseDto getVocAnswerById(@PathVariable("id") Long id);

    /**
     * VOC 답변 생성
     */
    @PostMapping("/voc-answers")
    VocAnswerResponseDto createVocAnswer(@RequestBody VocAnswerRequestDto dto);

    /**
     * VOC 답변 수정
     */
    @PutMapping("/voc-answers/{id}")
    VocAnswerResponseDto updateVocAnswer(
            @PathVariable("id") Long id,
            @RequestBody VocAnswerRequestDto dto
    );

    /**
     * VOC 답변 삭제
     */
    @DeleteMapping("/voc-answers/{id}")
    void deleteVocAnswer(@PathVariable("id") Long id);
}

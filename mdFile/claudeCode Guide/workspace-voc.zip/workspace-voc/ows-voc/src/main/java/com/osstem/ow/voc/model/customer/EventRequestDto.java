package com.osstem.ow.voc.model.customer;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.osstem.ow.voc.model.base.PagingDto;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Schema(description = "이벤트 요청 DTO")
public class EventRequestDto implements PagingDto {

    @Schema(description = "페이지 번호", example = "1")
    private Integer pageNo;

    @Schema(description = "페이지 크기", example = "10")
    private Integer pageSize;

    @Schema(description = "채널 구분 코드", example = "000100010001")
    private String channelCode;

    @Schema(description = "이벤트 등록 상세 구분 코드", example = "000100010001")
    private String serviceCategoryCode;

    @Size(max = 100)
    @Schema(description = "이벤트 제목", example = "이벤트 제목")
    private String eventTitle;

    @Schema(description = "이벤트 내용", example = "이벤트 내용")
    private String eventContent;

    @Size(max = 3)
    @Schema(description = "등록자 법인 코드", example = "001")
    private String registererCorporationCode;

    @Size(max = 30)
    @Schema(description = "등록자 부서 코드", example = "DEP001")
    private String registererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "등록자 사원 번호", example = "EMP00123")
    private String registererEmployeeNumber;

    @Schema(description = "이벤트 시작일시", example = "2025-01-01T00:00:00")
    private LocalDateTime eventStartDatetime;

    @Schema(description = "이벤트 종료일시", example = "2025-01-02T23:59:59")
    private LocalDateTime eventEndDatetime;

    @Size(max = 1)
    @Schema(description = "사용 여부", example = "Y")
    private String useYesOrNo;

    @Schema(description = "조회 건수", example = "100")
    private Short inquiryCount;

    @Schema(description = "이벤트 등록 일시", example = "2024-01-01T12:00:00")
    private LocalDateTime eventRegistrationDatetime;

    @Size(max = 50)
    @Schema(description = "썸네일 파일 ID", example = "THUMBNAIL123")
    private String thumbnailFileId;

    @Schema(description = "썸네일 파일 리스트")
    private List<TxmFileSaveRequest> thumbnailFile;

    @Size(max = 1)
    @Schema(description = "상단 고정 여부", example = "Y")
    private String topFixedYesOrNo;

    @Size(max = 2)
    @Schema(description = "이벤트 참여 구분 코드", example = "01")
    private String eventParticipationDivisionCode;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "FILE12345")
    private String fileId;

    @Schema(description = "파일 리스트")
    private List<TxmFileSaveRequest> fileList;

    @Schema(description = "검색 타입 (title:제목, content:내용, both:제목+내용)", example = "both")
    private String searchType;

    @Schema(description = "검색 키워드", example = "이벤트")
    private String keyword;

    @Schema(description = "시작일", example = "2025-01-01")
    private LocalDateTime fromDate;

    @Schema(description = "종료일", example = "2025-04-04")
    private LocalDateTime toDate;

    @JsonIgnore
    public Pageable getPageable() {
        int pageIndex = getOffset() / getLimit();
        return PageRequest.of(pageIndex, getLimit());
    }
}
package com.osstem.ow.voc.feign;

import com.osstem.ow.api.feign.FeignClientConfig;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.IndividualInquiryAnswerDto;
import com.osstem.ow.voc.model.request.IndividualInquiryRequestDto;
import com.osstem.ow.voc.model.response.IndividualInquiryResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "inquiryClient", url = "${voc.api.occ.root.uri}", configuration = FeignClientConfig.class)
public interface IndividualInquiryServiceClient {
    @PostMapping("/individual-inquiry-answers")
    IndividualInquiryAnswerDto createAnswer(IndividualInquiryAnswerDto individualInquiryAnswerDto);

    @GetMapping("/individual-inquiries")
    ResultDto<IndividualInquiryResponseDto> list(
            @SpringQueryMap IndividualInquiryRequestDto requestDto,
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @RequestHeader(value = "X-CORPORATION-CODE", required = false) String corporationCode);

    @GetMapping("/individual-inquiries/{inquiryNumber}")
    IndividualInquiryResponseDto getInquiryWithAnswer(
            @RequestHeader(name = "X-USER-ID", required = false) String userId,
            @PathVariable("inquiryNumber") Long inquiryNumber);

    @PutMapping("/individual-inquiry-answers/{inquiryNumber}")
    IndividualInquiryAnswerDto update(
            @PathVariable("inquiryNumber") Long inquiryNumber,
            @RequestBody IndividualInquiryAnswerDto individualInquiryAnswerDto);

}

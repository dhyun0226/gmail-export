package com.osstem.ow.voc.model.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import com.osstem.ow.voc.model.table.VocChargePersonDto;
import com.osstem.ow.voc.model.txm.File;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "QnA 답변 상세 DTO")
public class QnaAnswerDetailDto extends BaseDto {

    @NotNull
    @Schema(description = "QnA 번호", example = "1")
    private Long qnaNumber;

    @NotNull
    @Schema(description = "QnA 답변 상세 번호", example = "1001")
    private Long qnaAnswerDetailNumber;

    @Schema(description = "QnA 부모 답변 번호", example = "1001")
    private Long parentAnswerDetailNumber;

    @Schema(description = "QnA 답변 일시", example = "2025-04-04T14:30:00")
    private LocalDateTime qnaAnswerDatetime;

    @Size(max = 20)
    @Schema(description = "답변자 회원 ID", example = "admin123")
    private String answererMemberId;

    @Size(max = 3)
    @Schema(description = "답변자 법인 코드", example = "001")
    private String answererCorporationCode;

    @Size(max = 30)
    @Schema(description = "답변자 부서 코드", example = "DEP001")
    private String answererDepartmentCode;

    @Size(max = 60)
    @Schema(description = "답변자 사원 번호", example = "EMP00123")
    private String answererEmployeeNumber;

    @NotBlank
    @Size(max = 1000)
    @Schema(description = "QnA 답변 내용", example = "문의하신 내용에 대한 답변드립니다. 해당 제품은...")
    private String qnaAnswerContent;

    @Schema(description = "삭제 여부", example = "N")
    private String deleteYn;

    @Size(max = 50)
    @Schema(description = "파일 ID", example = "file456")
    private String answerFileId;

    @Schema(description = "파일 리스트")
    private List<File> fileList;


    public QnaAnswerDetailDto setFromDenallVocNumber(Long qnaNumber) {
        if (qnaNumber == null) {
            return this;
        }
        this.qnaNumber = qnaNumber;
        return this;
    }

    public QnaAnswerDetailDto setFromAnswerDetail(VocAnswerDetailDto answerDetailDto) {
        if (answerDetailDto == null) {
            return this;
        }
        this.qnaAnswerDatetime = answerDetailDto.getVocAnswerDateTime();
        this.qnaAnswerContent = answerDetailDto.getVocAnswerContent();
        this.answerFileId = answerDetailDto.getAnswerFileId();

        return this;
    }

    public QnaAnswerDetailDto setFromChargePerson(VocChargePersonDto chargePersonDto) {
        if (chargePersonDto == null) {
            return this;
        }

        this.answererCorporationCode = chargePersonDto.getVocChargePersonCorporationCode();
        this.answererDepartmentCode = chargePersonDto.getVocChargePersonDepartmentCode();
        this.answererEmployeeNumber = chargePersonDto.getVocChargePersonEmployeeNumber();

        return this;
    }

    public static QnaAnswerDetailDto composeVocAnswerEvent(Long qnaNumber, VocAnswerDetailDto answerDetailDto, VocChargePersonDto chargePersonDto) {
        return new QnaAnswerDetailDto().setFromDenallVocNumber(qnaNumber).setFromAnswerDetail(answerDetailDto).setFromChargePerson(chargePersonDto);
    }


}
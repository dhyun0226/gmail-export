package com.osstem.ow.voc.feign;

import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.NoticeRequestDto;
import com.osstem.ow.voc.model.customer.NoticeResponseDto;
import com.osstem.ow.voc.model.customer.FaqResponseWrapper;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "noticeServiceClient", url = "${voc.api.occ.root.uri}")
public interface NoticeServiceClient {
    @GetMapping("/notices/{id}")
    NoticeResponseDto getNoticeById(@PathVariable("id") Long id , @RequestHeader("X-User-Role") String userRole);

    @PostMapping("/notices")
    NoticeResponseDto createNotice(@RequestBody NoticeRequestDto dto);

    @PutMapping("/notices/{id}")
    NoticeResponseDto updateNotice(@PathVariable("id") Long id, @RequestBody NoticeRequestDto dto);

    @DeleteMapping("/notices/{id}")
    void deleteNotice(@PathVariable("id") Long id);

    @GetMapping("/notices/search")
    ResultDto<NoticeResponseDto> search(@SpringQueryMap NoticeRequestDto dto);
}

package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocAnswerDetailService;
import com.osstem.ow.voc.model.table.VocAnswerDetailDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/voc-answers")
@RequiredArgsConstructor
@Tag(name = "VOC 답변 관리", description = "VOC 답변 관리 API")
public class VocAnswerDetailController {

    private final VocAnswerDetailService vocAnswerService;

    @GetMapping("/{vocNumber}")
    @Operation(summary = "VOC 답변 조회", description = "VOC 번호로 VOC 답변 정보를 조회합니다.")
    public ResponseEntity<VocAnswerDetailDto> findById(@PathVariable Long vocNumber) {
        VocAnswerDetailDto vocAnswerDetailDto = vocAnswerService.findById(vocNumber);
        return ResponseEntity.ok(vocAnswerDetailDto);
    }

    @PostMapping
    @Operation(summary = "VOC 답변 등록", description = "새로운 VOC 답변을 등록합니다.")
    public ResponseEntity<VocAnswerDetailDto> create(@Valid @RequestBody VocAnswerDetailDto vocAnswerDetailDto) {
        VocAnswerDetailDto createdvocAnswerDetailDto = vocAnswerService.create(vocAnswerDetailDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdvocAnswerDetailDto);
    }

    @PutMapping("/{vocNumber}")
    @Operation(summary = "VOC 답변 수정", description = "기존 VOC 답변 정보를 수정합니다.")
    public ResponseEntity<VocAnswerDetailDto> update(
            @PathVariable Long vocNumber,
            @Valid @RequestBody VocAnswerDetailDto vocAnswerDetailDto) {
        VocAnswerDetailDto updatedvocAnswerDetailDto = vocAnswerService.update(vocNumber, vocAnswerDetailDto);
        return ResponseEntity.ok(updatedvocAnswerDetailDto);
    }

    @DeleteMapping("/{vocNumber}")
    @Operation(summary = "VOC 답변 삭제", description = "VOC 답변을 삭제합니다.")
    public ResponseEntity<Void> delete(@PathVariable Long vocNumber) {
        vocAnswerService.delete(vocNumber);
        return ResponseEntity.noContent().build();
    }
}
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocAnswerDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VocAnswerDetailRepository extends JpaRepository<VocAnswerDetail, Long> {
}
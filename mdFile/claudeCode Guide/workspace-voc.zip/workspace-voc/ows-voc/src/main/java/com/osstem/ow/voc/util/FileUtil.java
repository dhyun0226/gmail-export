package com.osstem.ow.voc.util;

import com.osstem.ow.voc.constant.TaskType;
import com.osstem.ow.voc.model.txm.TxmFileListRequest;
import com.osstem.ow.voc.model.txm.TxmFileSaveRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public final class FileUtil {
    /**
     * 파일 정보 일반 설정 메소드
     *
     * @param files    파일 목록
     * @param taskType 파일 타입
     * @param id       식별자
     * @return 설정된 파일 목록
     */
    public static List<TxmFileSaveRequest> prepareFiles(List<TxmFileSaveRequest> files, TaskType taskType, String id) {
        return files.stream()
                .map(file -> {
                    file.setReferenceOwTaskCode(taskType.getTaskCode());
                    file.setReferenceTableName(taskType.getTableName());
                    file.setReferenceDistinguishColumnValueContent(id);
                    return file;
                })
                .collect(Collectors.toList());
    }

    /**
     * 문의 파일 정보 설정
     */
    public static List<TxmFileSaveRequest> prepareInquiryFiles(List<TxmFileSaveRequest> files, String inquiryId) {
        return prepareFiles(files, TaskType.INQUIRY, inquiryId);
    }

    /**
     * 공지사항 파일 정보 설정
     */
    public static List<TxmFileSaveRequest> prepareNoticeFiles(List<TxmFileSaveRequest> files, String noticeId) {
        return prepareFiles(files, TaskType.NOTICE, noticeId);
    }

    /**
     * QnA 파일 정보 설정
     */
    public static List<TxmFileSaveRequest> prepareQnaFiles(List<TxmFileSaveRequest> files, String inquiryId) {
        return prepareFiles(files, TaskType.QNA, inquiryId);
    }

    /**
     * VOC 답변 파일 정보 설정
     */
    public static List<TxmFileSaveRequest> prepareVocAnswerFiles(List<TxmFileSaveRequest> files, String vocNumber) {
        return prepareFiles(files, TaskType.VOCANSWER, vocNumber);
    }

    /**
     * 파일 요청 객체 생성 - 지정된 파일 타입 사용
     *
     * @param taskType 파일 타입
     * @param id       식별자
     * @return 파일 요청 객체
     */
    public static TxmFileListRequest buildRequest(TaskType taskType, String id) {
        return TxmFileListRequest.builder()
                .referenceOwTaskCode(taskType.getTaskCode())
                .referenceTableName(taskType.getTableName())
                .referenceDistinguishColumnValueContent(id)
                .build();
    }
}
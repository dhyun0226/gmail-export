package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.entity.Voc;
import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.entity.VocChangeHistoryId;
import com.osstem.ow.voc.repository.VocChangeHistoryRepository;
import com.osstem.ow.voc.structMapper.VocChangeHistoryStruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class VocChangeHistoryService {

    private final VocChangeHistoryStruct vocChangeHistoryStruct;
    private final VocChangeHistoryRepository vocChangeHistoryRepository;

    public VocChangeHistory save(Voc voc) {
        VocChangeHistory vocChangeHistory = vocChangeHistoryStruct.toHistory(voc);
        // 1) java.util.Date 가 아니라 java.time.LocalDateTime 을 쓰세요
        LocalDateTime now = LocalDateTime.now();
        // 2) 복합키 VO 생성
        VocChangeHistoryId id = new VocChangeHistoryId(voc.getVocNumber(), now);
        // 3) 엔티티에 id 객체 통째로 세팅
        vocChangeHistory.setId(id);

        return vocChangeHistoryRepository.save(vocChangeHistory);
    }
}

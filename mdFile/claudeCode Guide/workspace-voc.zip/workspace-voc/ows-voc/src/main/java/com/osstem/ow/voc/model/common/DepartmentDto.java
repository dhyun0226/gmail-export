package com.osstem.ow.voc.model.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentDto {

    @JsonProperty("corporationCode")
    private String corporationCode;

    @JsonProperty("departmentCode")
    private String departmentCode;

    @JsonProperty("upDepartmentCode")
    private String upDepartmentCode;

    @JsonProperty("departmentName")
    private String departmentName;

    @JsonProperty("costCenterCode")
    private String costCenterCode;

    @JsonProperty("costCenterName")
    private String costCenterName;

    @JsonProperty("effectiveStartDate")
    private String effectiveStartDate;

    @JsonProperty("effectiveEndDate")
    private String effectiveEndDate;

    @JsonProperty("effectiveEndYn")
    private String effectiveEndYn;

    @JsonProperty("overseasCorporationEffectiveYn")
    private String overseasCorporationEffectiveYn;

    @JsonProperty("departmentLevelOrder")
    private Integer departmentLevelOrder;

    @JsonProperty("sortOrder")
    private Integer sortOrder;
}
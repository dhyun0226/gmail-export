package com.osstem.ow.voc.model.txm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class File {
    @Schema(description = "파일ID")
    String fileId;
    @Schema(description = "파일경로")
    String filePath;
    @Schema(description = "참조 OW업무코드")
    String referenceOwTaskCode;
    @Schema(description = "참조 테이블명")
    String referenceTableName;
    @Schema(description = "참조 식별 컬럼 값내용")
    String referenceDistinguishColumnValueContent;
    @Schema(description = "원본파일명")
    String fileOriginalName;
    @Schema(description = "파일확장자명")
    String fileExtensionName;
    @Schema(description = "파일크기")
    String fileSize;
}
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.constant.TaskType;
import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.model.response.TaskCategoryResponseDto;
import com.osstem.ow.voc.model.table.VocCategoryDto;
import com.osstem.ow.voc.repository.VocCategoryQueryRepository;
import com.osstem.ow.voc.repository.VocCategoryRepository;
import com.osstem.ow.voc.structMapper.VocCategoryStruct;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
public class VocCategoryService {

    private final VocCategoryRepository vocCategoryRepository;
    private final VocCategoryStruct vocCategoryStruct;
    private final VocCategoryQueryRepository vocCategoryQueryRepository;

    /**
     * 모든 VOC 카테고리 조회 (DTO 변환)
     */
    @Transactional(readOnly = true)
    public List<VocCategoryDto> getAllVocCategories() {
        List<VocCategory> entities = vocCategoryRepository.findAllByOrderBySortOrderAsc();
        return vocCategoryStruct.toDtoList(entities);
    }

    /**
     * 특정 VOC 카테고리 조회 (DTO 변환)
     */
    @Transactional(readOnly = true)
    public VocCategoryDto getVocCategoryById(String vocCategoryCode) {
        return vocCategoryRepository.findById(vocCategoryCode)
                .map(vocCategoryStruct::toDto)
                .orElseThrow(() -> new EntityNotFoundException("VOC 카테고리를 찾을 수 없습니다: " + vocCategoryCode));
    }

    /**
     * VOC 카테고리 생성
     */
    @Transactional
    public VocCategoryDto createVocCategory(VocCategoryDto vocCategoryDto) {
        // 중복 체크
        if (vocCategoryRepository.existsById(vocCategoryDto.getVocCategoryCode())) {
            throw new IllegalArgumentException("이미 존재하는 VOC 카테고리 코드입니다: " + vocCategoryDto.getVocCategoryCode());
        }

        // 상위 카테고리 존재 여부 확인 (있는 경우)
        if (vocCategoryDto.getUpVocCategoryCode() != null && !vocCategoryDto.getUpVocCategoryCode().isEmpty()) {
            vocCategoryRepository.findById(vocCategoryDto.getUpVocCategoryCode())
                    .orElseThrow(() -> new EntityNotFoundException("상위 VOC 카테고리를 찾을 수 없습니다: " + vocCategoryDto.getUpVocCategoryCode()));
        }

        // DTO -> 엔티티 변환
        VocCategory entity = vocCategoryStruct.toEntity(vocCategoryDto);

        // 상위 카테고리 설정
        if (vocCategoryDto.getUpVocCategoryCode() != null && !vocCategoryDto.getUpVocCategoryCode().isEmpty()) {
            VocCategory parentEntity = vocCategoryRepository.getReferenceById(vocCategoryDto.getUpVocCategoryCode());
            entity.setUpVocCategoryCode(parentEntity);
        }

        // 저장
        VocCategory savedEntity = vocCategoryRepository.save(entity);

        // 엔티티 -> DTO 변환하여 반환
        return vocCategoryStruct.toDto(savedEntity);
    }


    /**
     * VOC 카테고리 삭제
     */
    @Transactional
    public void deleteVocCategory(String vocCategoryCode) {
        // 카테고리 존재 여부 확인
        if (!vocCategoryRepository.existsById(vocCategoryCode)) {
            throw new EntityNotFoundException("VOC 카테고리를 찾을 수 없습니다: " + vocCategoryCode);
        }

        // 하위 카테고리가 있는지 확인
        if (vocCategoryRepository.existsByUpVocCategoryCode_VocCategoryCode(vocCategoryCode)) {
            throw new IllegalStateException("하위 카테고리가 존재하여 삭제할 수 없습니다: " + vocCategoryCode);
        }

        // 삭제 (또는 soft delete 처리)
        vocCategoryRepository.deleteById(vocCategoryCode);
    }

    /**
     * 특정 상위 카테고리에 속한 하위 카테고리 목록 조회
     */
    @Transactional(readOnly = true)
    public List<VocCategoryDto> getChildCategories(String parentCategoryCode) {
        List<VocCategory> childEntities = vocCategoryRepository.findByUpVocCategoryCode_VocCategoryCode(parentCategoryCode);
        return vocCategoryStruct.toDtoList(childEntities);
    }

    /**
     * 최상위 카테고리 목록 조회 (상위 카테고리가 없고 openYn 조건을 만족하는 카테고리)
     */
    @Transactional(readOnly = true)
    public List<VocCategoryDto> getRootCategoriesByOpenYn(Character openYn) {
        List<VocCategory> rootEntities = vocCategoryQueryRepository.findRootCategoriesByOpenYn(openYn);
        return vocCategoryStruct.toDtoList(rootEntities);
    }

    /**
     * 엔티티를 직접 조회해야 하는 내부 메서드 (서비스 내부에서만 사용)
     */
    @Transactional(readOnly = true)
    protected VocCategory getVocCategoryEntityById(String vocCategoryCode) {
        return vocCategoryRepository.findById(vocCategoryCode)
                .orElseThrow(() -> new EntityNotFoundException("VOC 카테고리를 찾을 수 없습니다: " + vocCategoryCode));
    }

    /**
     * 특정 카테고리의 최상위(루트) 카테고리 조회
     * @param categoryCode 카테고리 코드
     * @return 최상위 카테고리 DTO
     */
    @Transactional(readOnly = true)
    public VocCategoryDto findRootCategory(String categoryCode) {
        // 카테고리 코드 유효성 검사
        if (categoryCode == null || categoryCode.isEmpty()) {
            throw new IllegalArgumentException("카테고리 코드는 필수 입력값입니다.");
        }

        // 존재하는 카테고리인지 확인
        if (!vocCategoryRepository.existsById(categoryCode)) {
            throw new EntityNotFoundException("카테고리를 찾을 수 없습니다: " + categoryCode);
        }

        // 최상위 카테고리 조회
        VocCategory rootCategory = vocCategoryQueryRepository.findRootCategory(categoryCode);

        if (rootCategory == null) {
            throw new EntityNotFoundException("최상위 카테고리를 찾을 수 없습니다: " + categoryCode);
        }

        // 엔티티를 DTO로 변환하여 반환
        return vocCategoryStruct.toDto(rootCategory);
    }

    /**
     * taskName으로 해당하는 2레벨 카테고리가 존재하는 1레벨 카테고리들을 조회
     * @param taskName 작업명 (예: "event")
     * @param openYn 공개 여부
     * @return 1레벨 카테고리 DTO 리스트
     */
    public List<VocCategoryDto> getRootCategoriesByTaskNameAndOpenYn(String taskName, Character openYn) {
        // taskName으로 TaskType enum에서 taskCode 찾기
        String taskCode = findTaskCodeByTaskName(taskName);
        if (taskCode == null) {
            throw new IllegalArgumentException("Invalid task name: " + taskName);
        }

        List<VocCategory> rootEntities = vocCategoryQueryRepository
                .findRootCategoriesByTaskCodeAndOpenYn(taskCode, openYn);
        return vocCategoryStruct.toDtoList(rootEntities);
    }

    /**
     * taskName으로 TaskType enum에서 taskCode를 찾는 헬퍼 메서드
     */
    private String findTaskCodeByTaskName(String taskName) {
        for (TaskType taskType : TaskType.values()) {
            if (taskType.getTaskName().equalsIgnoreCase(taskName)) {
                return taskType.getTaskCode();
            }
        }
        return null;
    }

    /**
     * 2레벨 카테고리 목록 조회 (distinct 적용)
     */
    /**
     * TaskType과 일치하는 2레벨 카테고리 조회 및 변환
     * @param openYn 공개 여부
     * @return TaskType 기준으로 매핑된 카테고리 목록
     */
    @Transactional(readOnly = true)
    public List<TaskCategoryResponseDto> getMatchingTaskCategories(Character openYn) {
        // 1. 2레벨 카테고리 데이터 가져오기
        List<VocCategoryDto> secondLevelCategories = vocCategoryQueryRepository.findSecondLevelCategories(openYn);

        // 2. 중복 제거를 위한 맵 생성
        Map<String, TaskCategoryResponseDto> distinctCategories = new HashMap<>();

        // 3. 결과를 저장할 맵 (sortOrder를 키로 사용)
        Map<Integer, TaskCategoryResponseDto> sortedCategories = new TreeMap<>();

        // 4. 필터링 및 매핑
        for (VocCategoryDto category : secondLevelCategories) {
            String code = category.getVocCategoryCode();
            String name = category.getVocCategoryName();

            // '_' 기준으로 분리해서 뒷부분 확인
            if (code != null && code.contains("_")) {
                String[] parts = code.split("_");
                if (parts.length > 1) {
                    String suffix = parts[1];

                    // TaskType 열거형에서 일치하는 항목 찾기
                    for (TaskType taskType : TaskType.values()) {
                        // VOCANSWER는 제외
                        if (taskType != TaskType.VOCANSWER && suffix.equals(taskType.getTaskCode())) {
                            TaskCategoryResponseDto dto = new TaskCategoryResponseDto(
                                    taskType.getTaskCode(),
                                    taskType.name().toLowerCase(),
                                    name
                            );

                            // vocCategoryName 기준으로 중복 제거하고, 최초 발견된 항목만 유지
                            if (!distinctCategories.containsKey(name)) {
                                distinctCategories.put(name, dto);
                                // 정렬을 위해 sortOrder를 키로 사용
                                sortedCategories.put(taskType.getSortOrder(), dto);
                            }
                            break;
                        }
                    }
                }
            }
        }

        // 5. 정렬된 결과 반환 (TreeMap은 키를 기준으로 자동 정렬)
        return new ArrayList<>(sortedCategories.values());
    }
}
package com.osstem.ow.voc.controller;

import com.osstem.ow.voc.domain.VocService;
import com.osstem.ow.voc.model.base.GroupedResultDto;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.request.VocRequestDto;
import com.osstem.ow.voc.model.response.GroupedVocResponseDto;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.model.table.VocDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/vocs")
@RequiredArgsConstructor
@Tag(name = "VOC 관리", description = "Voice of Customer 관리 API")
public class VocController {

    private final VocService vocService;

    @GetMapping("/{vocNumber}")
    @Operation(summary = "VOC 조회", description = "VOC 번호로 VOC 정보를 조회합니다.")
    public ResponseEntity<VocDto> findById(@PathVariable Long vocNumber) {
        return ResponseEntity.ok(vocService.findById(vocNumber));
    }

    @GetMapping("/{vocNumber}/with-answer")
    @Operation(summary = "VOC 상세 조회", description = "VOC 번호로 VOC와 답변 정보를 함께 조회합니다.")
    public ResponseEntity<VocResponseDto> findByIdWithAnswersAndHistories(@PathVariable Long vocNumber) {
        return ResponseEntity.ok(vocService.findByIdWithAnswersAndHistories(vocNumber));
    }

    @PostMapping
    @Operation(summary = "VOC 등록", description = "새로운 VOC를 등록합니다.")
    public ResponseEntity<VocDto> create(@Valid @RequestBody VocDto vocDto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(vocService.create(vocDto));
    }

    @PutMapping("/{vocNumber}")
    @Operation(summary = "VOC 수정", description = "기존 VOC 정보를 수정합니다.")
    public ResponseEntity<VocDto> update(
            @PathVariable Long vocNumber,
            @Valid @RequestBody VocDto vocDto) {
        return ResponseEntity.ok(vocService.update(vocNumber, vocDto));
    }

    @PutMapping("/{vocNumber}/chargePerson")
    @Operation(summary = "VOC 담당자 수정", description = "VOC 담당자 정보를 수정합니다.")
    public ResponseEntity<VocDto> updateChargePerson(
            @PathVariable Long vocNumber,
            @Valid @RequestBody VocRequestDto vocRequestDto) {
        return ResponseEntity.ok(vocService.updateChargePerson(vocNumber, vocRequestDto.getVocChargePersonNumber()));
    }

    @DeleteMapping("/{vocNumber}")
    @Operation(summary = "VOC 삭제", description = "VOC를 논리적으로 삭제합니다.")
    public ResponseEntity<Void> delete(
            @PathVariable Long vocNumber,
            @RequestParam String processorId) {
        vocService.delete(vocNumber, processorId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    @Operation(summary = "VOC 목록 검색", description = "조건에 맞는 VOC 목록을 조회합니다.")
    public ResponseEntity<ResultDto<VocResponseDto>> search(@RequestHeader(value = "X-USER-ID", required = false) String userId, @RequestHeader(value = "X-DEPARTMENT-CODE", required = false) String departmentCode, @Valid VocRequestDto vocRequestDto) {
        return ResponseEntity.ok(vocService.search(vocRequestDto, userId, departmentCode));
    }


    @GetMapping("/grouped-by-item")
    public ResponseEntity<GroupedResultDto<GroupedVocResponseDto>> getGroupedVocsByItem(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @Parameter(description = "VOC 조회 요청 정보") VocRequestDto requestDto) {

        // 기본값 설정은 서비스 레이어에서 처리
        GroupedResultDto<GroupedVocResponseDto> result = vocService.searchGroupedByItem(requestDto, userId);
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "부서별 그룹화된 VOC 목록 조회", description = "부서별로 그룹화된 VOC 목록을 조회합니다.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "조회 성공"),
            @ApiResponse(responseCode = "400", description = "잘못된 요청"),
            @ApiResponse(responseCode = "500", description = "서버 오류")
    })

    @GetMapping("/grouped-by-dept")
    public ResponseEntity<GroupedResultDto<GroupedVocResponseDto>> getGroupedVocsByDept(
            @RequestHeader(value = "X-USER-ID", required = false) String userId,
            @Parameter(description = "VOC 조회 요청 정보") VocRequestDto requestDto) {

        // 기본값 설정은 서비스 레이어에서 처리
        GroupedResultDto<GroupedVocResponseDto> result = vocService.searchGroupedByDept(requestDto, userId);
        return ResponseEntity.ok(result);
    }

    @PutMapping("/{vocNumber}/denall")
    @Operation(summary = "VOC 수정", description = "기존 VOC 정보를 수정합니다.")
    public ResponseEntity<VocDto> updateDenall(
            @PathVariable Long vocNumber,
            @Valid @RequestBody VocDto vocDto) {
        return ResponseEntity.ok(vocService.updateDenall(vocNumber, vocDto));
    }

    @PutMapping("/{vocNumber}/classification")
    @Operation(summary = "VOC 분류", description = "기존 VOC 정보를 분류합니다.")
    public ResponseEntity<VocDto> classifyVoc(
            @PathVariable Long vocNumber,
            @Valid @RequestBody VocDto vocDto) {
        return ResponseEntity.ok(vocService.classifyVoc(vocNumber, vocDto));
    }

}
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.constant.ProductCategoryUtil;
import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.model.common.OrganizationResponseDto;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import com.osstem.ow.voc.model.statistic.ProductCategoryVocStatisticsDto;
import com.osstem.ow.voc.repository.VocStatisticsQueryRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VocItemStatisticsService {

    private final VocStatisticsQueryRepository vocStatisticsQueryRepository;
    private final CommonServiceClient commonServiceClient;

    /**
     * 제품 카테고리 구조 데이터 조회
     *
     * @param condition 검색 조건
     * @return 제품 카테고리 구조 데이터
     */
    private List<ProductCategoryVocStatisticsDto> getProductCategoryStructure(VocStatisticsRequestDto condition) {
        // ProductCategoryUtil을 사용하여 제품 카테고리 트리 가져오기
        List<ProductCategoryUtil.DepartmentData> productCategoryTree = ProductCategoryUtil.getProductCategoryTreeList();

        // DepartmentData를 ProductCategoryVocStatisticsDto로 변환
        return productCategoryTree.stream()
                .map(this::convertToProductCategoryVocStatisticsDto)
                .collect(Collectors.toList());
    }

    /**
     * DepartmentData를 ProductCategoryVocStatisticsDto로 변환
     */
    private ProductCategoryVocStatisticsDto convertToProductCategoryVocStatisticsDto(ProductCategoryUtil.DepartmentData departmentData) {
        ProductCategoryVocStatisticsDto dto = new ProductCategoryVocStatisticsDto();

        dto.setKey(departmentData.getKey());
        dto.setParentId(departmentData.getParentId());
        dto.setDisplay(departmentData.getDisplay());

        // 제품 카테고리 코드 설정 (아이템 코드로 사용될 값)
        Map<String, Object> data = departmentData.getData();
        if (data != null) {
            String deptCode = (String) data.get("deptCode");
            String deptName = (String) data.get("deptName");

            dto.setDeptCode(deptCode);
            dto.setDeptName(deptName);

            // 루트 노드가 아닌 경우에만 제품 카테고리 코드 설정
            if (!"0000".equals(deptCode)) {
                // 카테고리 이름으로 value 가져오기
                ProductCategoryUtil.ProductCategory category = ProductCategoryUtil.findCategoryByText(deptName);
                if (category != null) {
                    dto.setItemCode(category.getValue());
                }
            }
        }

        // 통계 맵 초기화
        dto.setStatistics(new HashMap<>());
        dto.setTotalCount(0);

        return dto;
    }

    /**
     * 부서 코드 리스트를 조회하는 공통 메소드
     *
     * @param departmentCode 부서 코드
     * @return 부서 코드 리스트 (하위 부서 포함)
     */
    private List<String> getDepartmentCodes(String departmentCode) {
        if (StringUtils.isEmpty(departmentCode)) {
            return new ArrayList<>();
        }
        OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode);

        if (result != null && result.getData() != null) {
            return result.getData().stream()
                    .map(org -> org.getData().getDepartmentCode())
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }

    /**
     * 일별 VOC 제품 카테고리 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 노드 리스트
     */
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
        // 제품 카테고리 구조 데이터 조회
        List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 조건에 따른 통계 조회
        Map<String, Map<String, Integer>> itemStatistics = vocStatisticsQueryRepository.getVocStatisticsByItemAndDayWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                condition.getVocCategoryCode(), condition.getItemCode(), chargeDepartmentCodes, registerDepartmentCodes
        );

        // 제품 카테고리에 통계 정보 추가
        enrichProductCategoryStructureWithStatistics(productCategoryStructure, itemStatistics);

        // total 키 추가
        addTotalKeyToStatistics(productCategoryStructure);

        return productCategoryStructure;
    }

    /**
     * 주별 VOC 제품 카테고리 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 노드 리스트
     */
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByWeek(VocStatisticsRequestDto condition) {
        // 제품 카테고리 구조 데이터 조회
        List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 주별 통계 조회
        Map<String, Map<String, Integer>> itemStatistics = vocStatisticsQueryRepository.getVocStatisticsByItemAndWeekWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                condition.getVocCategoryCode(), condition.getItemCode(), chargeDepartmentCodes, registerDepartmentCodes
        );

        // 제품 카테고리에 통계 정보 추가
        enrichProductCategoryStructureWithStatistics(productCategoryStructure, itemStatistics);

        // total 키 추가
        addTotalKeyToStatistics(productCategoryStructure);

        return productCategoryStructure;
    }

    /**
     * 월별 VOC 제품 카테고리 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 노드 리스트
     */
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByMonth(VocStatisticsRequestDto condition) {
        // 제품 카테고리 구조 데이터 조회
        List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 월별 통계 조회
        Map<String, Map<String, Integer>> itemStatistics = vocStatisticsQueryRepository.getVocStatisticsByItemAndMonthWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                condition.getVocCategoryCode(), condition.getItemCode(), chargeDepartmentCodes, registerDepartmentCodes
        );

        // 제품 카테고리에 통계 정보 추가
        enrichProductCategoryStructureWithStatistics(productCategoryStructure, itemStatistics);

        // total 키 추가
        addTotalKeyToStatistics(productCategoryStructure);

        return productCategoryStructure;
    }

    /**
     * 연도별 VOC 제품 카테고리 통계 조회
     *
     * @param condition 검색 조건
     * @return 통계가 포함된 제품 카테고리 노드 리스트
     */
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByYear(VocStatisticsRequestDto condition) {
        // 제품 카테고리 구조 데이터 조회
        List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);

        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());

        // 연도별 통계 조회
        Map<String, Map<String, Integer>> itemStatistics = vocStatisticsQueryRepository.getVocStatisticsByItemAndYearWithConditions(
                condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                condition.getVocCategoryCode(), condition.getItemCode(), chargeDepartmentCodes, registerDepartmentCodes
        );

        // 제품 카테고리에 통계 정보 추가
        enrichProductCategoryStructureWithStatistics(productCategoryStructure, itemStatistics);

        // total 키 추가
        addTotalKeyToStatistics(productCategoryStructure);

        return productCategoryStructure;
    }

    /**
     * 제품 카테고리 구조에 통계 정보 추가
     */
    private void enrichProductCategoryStructureWithStatistics(
            List<ProductCategoryVocStatisticsDto> productCategoryStructure,
            Map<String, Map<String, Integer>> itemStatistics) {

        // 각 노드에 해당하는 통계 정보 설정
        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            String itemCode = node.getItemCode();

            // 아이템 코드가 있는 경우에만 통계 추가
            if (itemCode != null && itemStatistics.containsKey(itemCode)) {
                node.setStatistics(new HashMap<>(itemStatistics.get(itemCode)));

                // 통계 합계 계산
                int total = itemStatistics.get(itemCode).values().stream()
                        .mapToInt(Integer::intValue)
                        .sum();
                node.setTotalCount(total);
            }
        }

        // 루트 노드와 부모 노드에 자식 노드의 통계 합산 (하위에서 상위로 집계)
        Map<String, ProductCategoryVocStatisticsDto> nodeMap = productCategoryStructure.stream()
                .collect(Collectors.toMap(ProductCategoryVocStatisticsDto::getKey, node -> node));

        // 자식 노드부터 처리 (재귀적으로 처리하기보다 단순화)
        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            if (node.getParentId() != null && nodeMap.containsKey(node.getParentId())) {
                ProductCategoryVocStatisticsDto parent = nodeMap.get(node.getParentId());

                // 부모 노드의 통계 정보 업데이트
                for (Map.Entry<String, Integer> entry : node.getStatistics().entrySet()) {
                    parent.getStatistics().merge(entry.getKey(), entry.getValue(), Integer::sum);
                }

                // 총합도 추가
                parent.setTotalCount(parent.getTotalCount() + node.getTotalCount());
            }
        }
    }

    /**
     * 통계 데이터에 total 키 추가
     */
    private void addTotalKeyToStatistics(List<ProductCategoryVocStatisticsDto> productCategoryStructure) {
        // 각 노드별로 total 키 추가
        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            Map<String, Integer> statistics = node.getStatistics();

            // "total" 키에 총합 추가
            statistics.put("total", node.getTotalCount());
        }
    }


}
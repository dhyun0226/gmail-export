# VocItemStatisticsService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 심각한 코드 중복
**문제점**: 4개의 메서드가 거의 동일한 로직을 가지고 있어 유지보수성 극도로 저하
**라인**: 103-123, 131-151, 159-179, 187-207번 라인
```java
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);
    List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
    List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());
    // 거의 동일한 패턴이 4번 반복됨
}
```

#### 예외 처리 부재
**문제점**: 복잡한 비즈니스 로직에서 예외 처리가 전혀 없어 장애 시 추적 불가
**라인**: 전체 메서드
```java
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // 외부 서비스 호출, 데이터베이스 조회, 복잡한 계산 로직에서 예외 처리 없음
    OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode);
    Map<String, Map<String, Integer>> itemStatistics = vocStatisticsQueryRepository.getVocStatisticsByItemAndDayWithConditions(...);
}
```

#### 단일 책임 원칙 심각한 위반
**문제점**: 하나의 메서드가 너무 많은 책임을 가져 복잡도가 극도로 높음
**라인**: 103-123번 라인 (그리고 다른 유사한 메서드들)
```java
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // 1. 제품 카테고리 구조 조회
    // 2. 부서 코드 조회 (2번)
    // 3. 통계 데이터 조회
    // 4. 데이터 집계 및 변환
    // 5. Total 키 추가
    // 너무 많은 책임이 한 메서드에 집중됨
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 파라미터 검증 부재  
**문제점**: null 파라미터나 유효하지 않은 조건에 대한 검증이 없음
**라인**: 103, 131, 159, 187번 라인
```java
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // condition null 검증 없음
    // condition의 내부 필드들 유효성 검증 없음
    List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
}
```

#### 하드코딩된 값
**문제점**: 설정 가능해야 할 값들이 하드코딩되어 있음
**라인**: 85, 59번 라인
```java
OrganizationResponseDto result = commonServiceClient.getDepartment("KR1", departmentCode); // "KR1" 하드코딩

if (!"0000".equals(deptCode)) { // "0000" 하드코딩
```

#### 로깅 부재
**문제점**: 복잡한 통계 처리 과정을 추적할 수 없음
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class VocItemStatisticsService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 복잡한 중첩 로직
**문제점**: enrichProductCategoryStructureWithStatistics 메서드가 너무 복잡함
**라인**: 212-250번 라인
```java
private void enrichProductCategoryStructureWithStatistics(...) {
    // 40라인의 복잡한 중첩 로직
    // 통계 계산, 트리 구조 처리, 집계 로직이 모두 섞여있음
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 읽기 전용 트랜잭션 설정이 없어 성능 최적화 부족
**라인**: 전체 public 메서드
```java
// @Transactional(readOnly = true) 애노테이션 없음
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 통계를 조회했는지 추적 불가
**라인**: 전체 메서드
```java
public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
    // 사용자 정보 로깅 없음
}
```

## 2. 개선 코드 예시

### 2.1 중복 제거 및 구조 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.constant.ProductCategoryUtil;
import com.osstem.ow.voc.feign.CommonServiceClient;
import com.osstem.ow.voc.model.common.OrganizationResponseDto;
import com.osstem.ow.voc.model.request.VocStatisticsRequestDto;
import com.osstem.ow.voc.model.statistic.ProductCategoryVocStatisticsDto;
import com.osstem.ow.voc.repository.VocStatisticsQueryRepository;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class VocItemStatisticsService {

    private final VocStatisticsQueryRepository vocStatisticsQueryRepository;
    private final CommonServiceClient commonServiceClient;
    
    @Value("${voc.statistics.default-corporation-code:KR1}")
    private String defaultCorporationCode;
    
    @Value("${voc.statistics.root-department-code:0000}")
    private String rootDepartmentCode;

    /**
     * 일별 VOC 제품 카테고리 통계 조회
     */
    @Transactional(readOnly = true)
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByDay(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.DAY);
    }

    /**
     * 주별 VOC 제품 카테고리 통계 조회
     */
    @Transactional(readOnly = true)
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByWeek(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.WEEK);
    }

    /**
     * 월별 VOC 제품 카테고리 통계 조회
     */
    @Transactional(readOnly = true)
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByMonth(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.MONTH);
    }

    /**
     * 연도별 VOC 제품 카테고리 통계 조회
     */
    @Transactional(readOnly = true)
    public List<ProductCategoryVocStatisticsDto> getVocStatisticsByYear(VocStatisticsRequestDto condition) {
        return getVocStatistics(condition, StatisticsPeriod.YEAR);
    }

    /**
     * 통합된 통계 조회 메서드
     */
    private List<ProductCategoryVocStatisticsDto> getVocStatistics(VocStatisticsRequestDto condition, StatisticsPeriod period) {
        log.info("VOC 제품 카테고리 통계 조회 시작 - period: {}, startDate: {}, endDate: {}", 
                period, condition.getStartDate(), condition.getEndDate());
        
        try {
            // 파라미터 검증
            validateStatisticsRequest(condition);
            
            // 1. 제품 카테고리 구조 데이터 조회
            List<ProductCategoryVocStatisticsDto> productCategoryStructure = getProductCategoryStructure(condition);
            
            // 2. 부서 코드 조회
            StatisticsContext context = createStatisticsContext(condition);
            
            // 3. 통계 데이터 조회
            Map<String, Map<String, Integer>> itemStatistics = getStatisticsData(condition, context, period);
            
            // 4. 제품 카테고리에 통계 정보 추가
            enrichProductCategoryWithStatistics(productCategoryStructure, itemStatistics);
            
            // 5. total 키 추가
            addTotalKeyToStatistics(productCategoryStructure);
            
            log.info("VOC 제품 카테고리 통계 조회 완료 - period: {}, resultCount: {}", 
                    period, productCategoryStructure.size());
            
            return productCategoryStructure;
            
        } catch (Exception e) {
            log.error("VOC 제품 카테고리 통계 조회 실패 - period: {}, error: {}", period, e.getMessage(), e);
            throw new BusinessException("voc.statistics.retrieval.failed", e);
        }
    }

    /**
     * 통계 조회 컨텍스트 생성
     */
    private StatisticsContext createStatisticsContext(VocStatisticsRequestDto condition) {
        List<String> chargeDepartmentCodes = getDepartmentCodes(condition.getVocChargePersonDepartmentCode());
        List<String> registerDepartmentCodes = getDepartmentCodes(condition.getVocRegistererDepartmentCode());
        
        return new StatisticsContext(chargeDepartmentCodes, registerDepartmentCodes);
    }

    /**
     * 기간별 통계 데이터 조회
     */
    private Map<String, Map<String, Integer>> getStatisticsData(VocStatisticsRequestDto condition, 
                                                                StatisticsContext context, 
                                                                StatisticsPeriod period) {
        switch (period) {
            case DAY:
                return vocStatisticsQueryRepository.getVocStatisticsByItemAndDayWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(), 
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            case WEEK:
                return vocStatisticsQueryRepository.getVocStatisticsByItemAndWeekWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(), 
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            case MONTH:
                return vocStatisticsQueryRepository.getVocStatisticsByItemAndMonthWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(), 
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            case YEAR:
                return vocStatisticsQueryRepository.getVocStatisticsByItemAndYearWithConditions(
                        condition.getStartDate(), condition.getEndDate(), condition.getVocStateCode(),
                        condition.getVocCategoryCode(), condition.getItemCode(), 
                        context.getChargeDepartmentCodes(), context.getRegisterDepartmentCodes());
            default:
                throw new BusinessException("voc.statistics.invalid.period");
        }
    }

    /**
     * 제품 카테고리 구조 데이터 조회
     */
    private List<ProductCategoryVocStatisticsDto> getProductCategoryStructure(VocStatisticsRequestDto condition) {
        try {
            List<ProductCategoryUtil.DepartmentData> productCategoryTree = ProductCategoryUtil.getProductCategoryTreeList();
            
            return productCategoryTree.stream()
                    .map(this::convertToProductCategoryVocStatisticsDto)
                    .collect(Collectors.toList());
                    
        } catch (Exception e) {
            log.error("제품 카테고리 구조 조회 실패", e);
            throw new BusinessException("voc.statistics.category.structure.failed", e);
        }
    }

    /**
     * DepartmentData를 ProductCategoryVocStatisticsDto로 변환
     */
    private ProductCategoryVocStatisticsDto convertToProductCategoryVocStatisticsDto(ProductCategoryUtil.DepartmentData departmentData) {
        ProductCategoryVocStatisticsDto dto = new ProductCategoryVocStatisticsDto();

        dto.setKey(departmentData.getKey());
        dto.setParentId(departmentData.getParentId());
        dto.setDisplay(departmentData.getDisplay());

        // 제품 카테고리 코드 설정
        Map<String, Object> data = departmentData.getData();
        if (data != null) {
            String deptCode = (String) data.get("deptCode");
            String deptName = (String) data.get("deptName");

            dto.setDeptCode(deptCode);
            dto.setDeptName(deptName);

            // 루트 노드가 아닌 경우에만 제품 카테고리 코드 설정
            if (!rootDepartmentCode.equals(deptCode)) {
                ProductCategoryUtil.ProductCategory category = ProductCategoryUtil.findCategoryByText(deptName);
                if (category != null) {
                    dto.setItemCode(category.getValue());
                }
            }
        }

        // 통계 맵 초기화
        dto.setStatistics(new HashMap<>());
        dto.setTotalCount(0);

        return dto;
    }

    /**
     * 부서 코드 리스트 조회
     */
    private List<String> getDepartmentCodes(String departmentCode) {
        if (StringUtils.isEmpty(departmentCode)) {
            return new ArrayList<>();
        }
        
        try {
            OrganizationResponseDto result = commonServiceClient.getDepartment(defaultCorporationCode, departmentCode);

            if (result != null && result.getData() != null) {
                return result.getData().stream()
                        .map(org -> org.getData().getDepartmentCode())
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList());
            }

            return new ArrayList<>();
            
        } catch (Exception e) {
            log.error("부서 코드 조회 실패 - departmentCode: {}, error: {}", departmentCode, e.getMessage(), e);
            // 부서 코드 조회 실패 시 빈 리스트 반환 (비즈니스 로직 계속 진행)
            return new ArrayList<>();
        }
    }

    /**
     * 제품 카테고리에 통계 정보 추가 (분리 및 단순화)
     */
    private void enrichProductCategoryWithStatistics(List<ProductCategoryVocStatisticsDto> productCategoryStructure,
                                                     Map<String, Map<String, Integer>> itemStatistics) {
        
        // 1단계: 각 노드에 직접 통계 정보 설정
        setDirectStatistics(productCategoryStructure, itemStatistics);
        
        // 2단계: 부모 노드에 자식 통계 집계
        aggregateParentStatistics(productCategoryStructure);
    }

    /**
     * 각 노드에 직접 통계 정보 설정
     */
    private void setDirectStatistics(List<ProductCategoryVocStatisticsDto> productCategoryStructure,
                                   Map<String, Map<String, Integer>> itemStatistics) {
        
        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            String itemCode = node.getItemCode();

            if (itemCode != null && itemStatistics.containsKey(itemCode)) {
                node.setStatistics(new HashMap<>(itemStatistics.get(itemCode)));

                int total = itemStatistics.get(itemCode).values().stream()
                        .mapToInt(Integer::intValue)
                        .sum();
                node.setTotalCount(total);
            }
        }
    }

    /**
     * 부모 노드에 자식 통계 집계
     */
    private void aggregateParentStatistics(List<ProductCategoryVocStatisticsDto> productCategoryStructure) {
        Map<String, ProductCategoryVocStatisticsDto> nodeMap = productCategoryStructure.stream()
                .collect(Collectors.toMap(ProductCategoryVocStatisticsDto::getKey, node -> node));

        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            if (node.getParentId() != null && nodeMap.containsKey(node.getParentId())) {
                ProductCategoryVocStatisticsDto parent = nodeMap.get(node.getParentId());

                // 부모 노드의 통계 정보 업데이트
                for (Map.Entry<String, Integer> entry : node.getStatistics().entrySet()) {
                    parent.getStatistics().merge(entry.getKey(), entry.getValue(), Integer::sum);
                }

                parent.setTotalCount(parent.getTotalCount() + node.getTotalCount());
            }
        }
    }

    /**
     * 통계 데이터에 total 키 추가
     */
    private void addTotalKeyToStatistics(List<ProductCategoryVocStatisticsDto> productCategoryStructure) {
        for (ProductCategoryVocStatisticsDto node : productCategoryStructure) {
            Map<String, Integer> statistics = node.getStatistics();
            statistics.put("total", node.getTotalCount());
        }
    }

    // 검증 메서드
    private void validateStatisticsRequest(VocStatisticsRequestDto condition) {
        if (condition == null) {
            throw new BusinessException("voc.statistics.invalid.condition");
        }
        
        if (condition.getStartDate() == null || condition.getEndDate() == null) {
            throw new BusinessException("voc.statistics.invalid.dateRange");
        }
        
        if (condition.getStartDate().isAfter(condition.getEndDate())) {
            throw new BusinessException("voc.statistics.invalid.dateOrder");
        }
    }

    // 내부 클래스들
    private enum StatisticsPeriod {
        DAY, WEEK, MONTH, YEAR
    }

    private static class StatisticsContext {
        private final List<String> chargeDepartmentCodes;
        private final List<String> registerDepartmentCodes;

        public StatisticsContext(List<String> chargeDepartmentCodes, List<String> registerDepartmentCodes) {
            this.chargeDepartmentCodes = chargeDepartmentCodes;
            this.registerDepartmentCodes = registerDepartmentCodes;
        }

        public List<String> getChargeDepartmentCodes() { return chargeDepartmentCodes; }
        public List<String> getRegisterDepartmentCodes() { return registerDepartmentCodes; }
    }
}
```

## 3. 다른 접근법

### 3.1 Strategy 패턴을 이용한 통계 조회
```java
public interface StatisticsQueryStrategy {
    Map<String, Map<String, Integer>> getStatistics(VocStatisticsRequestDto condition, StatisticsContext context);
}

@Component
public class DayStatisticsQueryStrategy implements StatisticsQueryStrategy {
    @Override
    public Map<String, Map<String, Integer>> getStatistics(VocStatisticsRequestDto condition, StatisticsContext context) {
        return vocStatisticsQueryRepository.getVocStatisticsByItemAndDayWithConditions(...);
    }
}

@Service
public class VocItemStatisticsService {
    
    private final Map<StatisticsPeriod, StatisticsQueryStrategy> strategyMap;
    
    public List<ProductCategoryVocStatisticsDto> getVocStatistics(VocStatisticsRequestDto condition, StatisticsPeriod period) {
        StatisticsQueryStrategy strategy = strategyMap.get(period);
        Map<String, Map<String, Integer>> statistics = strategy.getStatistics(condition, context);
        // ...
    }
}
```

### 3.2 Builder 패턴을 이용한 복잡한 객체 생성
```java
public class StatisticsRequestBuilder {
    private VocStatisticsRequestDto condition;
    private List<String> chargeDepartmentCodes;
    private List<String> registerDepartmentCodes;
    
    public static StatisticsRequestBuilder create(VocStatisticsRequestDto condition) {
        return new StatisticsRequestBuilder(condition);
    }
    
    public StatisticsRequestBuilder withChargeDepartments(List<String> codes) {
        this.chargeDepartmentCodes = codes;
        return this;
    }
    
    public StatisticsRequest build() {
        return new StatisticsRequest(condition, chargeDepartmentCodes, registerDepartmentCodes);
    }
}
```

### 3.3 Template Method 패턴 적용
```java
public abstract class AbstractVocStatisticsService {
    
    public final List<ProductCategoryVocStatisticsDto> getStatistics(VocStatisticsRequestDto condition) {
        validateRequest(condition);
        List<ProductCategoryVocStatisticsDto> structure = getProductCategoryStructure();
        Map<String, Map<String, Integer>> statistics = getStatisticsData(condition);
        enrichWithStatistics(structure, statistics);
        return structure;
    }
    
    protected abstract Map<String, Map<String, Integer>> getStatisticsData(VocStatisticsRequestDto condition);
}

public class DayVocStatisticsService extends AbstractVocStatisticsService {
    @Override
    protected Map<String, Map<String, Integer>> getStatisticsData(VocStatisticsRequestDto condition) {
        return vocStatisticsQueryRepository.getVocStatisticsByItemAndDayWithConditions(...);
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **캐싱**: 제품 카테고리 구조는 자주 변경되지 않으므로 캐싱 적용
- **병렬 처리**: 부서 코드 조회를 병렬로 처리하여 성능 개선
- **페이징**: 대용량 통계 데이터에 대한 페이징 처리

### 4.2 데이터 일관성 측면  
- **트랜잭션**: 읽기 전용 트랜잭션으로 일관된 데이터 조회 보장
- **격리 수준**: 통계 조회 시 적절한 격리 수준 설정
- **데이터 검증**: 통계 계산 결과의 무결성 검증

### 4.3 확장성 측면
- **새로운 기간 단위**: 시간별, 분기별 통계 추가 시 확장 용이성
- **필터 조건**: 새로운 필터 조건 추가 시 유연성
- **집계 방식**: 다양한 집계 방식(평균, 최대값 등) 지원

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 코드 중복 제거 | 높음 | 4시간 | 유지보수성 핵심 |
| 예외 처리 추가 | 높음 | 3시간 | 서비스 안정성 핵심 |
| 메서드 책임 분리 | 높음 | 5시간 | 가독성 및 테스트 용이성 |
| 파라미터 검증 | 중간 | 2시간 | NPE 방지 |
| 하드코딩 제거 | 중간 | 1시간 | 설정 분리 |
| 로깅 추가 | 중간 | 2시간 | 운영 모니터링 필요 |
| 트랜잭션 설정 | 낮음 | 30분 | 성능 최적화 |

**총 예상 소요 시간**: 17시간 30분
# VocRepository 클래스 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 단순한 Repository의 기능 부족
**문제점**: 가장 핵심적인 Voc 엔티티의 Repository임에도 기능이 매우 제한적
**파일**: VocRepository.java 전체 (10라인)
```java
@Repository
public interface VocRepository extends JpaRepository<Voc, Long> {
    Voc findByDenallVocNumber(Long denallVocNumber); // 단 1개의 커스텀 메서드
}
```

#### 반환 타입 안전성 부족
**문제점**: findByDenallVocNumber 메서드가 null을 반환할 수 있으나 Optional로 감싸지지 않음
**파일**: VocRepository.java 9번 라인
```java
Voc findByDenallVocNumber(Long denallVocNumber); // null 반환 가능하나 Optional 미사용
```

#### 기본 조회 메서드 부재
**문제점**: VOC의 핵심 비즈니스 조회 로직이 전혀 없어 모든 복잡한 쿼리가 VocQueryRepository로 분산됨
**파일**: VocRepository.java 전체
```java
// 없는 메서드들 (실제로는 VocQueryRepository에 구현됨)
// findActiveVocs() - 활성 VOC 조회
// findByVocStateCode() - 상태별 조회  
// findByRegistererInfo() - 등록자별 조회
// findByDateRange() - 기간별 조회
```

### 1.2 심각도 중간 (High) - 🟡

#### Repository 책임 분산 문제
**문제점**: 단순한 CRUD는 VocRepository, 복잡한 조회는 VocQueryRepository로 분산되어 일관성이 없음
**영향**: 개발자가 어떤 Repository를 사용해야 할지 혼란
```java
// 현재 구조의 문제점
VocRepository: 기본 CRUD + findByDenallVocNumber만
VocQueryRepository: 모든 복잡한 비즈니스 조회 로직 (643라인)
```

#### 메서드명 네이밍 일관성 부족  
**문제점**: DenallVocNumber 필드명이 그대로 메서드명에 노출됨
**파일**: VocRepository.java 9번 라인
```java
// 현재: 내부 필드명 그대로 노출
Voc findByDenallVocNumber(Long denallVocNumber);

// 개선: 비즈니스 의미가 명확한 메서드명 필요
Optional<Voc> findByExternalVocNumber(Long externalVocNumber);
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 확장성 부족
**문제점**: 향후 기본적인 비즈니스 조회 로직 추가 시 기존 구조와 충돌 가능성
**파일**: VocRepository.java 전체
```java
// 현재는 너무 단순하여 향후 확장 시 일관성 문제 발생 가능
public interface VocRepository extends JpaRepository<Voc, Long> {
    // 기본 CRUD만 가능하고 비즈니스 로직은 모두 다른 Repository에 의존
}
```

## 2. 개선 코드 예시

### 2.1 기본 비즈니스 조회 메서드 추가
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.Voc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * VOC 기본 데이터 액세스 Repository
 * 단순한 CRUD 및 기본적인 비즈니스 조회 메서드 제공
 */
@Repository
public interface VocRepository extends JpaRepository<Voc, Long> {

    /**
     * 외부 VOC 번호로 조회 (Denall VOC 번호)
     * @param externalVocNumber 외부 시스템 VOC 번호
     * @return VOC 엔티티 (Optional로 null-safe)
     */
    @Query("SELECT v FROM Voc v WHERE v.denallVocNumber = :externalVocNumber AND v.deleteYesOrNo != 'Y'")
    Optional<Voc> findByExternalVocNumber(@Param("externalVocNumber") Long externalVocNumber);

    /**
     * 활성 상태인 VOC 목록 조회 (삭제되지 않은 것들만)
     * @return 활성 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findActiveVocs();

    /**
     * VOC 상태 코드로 조회
     * @param stateCode VOC 상태 코드
     * @return 해당 상태의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocStateCode = :stateCode AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByVocStateCode(@Param("stateCode") String stateCode);

    /**
     * 카테고리 코드로 조회
     * @param categoryCode VOC 카테고리 코드
     * @return 해당 카테고리의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocCategoryCode = :categoryCode AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByVocCategoryCode(@Param("categoryCode") String categoryCode);

    /**
     * 등록자 사원 번호로 조회
     * @param employeeNumber 등록자 사원 번호
     * @return 해당 등록자의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.registererEmployeeNumber = :employeeNumber AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByRegistererEmployeeNumber(@Param("employeeNumber") String employeeNumber);

    /**
     * 고객명으로 조회 (부분 일치)
     * @param customerName 고객명
     * @return 해당 고객의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocCustomerName LIKE %:customerName% AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByCustomerNameContaining(@Param("customerName") String customerName);

    /**
     * 기간별 VOC 조회
     * @param startDate 시작 일자
     * @param endDate 종료 일자
     * @return 기간 내 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocRegistrationDateTime BETWEEN :startDate AND :endDate AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByRegistrationDateRange(@Param("startDate") LocalDateTime startDate, 
                                        @Param("endDate") LocalDateTime endDate);

    /**
     * 담당자 번호로 조회
     * @param chargePersonNumber VOC 담당자 번호
     * @return 해당 담당자의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocChargePersonNumber = :chargePersonNumber AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByVocChargePersonNumber(@Param("chargePersonNumber") Long chargePersonNumber);

    /**
     * 품목 코드로 조회
     * @param itemCode 품목 코드
     * @return 해당 품목의 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.itemCode = :itemCode AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC")
    List<Voc> findByItemCode(@Param("itemCode") String itemCode);

    /**
     * VOC 번호 목록으로 배치 조회
     * @param vocNumbers VOC 번호 목록
     * @return VOC 엔티티 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocNumber IN :vocNumbers AND v.deleteYesOrNo != 'Y'")
    List<Voc> findByVocNumberIn(@Param("vocNumbers") List<Long> vocNumbers);

    /**
     * 삭제되지 않은 VOC 총 개수 조회
     * @return 활성 VOC 개수
     */
    @Query("SELECT COUNT(v) FROM Voc v WHERE v.deleteYesOrNo != 'Y'")
    long countActiveVocs();

    /**
     * 상태별 VOC 개수 조회
     * @param stateCode VOC 상태 코드
     * @return 해당 상태의 VOC 개수
     */
    @Query("SELECT COUNT(v) FROM Voc v WHERE v.vocStateCode = :stateCode AND v.deleteYesOrNo != 'Y'")
    long countByVocStateCode(@Param("stateCode") String stateCode);

    /**
     * 특정 날짜 이후 등록된 VOC 조회
     * @param date 기준 날짜
     * @return 해당 날짜 이후 VOC 목록
     */
    @Query("SELECT v FROM Voc v WHERE v.vocRegistrationDateTime >= :date AND v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime ASC")
    List<Voc> findRegisteredAfter(@Param("date") LocalDateTime date);

    /**
     * VOC 존재 여부 확인 (외부 번호 기준)
     * @param externalVocNumber 외부 VOC 번호
     * @return 존재 여부
     */
    @Query("SELECT COUNT(v) > 0 FROM Voc v WHERE v.denallVocNumber = :externalVocNumber AND v.deleteYesOrNo != 'Y'")
    boolean existsByExternalVocNumber(@Param("externalVocNumber") Long externalVocNumber);
}
```

### 2.2 Repository 인터페이스 분리 전략
```java
package com.osstem.ow.voc.repository;

/**
 * VOC 기본 CRUD Repository
 * 단순한 엔티티 기반 조회만 담당
 */
public interface VocRepository extends JpaRepository<Voc, Long> {
    // 기본 CRUD + 단순 조회 메서드들
    Optional<Voc> findByExternalVocNumber(Long externalVocNumber);
    List<Voc> findActiveVocs();
    List<Voc> findByVocStateCode(String stateCode);
    // ... 기타 단순 조회 메서드들
}

/**
 * VOC 복잡한 조회 Repository 
 * QueryDSL 기반의 동적 쿼리와 조인이 필요한 조회 담당
 */
public interface VocSearchRepository {
    Page<VocResponseDto> searchVocs(VocSearchCriteria criteria, Pageable pageable);
    List<VocResponseDto> findVocsWithAnswerDetails(VocSearchCriteria criteria);
    Map<String, Long> getVocCountByDepartment(LocalDateTime startDate, LocalDateTime endDate);
    // ... 복잡한 비즈니스 조회 메서드들
}

/**
 * VOC 통계 전용 Repository
 * 각종 통계 및 집계 쿼리 담당
 */
public interface VocStatisticsRepository {
    Map<String, Integer> getVocStatisticsByHour(LocalDateTime startDate, LocalDateTime endDate);
    Map<String, Integer> getVocStatisticsByDepartment(String period);
    List<StatisticsDto> getVocTrendAnalysis(int months);
    // ... 통계 관련 메서드들
}
```

### 2.3 상수 기반 쿼리 개선
```java
package com.osstem.ow.voc.repository.common;

/**
 * VOC Repository에서 사용하는 공통 상수들
 */
public final class VocRepositoryConstants {
    public static final String DELETED_FLAG = "Y";
    public static final String ACTIVE_CONDITION = "v.deleteYesOrNo != '" + DELETED_FLAG + "'";
    public static final String ORDER_BY_LATEST = "ORDER BY v.vocRegistrationDateTime DESC";
    
    // 공통 쿼리 조각들
    public static final String FIND_ACTIVE_VOCS_BASE = 
        "SELECT v FROM Voc v WHERE " + ACTIVE_CONDITION;
        
    public static final String COUNT_ACTIVE_VOCS_BASE = 
        "SELECT COUNT(v) FROM Voc v WHERE " + ACTIVE_CONDITION;
    
    private VocRepositoryConstants() {
        // 인스턴스 생성 방지
    }
}

// 사용 예시
@Repository
public interface VocRepository extends JpaRepository<Voc, Long> {
    
    @Query(VocRepositoryConstants.FIND_ACTIVE_VOCS_BASE + " " + VocRepositoryConstants.ORDER_BY_LATEST)
    List<Voc> findActiveVocs();
    
    @Query(VocRepositoryConstants.FIND_ACTIVE_VOCS_BASE + " AND v.vocStateCode = :stateCode " + VocRepositoryConstants.ORDER_BY_LATEST)
    List<Voc> findByVocStateCode(@Param("stateCode") String stateCode);
}
```

## 3. 다른 접근법

### 3.1 Specification 패턴 적용
```java
package com.osstem.ow.voc.repository.specification;

import com.osstem.ow.voc.entity.Voc;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

/**
 * VOC 검색을 위한 Specification 클래스
 */
public class VocSpecifications {
    
    public static Specification<Voc> isNotDeleted() {
        return (root, query, criteriaBuilder) -> 
            criteriaBuilder.notEqual(root.get("deleteYesOrNo"), "Y");
    }
    
    public static Specification<Voc> hasStateCode(String stateCode) {
        return (root, query, criteriaBuilder) -> 
            stateCode != null ? criteriaBuilder.equal(root.get("vocStateCode"), stateCode) : null;
    }
    
    public static Specification<Voc> hasCategoryCode(String categoryCode) {
        return (root, query, criteriaBuilder) -> 
            categoryCode != null ? criteriaBuilder.equal(root.get("vocCategoryCode"), categoryCode) : null;
    }
    
    public static Specification<Voc> registeredBetween(LocalDateTime start, LocalDateTime end) {
        return (root, query, criteriaBuilder) -> {
            if (start != null && end != null) {
                return criteriaBuilder.between(root.get("vocRegistrationDateTime"), start, end);
            } else if (start != null) {
                return criteriaBuilder.greaterThanOrEqualTo(root.get("vocRegistrationDateTime"), start);
            } else if (end != null) {
                return criteriaBuilder.lessThanOrEqualTo(root.get("vocRegistrationDateTime"), end);
            }
            return null;
        };
    }
    
    public static Specification<Voc> hasCustomerName(String customerName) {
        return (root, query, criteriaBuilder) -> 
            customerName != null ? criteriaBuilder.like(root.get("vocCustomerName"), "%" + customerName + "%") : null;
    }
}

// Repository에서 사용
public interface VocRepository extends JpaRepository<Voc, Long>, JpaSpecificationExecutor<Voc> {
    
    // 기본 메서드들...
    
    // Specification 사용 예시는 Service에서
    // Specification<Voc> spec = Specification
    //     .where(VocSpecifications.isNotDeleted())
    //     .and(VocSpecifications.hasStateCode(stateCode))
    //     .and(VocSpecifications.registeredBetween(startDate, endDate));
    // List<Voc> results = vocRepository.findAll(spec);
}
```

### 3.2 Custom Repository 구현체 패턴
```java
// 인터페이스 정의
public interface VocRepositoryCustom {
    List<Voc> findVocsByComplexCriteria(VocSearchCriteria criteria);
    Optional<Voc> findVocWithAllRelations(Long vocNumber);
    List<Voc> findVocsByDynamicQuery(Map<String, Object> params);
}

// 구현체
@Repository
public class VocRepositoryCustomImpl implements VocRepositoryCustom {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public List<Voc> findVocsByComplexCriteria(VocSearchCriteria criteria) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Voc> query = cb.createQuery(Voc.class);
        Root<Voc> root = query.from(Voc.class);
        
        List<Predicate> predicates = new ArrayList<>();
        
        // 삭제되지 않은 것만
        predicates.add(cb.notEqual(root.get("deleteYesOrNo"), "Y"));
        
        // 동적 조건 추가
        if (criteria.getVocStateCode() != null) {
            predicates.add(cb.equal(root.get("vocStateCode"), criteria.getVocStateCode()));
        }
        
        if (criteria.getStartDate() != null && criteria.getEndDate() != null) {
            predicates.add(cb.between(root.get("vocRegistrationDateTime"), 
                                    criteria.getStartDate(), criteria.getEndDate()));
        }
        
        query.where(predicates.toArray(new Predicate[0]));
        query.orderBy(cb.desc(root.get("vocRegistrationDateTime")));
        
        return entityManager.createQuery(query).getResultList();
    }
    
    @Override
    public Optional<Voc> findVocWithAllRelations(Long vocNumber) {
        String jpql = """
            SELECT DISTINCT v FROM Voc v 
            LEFT JOIN FETCH v.vocChargePerson
            LEFT JOIN FETCH v.vocAnswerDetails
            LEFT JOIN FETCH v.vocChangeHistories
            WHERE v.vocNumber = :vocNumber 
            AND v.deleteYesOrNo != 'Y'
            """;
            
        try {
            Voc voc = entityManager.createQuery(jpql, Voc.class)
                    .setParameter("vocNumber", vocNumber)
                    .getSingleResult();
            return Optional.of(voc);
        } catch (NoResultException e) {
            return Optional.empty();
        }
    }
}

// 메인 Repository 인터페이스에서 상속
public interface VocRepository extends JpaRepository<Voc, Long>, VocRepositoryCustom {
    Optional<Voc> findByExternalVocNumber(Long externalVocNumber);
    // 기타 메서드들...
}
```

### 3.3 Repository Layer 추상화
```java
// 기본 Repository 인터페이스
public interface BaseVocRepository<T, ID> {
    Optional<T> findById(ID id);
    List<T> findAll();
    T save(T entity);
    void deleteById(ID id);
    boolean existsById(ID id);
    long count();
}

// VOC 전용 Repository 인터페이스
public interface VocRepository extends BaseVocRepository<Voc, Long> {
    // VOC 특화 메서드들
    Optional<Voc> findByExternalVocNumber(Long externalVocNumber);
    List<Voc> findActiveVocs();
    List<Voc> findByStateCode(String stateCode);
}

// 구현체에서 공통 로직 처리
@Repository
@Transactional(readOnly = true)
public class VocRepositoryImpl implements VocRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public Optional<Voc> findById(Long id) {
        Voc voc = entityManager.find(Voc.class, id);
        // 삭제된 것은 조회하지 않음
        if (voc != null && "Y".equals(voc.getDeleteYesOrNo())) {
            return Optional.empty();
        }
        return Optional.ofNullable(voc);
    }
    
    @Override
    public List<Voc> findAll() {
        return entityManager.createQuery(
            "SELECT v FROM Voc v WHERE v.deleteYesOrNo != 'Y' ORDER BY v.vocRegistrationDateTime DESC", 
            Voc.class
        ).getResultList();
    }
    
    // 기타 구현...
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **인덱스 활용**: 자주 조회되는 필드(vocStateCode, vocCategoryCode, denallVocNumber)에 인덱스 확인
- **Batch 처리**: 대량 데이터 조회 시 페이징 처리 고려  
- **쿼리 최적화**: N+1 문제 방지를 위한 Fetch Join 전략
- **캐싱**: 자주 조회되는 데이터에 대한 캐싱 전략

### 4.2 유지보수 측면
- **메서드명 일관성**: 비즈니스 의미가 명확한 메서드명 사용
- **쿼리 복잡도 관리**: 너무 복잡한 쿼리는 별도 Repository로 분리
- **예외 처리**: Repository 레벨에서의 예외 처리 전략
- **테스트**: Repository 메서드별 단위 테스트 작성

### 4.3 확장성 측면
- **다중 데이터소스**: 읽기/쓰기 분리 시 Repository 구조 고려
- **이벤트 기반**: 엔티티 변경 시 도메인 이벤트 발행
- **감사 기능**: 엔티티 변경 이력 추적을 위한 Auditing
- **버전 관리**: 엔티티 스키마 변경 시 하위 호환성 고려

### 4.4 보안 측면
- **데이터 접근 제어**: Row-level Security 고려
- **민감 정보 처리**: 개인정보 필드 접근 시 마스킹 처리
- **SQL Injection 방지**: 동적 쿼리 작성 시 파라미터 바인딩 사용
- **권한 기반 필터링**: 사용자 권한에 따른 데이터 필터링

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| Optional 반환 타입 적용 | 높음 | 30분 | 안전성 즉시 개선 |
| 기본 비즈니스 조회 메서드 추가 | 높음 | 3시간 | Repository 기능 강화 |
| 상수 기반 쿼리 개선 | 높음 | 1시간 | 유지보수성 향상 |
| Repository 인터페이스 분리 설계 | 중간 | 2시간 | 아키텍처 개선 |
| Specification 패턴 적용 | 중간 | 4시간 | 동적 쿼리 개선 |
| Custom Repository 구현 | 낮음 | 3시간 | 고급 기능 추가 |
| 성능 최적화 (인덱스, 캐싱) | 낮음 | 2시간 | 성능 개선 |

**총 예상 소요 시간**: 15.5시간
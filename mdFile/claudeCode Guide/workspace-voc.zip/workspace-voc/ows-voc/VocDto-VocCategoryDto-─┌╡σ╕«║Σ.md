# VocDto & VocCategoryDto 클래스 코드 리뷰
## (VocDto.java, VocCategoryDto.java)

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### VocDto의 과도한 책임 (God Object)
**문제점**: 하나의 DTO 클래스에 158라인에 걸쳐 40개 이상의 필드가 집중됨
**파일**: VocDto.java 전체
```java
@Schema(description = "VOC DTO")
public class VocDto extends BaseDto {
    private Long vocNumber;
    private Long vocChargePersonNumber;
    private String vocCategoryCode;
    private Long denallVocNumber;
    private String itemCode;
    private String vocItemName;
    private String vocRegistererDivisionCode;
    // ... 40개 이상의 필드들
    private String deleteYesOrNo;
    private LocalDateTime vocRegistrationDateTime;
    private String vocDetailsItemName;
}
```

#### DTO에 비즈니스 로직 포함
**문제점**: DTO 클래스에 상태 변경 로직이 포함되어 책임 분리 원칙 위반
**파일**: VocDto.java 154-156번 라인
```java
public void setProcessingComplete() {
    this.vocStateCode = StatusType.COMPLETE.getStatusCode(); // 비즈니스 로직이 DTO에 있음
}
```

#### Y/N 플래그의 일관성 없는 타입 사용
**문제점**: VocDto는 String, VocCategoryDto는 Character 타입으로 Y/N 값을 저장
**파일**: VocDto.java 112, 138번 라인 / VocCategoryDto.java 21, 26, 27번 라인
```java
// VocDto - String 타입
@Size(max = 1)
private String individualInformationCollectionTermsOfUseAgreementYesOrNo;
private String deleteYesOrNo;

// VocCategoryDto - Character 타입  
private Character openYn;
private Character customerCenterYn;
private Character deleteYn;
```

#### 과도하게 긴 필드명
**문제점**: 필드명이 너무 길어 가독성 저하 및 유지보수 어려움
**파일**: VocDto.java 112번 라인 / VocCategoryDto.java 23-25번 라인
```java
// VocDto
private String individualInformationCollectionTermsOfUseAgreementYesOrNo; // 67자

// VocCategoryDto
private String registererCorporationEmployeeNumber; // 35자
private Instant vocCategoryRegistererCorporationDatetime; // 43자
```

### 1.2 심각도 중간 (High) - 🟡

#### 캡슐화 위반 (Audit 정보 직접 조작)
**문제점**: BaseDto의 audit 필드를 직접 조작하는 메서드 제공
**파일**: VocDto.java 146-152번 라인
```java
public void setAudit(BaseDto dto) {
    this.setProcPrgmId(dto.getProcPrgmId());     // 직접 설정
    this.setRgstProcrId(dto.getRgstProcrId());   // 캡슐화 위반
    this.setRgstProcDtm(dto.getRgstProcDtm());
    this.setUpdtProcrId(dto.getUpdtProcrId());
    this.setUpdtProcDtm(dto.getUpdtProcDtm());
}
```

#### 일관성 없는 검증 어노테이션 적용
**문제점**: 일부 필드에만 검증 어노테이션이 있고, 중요한 필드에 검증이 누락됨
**파일**: VocDto.java 전체 / VocCategoryDto.java 전체
```java
// VocDto - 일부만 검증
@NotBlank
@Size(max = 2000)
private String vocContent; // 검증 있음

private Long vocNumber;     // 검증 없음 (중요한 필드임에도)
private String vocTitle;    // 검증 없음

// VocCategoryDto - 검증 어노테이션 전혀 없음
public class VocCategoryDto extends BaseDto {
    private String vocCategoryCode; // 필수값임에도 검증 없음
}
```

#### Lombok 어노테이션 불일치
**문제점**: VocDto는 @Getter/@Setter 분리, VocCategoryDto는 @Data 사용으로 일관성 부족
**파일**: VocDto.java 13-19번 라인 / VocCategoryDto.java 12-15번 라인
```java
// VocDto
@Getter
@Builder
@Setter
@NoArgsConstructor
@AllArgsConstructor

// VocCategoryDto  
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 타입 일관성 부족
**문제점**: 유사한 용도의 필드가 서로 다른 타입 사용
**파일**: VocDto.java vs VocCategoryDto.java
```java
// VocDto - LocalDateTime 사용
private LocalDateTime vocRegistrationDateTime;

// VocCategoryDto - Instant 사용  
private Instant vocCategoryRegistererCorporationDatetime;

// VocCategoryDto - BigDecimal 사용
private BigDecimal sortOrder; // int나 Integer가 더 적절할 수 있음
```

#### Swagger 문서화 불일치
**문제점**: VocDto는 상세한 @Schema, VocCategoryDto는 문서화 누락
**파일**: VocDto.java vs VocCategoryDto.java
```java
// VocDto - 상세한 문서화
@Schema(description = "VOC 번호")
private Long vocNumber;

// VocCategoryDto - 문서화 없음
private String vocCategoryCode; // 설명 없음
```

## 2. 개선 코드 예시

### 2.1 VocDto 책임 분리 및 개선
```java
package com.osstem.ow.voc.model.table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * VOC 기본 정보 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "VOC 기본 정보 DTO")
public class VocBasicDto extends BaseDto {

    @Schema(description = "VOC 번호")
    @NotNull(message = "VOC 번호는 필수입니다")
    private Long vocNumber;

    @Schema(description = "VOC 담당자 번호")
    private Long vocChargePersonNumber;

    @Schema(description = "VOC 카테고리 코드")
    @NotBlank(message = "VOC 카테고리 코드는 필수입니다")
    @Size(max = 12, message = "VOC 카테고리 코드는 12자 이하여야 합니다")
    private String vocCategoryCode;

    @Schema(description = "덴올 VOC 번호")
    private Long denallVocNumber;

    @Schema(description = "품목 코드")
    @Size(max = 90, message = "품목 코드는 90자 이하여야 합니다")
    private String itemCode;

    @Schema(description = "VOC 품목명")
    @Size(max = 100, message = "VOC 품목명은 100자 이하여야 합니다")
    private String vocItemName;

    @Schema(description = "VOC 제목")
    @NotBlank(message = "VOC 제목은 필수입니다")
    @Size(max = 100, message = "VOC 제목은 100자 이하여야 합니다")
    private String vocTitle;

    @Schema(description = "VOC 내용")
    @NotBlank(message = "VOC 내용은 필수입니다")
    @Size(max = 2000, message = "VOC 내용은 2000자 이하여야 합니다")
    private String vocContent;

    @Schema(description = "VOC 상태 코드")
    @NotBlank(message = "VOC 상태 코드는 필수입니다")
    @Size(max = 2, message = "VOC 상태 코드는 2자 이하여야 합니다")
    private String vocStateCode;

    @Schema(description = "삭제 여부")
    @Builder.Default
    private Boolean isDeleted = false;

    @Schema(description = "VOC 등록 일시")
    private LocalDateTime vocRegistrationDateTime;

    /**
     * VOC가 삭제된 상태인지 확인합니다.
     */
    public boolean isDeleted() {
        return Boolean.TRUE.equals(this.isDeleted);
    }

    /**
     * VOC를 완료 상태로 변경하기 위한 정보를 반환합니다.
     * 실제 상태 변경은 서비스 레이어에서 수행합니다.
     */
    public VocStateChangeRequest createCompletionRequest() {
        return VocStateChangeRequest.builder()
                .vocNumber(this.vocNumber)
                .newStateCode("COMPLETE")
                .reason("처리 완료")
                .changeDateTime(LocalDateTime.now())
                .build();
    }
}
```

### 2.2 VOC 등록자 정보 분리
```java
package com.osstem.ow.voc.model.table;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

/**
 * VOC 등록자 정보 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Schema(description = "VOC 등록자 정보 DTO")
public class VocRegistererDto {

    @Schema(description = "등록자 구분 코드")
    @NotBlank(message = "등록자 구분 코드는 필수입니다")
    @Size(max = 2, message = "등록자 구분 코드는 2자 이하여야 합니다")
    private String registererDivisionCode;

    @Schema(description = "등록자 법인 코드")
    @Size(max = 3, message = "등록자 법인 코드는 3자 이하여야 합니다")
    private String corporationCode;

    @Schema(description = "등록자 부서 코드")
    @Size(max = 30, message = "등록자 부서 코드는 30자 이하여야 합니다")
    private String departmentCode;

    @Schema(description = "등록자 사원 번호")
    @Size(max = 60, message = "등록자 사원 번호는 60자 이하여야 합니다")
    private String employeeNumber;

    @Schema(description = "등록자 회원 ID")
    @Size(max = 20, message = "등록자 회원 ID는 20자 이하여야 합니다")
    private String memberId;

    /**
     * 등록자가 내부 직원인지 확인합니다.
     */
    public boolean isInternalEmployee() {
        return "01".equals(registererDivisionCode); // 내부 직원 코드
    }

    /**
     * 등록자가 외부 고객인지 확인합니다.
     */
    public boolean isExternalCustomer() {
        return "02".equals(registererDivisionCode); // 외부 고객 코드
    }
}
```

### 2.3 VOC 고객 정보 분리
```java
package com.osstem.ow.voc.model.table;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

/**
 * VOC 고객 정보 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Schema(description = "VOC 고객 정보 DTO")
public class VocCustomerDto {

    @Schema(description = "고객명")
    @Size(max = 50, message = "고객명은 50자 이하여야 합니다")
    private String customerName;

    @Schema(description = "거래처명")
    @Size(max = 100, message = "거래처명은 100자 이하여야 합니다")
    private String customerCompanyName;

    @Schema(description = "이메일 주소")
    @Email(message = "올바른 이메일 형식이어야 합니다")
    @Size(max = 50, message = "이메일 주소는 50자 이하여야 합니다")
    private String emailAddress;

    @Schema(description = "전화번호")
    @Pattern(regexp = "^[0-9-]{1,20}$", message = "전화번호는 숫자와 하이픈만 포함해야 합니다")
    @Size(max = 20, message = "전화번호는 20자 이하여야 합니다")
    private String telephoneNumber;

    @Schema(description = "휴대전화번호")
    @Pattern(regexp = "^[0-9-]{1,20}$", message = "휴대전화번호는 숫자와 하이픈만 포함해야 합니다")
    @Size(max = 20, message = "휴대전화번호는 20자 이하여야 합니다")
    private String mobilePhoneNumber;

    @Schema(description = "개인정보 수집 이용 동의 여부")
    @Builder.Default
    private Boolean hasAgreedToPrivacyPolicy = false;

    /**
     * 연락 가능한 전화번호를 반환합니다.
     */
    public String getContactNumber() {
        if (mobilePhoneNumber != null && !mobilePhoneNumber.trim().isEmpty()) {
            return mobilePhoneNumber;
        }
        return telephoneNumber;
    }

    /**
     * 고객 연락처가 유효한지 확인합니다.
     */
    public boolean hasValidContact() {
        return (emailAddress != null && !emailAddress.trim().isEmpty()) ||
               (telephoneNumber != null && !telephoneNumber.trim().isEmpty()) ||
               (mobilePhoneNumber != null && !mobilePhoneNumber.trim().isEmpty());
    }
}
```

### 2.4 개선된 VocCategoryDto
```java
package com.osstem.ow.voc.model.table;

import com.osstem.ow.model.BaseDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * VOC 카테고리 정보 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "VOC 카테고리 정보 DTO")
public class VocCategoryDto extends BaseDto {

    @Schema(description = "VOC 카테고리 코드")
    @NotBlank(message = "VOC 카테고리 코드는 필수입니다")
    @Size(max = 12, message = "VOC 카테고리 코드는 12자 이하여야 합니다")
    private String vocCategoryCode;

    @Schema(description = "상위 카테고리 코드")
    @Size(max = 12, message = "상위 카테고리 코드는 12자 이하여야 합니다")
    private String parentCategoryCode;

    @Schema(description = "상위 카테고리명")
    @Size(max = 100, message = "상위 카테고리명은 100자 이하여야 합니다")
    private String parentCategoryName;

    @Schema(description = "카테고리명")
    @NotBlank(message = "카테고리명은 필수입니다")
    @Size(max = 100, message = "카테고리명은 100자 이하여야 합니다")
    private String vocCategoryName;

    @Schema(description = "공개 여부")
    @Builder.Default
    private Boolean isOpen = true;

    @Schema(description = "고객센터 표시 여부")
    @Builder.Default
    private Boolean isVisibleInCustomerCenter = true;

    @Schema(description = "삭제 여부")
    @Builder.Default
    private Boolean isDeleted = false;

    @Schema(description = "정렬 순서")
    @Min(value = 0, message = "정렬 순서는 0 이상이어야 합니다")
    @Max(value = 9999, message = "정렬 순서는 9999 이하여야 합니다")
    @Builder.Default
    private Integer sortOrder = 0;

    @Schema(description = "등록자 법인 코드")
    @Size(max = 3, message = "등록자 법인 코드는 3자 이하여야 합니다")
    private String registererCorporationCode;

    @Schema(description = "등록자 부서 코드")
    @Size(max = 30, message = "등록자 부서 코드는 30자 이하여야 합니다")
    private String registererDepartmentCode;

    @Schema(description = "등록자 사원 번호")
    @Size(max = 60, message = "등록자 사원 번호는 60자 이하여야 합니다")
    private String registererEmployeeNumber;

    @Schema(description = "카테고리 등록 일시")
    private LocalDateTime categoryRegistrationDateTime;

    /**
     * 최상위 카테고리인지 확인합니다.
     */
    public boolean isRootCategory() {
        return parentCategoryCode == null || parentCategoryCode.trim().isEmpty();
    }

    /**
     * 하위 카테고리인지 확인합니다.
     */
    public boolean isSubCategory() {
        return !isRootCategory();
    }

    /**
     * 카테고리가 활성 상태인지 확인합니다.
     */
    public boolean isActive() {
        return Boolean.TRUE.equals(isOpen) && !Boolean.TRUE.equals(isDeleted);
    }

    /**
     * 고객센터에서 볼 수 있는 카테고리인지 확인합니다.
     */
    public boolean isVisibleToCustomer() {
        return isActive() && Boolean.TRUE.equals(isVisibleInCustomerCenter);
    }
}
```

### 2.5 상태 변경 요청 DTO
```java
package com.osstem.ow.voc.model.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

/**
 * VOC 상태 변경 요청 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Schema(description = "VOC 상태 변경 요청 DTO")
public class VocStateChangeRequest {

    @Schema(description = "VOC 번호")
    @NotNull(message = "VOC 번호는 필수입니다")
    private Long vocNumber;

    @Schema(description = "새로운 상태 코드")
    @NotBlank(message = "새로운 상태 코드는 필수입니다")
    private String newStateCode;

    @Schema(description = "변경 사유")
    @NotBlank(message = "변경 사유는 필수입니다")
    private String reason;

    @Schema(description = "변경 요청 일시")
    @Builder.Default
    private LocalDateTime changeDateTime = LocalDateTime.now();

    @Schema(description = "변경자 ID")
    private String changerId;
}
```

## 3. 다른 접근법

### 3.1 Value Object 패턴 적용
```java
// 연락처 정보를 별도 Value Object로 분리
@Embeddable
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@EqualsAndHashCode
public class ContactInfo {
    @Column(name = "email_address")
    @Email
    private String emailAddress;
    
    @Column(name = "telephone_number")
    private String telephoneNumber;
    
    @Column(name = "mobile_phone_number")
    private String mobilePhoneNumber;
    
    public boolean hasValidContact() {
        return emailAddress != null || telephoneNumber != null || mobilePhoneNumber != null;
    }
}

// VOC DTO에서 사용
public class VocDto {
    @Embedded
    private ContactInfo customerContact;
}
```

### 3.2 Enum을 활용한 상태 관리
```java
public enum VocState {
    REGISTERED("01", "등록"),
    IN_PROGRESS("02", "처리중"),
    COMPLETED("03", "완료"),
    CANCELLED("04", "취소");
    
    private final String code;
    private final String description;
    
    VocState(String code, String description) {
        this.code = code;
        this.description = description;
    }
    
    public static VocState fromCode(String code) {
        return Arrays.stream(values())
                .filter(state -> state.code.equals(code))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid VOC state code: " + code));
    }
}
```

### 3.3 Builder 패턴을 활용한 복합 생성
```java
public class VocDtoBuilder {
    private VocBasicDto basicInfo;
    private VocRegistererDto registererInfo;
    private VocCustomerDto customerInfo;
    
    public static VocDtoBuilder create() {
        return new VocDtoBuilder();
    }
    
    public VocDtoBuilder withBasicInfo(VocBasicDto basicInfo) {
        this.basicInfo = basicInfo;
        return this;
    }
    
    public VocDtoBuilder withRegisterer(VocRegistererDto registererInfo) {
        this.registererInfo = registererInfo;
        return this;
    }
    
    public VocDtoBuilder withCustomer(VocCustomerDto customerInfo) {
        this.customerInfo = customerInfo;
        return this;
    }
    
    public CompleteVocDto build() {
        return CompleteVocDto.builder()
                .basicInfo(basicInfo)
                .registererInfo(registererInfo)
                .customerInfo(customerInfo)
                .build();
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **DTO 분리**: 큰 DTO를 작은 단위로 분리하여 필요한 데이터만 전송
- **지연 로딩**: 관련 정보는 필요할 때만 조회하도록 설계
- **캐싱**: 자주 사용되는 카테고리 정보는 캐싱 적용

### 4.2 유지보수 측면
- **책임 분리**: 각 DTO가 명확한 책임을 가지도록 설계
- **재사용성**: 공통 정보는 별도 클래스로 분리하여 재사용
- **확장성**: 새로운 필드 추가 시 기존 코드 영향 최소화

### 4.3 보안 측면
- **민감 정보 분리**: 개인정보는 별도 DTO로 관리
- **접근 권한**: 필드별 접근 권한 체크 로직 추가
- **데이터 마스킹**: 로그 출력 시 민감 정보 마스킹

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| VocDto 책임 분리 | 높음 | 4시간 | 아키텍처 개선 핵심 |
| Y/N 필드 Boolean 통일 | 높음 | 2시간 | 타입 일관성 확보 |
| 비즈니스 로직 서비스 이동 | 높음 | 3시간 | 책임 분리 |
| 필드명 리팩토링 | 중간 | 3시간 | 가독성 개선 |
| 검증 어노테이션 통일 | 중간 | 2시간 | 데이터 품질 향상 |
| Swagger 문서화 추가 | 중간 | 2시간 | API 문서화 |
| 캡슐화 개선 | 낮음 | 1시간 | 코드 품질 |

**총 예상 소요 시간**: 17시간
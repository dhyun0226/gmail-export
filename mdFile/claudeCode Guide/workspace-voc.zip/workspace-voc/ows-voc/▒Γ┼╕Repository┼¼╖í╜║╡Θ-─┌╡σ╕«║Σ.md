# 기타 Repository 클래스들 코드 리뷰
## (VocAnswerDetailRepository.java, VocChangeHistoryRepository.java, VocChargePersonRepository.java, VocStatisticsQueryRepository.java)

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### VocStatisticsQueryRepository의 God Object 패턴
**문제점**: 553라인에 12개의 거의 동일한 통계 메서드를 가진 거대한 클래스
**파일**: VocStatisticsQueryRepository.java 전체
```java
@Repository
@RequiredArgsConstructor
public class VocStatisticsQueryRepository {
    
    // 부서별 통계 메서드들 (4개)
    public Map<String, Map<String, Integer>> getVocStatisticsByDayWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByWeekWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByMonthWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByYearWithConditions(...)
    
    // 품목별 통계 메서드들 (4개)
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndDayWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndWeekWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndMonthWithConditions(...)
    public Map<String, Map<String, Integer>> getVocStatisticsByItemAndYearWithConditions(...)
    
    // 담당자별 통계 메서드들 (4개)
    public Map<String, Map<String, Integer>> getVocChargePersonStatisticsByDayWithConditions(...)
    // ... 총 12개의 거의 동일한 구조 메서드
}
```

#### 대량의 중복 코드 (Massive Code Duplication)
**문제점**: 12개 메서드가 거의 100% 동일한 구조로 템플릿만 다름
**파일**: VocStatisticsQueryRepository.java 28-128, 166-235, 315-382번 라인
```java
// 시간별 부서 통계 - 28-60라인
public Map<String, Map<String, Integer>> getVocStatisticsByDayWithConditions(...) {
    List<Tuple> results = queryFactory
            .select(
                    voc.registererDepartmentCode,
                    Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"),
                    voc.count()
            )
            .from(voc)
            .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
            .where(/* 동일한 조건들 */)
            .groupBy(voc.registererDepartmentCode, Expressions.stringTemplate("hour({0})", voc.vocRegistrationDateTime))
            .fetch();
    return mapResultsToStatistics(results);
}

// 품목별 시간 통계 - 166-198라인 (거의 동일한 구조)
public Map<String, Map<String, Integer>> getVocStatisticsByItemAndDayWithConditions(...) {
    List<Tuple> results = queryFactory
            .select(
                    voc.itemCode,  // 이 부분만 다름
                    Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"), // 동일
                    voc.count() // 동일
            )
            .from(voc) // 동일
            .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber)) // 동일
            .where(/* 거의 동일한 조건들 */)
            .groupBy(voc.itemCode, Expressions.stringTemplate("hour({0})", voc.vocRegistrationDateTime)) // 그룹핑 필드만 다름
            .fetch();
    return mapResultsToStatistics(results); // 동일
}
```

#### VocAnswerDetailRepository의 기능 부족
**문제점**: 핵심 엔티티임에도 기본 JpaRepository만 상속하고 아무런 비즈니스 메서드 없음
**파일**: VocAnswerDetailRepository.java 전체 (9라인만)
```java
@Repository
public interface VocAnswerDetailRepository extends JpaRepository<VocAnswerDetail, Long> {
    // 아무런 커스텀 메서드 없음
    
    // 필요하지만 없는 메서드들:
    // - VOC 번호로 답변 조회
    // - 답변자별 답변 조회  
    // - 기간별 답변 조회
    // - 답변 상태별 조회
}
```

### 1.2 심각도 중간 (High) - 🟡

#### VocChargePersonRepository의 메서드명 일관성 부족
**문제점**: 메서드명이 내부 필드 구조를 그대로 노출하고 일관성이 없음
**파일**: VocChargePersonRepository.java 13-15번 라인
```java
// 일관성 없는 메서드명
List<VocChargePerson> findByVocCategoryCode(String vocCategoryCode);

// 너무 긴 메서드명 + Y/N 필드 노출
Optional<VocChargePerson> findByVocCategoryCodeAndVocDesignationThePersonInChargeYn(
    String vocCategoryCode, String vocDesignationThePersonInChargeYn);

List<VocChargePerson> findByVocChargePersonEmployeeNumber(String vocChargePersonEmployeeNumber);
```

#### VocChangeHistoryRepository의 복합키 활용 부족
**문제점**: 복합키 엔티티임에도 활용도가 낮고 비즈니스 메서드 부족
**파일**: VocChangeHistoryRepository.java 전체 (13라인)
```java
@Repository
public interface VocChangeHistoryRepository extends JpaRepository<VocChangeHistory, VocChangeHistoryId> {
    List<VocChangeHistory> findById_VocNumber(Long vocNumber); // 복합키의 일부만 활용
    
    // 부족한 메서드들:
    // - 기간별 변경 이력 조회
    // - 변경자별 이력 조회
    // - 변경 유형별 조회
    // - 최신 변경 이력 조회
}
```

#### 하드코딩된 상수값들 (Magic Values)
**문제점**: 모든 Repository에서 문자열 상수들이 하드코딩됨
**파일**: 모든 Repository 클래스들
```java
// VocStatisticsQueryRepository
private BooleanExpression isNotDeleted() {
    return voc.deleteYesOrNo.ne("Y"); // 하드코딩된 "Y"
}

// VocChargePersonRepository (사용하는 Service에서)
findByVocCategoryCodeAndVocDesignationThePersonInChargeYn(categoryCode, "Y"); // 하드코딩된 "Y"
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 예외 처리 및 로깅 부재
**문제점**: 모든 Repository에서 예외 처리나 로깅이 전혀 없음
**파일**: 모든 Repository 클래스들
```java
// 예외 처리나 로깅이 없는 패턴
public Map<String, Map<String, Integer>> getVocStatisticsByDayWithConditions(...) {
    List<Tuple> results = queryFactory.select(...).fetch(); // 예외 처리 없음
    return mapResultsToStatistics(results); // 로깅 없음
}
```

#### 반환 타입 안전성 부족
**문제점**: null이 반환될 수 있는 메서드들이 Optional로 래핑되지 않음
**파일**: VocChargePersonRepository.java
```java
// Optional을 사용하지 않는 메서드들
List<VocChargePerson> findByVocCategoryCode(String vocCategoryCode); // 빈 리스트 가능
List<VocChargePerson> findByVocChargePersonEmployeeNumber(String employeeNumber); // 빈 리스트 가능
```

## 2. 개선 코드 예시

### 2.1 통계 전용 Repository 리팩토링
```java
package com.osstem.ow.voc.repository.statistics;

import com.osstem.ow.voc.model.statistics.StatisticsPeriod;
import com.osstem.ow.voc.model.statistics.StatisticsGroupBy;
import com.osstem.ow.voc.model.statistics.VocStatisticsRequest;
import com.osstem.ow.voc.model.statistics.VocStatisticsResult;
import com.osstem.ow.voc.repository.common.VocQueryConditions;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Expression;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 통계 전용 Repository (리팩토링 버전)
 * 중복 코드를 제거하고 템플릿 패턴 적용
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocStatisticsRepository {

    private final JPAQueryFactory queryFactory;

    /**
     * VOC 통계 조회 (통합 메서드)
     * 
     * @param request 통계 요청 정보
     * @return 통계 결과
     */
    public VocStatisticsResult getVocStatistics(VocStatisticsRequest request) {
        log.debug("VOC 통계 조회 시작: request={}", request);
        
        try {
            // 그룹핑 표현식 결정
            Expression<String> groupExpression = getGroupExpression(request.getGroupBy());
            
            // 기간 표현식 결정  
            Expression<String> periodExpression = getPeriodExpression(request.getPeriod());
            
            // 통계 쿼리 실행
            List<Tuple> results = queryFactory
                    .select(groupExpression, periodExpression, voc.count())
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocStateCodeIn(request.getStateCodes()),
                            VocQueryConditions.vocCategoryCodeEquals(request.getCategoryCode()),
                            VocQueryConditions.itemCodeEquals(request.getItemCode()),
                            VocQueryConditions.registrationDateBetween(request.getStartDate(), request.getEndDate()),
                            VocQueryConditions.chargerDepartmentCodeIn(request.getChargerDepartmentCodes()),
                            VocQueryConditions.registererDepartmentCodeIn(request.getRegistererDepartmentCodes()),
                            getAdditionalWhereCondition(request.getGroupBy())
                    )
                    .groupBy(groupExpression, periodExpression)
                    .orderBy(voc.count().desc())
                    .fetch();

            // 결과 변환
            Map<String, Map<String, Integer>> statisticsData = transformResults(results);
            
            VocStatisticsResult result = VocStatisticsResult.builder()
                    .period(request.getPeriod())
                    .groupBy(request.getGroupBy())
                    .statisticsData(statisticsData)
                    .totalCount(calculateTotalCount(statisticsData))
                    .build();

            log.debug("VOC 통계 조회 완료: 그룹수={}, 총건수={}", 
                     statisticsData.size(), result.getTotalCount());
            
            return result;
            
        } catch (Exception e) {
            log.error("VOC 통계 조회 중 오류 발생: request={}", request, e);
            return VocStatisticsResult.empty();
        }
    }

    /**
     * 그룹핑 표현식 생성
     */
    private Expression<String> getGroupExpression(StatisticsGroupBy groupBy) {
        return switch (groupBy) {
            case REGISTERER_DEPARTMENT -> voc.registererDepartmentCode;
            case CHARGE_PERSON_DEPARTMENT -> vocChargePerson.vocChargePersonDepartmentCode;
            case ITEM_CODE -> voc.itemCode;
            case CATEGORY_CODE -> voc.vocCategoryCode;
            case STATE_CODE -> voc.vocStateCode;
        };
    }

    /**
     * 기간 표현식 생성
     */
    private Expression<String> getPeriodExpression(StatisticsPeriod period) {
        return switch (period) {
            case HOURLY -> Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime);
            case DAILY -> Expressions.stringTemplate("concat('d', dayofmonth({0}))", voc.vocRegistrationDateTime);
            case WEEKLY -> Expressions.stringTemplate("concat('w', week({0}))", voc.vocRegistrationDateTime);
            case MONTHLY -> Expressions.stringTemplate("concat('m', month({0}))", voc.vocRegistrationDateTime);
            case YEARLY -> Expressions.stringTemplate("concat('y', year({0}))", voc.vocRegistrationDateTime);
        };
    }

    /**
     * 그룹별 추가 조건
     */
    private BooleanExpression getAdditionalWhereCondition(StatisticsGroupBy groupBy) {
        return switch (groupBy) {
            case ITEM_CODE -> voc.itemCode.isNotNull();
            case CHARGE_PERSON_DEPARTMENT -> VocQueryConditions.isChargePersonActive();
            default -> null;
        };
    }

    /**
     * 쿼리 결과 변환
     */
    private Map<String, Map<String, Integer>> transformResults(List<Tuple> results) {
        Map<String, Map<String, Integer>> statisticsMap = new HashMap<>();

        for (Tuple tuple : results) {
            String groupKey = tuple.get(0, String.class);
            String periodKey = tuple.get(1, String.class);
            Long count = tuple.get(2, Long.class);

            if (groupKey != null && periodKey != null && count != null) {
                statisticsMap
                        .computeIfAbsent(groupKey, k -> new HashMap<>())
                        .put(periodKey, count.intValue());
            }
        }

        return statisticsMap;
    }

    /**
     * 전체 카운트 계산
     */
    private long calculateTotalCount(Map<String, Map<String, Integer>> statisticsData) {
        return statisticsData.values().stream()
                .flatMap(periodMap -> periodMap.values().stream())
                .mapToLong(Integer::longValue)
                .sum();
    }

    /**
     * 간단한 집계 통계 조회
     */
    public Map<String, Long> getSimpleStatistics(VocStatisticsRequest request) {
        log.debug("간단 통계 조회 시작: request={}", request);
        
        try {
            Expression<String> groupExpression = getGroupExpression(request.getGroupBy());
            
            List<Tuple> results = queryFactory
                    .select(groupExpression, voc.count())
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocStateCodeIn(request.getStateCodes()),
                            VocQueryConditions.registrationDateBetween(request.getStartDate(), request.getEndDate()),
                            getAdditionalWhereCondition(request.getGroupBy())
                    )
                    .groupBy(groupExpression)
                    .orderBy(voc.count().desc())
                    .fetch();

            Map<String, Long> resultMap = new HashMap<>();
            for (Tuple tuple : results) {
                String key = tuple.get(0, String.class);
                Long count = tuple.get(1, Long.class);
                if (key != null && count != null) {
                    resultMap.put(key, count);
                }
            }

            log.debug("간단 통계 조회 완료: 그룹수={}", resultMap.size());
            return resultMap;
            
        } catch (Exception e) {
            log.error("간단 통계 조회 중 오류 발생: request={}", request, e);
            return Map.of();
        }
    }
}
```

### 2.2 개선된 VocAnswerDetailRepository
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocAnswerDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * VOC 답변 상세 Repository (개선 버전)
 */
@Repository
public interface VocAnswerDetailRepository extends JpaRepository<VocAnswerDetail, Long> {

    /**
     * VOC 번호로 답변 상세 조회
     * @param vocNumber VOC 번호
     * @return 답변 상세 (Optional)
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.vocNumber = :vocNumber")
    Optional<VocAnswerDetail> findByVocNumber(@Param("vocNumber") Long vocNumber);

    /**
     * VOC 번호 목록으로 답변 상세 배치 조회
     * @param vocNumbers VOC 번호 목록
     * @return 답변 상세 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.vocNumber IN :vocNumbers ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findByVocNumbers(@Param("vocNumbers") List<Long> vocNumbers);

    /**
     * 답변자별 답변 목록 조회
     * @param employeeNumber 답변자 사원번호
     * @return 답변 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.answererEmployeeNumber = :employeeNumber " +
           "ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findByAnswerer(@Param("employeeNumber") String employeeNumber);

    /**
     * 기간별 답변 조회
     * @param startDate 시작일
     * @param endDate 종료일
     * @return 해당 기간 답변 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.vocAnswerDateTime BETWEEN :startDate AND :endDate " +
           "ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findByAnswerDateRange(@Param("startDate") LocalDateTime startDate,
                                               @Param("endDate") LocalDateTime endDate);

    /**
     * 답변 내용으로 검색
     * @param keyword 검색 키워드
     * @return 검색된 답변 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.vocAnswerContent LIKE %:keyword% " +
           "ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findByAnswerContentContaining(@Param("keyword") String keyword);

    /**
     * 파일이 첨부된 답변 조회
     * @return 파일 첨부 답변 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.answerFileId IS NOT NULL " +
           "ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findAnswersWithFiles();

    /**
     * 특정 카테고리의 답변 조회
     * @param categoryCode 카테고리 코드
     * @return 해당 카테고리 답변 목록
     */
    @Query("SELECT vad FROM VocAnswerDetail vad WHERE vad.vocCategoryCode = :categoryCode " +
           "ORDER BY vad.vocAnswerDateTime DESC")
    List<VocAnswerDetail> findByCategoryCode(@Param("categoryCode") String categoryCode);

    /**
     * 답변 존재 여부 확인
     * @param vocNumber VOC 번호
     * @return 답변 존재 여부
     */
    @Query("SELECT COUNT(vad) > 0 FROM VocAnswerDetail vad WHERE vad.vocNumber = :vocNumber")
    boolean existsByVocNumber(@Param("vocNumber") Long vocNumber);

    /**
     * 최근 답변 조회 (제한된 개수)
     * @param limit 조회 개수
     * @return 최근 답변 목록
     */
    @Query(value = "SELECT * FROM voc_answer_detail ORDER BY voc_answer_date_time DESC LIMIT :limit", 
           nativeQuery = true)
    List<VocAnswerDetail> findRecentAnswers(@Param("limit") int limit);

    /**
     * 답변자별 답변 개수 조회
     * @param employeeNumber 답변자 사원번호
     * @return 답변 개수
     */
    @Query("SELECT COUNT(vad) FROM VocAnswerDetail vad WHERE vad.answererEmployeeNumber = :employeeNumber")
    long countByAnswerer(@Param("employeeNumber") String employeeNumber);

    /**
     * 기간별 답변 개수 조회
     * @param startDate 시작일
     * @param endDate 종료일
     * @return 답변 개수
     */
    @Query("SELECT COUNT(vad) FROM VocAnswerDetail vad WHERE vad.vocAnswerDateTime BETWEEN :startDate AND :endDate")
    long countByAnswerDateRange(@Param("startDate") LocalDateTime startDate,
                               @Param("endDate") LocalDateTime endDate);
}
```

### 2.3 개선된 VocChargePersonRepository
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocChargePerson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * VOC 담당자 Repository (개선 버전)
 */
@Repository
public interface VocChargePersonRepository extends JpaRepository<VocChargePerson, Long> {

    /**
     * 카테고리별 담당자 목록 조회 (활성 상태만)
     * @param categoryCode 카테고리 코드
     * @return 활성 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocCategoryCode = :categoryCode " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocChargePersonName")
    List<VocChargePerson> findActiveByCategoryCode(@Param("categoryCode") String categoryCode);

    /**
     * 지정 담당자 조회 (카테고리별)
     * @param categoryCode 카테고리 코드
     * @return 지정 담당자 (Optional)
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocCategoryCode = :categoryCode " +
           "AND vcp.vocDesignationThePersonInChargeYn = 'Y' AND vcp.deleteYn = 'N'")
    Optional<VocChargePerson> findDesignatedPersonByCategory(@Param("categoryCode") String categoryCode);

    /**
     * 사원번호로 담당자 정보 목록 조회
     * @param employeeNumber 사원번호
     * @return 담당자 정보 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocChargePersonEmployeeNumber = :employeeNumber " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocCategoryCode")
    List<VocChargePerson> findActiveByEmployeeNumber(@Param("employeeNumber") String employeeNumber);

    /**
     * 부서별 담당자 목록 조회
     * @param departmentCode 부서 코드
     * @return 해당 부서 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocChargePersonDepartmentCode = :departmentCode " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocChargePersonName")
    List<VocChargePerson> findByDepartmentCode(@Param("departmentCode") String departmentCode);

    /**
     * 법인별 담당자 목록 조회
     * @param corporationCode 법인 코드
     * @return 해당 법인 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocChargePersonCorporationCode = :corporationCode " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocChargePersonDepartmentCode, vcp.vocChargePersonName")
    List<VocChargePerson> findByCorporationCode(@Param("corporationCode") String corporationCode);

    /**
     * 품목별 담당자 목록 조회
     * @param itemCode 품목 코드
     * @return 해당 품목 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.itemCode = :itemCode " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocChargePersonName")
    List<VocChargePerson> findByItemCode(@Param("itemCode") String itemCode);

    /**
     * 담당자명으로 검색
     * @param name 담당자명 (부분)
     * @return 검색된 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocChargePersonName LIKE %:name% " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocChargePersonName")
    List<VocChargePerson> findByNameContaining(@Param("name") String name);

    /**
     * 지정 담당자 목록 조회 (전체)
     * @return 모든 지정 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.vocDesignationThePersonInChargeYn = 'Y' " +
           "AND vcp.deleteYn = 'N' ORDER BY vcp.vocCategoryCode")
    List<VocChargePerson> findAllDesignatedPersons();

    /**
     * 담당자 존재 여부 확인 (사원번호 기준)
     * @param employeeNumber 사원번호
     * @return 존재 여부
     */
    @Query("SELECT COUNT(vcp) > 0 FROM VocChargePerson vcp WHERE vcp.vocChargePersonEmployeeNumber = :employeeNumber " +
           "AND vcp.deleteYn = 'N'")
    boolean existsByEmployeeNumber(@Param("employeeNumber") String employeeNumber);

    /**
     * 카테고리별 담당자 수 조회
     * @param categoryCode 카테고리 코드
     * @return 담당자 수
     */
    @Query("SELECT COUNT(vcp) FROM VocChargePerson vcp WHERE vcp.vocCategoryCode = :categoryCode " +
           "AND vcp.deleteYn = 'N'")
    long countByCategoryCode(@Param("categoryCode") String categoryCode);

    /**
     * 활성 담당자 전체 목록 조회
     * @return 활성 담당자 목록
     */
    @Query("SELECT vcp FROM VocChargePerson vcp WHERE vcp.deleteYn = 'N' " +
           "ORDER BY vcp.vocCategoryCode, vcp.vocChargePersonName")
    List<VocChargePerson> findAllActiveChargePersons();
}
```

### 2.4 개선된 VocChangeHistoryRepository
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocChangeHistory;
import com.osstem.ow.voc.entity.VocChangeHistoryId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * VOC 변경 이력 Repository (개선 버전)
 */
@Repository
public interface VocChangeHistoryRepository extends JpaRepository<VocChangeHistory, VocChangeHistoryId> {

    /**
     * VOC 번호로 변경 이력 조회 (시간 순 정렬)
     * @param vocNumber VOC 번호
     * @return 변경 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber " +
           "ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findByVocNumberOrderByDateTime(@Param("vocNumber") Long vocNumber);

    /**
     * VOC 번호로 변경 이력 조회 (페이징)
     * @param vocNumber VOC 번호
     * @param pageable 페이징 정보
     * @return 변경 이력 페이지
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber " +
           "ORDER BY vch.id.vocChangeDateTime DESC")
    Page<VocChangeHistory> findByVocNumber(@Param("vocNumber") Long vocNumber, Pageable pageable);

    /**
     * 최신 변경 이력 조회
     * @param vocNumber VOC 번호
     * @return 최신 변경 이력 (Optional)
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber " +
           "ORDER BY vch.id.vocChangeDateTime DESC LIMIT 1")
    Optional<VocChangeHistory> findLatestByVocNumber(@Param("vocNumber") Long vocNumber);

    /**
     * 변경자별 이력 조회
     * @param employeeNumber 변경자 사원번호
     * @return 변경 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.changeProcessorEmployeeNumber = :employeeNumber " +
           "ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findByChangeProcessor(@Param("employeeNumber") String employeeNumber);

    /**
     * 기간별 변경 이력 조회
     * @param startDate 시작일
     * @param endDate 종료일
     * @return 해당 기간 변경 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocChangeDateTime BETWEEN :startDate AND :endDate " +
           "ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findByChangeDateRange(@Param("startDate") LocalDateTime startDate,
                                                @Param("endDate") LocalDateTime endDate);

    /**
     * 상태 변경 이력 조회
     * @param vocNumber VOC 번호
     * @param stateCode 상태 코드
     * @return 해당 상태로 변경된 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber " +
           "AND vch.vocStateCode = :stateCode ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findByVocNumberAndStateCode(@Param("vocNumber") Long vocNumber,
                                                      @Param("stateCode") String stateCode);

    /**
     * 카테고리별 변경 이력 조회
     * @param categoryCode 카테고리 코드
     * @return 해당 카테고리 변경 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.vocCategoryCode = :categoryCode " +
           "ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findByCategoryCode(@Param("categoryCode") String categoryCode);

    /**
     * 담당자 변경 이력 조회
     * @param vocNumber VOC 번호
     * @return 담당자 변경 이력 목록
     */
    @Query("SELECT vch FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber " +
           "AND vch.vocChargePersonNumber IS NOT NULL ORDER BY vch.id.vocChangeDateTime DESC")
    List<VocChangeHistory> findChargePersonChangesByVocNumber(@Param("vocNumber") Long vocNumber);

    /**
     * 변경 이력 개수 조회 (VOC별)
     * @param vocNumber VOC 번호
     * @return 변경 이력 개수
     */
    @Query("SELECT COUNT(vch) FROM VocChangeHistory vch WHERE vch.id.vocNumber = :vocNumber")
    long countByVocNumber(@Param("vocNumber") Long vocNumber);

    /**
     * 기간별 변경 이력 개수 조회
     * @param startDate 시작일
     * @param endDate 종료일
     * @return 변경 이력 개수
     */
    @Query("SELECT COUNT(vch) FROM VocChangeHistory vch WHERE vch.id.vocChangeDateTime BETWEEN :startDate AND :endDate")
    long countByChangeDateRange(@Param("startDate") LocalDateTime startDate,
                               @Param("endDate") LocalDateTime endDate);

    /**
     * 변경자별 변경 이력 개수 조회
     * @param employeeNumber 변경자 사원번호
     * @return 변경 이력 개수
     */
    @Query("SELECT COUNT(vch) FROM VocChangeHistory vch WHERE vch.changeProcessorEmployeeNumber = :employeeNumber")
    long countByChangeProcessor(@Param("employeeNumber") String employeeNumber);

    /**
     * 최근 변경 이력 조회 (제한된 개수)
     * @param limit 조회 개수
     * @return 최근 변경 이력 목록
     */
    @Query(value = "SELECT * FROM voc_change_history ORDER BY voc_change_date_time DESC LIMIT :limit", 
           nativeQuery = true)
    List<VocChangeHistory> findRecentChanges(@Param("limit") int limit);
}
```

### 2.5 통계 요청/응답 DTO
```java
package com.osstem.ow.voc.model.statistics;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 통계 요청 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class VocStatisticsRequest {
    private StatisticsPeriod period;
    private StatisticsGroupBy groupBy;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private List<String> stateCodes;
    private String categoryCode;
    private String itemCode;
    private List<String> chargerDepartmentCodes;
    private List<String> registererDepartmentCodes;
}

/**
 * VOC 통계 결과 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class VocStatisticsResult {
    private StatisticsPeriod period;
    private StatisticsGroupBy groupBy;
    private Map<String, Map<String, Integer>> statisticsData;
    private long totalCount;
    
    public static VocStatisticsResult empty() {
        return VocStatisticsResult.builder()
                .statisticsData(Map.of())
                .totalCount(0L)
                .build();
    }
}

/**
 * 통계 기간 열거형
 */
public enum StatisticsPeriod {
    HOURLY("시간별"),
    DAILY("일별"),
    WEEKLY("주별"),
    MONTHLY("월별"),
    YEARLY("연별");
    
    private final String description;
    
    StatisticsPeriod(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}

/**
 * 통계 그룹핑 기준 열거형
 */
public enum StatisticsGroupBy {
    REGISTERER_DEPARTMENT("등록자 부서"),
    CHARGE_PERSON_DEPARTMENT("담당자 부서"),
    ITEM_CODE("품목 코드"),
    CATEGORY_CODE("카테고리 코드"),
    STATE_CODE("상태 코드");
    
    private final String description;
    
    StatisticsGroupBy(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}
```

## 3. 다른 접근법

### 3.1 Repository Factory Pattern
```java
/**
 * Repository Factory를 통한 동적 Repository 선택
 */
@Component
public class VocRepositoryFactory {
    
    private final Map<String, VocSpecializedRepository> repositories;
    
    public VocRepositoryFactory(List<VocSpecializedRepository> repositoryList) {
        this.repositories = repositoryList.stream()
                .collect(Collectors.toMap(
                    repo -> repo.getClass().getSimpleName(),
                    repo -> repo
                ));
    }
    
    public <T extends VocSpecializedRepository> T getRepository(Class<T> repositoryType) {
        String key = repositoryType.getSimpleName();
        return (T) repositories.get(key);
    }
}

// 특화된 Repository 인터페이스
public interface VocSpecializedRepository {
    // 공통 메서드 정의
}

@Repository
public class VocAnswerRepository implements VocSpecializedRepository {
    // 답변 관련 특화 로직
}

@Repository  
public class VocHistoryRepository implements VocSpecializedRepository {
    // 이력 관련 특화 로직
}
```

### 3.2 Template Method Pattern for Statistics
```java
/**
 * 통계 쿼리를 위한 템플릿 메서드 패턴
 */
public abstract class StatisticsQueryTemplate {
    
    protected final JPAQueryFactory queryFactory;
    
    public final Map<String, Integer> getStatistics(StatisticsRequest request) {
        // 템플릿 메서드
        validateRequest(request);
        List<Tuple> results = executeQuery(request);
        return transformResults(results);
    }
    
    protected abstract List<Tuple> executeQuery(StatisticsRequest request);
    protected abstract Expression<?> getGroupByExpression();
    protected abstract BooleanExpression getWhereCondition(StatisticsRequest request);
    
    private void validateRequest(StatisticsRequest request) {
        // 공통 검증 로직
    }
    
    private Map<String, Integer> transformResults(List<Tuple> results) {
        // 공통 변환 로직
    }
}

@Repository
public class DepartmentStatisticsRepository extends StatisticsQueryTemplate {
    
    @Override
    protected List<Tuple> executeQuery(StatisticsRequest request) {
        return queryFactory
                .select(getGroupByExpression(), voc.count())
                .from(voc)
                .where(getWhereCondition(request))
                .groupBy(getGroupByExpression())
                .fetch();
    }
    
    @Override
    protected Expression<?> getGroupByExpression() {
        return voc.registererDepartmentCode;
    }
    
    @Override
    protected BooleanExpression getWhereCondition(StatisticsRequest request) {
        return voc.deleteYesOrNo.ne("Y")
                .and(voc.registererDepartmentCode.isNotNull());
    }
}
```

### 3.3 Reactive Repository Pattern
```java
/**
 * 비동기 처리를 위한 Reactive Repository
 */
@Repository
public class VocReactiveRepository {
    
    private final JPAQueryFactory queryFactory;
    
    @Async("statisticsExecutor")
    public CompletableFuture<Map<String, Long>> getStatisticsAsync(VocStatisticsRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            // 통계 쿼리 실행
            return executeStatisticsQuery(request);
        });
    }
    
    @Async("historyExecutor") 
    public CompletableFuture<List<VocChangeHistory>> getHistoryAsync(Long vocNumber) {
        return CompletableFuture.supplyAsync(() -> {
            // 이력 쿼리 실행
            return executeHistoryQuery(vocNumber);
        });
    }
    
    public CompletableFuture<VocCompleteInfo> getCompleteInfoAsync(Long vocNumber) {
        CompletableFuture<VocResponseDto> vocFuture = getVocAsync(vocNumber);
        CompletableFuture<List<VocAnswerDetail>> answersFuture = getAnswersAsync(vocNumber);
        CompletableFuture<List<VocChangeHistory>> historyFuture = getHistoryAsync(vocNumber);
        
        return CompletableFuture.allOf(vocFuture, answersFuture, historyFuture)
                .thenApply(v -> VocCompleteInfo.builder()
                        .voc(vocFuture.join())
                        .answers(answersFuture.join())
                        .history(historyFuture.join())
                        .build());
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **쿼리 최적화**: 통계 쿼리의 인덱스 활용도 개선
- **배치 처리**: 대량 이력 조회 시 청크 단위 처리
- **캐싱**: 자주 조회되는 통계나 담당자 정보 캐싱
- **비동기 처리**: 무거운 통계 쿼리의 비동기 실행

### 4.2 유지보수 측면
- **코드 중복 제거**: Template Pattern이나 공통 유틸리티로 중복 제거
- **메서드명 일관성**: 비즈니스 의미가 명확한 메서드명 사용
- **반환 타입 안전성**: Optional이나 빈 컬렉션으로 null 안전성 확보
- **예외 처리**: Repository별 적절한 예외 처리 및 로깅

### 4.3 확장성 측면
- **동적 쿼리**: 검색 조건에 따른 유연한 쿼리 생성
- **다중 데이터소스**: 읽기/쓰기 분리 또는 분산 데이터베이스 지원
- **이벤트 기반**: Repository 변경 시 도메인 이벤트 발행
- **모니터링**: Repository별 성능 지표 수집

### 4.4 비즈니스 로직 측면
- **도메인 모델 강화**: Repository가 도메인 모델의 불변식 지원
- **집계 루트**: DDD 관점에서 적절한 집계 경계 설정
- **트랜잭션 경계**: Repository 간 트랜잭션 일관성 보장
- **비즈니스 규칙**: Repository에서 데이터 접근 규칙 구현

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| VocStatisticsQueryRepository 리팩토링 | 높음 | 8시간 | 중복 코드 대폭 제거 |
| VocAnswerDetailRepository 기능 보강 | 높음 | 3시간 | 핵심 기능 추가 |
| 하드코딩 상수화 | 높음 | 2시간 | 유지보수성 향상 |
| VocChargePersonRepository 메서드명 개선 | 중간 | 2시간 | 가독성 향상 |
| VocChangeHistoryRepository 기능 보강 | 중간 | 4시간 | 이력 관리 개선 |
| 예외 처리 및 로깅 추가 | 중간 | 3시간 | 안정성 향상 |
| Template Pattern 적용 | 낮음 | 5시간 | 코드 재사용성 |
| 비동기 처리 도입 | 낮음 | 6시간 | 성능 최적화 |

**총 예상 소요 시간**: 33시간
# VocCategoryQueryRepository 클래스 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 무한 루프 위험 (Infinite Loop Risk)
**문제점**: 카테고리 계층 구조에서 순환 참조 시 무한 루프 발생 가능성
**파일**: VocCategoryQueryRepository.java 48-62번 라인
```java
public VocCategory findRootCategory(String categoryCode) {
    // 최상위 카테고리를 찾을 때까지 반복
    VocCategory current = category;
    while (current.getUpVocCategoryCode() != null) {
        current = queryFactory
                .selectFrom(vocCategory)
                .where(vocCategory.vocCategoryCode.eq(current.getUpVocCategoryCode().getVocCategoryCode()))
                .fetchOne();
        
        if (current == null) {
            break; // null 체크만 있고 순환 참조 체크가 없음
        }
    }
    // A -> B -> A 같은 순환 참조 시 무한 루프 발생
    return current;
}
```

#### N+1 쿼리 문제 (Inefficient Query Pattern)
**문제점**: 개별 조회 후 Java에서 필터링하는 비효율적 패턴
**파일**: VocCategoryQueryRepository.java 90-110번 라인
```java
public List<VocCategory> findLowestLevelCategoriesByRootCode(String rootCategoryCode) {
    // 1. 첫 번째 쿼리: 모든 카테고리 조회
    List<VocCategory> allCategories = queryFactory
            .selectFrom(vocCategory)
            .where(vocCategory.vocCategoryCode.like(rootCategoryCode + "%"))
            .fetch();

    // 2. 두 번째 쿼리: 부모 카테고리 코드 목록 조회
    List<String> parentCategoryCodes = queryFactory
            .select(vocCategory.upVocCategoryCode.vocCategoryCode)
            .from(vocCategory)
            .where(vocCategory.upVocCategoryCode.vocCategoryCode.like(rootCategoryCode + "%"))
            .distinct()
            .fetch();

    // 3. Java에서 필터링 (메모리에서 처리 - 비효율적)
    return allCategories.stream()
            .filter(category -> !parentCategoryCodes.contains(category.getVocCategoryCode()))
            .toList();
}
```

#### 하드코딩된 매직 문자열 (Magic Strings)
**문제점**: 코드 전반에 하드코딩된 상수값들이 직접 사용됨
**파일**: VocCategoryQueryRepository.java 전체
```java
// 하드코딩된 문자열들
.where(vocCategory.upVocCategoryCode.isNull())        // 73번 라인
.where(parent.openYn.eq(openYn))                     // 74번 라인
.where(parent.deleteYn.eq('N'))                      // 75번 라인
.where(child.vocCategoryCode.like("%" + taskCode + "%")) // 76번 라인
.where(child.openYn.eq(openYn))                     // 77번 라인
.where(child.deleteYn.eq('N'))                      // 78번 라인
```

### 1.2 심각도 중간 (High) - 🟡

#### 메서드 책임 불분명 (Unclear Method Responsibility)
**문제점**: 메서드명과 실제 기능이 일치하지 않거나 책임이 모호함
**파일**: VocCategoryQueryRepository.java 64-82번 라인
```java
// 메서드명: "RootCategories"를 찾는다고 하지만
// 실제로는 "1레벨 카테고리 중에서 특정 taskCode를 가진 2레벨 자식이 있는 것들"을 조회
public List<VocCategory> findRootCategoriesByTaskCodeAndOpenYn(String taskCode, Character openYn) {
    QVocCategory parent = new QVocCategory("parent");
    QVocCategory child = new QVocCategory("child");

    return queryFactory
            .selectDistinct(parent)  // parent를 반환하는데
            .from(parent)
            .innerJoin(child).on(child.upVocCategoryCode.eq(parent)) // child 조건이 핵심
            .where(
                    parent.upVocCategoryCode.isNull(), // 1레벨 (부모가 null)
                    parent.openYn.eq(openYn),
                    parent.deleteYn.eq('N'),
                    child.vocCategoryCode.like("%" + taskCode + "%"), // 실제 핵심 조건
                    child.openYn.eq(openYn),
                    child.deleteYn.eq('N')
            )
            .orderBy(parent.sortOrder.asc())
            .fetch();
}
```

#### 일관성 없는 QueryDSL Q객체 사용
**문제점**: 일부는 static import, 일부는 new 인스턴스 생성으로 일관성 부족
**파일**: VocCategoryQueryRepository.java 전체
```java
// 16번 라인: static import 사용
import static com.osstem.ow.voc.entity.QVocCategory.vocCategory;

// 31번 라인: static import된 객체 사용
QVocCategory vocCategory = QVocCategory.vocCategory;

// 65-66번 라인: 새 인스턴스 생성
QVocCategory parent = new QVocCategory("parent");
QVocCategory child = new QVocCategory("child");

// 113-114번 라인: 또 다른 새 인스턴스 생성
QVocCategory vocCategory = QVocCategory.vocCategory;
QVocCategory parentCategory = new QVocCategory("parentCategory");
```

#### 매개변수 검증 부재
**문제점**: null이나 빈 문자열에 대한 검증 없이 쿼리 실행
**파일**: VocCategoryQueryRepository.java 전체
```java
public VocCategory findRootCategory(String categoryCode) {
    // categoryCode가 null이거나 빈 문자열인 경우에 대한 검증 없음
    VocCategory category = queryFactory
            .selectFrom(vocCategory)
            .where(vocCategory.vocCategoryCode.eq(categoryCode)) // NPE 가능성
            .fetchOne();
}

public List<VocCategory> findLowestLevelCategoriesByRootCode(String rootCategoryCode) {
    // rootCategoryCode가 null인 경우 like 검색에서 문제 발생 가능
    List<VocCategory> allCategories = queryFactory
            .selectFrom(vocCategory)
            .where(vocCategory.vocCategoryCode.like(rootCategoryCode + "%")) // NPE 가능성
            .fetch();
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 예외 처리 부재
**문제점**: 복잡한 쿼리 실행 중 발생할 수 있는 예외에 대한 처리 없음
**파일**: VocCategoryQueryRepository.java 전체
```java
public VocCategory findRootCategory(String categoryCode) {
    // DataAccessException, SQLException 등 예외 처리 없음
    VocCategory category = queryFactory
            .selectFrom(vocCategory)
            .where(vocCategory.vocCategoryCode.eq(categoryCode))
            .fetchOne();
}
```

#### 로깅 부재
**문제점**: 복잡한 계층 구조 쿼리의 실행 과정이나 결과에 대한 로깅 없음
**파일**: VocCategoryQueryRepository.java 전체
```java
// 복잡한 로직이지만 로깅이 전혀 없음
public List<VocCategory> findLowestLevelCategoriesByRootCode(String rootCategoryCode) {
    // 로그 없이 복잡한 처리 진행
}
```

#### 메서드 문서화 부족
**문제점**: 복잡한 쿼리 로직에 대한 충분한 설명 부족
**파일**: VocCategoryQueryRepository.java 전체
```java
/**
 * 특정 카테고리의 최상위(루트) 카테고리 조회
 * @param categoryCode 카테고리 코드
 * @return 최상위 카테고리
 */
// 간단한 주석만 있고, 순환 참조 위험이나 성능 고려사항에 대한 설명 없음
public VocCategory findRootCategory(String categoryCode) {
```

## 2. 개선 코드 예시

### 2.1 순환 참조 방지 및 안전한 루트 카테고리 조회
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.QVocCategory;
import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.exception.CircularReferenceException;
import com.osstem.ow.voc.exception.InvalidCategoryException;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.*;

import static com.osstem.ow.voc.entity.QVocCategory.vocCategory;

/**
 * VOC 카테고리 계층 구조 안전 조회 Repository
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocCategoryHierarchyRepository {

    private final JPAQueryFactory queryFactory;
    
    // 상수 정의
    private static final char ACTIVE_FLAG = 'Y';
    private static final char INACTIVE_FLAG = 'N';
    private static final char DELETED_FLAG = 'Y';
    private static final char NOT_DELETED_FLAG = 'N';
    private static final int MAX_HIERARCHY_DEPTH = 10; // 최대 계층 깊이 제한

    /**
     * 특정 카테고리의 최상위 카테고리를 안전하게 조회
     * 순환 참조 방지 및 최대 깊이 제한 적용
     * 
     * @param categoryCode 카테고리 코드
     * @return 최상위 카테고리 (Optional)
     * @throws InvalidCategoryException 유효하지 않은 카테고리 코드
     * @throws CircularReferenceException 순환 참조 발견
     */
    public Optional<VocCategory> findRootCategorySafely(String categoryCode) {
        log.debug("최상위 카테고리 조회 시작: categoryCode={}", categoryCode);
        
        // 입력값 검증
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            log.warn("카테고리 코드가 비어있음: categoryCode={}", categoryCode);
            return Optional.empty();
        }

        try {
            // 시작 카테고리 조회
            VocCategory startCategory = queryFactory
                    .selectFrom(vocCategory)
                    .where(vocCategory.vocCategoryCode.eq(categoryCode.trim())
                            .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG)))
                    .fetchOne();

            if (startCategory == null) {
                log.warn("존재하지 않는 카테고리: categoryCode={}", categoryCode);
                return Optional.empty();
            }

            // 상위 카테고리가 없는 경우 현재 카테고리가 최상위
            if (startCategory.getUpVocCategoryCode() == null) {
                log.debug("최상위 카테고리 조회 완료 (자기 자신): categoryCode={}", categoryCode);
                return Optional.of(startCategory);
            }

            // 순환 참조 방지를 위한 방문 기록
            Set<String> visitedCodes = new HashSet<>();
            VocCategory current = startCategory;
            int depth = 0;

            // 최상위까지 안전하게 탐색
            while (current.getUpVocCategoryCode() != null && depth < MAX_HIERARCHY_DEPTH) {
                String currentCode = current.getVocCategoryCode();
                
                // 순환 참조 체크
                if (visitedCodes.contains(currentCode)) {
                    log.error("카테고리 계층에 순환 참조 발견: visitedPath={}, currentCode={}", visitedCodes, currentCode);
                    throw new CircularReferenceException("카테고리 계층에 순환 참조가 존재합니다: " + currentCode);
                }
                
                visitedCodes.add(currentCode);
                depth++;
                
                String parentCode = current.getUpVocCategoryCode().getVocCategoryCode();
                current = queryFactory
                        .selectFrom(vocCategory)
                        .where(vocCategory.vocCategoryCode.eq(parentCode)
                                .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG)))
                        .fetchOne();

                if (current == null) {
                    log.warn("상위 카테고리가 존재하지 않거나 삭제됨: parentCode={}", parentCode);
                    break;
                }
            }

            if (depth >= MAX_HIERARCHY_DEPTH) {
                log.warn("카테고리 계층 깊이 제한 초과: maxDepth={}, categoryCode={}", MAX_HIERARCHY_DEPTH, categoryCode);
            }

            log.debug("최상위 카테고리 조회 완료: categoryCode={}, rootCode={}, depth={}", 
                     categoryCode, current != null ? current.getVocCategoryCode() : null, depth);
            
            return Optional.ofNullable(current);
            
        } catch (CircularReferenceException e) {
            throw e; // 순환 참조 예외는 다시 던짐
        } catch (Exception e) {
            log.error("최상위 카테고리 조회 중 오류 발생: categoryCode={}", categoryCode, e);
            return Optional.empty();
        }
    }

    /**
     * 특정 루트 카테고리의 최하위 카테고리들 효율적 조회
     * 단일 쿼리로 처리하여 성능 향상
     * 
     * @param rootCategoryCode 루트 카테고리 코드
     * @return 최하위 카테고리 목록
     */
    public List<VocCategory> findLeafCategoriesEfficiently(String rootCategoryCode) {
        log.debug("최하위 카테고리 조회 시작: rootCategoryCode={}", rootCategoryCode);
        
        // 입력값 검증
        if (rootCategoryCode == null || rootCategoryCode.trim().isEmpty()) {
            log.warn("루트 카테고리 코드가 비어있음");
            return Collections.emptyList();
        }

        try {
            // 단일 쿼리로 최하위 카테고리 조회 (서브쿼리 사용)
            List<VocCategory> leafCategories = queryFactory
                    .selectFrom(vocCategory)
                    .where(
                            vocCategory.vocCategoryCode.like(rootCategoryCode.trim() + "%")
                                    .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG))
                                    .and(vocCategory.vocCategoryCode.notIn(
                                            // 다른 카테고리의 부모로 사용되는 카테고리 제외
                                            queryFactory
                                                    .select(vocCategory.upVocCategoryCode.vocCategoryCode)
                                                    .from(vocCategory)
                                                    .where(vocCategory.upVocCategoryCode.vocCategoryCode.isNotNull()
                                                            .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG)))
                                                    .distinct()
                                    ))
                    )
                    .orderBy(vocCategory.sortOrder.asc())
                    .fetch();

            log.debug("최하위 카테고리 조회 완료: rootCategoryCode={}, count={}", rootCategoryCode, leafCategories.size());
            return leafCategories;
            
        } catch (Exception e) {
            log.error("최하위 카테고리 조회 중 오류 발생: rootCategoryCode={}", rootCategoryCode, e);
            return Collections.emptyList();
        }
    }

    /**
     * 업무 코드와 공개 여부를 만족하는 루트 카테고리 조회
     * 메서드명과 기능을 명확히 일치시킴
     * 
     * @param taskCode 업무 코드 (2레벨 카테고리에서 검색)
     * @param isOpen 공개 여부
     * @return 조건을 만족하는 1레벨 카테고리 목록
     */
    public List<VocCategory> findFirstLevelCategoriesHavingTaskCode(String taskCode, Boolean isOpen) {
        log.debug("업무 코드별 1레벨 카테고리 조회 시작: taskCode={}, isOpen={}", taskCode, isOpen);
        
        // 입력값 검증
        if (taskCode == null || taskCode.trim().isEmpty()) {
            log.warn("업무 코드가 비어있음");
            return Collections.emptyList();
        }

        try {
            Character openFlag = Boolean.TRUE.equals(isOpen) ? ACTIVE_FLAG : INACTIVE_FLAG;
            
            QVocCategory parent = new QVocCategory("parent");
            QVocCategory child = new QVocCategory("child");

            List<VocCategory> categories = queryFactory
                    .selectDistinct(parent)
                    .from(parent)
                    .innerJoin(child).on(child.upVocCategoryCode.eq(parent))
                    .where(
                            // 1레벨 카테고리 조건 (부모가 없음)
                            parent.upVocCategoryCode.isNull(),
                            // 1레벨 카테고리 상태 조건
                            parent.openYn.eq(openFlag),
                            parent.deleteYn.eq(NOT_DELETED_FLAG),
                            // 2레벨 카테고리에서 업무 코드 포함 조건
                            child.vocCategoryCode.containsIgnoreCase(taskCode.trim()),
                            // 2레벨 카테고리 상태 조건
                            child.openYn.eq(openFlag),
                            child.deleteYn.eq(NOT_DELETED_FLAG)
                    )
                    .orderBy(parent.sortOrder.asc())
                    .fetch();

            log.debug("업무 코드별 1레벨 카테고리 조회 완료: taskCode={}, count={}", taskCode, categories.size());
            return categories;
            
        } catch (Exception e) {
            log.error("업무 코드별 1레벨 카테고리 조회 중 오류 발생: taskCode={}, isOpen={}", taskCode, isOpen, e);
            return Collections.emptyList();
        }
    }

    /**
     * 2레벨 카테고리들 조회 (부모가 1레벨인 카테고리들)
     * 
     * @param isOpen 공개 여부
     * @return 2레벨 카테고리 DTO 목록
     */
    public List<CategoryLevelDto> findSecondLevelCategories(Boolean isOpen) {
        log.debug("2레벨 카테고리 조회 시작: isOpen={}", isOpen);
        
        try {
            Character openFlag = Boolean.TRUE.equals(isOpen) ? ACTIVE_FLAG : INACTIVE_FLAG;
            
            QVocCategory current = vocCategory;
            QVocCategory parent = new QVocCategory("parent");

            List<CategoryLevelDto> categories = queryFactory
                    .select(Projections.constructor(CategoryLevelDto.class,
                            current.vocCategoryCode,
                            current.vocCategoryName,
                            current.sortOrder,
                            parent.vocCategoryCode.as("parentCode"),
                            parent.vocCategoryName.as("parentName")
                    ))
                    .from(current)
                    .join(current.upVocCategoryCode, parent)
                    .where(
                            // 현재 카테고리 조건
                            current.openYn.eq(openFlag),
                            current.deleteYn.eq(NOT_DELETED_FLAG),
                            // 부모가 1레벨인 조건 (부모의 부모가 null)
                            parent.upVocCategoryCode.isNull(),
                            parent.openYn.eq(openFlag),
                            parent.deleteYn.eq(NOT_DELETED_FLAG)
                    )
                    .orderBy(parent.sortOrder.asc(), current.sortOrder.asc())
                    .fetch();

            log.debug("2레벨 카테고리 조회 완료: isOpen={}, count={}", isOpen, categories.size());
            return categories;
            
        } catch (Exception e) {
            log.error("2레벨 카테고리 조회 중 오류 발생: isOpen={}", isOpen, e);
            return Collections.emptyList();
        }
    }

    /**
     * 모든 루트 카테고리 조회 (공개 여부별)
     * 
     * @param isOpen 공개 여부
     * @return 루트 카테고리 목록
     */
    public List<VocCategory> findRootCategories(Boolean isOpen) {
        log.debug("루트 카테고리 조회 시작: isOpen={}", isOpen);
        
        try {
            Character openFlag = Boolean.TRUE.equals(isOpen) ? ACTIVE_FLAG : INACTIVE_FLAG;

            List<VocCategory> categories = queryFactory
                    .selectFrom(vocCategory)
                    .where(
                            vocCategory.upVocCategoryCode.isNull(),
                            vocCategory.openYn.eq(openFlag),
                            vocCategory.deleteYn.eq(NOT_DELETED_FLAG)
                    )
                    .orderBy(vocCategory.sortOrder.asc())
                    .fetch();

            log.debug("루트 카테고리 조회 완료: isOpen={}, count={}", isOpen, categories.size());
            return categories;
            
        } catch (Exception e) {
            log.error("루트 카테고리 조회 중 오류 발생: isOpen={}", isOpen, e);
            return Collections.emptyList();
        }
    }

    /**
     * 카테고리 계층 구조 검증
     * 
     * @param categoryCode 검증할 카테고리 코드
     * @return 검증 결과
     */
    public CategoryHierarchyValidationResult validateCategoryHierarchy(String categoryCode) {
        log.debug("카테고리 계층 구조 검증 시작: categoryCode={}", categoryCode);
        
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            return CategoryHierarchyValidationResult.invalid("카테고리 코드가 없습니다");
        }

        try {
            // 순환 참조 체크
            Optional<VocCategory> rootCategory = findRootCategorySafely(categoryCode);
            
            if (rootCategory.isEmpty()) {
                return CategoryHierarchyValidationResult.invalid("유효하지 않은 카테고리이거나 루트를 찾을 수 없습니다");
            }

            // 계층 깊이 체크
            int depth = calculateCategoryDepth(categoryCode);
            if (depth > MAX_HIERARCHY_DEPTH) {
                return CategoryHierarchyValidationResult.invalid("최대 계층 깊이를 초과했습니다: " + depth);
            }

            return CategoryHierarchyValidationResult.valid(rootCategory.get(), depth);
            
        } catch (CircularReferenceException e) {
            return CategoryHierarchyValidationResult.invalid("순환 참조가 발견되었습니다: " + e.getMessage());
        } catch (Exception e) {
            log.error("카테고리 계층 구조 검증 중 오류 발생: categoryCode={}", categoryCode, e);
            return CategoryHierarchyValidationResult.invalid("검증 중 오류가 발생했습니다");
        }
    }

    /**
     * 카테고리 깊이 계산
     */
    private int calculateCategoryDepth(String categoryCode) {
        Set<String> visited = new HashSet<>();
        VocCategory current = queryFactory
                .selectFrom(vocCategory)
                .where(vocCategory.vocCategoryCode.eq(categoryCode)
                        .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG)))
                .fetchOne();
        
        int depth = 0;
        while (current != null && current.getUpVocCategoryCode() != null && depth < MAX_HIERARCHY_DEPTH) {
            if (visited.contains(current.getVocCategoryCode())) {
                throw new CircularReferenceException("순환 참조 발견: " + current.getVocCategoryCode());
            }
            visited.add(current.getVocCategoryCode());
            
            current = queryFactory
                    .selectFrom(vocCategory)
                    .where(vocCategory.vocCategoryCode.eq(current.getUpVocCategoryCode().getVocCategoryCode())
                            .and(vocCategory.deleteYn.eq(NOT_DELETED_FLAG)))
                    .fetchOne();
            depth++;
        }
        
        return depth;
    }
}
```

### 2.2 카테고리 레벨 DTO 및 검증 결과 클래스
```java
package com.osstem.ow.voc.model.dto;

import lombok.*;

/**
 * 카테고리 레벨 정보 DTO
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
public class CategoryLevelDto {
    private String categoryCode;
    private String categoryName;
    private Integer sortOrder;
    private String parentCode;
    private String parentName;
    
    /**
     * 루트 카테고리인지 확인
     */
    public boolean isRootCategory() {
        return parentCode == null;
    }
    
    /**
     * 표시명 생성 (부모 > 현재)
     */
    public String getDisplayName() {
        if (isRootCategory()) {
            return categoryName;
        }
        return parentName + " > " + categoryName;
    }
}
```

### 2.3 카테고리 계층 구조 검증 결과
```java
package com.osstem.ow.voc.model.validation;

import com.osstem.ow.voc.entity.VocCategory;
import lombok.*;

/**
 * 카테고리 계층 구조 검증 결과
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode
public class CategoryHierarchyValidationResult {
    private final boolean valid;
    private final String message;
    private final VocCategory rootCategory;
    private final Integer depth;

    /**
     * 유효한 결과 생성
     */
    public static CategoryHierarchyValidationResult valid(VocCategory rootCategory, Integer depth) {
        return new CategoryHierarchyValidationResult(true, "유효한 카테고리 계층입니다", rootCategory, depth);
    }

    /**
     * 무효한 결과 생성
     */
    public static CategoryHierarchyValidationResult invalid(String message) {
        return new CategoryHierarchyValidationResult(false, message, null, null);
    }

    /**
     * 검증 성공 여부
     */
    public boolean isValid() {
        return valid;
    }

    /**
     * 에러 메시지 (검증 실패 시)
     */
    public String getErrorMessage() {
        return valid ? null : message;
    }
}
```

### 2.4 예외 클래스 정의
```java
package com.osstem.ow.voc.exception;

/**
 * 순환 참조 예외
 */
public class CircularReferenceException extends RuntimeException {
    public CircularReferenceException(String message) {
        super(message);
    }
    
    public CircularReferenceException(String message, Throwable cause) {
        super(message, cause);
    }
}

/**
 * 유효하지 않은 카테고리 예외
 */
public class InvalidCategoryException extends RuntimeException {
    public InvalidCategoryException(String message) {
        super(message);
    }
    
    public InvalidCategoryException(String message, Throwable cause) {
        super(message, cause);
    }
}
```

## 3. 다른 접근법

### 3.1 Recursive CTE를 활용한 계층 구조 처리
```java
/**
 * PostgreSQL/MySQL 8.0+ Recursive CTE를 활용한 계층 구조 쿼리
 */
@Repository
public class VocCategoryRecursiveRepository {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Recursive CTE로 전체 계층 구조 조회
     */
    public List<CategoryHierarchyDto> findFullHierarchy(String rootCode) {
        String sql = """
            WITH RECURSIVE category_hierarchy AS (
                -- 기준점: 루트 카테고리
                SELECT 
                    voc_category_code,
                    voc_category_name,
                    up_voc_category_code,
                    sort_order,
                    1 as level,
                    CAST(voc_category_code AS VARCHAR(1000)) as path
                FROM voc_category 
                WHERE up_voc_category_code IS NULL 
                  AND voc_category_code = :rootCode
                  AND delete_yn = 'N'
                
                UNION ALL
                
                -- 재귀: 하위 카테고리들
                SELECT 
                    vc.voc_category_code,
                    vc.voc_category_name,
                    vc.up_voc_category_code,
                    vc.sort_order,
                    ch.level + 1,
                    CONCAT(ch.path, '/', vc.voc_category_code) as path
                FROM voc_category vc
                INNER JOIN category_hierarchy ch ON vc.up_voc_category_code = ch.voc_category_code
                WHERE vc.delete_yn = 'N'
                  AND ch.level < 10  -- 최대 깊이 제한
            )
            SELECT * FROM category_hierarchy 
            ORDER BY level, sort_order
            """;
            
        return entityManager.createNativeQuery(sql)
                .setParameter("rootCode", rootCode)
                .unwrap(NativeQuery.class)
                .setResultTransformer(Transformers.aliasToBean(CategoryHierarchyDto.class))
                .getResultList();
    }

    /**
     * 특정 카테고리까지의 경로 조회
     */
    public List<CategoryPathDto> findCategoryPath(String categoryCode) {
        String sql = """
            WITH RECURSIVE category_path AS (
                -- 시작점: 대상 카테고리
                SELECT 
                    voc_category_code,
                    voc_category_name,
                    up_voc_category_code,
                    0 as distance_from_target
                FROM voc_category 
                WHERE voc_category_code = :categoryCode AND delete_yn = 'N'
                
                UNION ALL
                
                -- 재귀: 상위 카테고리들
                SELECT 
                    vc.voc_category_code,
                    vc.voc_category_name,
                    vc.up_voc_category_code,
                    cp.distance_from_target + 1
                FROM voc_category vc
                INNER JOIN category_path cp ON vc.voc_category_code = cp.up_voc_category_code
                WHERE vc.delete_yn = 'N'
            )
            SELECT * FROM category_path 
            ORDER BY distance_from_target DESC  -- 루트부터 대상까지 순서
            """;
            
        return entityManager.createNativeQuery(sql)
                .setParameter("categoryCode", categoryCode)
                .unwrap(NativeQuery.class)
                .setResultTransformer(Transformers.aliasToBean(CategoryPathDto.class))
                .getResultList();
    }
}
```

### 3.2 Materialized Path 패턴 적용
```java
/**
 * Materialized Path 패턴을 활용한 계층 구조 최적화
 * 각 노드에 전체 경로를 문자열로 저장
 */
@Entity
public class VocCategoryWithPath {
    private String vocCategoryCode;
    private String vocCategoryName; 
    private String materializedPath;  // 예: "/ROOT/CAT1/SUBCAT1"
    private Integer depth;
    
    // 기타 필드들...
}

@Repository
public interface VocCategoryPathRepository extends JpaRepository<VocCategoryWithPath, String> {
    
    /**
     * 특정 경로 하위의 모든 카테고리 조회
     */
    @Query("SELECT vc FROM VocCategoryWithPath vc WHERE vc.materializedPath LIKE CONCAT(:basePath, '%')")
    List<VocCategoryWithPath> findAllDescendants(@Param("basePath") String basePath);
    
    /**
     * 특정 깊이의 카테고리들만 조회
     */
    @Query("SELECT vc FROM VocCategoryWithPath vc WHERE vc.depth = :depth ORDER BY vc.materializedPath")
    List<VocCategoryWithPath> findByDepth(@Param("depth") Integer depth);
    
    /**
     * 경로 기반 검색 (특정 구간 검색 가능)
     */
    @Query("SELECT vc FROM VocCategoryWithPath vc WHERE vc.materializedPath LIKE %:pathSegment%")
    List<VocCategoryWithPath> findByPathContaining(@Param("pathSegment") String pathSegment);
    
    /**
     * 리프 노드 조회 (하위 카테고리가 없는 노드들)
     */
    @Query("SELECT vc FROM VocCategoryWithPath vc WHERE NOT EXISTS " +
           "(SELECT 1 FROM VocCategoryWithPath child WHERE child.materializedPath LIKE CONCAT(vc.materializedPath, '/%'))")
    List<VocCategoryWithPath> findLeafNodes();
}
```

### 3.3 캐시 기반 계층 구조 처리
```java
/**
 * Redis를 활용한 카테고리 계층 구조 캐싱
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class VocCategoryCacheService {

    private final VocCategoryRepository vocCategoryRepository;
    private final RedisTemplate<String, Object> redisTemplate;
    
    private static final String CACHE_KEY_PREFIX = "voc:category:hierarchy:";
    private static final Duration CACHE_TTL = Duration.ofHours(24);

    /**
     * 캐시를 활용한 계층 구조 조회
     */
    @Cacheable(value = "categoryHierarchy", key = "#rootCode")
    public CategoryTreeNode getCategoryTree(String rootCode) {
        log.debug("카테고리 트리 캐시 조회: rootCode={}", rootCode);
        
        try {
            // 캐시 키 생성
            String cacheKey = CACHE_KEY_PREFIX + rootCode;
            
            // Redis에서 조회
            CategoryTreeNode cachedTree = (CategoryTreeNode) redisTemplate.opsForValue().get(cacheKey);
            
            if (cachedTree != null) {
                log.debug("캐시에서 카테고리 트리 조회 성공: rootCode={}", rootCode);
                return cachedTree;
            }
            
            // 캐시 미스 시 DB에서 조회
            CategoryTreeNode treeNode = buildCategoryTreeFromDatabase(rootCode);
            
            // Redis에 캐시 저장
            redisTemplate.opsForValue().set(cacheKey, treeNode, CACHE_TTL);
            
            log.debug("카테고리 트리 DB 조회 후 캐시 저장: rootCode={}", rootCode);
            return treeNode;
            
        } catch (Exception e) {
            log.error("카테고리 트리 조회 중 오류 발생: rootCode={}", rootCode, e);
            // 캐시 오류 시 DB에서 직접 조회
            return buildCategoryTreeFromDatabase(rootCode);
        }
    }

    /**
     * 카테고리 변경 시 관련 캐시 무효화
     */
    @CacheEvict(value = "categoryHierarchy", allEntries = true)
    public void evictCategoryCache() {
        log.info("카테고리 계층 구조 캐시 전체 무효화");
        
        try {
            // Redis에서 패턴 매칭으로 관련 키 삭제
            Set<String> keys = redisTemplate.keys(CACHE_KEY_PREFIX + "*");
            if (keys != null && !keys.isEmpty()) {
                redisTemplate.delete(keys);
                log.info("Redis에서 카테고리 캐시 키 삭제: {}개", keys.size());
            }
        } catch (Exception e) {
            log.error("카테고리 캐시 무효화 중 오류 발생", e);
        }
    }

    /**
     * DB에서 카테고리 트리 구조 생성
     */
    private CategoryTreeNode buildCategoryTreeFromDatabase(String rootCode) {
        List<VocCategory> allCategories = vocCategoryRepository
                .findByCategoryCodes(Arrays.asList(rootCode)); // 실제로는 하위 카테고리도 포함
        
        // 트리 구조 생성 로직...
        return CategoryTreeNode.buildTree(allCategories);
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **인덱스 최적화**: (up_voc_category_code, delete_yn, open_yn) 복합 인덱스
- **쿼리 최적화**: Recursive CTE나 Materialized Path를 통한 계층 쿼리 최적화
- **캐싱 전략**: 변경이 적은 카테고리 구조는 Redis/Application Level 캐싱
- **지연 로딩**: 필요한 레벨만 로드하는 지연 로딩 전략

### 4.2 안정성 측면
- **순환 참조 방지**: 모든 계층 구조 조회에서 순환 참조 체크
- **최대 깊이 제한**: 무한 루프 방지를 위한 깊이 제한 설정
- **예외 처리**: 계층 구조 무결성 오류에 대한 적절한 예외 처리
- **트랜잭션 관리**: 계층 구조 변경 시 일관성 보장

### 4.3 확장성 측면
- **동적 계층**: 런타임에 계층 구조 변경 가능한 설계
- **다중 루트**: 여러 루트 카테고리 동시 처리
- **권한 기반**: 사용자 권한에 따른 카테고리 필터링
- **국제화**: 다국어 카테고리명 지원

### 4.4 모니터링 측면
- **성능 모니터링**: 복잡한 계층 쿼리의 실행 시간 추적
- **캐시 효율성**: 캐시 히트율 및 무효화 패턴 모니터링
- **데이터 무결성**: 계층 구조 일관성 정기 검증
- **사용 패턴**: 어떤 계층 조회가 빈번한지 분석

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 순환 참조 방지 로직 구현 | 높음 | 4시간 | 안정성 확보 핵심 |
| 하드코딩 상수화 | 높음 | 1시간 | 유지보수성 향상 |
| N+1 쿼리 최적화 | 높음 | 3시간 | 성능 개선 |
| 매개변수 검증 및 예외 처리 | 높음 | 3시간 | 안정성 강화 |
| 메서드명 및 책임 명확화 | 중간 | 2시간 | 가독성 향상 |
| 로깅 및 모니터링 추가 | 중간 | 2시간 | 운영 지원 |
| QueryDSL 사용 일관성 개선 | 중간 | 1시간 | 코드 품질 |
| Recursive CTE 패턴 적용 | 낮음 | 6시간 | 고급 최적화 |
| 캐싱 시스템 구축 | 낮음 | 8시간 | 성능 최적화 |

**총 예상 소요 시간**: 30시간
rootProject.name = "ows-voc"

# VocCategoryRepository 클래스 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 메서드명에 내부 구조 노출 (Leaky Abstraction)
**문제점**: 메서드명이 JPA 연관관계의 내부 구조를 그대로 노출하여 캡슐화 위반
**파일**: VocCategoryRepository.java 11, 16번 라인
```java
// 문제: 내부 엔티티 구조(upVocCategoryCode_VocCategoryCode)가 메서드명에 노출됨
List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
boolean existsByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);

// 개발자가 내부 구조를 알아야만 사용 가능
// upVocCategoryCode는 VocCategory 엔티티를 참조
// _VocCategoryCode는 그 엔티티의 기본키 필드를 의미
```

#### Repository의 기능 부족
**문제점**: 카테고리 도메인의 핵심 Repository임에도 기본적인 비즈니스 메서드가 부족
**파일**: VocCategoryRepository.java 전체 (17라인)
```java
@Repository
public interface VocCategoryRepository extends JpaRepository<VocCategory, String> {
    // 단 3개의 커스텀 메서드만 존재
    List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
    List<VocCategory> findAllByOrderBySortOrderAsc();
    boolean existsByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
    
    // 부족한 메서드들:
    // - 활성 카테고리 조회 (openYn, deleteYn 고려)
    // - 카테고리명으로 검색
    // - 깊이별 카테고리 조회
    // - 특정 깊이의 카테고리만 조회
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 정렬 기준의 하드코딩
**문제점**: 정렬 기준이 메서드명에 하드코딩되어 유연성 부족
**파일**: VocCategoryRepository.java 13번 라인
```java
// 정렬 기준이 고정됨
List<VocCategory> findAllByOrderBySortOrderAsc();

// 다른 정렬이 필요한 경우 별도 메서드 추가 필요:
// findAllByOrderBySortOrderDesc()
// findAllByOrderByVocCategoryNameAsc()
// 등등...
```

#### 반환 타입 안전성 부족
**문제점**: 계층 구조 조회 시 빈 결과에 대한 명확한 처리 부재
**파일**: VocCategoryRepository.java 11번 라인
```java
// 빈 List를 반환할 수 있으나 Optional로 감싸지지 않음
List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);

// 부모가 존재하지 않는 경우나 하위 카테고리가 없는 경우의 처리가 불분명
```

#### 비즈니스 조건 누락
**문제점**: 카테고리 조회 시 기본적인 비즈니스 조건(활성 상태, 삭제 여부)이 고려되지 않음
**파일**: VocCategoryRepository.java 전체
```java
// 현재: 모든 카테고리 조회 (삭제된 것도 포함)
List<VocCategory> findAllByOrderBySortOrderAsc();

// 필요: 활성 카테고리만 조회
// List<VocCategory> findActiveOrderBySortOrder();
// List<VocCategory> findByDeleteYnAndOpenYnOrderBySortOrder('N', 'Y');
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 확장성 부족
**문제점**: 향후 카테고리 관련 복잡한 조회 로직 추가 시 구조적 한계
**파일**: VocCategoryRepository.java 전체
```java
// 현재는 단순한 메서드만 있어서 향후 확장 시 일관성 문제
// 예: 카테고리 트리 구조 조회, 경로 기반 검색 등
```

#### 성능 고려 부족
**문제점**: 계층 구조 특성상 N+1 문제가 발생할 수 있으나 이에 대한 고려 없음
**파일**: VocCategoryRepository.java 11번 라인
```java
// 하위 카테고리 조회 시 각 카테고리마다 추가 쿼리 발생 가능
List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
```

## 2. 개선 코드 예시

### 2.1 비즈니스 의미가 명확한 메서드명으로 개선
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocCategory;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * VOC 카테고리 데이터 액세스 Repository
 * 카테고리 계층 구조 및 기본 CRUD 기능 제공
 */
@Repository
public interface VocCategoryRepository extends JpaRepository<VocCategory, String> {

    /**
     * 특정 상위 카테고리의 직접 하위 카테고리 목록 조회
     * @param parentCategoryCode 상위 카테고리 코드
     * @return 하위 카테고리 목록 (정렬 순서대로)
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.upVocCategoryCode.vocCategoryCode = :parentCategoryCode " +
           "AND vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findChildCategories(@Param("parentCategoryCode") String parentCategoryCode);

    /**
     * 활성 상태인 직접 하위 카테고리 목록 조회
     * @param parentCategoryCode 상위 카테고리 코드
     * @return 활성 하위 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.upVocCategoryCode.vocCategoryCode = :parentCategoryCode " +
           "AND vc.deleteYn = 'N' AND vc.openYn = 'Y' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findActiveChildCategories(@Param("parentCategoryCode") String parentCategoryCode);

    /**
     * 최상위 카테고리 목록 조회 (부모가 없는 카테고리들)
     * @return 최상위 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.upVocCategoryCode IS NULL " +
           "AND vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findRootCategories();

    /**
     * 활성 상태인 최상위 카테고리 목록 조회
     * @return 활성 최상위 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.upVocCategoryCode IS NULL " +
           "AND vc.deleteYn = 'N' AND vc.openYn = 'Y' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findActiveRootCategories();

    /**
     * 활성 상태인 모든 카테고리 조회 (정렬 순서대로)
     * @return 활성 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.deleteYn = 'N' AND vc.openYn = 'Y' " +
           "ORDER BY vc.sortOrder ASC")
    List<VocCategory> findActiveCategories();

    /**
     * 활성 상태인 모든 카테고리 조회 (사용자 정의 정렬)
     * @param sort 정렬 조건
     * @return 활성 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.deleteYn = 'N' AND vc.openYn = 'Y'")
    List<VocCategory> findActiveCategories(Sort sort);

    /**
     * 카테고리명으로 검색 (부분 일치)
     * @param categoryName 카테고리명 (부분)
     * @return 검색된 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.vocCategoryName LIKE %:categoryName% " +
           "AND vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findByNameContaining(@Param("categoryName") String categoryName);

    /**
     * 특정 상위 카테고리에 하위 카테고리가 존재하는지 확인
     * @param parentCategoryCode 상위 카테고리 코드
     * @return 하위 카테고리 존재 여부
     */
    @Query("SELECT COUNT(vc) > 0 FROM VocCategory vc WHERE vc.upVocCategoryCode.vocCategoryCode = :parentCategoryCode " +
           "AND vc.deleteYn = 'N'")
    boolean hasChildCategories(@Param("parentCategoryCode") String parentCategoryCode);

    /**
     * 활성 하위 카테고리가 존재하는지 확인
     * @param parentCategoryCode 상위 카테고리 코드
     * @return 활성 하위 카테고리 존재 여부
     */
    @Query("SELECT COUNT(vc) > 0 FROM VocCategory vc WHERE vc.upVocCategoryCode.vocCategoryCode = :parentCategoryCode " +
           "AND vc.deleteYn = 'N' AND vc.openYn = 'Y'")
    boolean hasActiveChildCategories(@Param("parentCategoryCode") String parentCategoryCode);

    /**
     * 카테고리 코드 목록으로 배치 조회
     * @param categoryCodes 카테고리 코드 목록
     * @return 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.vocCategoryCode IN :categoryCodes " +
           "AND vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findByCategoryCodes(@Param("categoryCodes") List<String> categoryCodes);

    /**
     * 특정 깊이의 카테고리들 조회
     * @param depth 카테고리 깊이 (1: 최상위, 2: 2레벨 등)
     * @return 해당 깊이의 카테고리 목록
     */
    @Query(value = "WITH RECURSIVE category_hierarchy AS (" +
                   "  SELECT voc_category_code, up_voc_category_code, voc_category_name, sort_order, 1 as depth " +
                   "  FROM voc_category WHERE up_voc_category_code IS NULL AND delete_yn = 'N' " +
                   "  UNION ALL " +
                   "  SELECT vc.voc_category_code, vc.up_voc_category_code, vc.voc_category_name, vc.sort_order, ch.depth + 1 " +
                   "  FROM voc_category vc INNER JOIN category_hierarchy ch ON vc.up_voc_category_code = ch.voc_category_code " +
                   "  WHERE vc.delete_yn = 'N' " +
                   ") " +
                   "SELECT * FROM category_hierarchy WHERE depth = :depth ORDER BY sort_order", 
           nativeQuery = true)
    List<VocCategory> findByDepth(@Param("depth") int depth);

    /**
     * 특정 카테고리의 전체 경로 조회 (최상위까지)
     * @param categoryCode 카테고리 코드
     * @return 경로상의 모든 카테고리 (자식부터 최상위까지)
     */
    @Query(value = "WITH RECURSIVE category_path AS (" +
                   "  SELECT voc_category_code, up_voc_category_code, voc_category_name, sort_order, 0 as level " +
                   "  FROM voc_category WHERE voc_category_code = :categoryCode AND delete_yn = 'N' " +
                   "  UNION ALL " +
                   "  SELECT vc.voc_category_code, vc.up_voc_category_code, vc.voc_category_name, vc.sort_order, cp.level + 1 " +
                   "  FROM voc_category vc INNER JOIN category_path cp ON vc.voc_category_code = cp.up_voc_category_code " +
                   "  WHERE vc.delete_yn = 'N' " +
                   ") " +
                   "SELECT * FROM category_path ORDER BY level DESC", 
           nativeQuery = true)
    List<VocCategory> findCategoryPath(@Param("categoryCode") String categoryCode);

    /**
     * 정렬 순서 범위내의 카테고리들 조회
     * @param minSortOrder 최소 정렬 순서
     * @param maxSortOrder 최대 정렬 순서
     * @return 해당 범위의 카테고리 목록
     */
    @Query("SELECT vc FROM VocCategory vc WHERE vc.sortOrder BETWEEN :minSortOrder AND :maxSortOrder " +
           "AND vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findBySortOrderRange(@Param("minSortOrder") Integer minSortOrder, 
                                         @Param("maxSortOrder") Integer maxSortOrder);

    /**
     * 카테고리 사용 가능 여부 확인 (활성 상태이고 삭제되지 않음)
     * @param categoryCode 카테고리 코드
     * @return 사용 가능 여부
     */
    @Query("SELECT COUNT(vc) > 0 FROM VocCategory vc WHERE vc.vocCategoryCode = :categoryCode " +
           "AND vc.deleteYn = 'N' AND vc.openYn = 'Y'")
    boolean isAvailableCategory(@Param("categoryCode") String categoryCode);

    /**
     * 다음 정렬 순서 값 조회
     * @param parentCategoryCode 상위 카테고리 코드 (null이면 최상위)
     * @return 다음 정렬 순서 값
     */
    @Query("SELECT COALESCE(MAX(vc.sortOrder), 0) + 1 FROM VocCategory vc " +
           "WHERE (:parentCategoryCode IS NULL AND vc.upVocCategoryCode IS NULL) " +
           "OR (:parentCategoryCode IS NOT NULL AND vc.upVocCategoryCode.vocCategoryCode = :parentCategoryCode)")
    Integer getNextSortOrder(@Param("parentCategoryCode") String parentCategoryCode);
}
```

### 2.2 캐시 및 성능 최적화를 고려한 Repository
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocCategory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * VOC 카테고리 성능 최적화 Repository
 */
@Repository
public interface VocCategoryPerformanceRepository extends VocCategoryRepository {

    /**
     * 전체 카테고리 트리 조회 (캐시 적용)
     * 변경이 적은 카테고리 구조는 캐싱하여 성능 향상
     */
    @Cacheable(value = "categoryTree", key = "'all'")
    @Query("SELECT vc FROM VocCategory vc WHERE vc.deleteYn = 'N' ORDER BY vc.sortOrder ASC")
    List<VocCategory> findAllCategoriesForTree();

    /**
     * 특정 루트 카테고리의 전체 하위 트리 조회 (Fetch Join 적용)
     * N+1 문제 방지를 위한 한 번의 쿼리로 전체 트리 로드
     */
    @EntityGraph(attributePaths = {"upVocCategoryCode"})
    @Query("SELECT vc FROM VocCategory vc WHERE vc.vocCategoryCode LIKE CONCAT(:rootCode, '%') " +
           "AND vc.deleteYn = 'N' ORDER BY vc.vocCategoryCode ASC")
    List<VocCategory> findCategoryTreeByRoot(@Param("rootCode") String rootCode);

    /**
     * 활성 카테고리만 조회 (캐시 적용)
     */
    @Cacheable(value = "activeCategories", key = "'active'")
    @Query("SELECT vc FROM VocCategory vc WHERE vc.deleteYn = 'N' AND vc.openYn = 'Y' " +
           "ORDER BY vc.sortOrder ASC")
    List<VocCategory> findActiveCategoriesCached();

    /**
     * 카테고리 계층 정보와 함께 조회 (단일 쿼리)
     */
    @Query("SELECT vc, parent FROM VocCategory vc " +
           "LEFT JOIN vc.upVocCategoryCode parent " +
           "WHERE vc.vocCategoryCode = :categoryCode AND vc.deleteYn = 'N'")
    Optional<VocCategory> findWithParentCategory(@Param("categoryCode") String categoryCode);

    /**
     * 배치 처리를 위한 청크 단위 조회
     */
    @Query(value = "SELECT * FROM voc_category WHERE delete_yn = 'N' " +
                   "ORDER BY voc_category_code LIMIT :limit OFFSET :offset", 
           nativeQuery = true)
    List<VocCategory> findCategoriesInChunks(@Param("offset") long offset, @Param("limit") int limit);
}
```

### 2.3 사용자 친화적인 Repository 래퍼 클래스
```java
package com.osstem.ow.voc.repository.facade;

import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.repository.VocCategoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * VOC 카테고리 Repository 파사드
 * 복잡한 카테고리 계층 구조 조회를 단순화하여 제공
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class VocCategoryRepositoryFacade {

    private final VocCategoryRepository vocCategoryRepository;

    /**
     * 카테고리 트리 구조 조회
     * @return 전체 카테고리 트리 (Map 형태)
     */
    public Map<String, CategoryNode> getCategoryTree() {
        log.debug("카테고리 트리 구조 조회 시작");
        
        try {
            List<VocCategory> allCategories = vocCategoryRepository.findActiveCategories();
            Map<String, CategoryNode> nodeMap = new HashMap<>();
            Map<String, List<CategoryNode>> childrenMap = new HashMap<>();

            // 1단계: 모든 카테고리를 Node로 변환
            for (VocCategory category : allCategories) {
                CategoryNode node = CategoryNode.from(category);
                nodeMap.put(category.getVocCategoryCode(), node);
            }

            // 2단계: 부모-자식 관계 설정
            for (VocCategory category : allCategories) {
                String parentCode = category.getUpVocCategoryCode() != null ? 
                                  category.getUpVocCategoryCode().getVocCategoryCode() : null;
                
                if (parentCode != null) {
                    childrenMap.computeIfAbsent(parentCode, k -> new ArrayList<>())
                              .add(nodeMap.get(category.getVocCategoryCode()));
                }
            }

            // 3단계: 자식 노드 설정
            for (Map.Entry<String, List<CategoryNode>> entry : childrenMap.entrySet()) {
                CategoryNode parent = nodeMap.get(entry.getKey());
                if (parent != null) {
                    parent.setChildren(entry.getValue().stream()
                                     .sorted(Comparator.comparing(CategoryNode::getSortOrder))
                                     .collect(Collectors.toList()));
                }
            }

            log.debug("카테고리 트리 구조 조회 완료: 총 {}개 카테고리", nodeMap.size());
            return nodeMap;
            
        } catch (Exception e) {
            log.error("카테고리 트리 구조 조회 중 오류 발생", e);
            return Collections.emptyMap();
        }
    }

    /**
     * 특정 카테고리의 브레드크럼 경로 조회
     * @param categoryCode 카테고리 코드
     * @return 경로 문자열 (예: "루트 > 중분류 > 소분류")
     */
    public String getCategoryBreadcrumb(String categoryCode) {
        log.debug("카테고리 브레드크럼 조회: categoryCode={}", categoryCode);
        
        try {
            List<VocCategory> path = vocCategoryRepository.findCategoryPath(categoryCode);
            if (path.isEmpty()) {
                return "";
            }

            String breadcrumb = path.stream()
                                  .map(VocCategory::getVocCategoryName)
                                  .collect(Collectors.joining(" > "));
            
            log.debug("카테고리 브레드크럼 조회 완료: {}", breadcrumb);
            return breadcrumb;
            
        } catch (Exception e) {
            log.error("카테고리 브레드크럼 조회 중 오류 발생: categoryCode={}", categoryCode, e);
            return "";
        }
    }

    /**
     * 카테고리 레벨별 조회 (깊이별)
     * @param maxDepth 최대 깊이
     * @return 레벨별 카테고리 맵
     */
    public Map<Integer, List<VocCategory>> getCategoriesByLevel(int maxDepth) {
        log.debug("레벨별 카테고리 조회: maxDepth={}", maxDepth);
        
        try {
            Map<Integer, List<VocCategory>> levelMap = new HashMap<>();
            
            for (int depth = 1; depth <= maxDepth; depth++) {
                List<VocCategory> categories = vocCategoryRepository.findByDepth(depth);
                if (!categories.isEmpty()) {
                    levelMap.put(depth, categories);
                }
            }
            
            log.debug("레벨별 카테고리 조회 완료: {}개 레벨", levelMap.size());
            return levelMap;
            
        } catch (Exception e) {
            log.error("레벨별 카테고리 조회 중 오류 발생: maxDepth={}", maxDepth, e);
            return Collections.emptyMap();
        }
    }

    /**
     * 사용 가능한 카테고리 옵션 조회 (드롭다운 등에서 사용)
     * @return 카테고리 옵션 리스트
     */
    public List<CategoryOption> getAvailableCategoryOptions() {
        log.debug("사용 가능한 카테고리 옵션 조회 시작");
        
        try {
            List<VocCategory> activeCategories = vocCategoryRepository.findActiveCategories(
                Sort.by(Sort.Direction.ASC, "sortOrder"));
            
            List<CategoryOption> options = activeCategories.stream()
                    .map(category -> CategoryOption.builder()
                            .code(category.getVocCategoryCode())
                            .name(category.getVocCategoryName())
                            .parentCode(category.getUpVocCategoryCode() != null ? 
                                      category.getUpVocCategoryCode().getVocCategoryCode() : null)
                            .sortOrder(category.getSortOrder())
                            .build())
                    .collect(Collectors.toList());
            
            log.debug("사용 가능한 카테고리 옵션 조회 완료: {}개", options.size());
            return options;
            
        } catch (Exception e) {
            log.error("사용 가능한 카테고리 옵션 조회 중 오류 발생", e);
            return Collections.emptyList();
        }
    }

    /**
     * 카테고리 검증 (존재하고 활성 상태인지)
     * @param categoryCode 카테고리 코드
     * @return 유효성 검증 결과
     */
    public CategoryValidationResult validateCategory(String categoryCode) {
        log.debug("카테고리 검증: categoryCode={}", categoryCode);
        
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            return CategoryValidationResult.invalid("카테고리 코드가 없습니다");
        }

        try {
            Optional<VocCategory> category = vocCategoryRepository.findById(categoryCode);
            
            if (category.isEmpty()) {
                return CategoryValidationResult.invalid("존재하지 않는 카테고리입니다");
            }

            VocCategory cat = category.get();
            
            if ("Y".equals(cat.getDeleteYn())) {
                return CategoryValidationResult.invalid("삭제된 카테고리입니다");
            }

            if ("N".equals(cat.getOpenYn())) {
                return CategoryValidationResult.invalid("비활성 카테고리입니다");
            }

            return CategoryValidationResult.valid(cat);
            
        } catch (Exception e) {
            log.error("카테고리 검증 중 오류 발생: categoryCode={}", categoryCode, e);
            return CategoryValidationResult.invalid("카테고리 검증 중 오류가 발생했습니다");
        }
    }

    // 내부 클래스들
    @lombok.Data
    @lombok.Builder
    public static class CategoryNode {
        private String code;
        private String name;
        private Integer sortOrder;
        private String parentCode;
        private List<CategoryNode> children = new ArrayList<>();

        public static CategoryNode from(VocCategory category) {
            return CategoryNode.builder()
                    .code(category.getVocCategoryCode())
                    .name(category.getVocCategoryName())
                    .sortOrder(category.getSortOrder())
                    .parentCode(category.getUpVocCategoryCode() != null ? 
                              category.getUpVocCategoryCode().getVocCategoryCode() : null)
                    .build();
        }
    }

    @lombok.Data
    @lombok.Builder
    public static class CategoryOption {
        private String code;
        private String name;
        private String parentCode;
        private Integer sortOrder;
    }

    @lombok.Data
    @lombok.AllArgsConstructor
    public static class CategoryValidationResult {
        private boolean valid;
        private String message;
        private VocCategory category;

        public static CategoryValidationResult valid(VocCategory category) {
            return new CategoryValidationResult(true, "유효한 카테고리입니다", category);
        }

        public static CategoryValidationResult invalid(String message) {
            return new CategoryValidationResult(false, message, null);
        }
    }
}
```

## 3. 다른 접근법

### 3.1 Nested Set Model 패턴 적용
```java
/**
 * Nested Set Model을 활용한 계층 구조 최적화
 * 각 노드에 left, right 값을 저장하여 트리 쿼리 성능 향상
 */
@Entity
public class VocCategoryNested {
    private String vocCategoryCode;
    private String vocCategoryName;
    private Integer leftValue;   // Nested Set의 left 값
    private Integer rightValue;  // Nested Set의 right 값
    private Integer depth;       // 깊이
    
    // 기타 필드들...
}

@Repository
public interface VocCategoryNestedRepository extends JpaRepository<VocCategoryNested, String> {
    
    /**
     * 특정 노드의 모든 하위 노드 조회 (한 번의 쿼리)
     */
    @Query("SELECT vc FROM VocCategoryNested vc " +
           "WHERE vc.leftValue > :leftValue AND vc.rightValue < :rightValue " +
           "ORDER BY vc.leftValue")
    List<VocCategoryNested> findAllDescendants(@Param("leftValue") Integer leftValue,
                                              @Param("rightValue") Integer rightValue);
    
    /**
     * 특정 노드의 직접 하위 노드만 조회
     */
    @Query("SELECT vc FROM VocCategoryNested vc " +
           "WHERE vc.leftValue > :leftValue AND vc.rightValue < :rightValue " +
           "AND vc.depth = :childDepth " +
           "ORDER BY vc.leftValue")
    List<VocCategoryNested> findDirectChildren(@Param("leftValue") Integer leftValue,
                                              @Param("rightValue") Integer rightValue,
                                              @Param("childDepth") Integer childDepth);
    
    /**
     * 리프 노드 조회 (하위 노드가 없는 노드들)
     */
    @Query("SELECT vc FROM VocCategoryNested vc " +
           "WHERE vc.rightValue = vc.leftValue + 1")
    List<VocCategoryNested> findLeafNodes();
}
```

### 3.2 Repository Pattern with Specification
```java
/**
 * Specification 패턴을 활용한 동적 조회
 */
public class VocCategorySpecifications {
    
    public static Specification<VocCategory> isActive() {
        return (root, query, criteriaBuilder) -> 
            criteriaBuilder.and(
                criteriaBuilder.equal(root.get("deleteYn"), 'N'),
                criteriaBuilder.equal(root.get("openYn"), 'Y')
            );
    }
    
    public static Specification<VocCategory> hasParent(String parentCode) {
        return (root, query, criteriaBuilder) -> {
            if (parentCode == null) {
                return criteriaBuilder.isNull(root.get("upVocCategoryCode"));
            }
            return criteriaBuilder.equal(root.get("upVocCategoryCode").get("vocCategoryCode"), parentCode);
        };
    }
    
    public static Specification<VocCategory> nameContains(String name) {
        return (root, query, criteriaBuilder) -> 
            name != null ? criteriaBuilder.like(root.get("vocCategoryName"), "%" + name + "%") : null;
    }
    
    public static Specification<VocCategory> inSortOrderRange(Integer min, Integer max) {
        return (root, query, criteriaBuilder) -> {
            if (min != null && max != null) {
                return criteriaBuilder.between(root.get("sortOrder"), min, max);
            } else if (min != null) {
                return criteriaBuilder.greaterThanOrEqualTo(root.get("sortOrder"), min);
            } else if (max != null) {
                return criteriaBuilder.lessThanOrEqualTo(root.get("sortOrder"), max);
            }
            return null;
        };
    }
}

// Repository에서 사용
public interface VocCategoryRepository extends JpaRepository<VocCategory, String>, 
                                             JpaSpecificationExecutor<VocCategory> {
    
    // Specification 사용 예시는 Service에서
    // Specification<VocCategory> spec = Specification
    //     .where(VocCategorySpecifications.isActive())
    //     .and(VocCategorySpecifications.hasParent(parentCode))
    //     .and(VocCategorySpecifications.nameContains(searchName));
    // List<VocCategory> results = vocCategoryRepository.findAll(spec, sort);
}
```

### 3.3 Custom Repository Implementation
```java
/**
 * 복잡한 카테고리 계층 구조 쿼리를 위한 커스텀 구현체
 */
public interface VocCategoryRepositoryCustom {
    List<VocCategory> findCategoryTreeWithDepth(String rootCode, int maxDepth);
    Map<String, List<VocCategory>> groupCategoriesByParent();
    List<VocCategory> findCategoriesByPath(String path);
}

@Repository
public class VocCategoryRepositoryCustomImpl implements VocCategoryRepositoryCustom {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public List<VocCategory> findCategoryTreeWithDepth(String rootCode, int maxDepth) {
        String sql = """
            WITH RECURSIVE category_tree AS (
                SELECT *, 1 as depth FROM voc_category 
                WHERE voc_category_code = :rootCode AND delete_yn = 'N'
                
                UNION ALL
                
                SELECT vc.*, ct.depth + 1 
                FROM voc_category vc 
                INNER JOIN category_tree ct ON vc.up_voc_category_code = ct.voc_category_code
                WHERE vc.delete_yn = 'N' AND ct.depth < :maxDepth
            )
            SELECT * FROM category_tree ORDER BY depth, sort_order
            """;
            
        return entityManager.createNativeQuery(sql, VocCategory.class)
                .setParameter("rootCode", rootCode)
                .setParameter("maxDepth", maxDepth)
                .getResultList();
    }
    
    @Override
    public Map<String, List<VocCategory>> groupCategoriesByParent() {
        List<VocCategory> allCategories = entityManager
                .createQuery("SELECT vc FROM VocCategory vc WHERE vc.deleteYn = 'N'", VocCategory.class)
                .getResultList();
                
        return allCategories.stream()
                .collect(Collectors.groupingBy(
                    category -> category.getUpVocCategoryCode() != null ? 
                              category.getUpVocCategoryCode().getVocCategoryCode() : "ROOT",
                    LinkedHashMap::new,
                    Collectors.toList()
                ));
    }
    
    @Override
    public List<VocCategory> findCategoriesByPath(String path) {
        // 경로 기반 검색 (예: "ROOT/CATEGORY1/SUBCATEGORY")
        String[] pathSegments = path.split("/");
        
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VocCategory> query = cb.createQuery(VocCategory.class);
        Root<VocCategory> root = query.from(VocCategory.class);
        
        // 복잡한 경로 기반 조건 구성...
        
        return entityManager.createQuery(query).getResultList();
    }
}

// 메인 Repository 인터페이스에서 상속
public interface VocCategoryRepository extends JpaRepository<VocCategory, String>, 
                                             VocCategoryRepositoryCustom {
    // 기존 메서드들...
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **인덱스 최적화**: 계층 구조 쿼리를 위한 복합 인덱스 (up_voc_category_code, sort_order, delete_yn)
- **캐싱 전략**: 변경이 적은 카테고리 구조는 Redis/EHCache로 캐싱
- **지연 로딩**: 깊은 계층 구조 조회 시 필요한 부분만 로드
- **쿼리 최적화**: Recursive CTE나 Nested Set Model을 통한 트리 쿼리 최적화

### 4.2 유지보수 측면
- **메서드명 일관성**: 비즈니스 의미가 명확한 메서드명 사용
- **결과 안전성**: Optional이나 빈 컬렉션 반환으로 null 안전성 확보
- **예외 처리**: 계층 구조의 무결성 검증 및 예외 상황 처리
- **문서화**: 복잡한 계층 구조 쿼리에 대한 상세한 주석

### 4.3 확장성 측면
- **동적 쿼리**: 검색 조건에 따른 유연한 카테고리 조회
- **다국어 지원**: 카테고리명의 다국어 처리 고려
- **권한 기반 필터링**: 사용자 권한에 따른 카테고리 필터링
- **버전 관리**: 카테고리 구조 변경 시 이력 관리

### 4.4 데이터 무결성 측면
- **참조 무결성**: 부모-자식 관계의 일관성 검증
- **순환 참조 방지**: 계층 구조에서 순환 참조 검출 및 방지
- **트랜잭션 관리**: 카테고리 구조 변경 시 일관성 보장
- **제약 조건**: 데이터베이스 레벨에서의 무결성 제약 설정

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 메서드명 비즈니스 의미화 | 높음 | 2시간 | 가독성 즉시 개선 |
| 기본 비즈니스 메서드 추가 | 높음 | 4시간 | 필수 기능 보완 |
| 활성 상태 필터링 쿼리 적용 | 높음 | 2시간 | 데이터 품질 향상 |
| Repository 파사드 클래스 구현 | 중간 | 6시간 | 사용성 대폭 개선 |
| 성능 최적화 (캐싱, Fetch Join) | 중간 | 4시간 | 성능 향상 |
| Specification 패턴 적용 | 중간 | 3시간 | 동적 쿼리 개선 |
| Nested Set Model 적용 검토 | 낮음 | 8시간 | 고급 최적화 |
| Custom Repository 구현 | 낮음 | 5시간 | 고급 기능 |

**총 예상 소요 시간**: 34시간
# QnaService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 예외 처리 부재
**문제점**: Feign Client 호출 실패 시 예외 처리가 없어 장애 전파 가능
**라인**: 전체 메서드 (18-36번 라인)
```java
public QnaAnswerDetailDto createQnaAnswer(QnaAnswerDetailDto qnaAnswerDetailDto) {
    return qnaServiceClient.createQnaAnswer(qnaAnswerDetailDto); // 예외 처리 없음
}
```

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 18, 22, 26, 30, 34번 라인
```java
public QnaResponseDto getQnaById(Long qnaNumber, String channelCode, String serviceCategoryCode, String userId, String corporationCode) {
    // 5개 파라미터 모두 null 검증 없음
    return qnaServiceClient.getQnaById(userId, corporationCode, qnaNumber, channelCode, serviceCategoryCode);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 메서드 파라미터 순서 불일치
**문제점**: 메서드 정의와 Feign 클라이언트 호출 시 파라미터 순서가 다름
**라인**: 26-27번 라인
```java
// 메서드 정의: qnaNumber, channelCode, serviceCategoryCode, userId, corporationCode 순서
public QnaResponseDto getQnaById(Long qnaNumber, String channelCode, String serviceCategoryCode, String userId, String corporationCode) {
    // Feign 호출: userId, corporationCode, qnaNumber, channelCode, serviceCategoryCode 순서 (완전히 다름)
    return qnaServiceClient.getQnaById(userId, corporationCode, qnaNumber, channelCode, serviceCategoryCode);
}
```

#### 복잡한 파라미터 목록
**문제점**: getQnaById 메서드가 5개의 파라미터를 받아 가독성과 유지보수성 저하
**라인**: 26번 라인
```java
public QnaResponseDto getQnaById(Long qnaNumber, String channelCode, String serviceCategoryCode, String userId, String corporationCode) {
    // 너무 많은 파라미터로 인한 가독성 저하
}
```

#### 로깅 부재
**문제점**: 비즈니스 로직 추적과 디버깅이 어려움
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class QnaService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 어떤 작업을 수행했는지 추적 불가
**라인**: 전체 메서드
```java
public QnaAnswerDetailDto createQnaAnswer(QnaAnswerDetailDto qnaAnswerDetailDto) {
    // 사용자 정보 로깅 없음
    return qnaServiceClient.createQnaAnswer(qnaAnswerDetailDto);
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 외부 서비스 호출에 대한 트랜잭션 전략이 명확하지 않음
**라인**: 전체 메서드
```java
// @Transactional 애노테이션 없음
public QnaAnswerDetailDto updateQnaAnswer(Long qnaNumber, Long qnaAnswerDetailNumber, QnaAnswerDetailDto dto) {
    return qnaServiceClient.updateQnaAnswer(qnaNumber, qnaAnswerDetailNumber, dto);
}
```

#### 메서드 명명 일관성 부족
**문제점**: 일부 메서드는 동사+명사(createQnaAnswer), 일부는 동사+목적어(getQnaById) 패턴이 혼재
**라인**: 18, 22, 26번 라인
```java
public QnaAnswerDetailDto createQnaAnswer(...) // create + QnaAnswer
public ResultDto<QnaResponseDto> getQnaList(...) // get + QnaList  
public QnaResponseDto getQnaById(...) // get + Qna + ById
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.QnaServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.event.QnaAnswerDetailDto;
import com.osstem.ow.voc.model.event.QnaDto;
import com.osstem.ow.voc.model.request.QnaRequestDto;
import com.osstem.ow.voc.model.response.QnaResponseDto;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class QnaService {

    private final QnaServiceClient qnaServiceClient;

    /**
     * QnA 답변 생성
     * @param qnaAnswerDetailDto QnA 답변 정보
     * @return 생성된 QnA 답변 정보
     */
    public QnaAnswerDetailDto createQnaAnswer(QnaAnswerDetailDto qnaAnswerDetailDto) {
        log.info("QnA 답변 생성 시작 - qnaNumber: {}", 
                qnaAnswerDetailDto != null ? qnaAnswerDetailDto.getQnaNumber() : "null");
        
        // 파라미터 검증
        validateQnaAnswerDetailDto(qnaAnswerDetailDto);
        validateQnaAnswerCreateRequest(qnaAnswerDetailDto);
        
        try {
            QnaAnswerDetailDto result = qnaServiceClient.createQnaAnswer(qnaAnswerDetailDto);
            log.info("QnA 답변 생성 완료 - qnaNumber: {}, answerNumber: {}", 
                    result.getQnaNumber(), result.getQnaAnswerDetailNumber());
            return result;
        } catch (Exception e) {
            log.error("QnA 답변 생성 실패 - qnaNumber: {}, error: {}", 
                     qnaAnswerDetailDto != null ? qnaAnswerDetailDto.getQnaNumber() : "null", e.getMessage(), e);
            throw new BusinessException("qna.answer.creation.failed", e);
        }
    }

    /**
     * QnA 목록 조회
     * @param requestDto 조회 조건
     * @param processStatus 처리 상태
     * @return QnA 목록
     */
    public ResultDto<QnaResponseDto> getQnaList(QnaRequestDto requestDto, String processStatus) {
        log.info("QnA 목록 조회 시작 - processStatus: {}", processStatus);
        
        // 파라미터 검증
        validateQnaRequestDto(requestDto);
        validateProcessStatus(processStatus);
        
        try {
            ResultDto<QnaResponseDto> result = qnaServiceClient.getQnaList(requestDto, processStatus);
            log.info("QnA 목록 조회 완료 - count: {}, processStatus: {}", 
                    result.getList().size(), processStatus);
            return result;
        } catch (Exception e) {
            log.error("QnA 목록 조회 실패 - processStatus: {}, error: {}", processStatus, e.getMessage(), e);
            throw new BusinessException("qna.list.retrieval.failed", e);
        }
    }

    /**
     * QnA 상세 조회
     * @param context QnA 조회 컨텍스트 정보
     * @return QnA 상세 정보
     */
    public QnaResponseDto getQnaById(QnaRetrievalContext context) {
        log.info("QnA 상세 조회 시작 - qnaNumber: {}, userId: {}", context.getQnaNumber(), context.getUserId());
        
        // 파라미터 검증
        validateQnaRetrievalContext(context);
        
        try {
            QnaResponseDto result = qnaServiceClient.getQnaById(
                    context.getUserId(), 
                    context.getCorporationCode(), 
                    context.getQnaNumber(), 
                    context.getChannelCode(), 
                    context.getServiceCategoryCode()
            );
            log.info("QnA 상세 조회 완료 - qnaNumber: {}, userId: {}", context.getQnaNumber(), context.getUserId());
            return result;
        } catch (Exception e) {
            log.error("QnA 상세 조회 실패 - qnaNumber: {}, userId: {}, error: {}", 
                     context.getQnaNumber(), context.getUserId(), e.getMessage(), e);
            throw new BusinessException("qna.retrieval.failed", e);
        }
    }

    /**
     * QnA 답변 수정
     * @param qnaNumber QnA 번호
     * @param qnaAnswerDetailNumber QnA 답변 상세 번호
     * @param dto QnA 답변 수정 정보
     * @return 수정된 QnA 답변 정보
     */
    public QnaAnswerDetailDto updateQnaAnswer(Long qnaNumber, Long qnaAnswerDetailNumber, QnaAnswerDetailDto dto) {
        log.info("QnA 답변 수정 시작 - qnaNumber: {}, answerNumber: {}", qnaNumber, qnaAnswerDetailNumber);
        
        // 파라미터 검증
        validateQnaNumber(qnaNumber);
        validateQnaAnswerDetailNumber(qnaAnswerDetailNumber);
        validateQnaAnswerDetailDto(dto);
        validateQnaAnswerUpdateRequest(dto);
        
        try {
            QnaAnswerDetailDto result = qnaServiceClient.updateQnaAnswer(qnaNumber, qnaAnswerDetailNumber, dto);
            log.info("QnA 답변 수정 완료 - qnaNumber: {}, answerNumber: {}", qnaNumber, qnaAnswerDetailNumber);
            return result;
        } catch (Exception e) {
            log.error("QnA 답변 수정 실패 - qnaNumber: {}, answerNumber: {}, error: {}", 
                     qnaNumber, qnaAnswerDetailNumber, e.getMessage(), e);
            throw new BusinessException("qna.answer.update.failed", e);
        }
    }

    /**
     * QnA 수정
     * @param context QnA 수정 컨텍스트 정보
     * @return 수정된 QnA 정보
     */
    public QnaResponseDto updateQna(QnaUpdateContext context) {
        log.info("QnA 수정 시작 - qnaNumber: {}, userId: {}", context.getQnaNumber(), context.getUserId());
        
        // 파라미터 검증
        validateQnaUpdateContext(context);
        
        try {
            QnaResponseDto result = qnaServiceClient.updateQna(
                    context.getQnaNumber(), 
                    context.getRequestDto(), 
                    context.getUserId(), 
                    context.getCorporationCode()
            );
            log.info("QnA 수정 완료 - qnaNumber: {}, userId: {}", context.getQnaNumber(), context.getUserId());
            return result;
        } catch (Exception e) {
            log.error("QnA 수정 실패 - qnaNumber: {}, userId: {}, error: {}", 
                     context.getQnaNumber(), context.getUserId(), e.getMessage(), e);
            throw new BusinessException("qna.update.failed", e);
        }
    }

    // 검증 메서드들
    private void validateQnaNumber(Long qnaNumber) {
        if (Objects.isNull(qnaNumber) || qnaNumber <= 0) {
            throw new BusinessException("qna.invalid.qnaNumber");
        }
    }

    private void validateQnaAnswerDetailNumber(Long qnaAnswerDetailNumber) {
        if (Objects.isNull(qnaAnswerDetailNumber) || qnaAnswerDetailNumber <= 0) {
            throw new BusinessException("qna.invalid.answerDetailNumber");
        }
    }

    private void validateQnaAnswerDetailDto(QnaAnswerDetailDto dto) {
        if (Objects.isNull(dto)) {
            throw new BusinessException("qna.invalid.answerDetail");
        }
    }

    private void validateQnaRequestDto(QnaRequestDto dto) {
        if (Objects.isNull(dto)) {
            throw new BusinessException("qna.invalid.request");
        }
    }

    private void validateProcessStatus(String processStatus) {
        if (!StringUtils.hasText(processStatus)) {
            throw new BusinessException("qna.invalid.processStatus");
        }
    }

    private void validateQnaAnswerCreateRequest(QnaAnswerDetailDto dto) {
        if (Objects.isNull(dto.getQnaNumber()) || dto.getQnaNumber() <= 0) {
            throw new BusinessException("qna.invalid.answer.qnaNumber");
        }
        if (!StringUtils.hasText(dto.getQnaAnswerDetailContent())) {
            throw new BusinessException("qna.invalid.answer.content");
        }
    }

    private void validateQnaAnswerUpdateRequest(QnaAnswerDetailDto dto) {
        if (!StringUtils.hasText(dto.getQnaAnswerDetailContent())) {
            throw new BusinessException("qna.invalid.answer.content");
        }
    }

    private void validateQnaRetrievalContext(QnaRetrievalContext context) {
        if (Objects.isNull(context)) {
            throw new BusinessException("qna.invalid.retrievalContext");
        }
        validateQnaNumber(context.getQnaNumber());
        if (!StringUtils.hasText(context.getUserId())) {
            throw new BusinessException("qna.invalid.userId");
        }
        if (!StringUtils.hasText(context.getCorporationCode())) {
            throw new BusinessException("qna.invalid.corporationCode");
        }
    }

    private void validateQnaUpdateContext(QnaUpdateContext context) {
        if (Objects.isNull(context)) {
            throw new BusinessException("qna.invalid.updateContext");
        }
        validateQnaNumber(context.getQnaNumber());
        if (Objects.isNull(context.getRequestDto())) {
            throw new BusinessException("qna.invalid.requestDto");
        }
        if (!StringUtils.hasText(context.getUserId())) {
            throw new BusinessException("qna.invalid.userId");
        }
        if (!StringUtils.hasText(context.getCorporationCode())) {
            throw new BusinessException("qna.invalid.corporationCode");
        }
    }

    // 컨텍스트 클래스들
    public static class QnaRetrievalContext {
        private Long qnaNumber;
        private String channelCode;
        private String serviceCategoryCode;
        private String userId;
        private String corporationCode;

        // constructors, getters, setters
        public QnaRetrievalContext(Long qnaNumber, String channelCode, String serviceCategoryCode, 
                                  String userId, String corporationCode) {
            this.qnaNumber = qnaNumber;
            this.channelCode = channelCode;
            this.serviceCategoryCode = serviceCategoryCode;
            this.userId = userId;
            this.corporationCode = corporationCode;
        }

        // getters
        public Long getQnaNumber() { return qnaNumber; }
        public String getChannelCode() { return channelCode; }
        public String getServiceCategoryCode() { return serviceCategoryCode; }
        public String getUserId() { return userId; }
        public String getCorporationCode() { return corporationCode; }
    }

    public static class QnaUpdateContext {
        private Long qnaNumber;
        private QnaDto requestDto;
        private String userId;
        private String corporationCode;

        // constructors, getters, setters
        public QnaUpdateContext(Long qnaNumber, QnaDto requestDto, String userId, String corporationCode) {
            this.qnaNumber = qnaNumber;
            this.requestDto = requestDto;
            this.userId = userId;
            this.corporationCode = corporationCode;
        }

        // getters
        public Long getQnaNumber() { return qnaNumber; }
        public QnaDto getRequestDto() { return requestDto; }
        public String getUserId() { return userId; }
        public String getCorporationCode() { return corporationCode; }
    }
}
```

## 3. 다른 접근법

### 3.1 Builder 패턴을 이용한 파라미터 그룹화
```java
@Service
@RequiredArgsConstructor
public class QnaService {
    
    public QnaResponseDto getQnaById(QnaSearchCriteria criteria) {
        return qnaServiceClient.getQnaById(
            criteria.getUserId(),
            criteria.getCorporationCode(),
            criteria.getQnaNumber(),
            criteria.getChannelCode(),
            criteria.getServiceCategoryCode()
        );
    }
    
    public static class QnaSearchCriteria {
        public static QnaSearchCriteriaBuilder builder() {
            return new QnaSearchCriteriaBuilder();
        }
        
        public static class QnaSearchCriteriaBuilder {
            private Long qnaNumber;
            private String channelCode;
            private String serviceCategoryCode;
            private String userId;
            private String corporationCode;
            
            public QnaSearchCriteriaBuilder qnaNumber(Long qnaNumber) {
                this.qnaNumber = qnaNumber;
                return this;
            }
            
            public QnaSearchCriteriaBuilder userId(String userId) {
                this.userId = userId;
                return this;
            }
            
            // ... 다른 필드들
            
            public QnaSearchCriteria build() {
                return new QnaSearchCriteria(qnaNumber, channelCode, serviceCategoryCode, userId, corporationCode);
            }
        }
    }
}
```

### 3.2 Validation 그룹을 이용한 검증
```java
public interface QnaCreateValidation {}
public interface QnaUpdateValidation {}

@Service
@RequiredArgsConstructor
public class QnaService {
    
    private final Validator validator;
    
    public QnaAnswerDetailDto createQnaAnswer(@Valid @ValidationGroup(QnaCreateValidation.class) QnaAnswerDetailDto dto) {
        validateDto(dto, QnaCreateValidation.class);
        return qnaServiceClient.createQnaAnswer(dto);
    }
    
    private <T> void validateDto(T dto, Class<?> validationGroup) {
        Set<ConstraintViolation<T>> violations = validator.validate(dto, validationGroup);
        if (!violations.isEmpty()) {
            throw new BusinessException("validation.failed", violations);
        }
    }
}
```

### 3.3 Command Pattern 적용
```java
public interface QnaCommand<T> {
    T execute();
}

@Service
@RequiredArgsConstructor
public class QnaService {
    
    private final QnaServiceClient qnaServiceClient;
    
    public <T> T executeCommand(QnaCommand<T> command) {
        try {
            log.info("QnA 명령 실행 시작 - command: {}", command.getClass().getSimpleName());
            T result = command.execute();
            log.info("QnA 명령 실행 완료 - command: {}", command.getClass().getSimpleName());
            return result;
        } catch (Exception e) {
            log.error("QnA 명령 실행 실패 - command: {}, error: {}", 
                     command.getClass().getSimpleName(), e.getMessage(), e);
            throw new BusinessException("qna.command.execution.failed", e);
        }
    }
    
    public class CreateQnaAnswerCommand implements QnaCommand<QnaAnswerDetailDto> {
        private final QnaAnswerDetailDto dto;
        
        public CreateQnaAnswerCommand(QnaAnswerDetailDto dto) {
            this.dto = dto;
        }
        
        @Override
        public QnaAnswerDetailDto execute() {
            return qnaServiceClient.createQnaAnswer(dto);
        }
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **배치 처리**: 여러 QnA 답변을 한 번에 처리하는 배치 메서드 추가
- **캐싱 전략**: 자주 조회되는 QnA에 대한 캐싱 적용
- **페이징 최적화**: 대용량 QnA 목록 조회 시 성능 최적화

### 4.2 보안 측면  
- **권한 검증**: 사용자가 해당 QnA에 대한 접근/수정 권한이 있는지 확인
- **데이터 마스킹**: 민감한 정보가 포함된 경우 로그에서 마스킹
- **입력 검증**: XSS, SQL Injection 방지를 위한 입력값 검증

### 4.3 사용성 측면
- **상태 관리**: QnA 상태(미답변, 답변완료, 해결완료 등) 자동 업데이트
- **알림 기능**: 답변 생성/수정 시 질문자에게 알림 발송
- **템플릿 기능**: 자주 사용되는 답변 템플릿 관리

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 예외 처리 추가 | 높음 | 2시간 | 서비스 안정성 핵심 |
| 파라미터 검증 | 높음 | 2시간 | NPE 방지 필수 |
| 파라미터 순서 일관성 | 높음 | 1시간 | 버그 위험 제거 |
| 복잡한 파라미터 목록 개선 | 중간 | 3시간 | 가독성 향상 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| 컨텍스트 클래스 작성 | 중간 | 2시간 | 코드 구조 개선 |

**총 예상 소요 시간**: 11시간
# VocChargePerson.java 엔티티 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 컬럼 길이와 검증 불일치
**문제점**: @Size 검증과 @Column의 length 속성이 일치하지 않아 데이터 정합성 문제 발생 가능
**라인**: 56번 라인
```java
@Size(max = 30)
@Column(name = "VOC_CHPR_DEPT_NM", length = 500, nullable = false)
private String vocChargePersonDepartmentName;
// @Size는 30자 제한, DB 컬럼은 500자 허용으로 불일치
```

#### Y/N 플래그의 String 처리
**문제점**: Boolean으로 처리해야 할 Y/N 값을 String으로 처리하여 타입 안전성 부족
**라인**: 67, 72번 라인
```java
@Column(name = "VOC_DSNT_CHPR_YN", length = 1)
private String vocDesignationThePersonInChargeYn; // Boolean이 적절

@Column(name = "DEL_YN", length = 1)
private String deleteYn; // Boolean이 적절
```

#### 선택적 @Setter 사용으로 인한 일관성 부족
**문제점**: 일부 필드만 @Setter를 적용하여 객체 상태 변경 규칙이 불명확
**라인**: 31, 36, 42, 48, 53, 59, 64, 69번 라인
```java
@Setter // 일부 필드만 setter 허용
private String itemCode;

// vocCategoryCode는 setter 없음 (불변?)
private String vocCategoryCode;
```

### 1.2 심각도 중간 (High) - 🟡

#### 연관관계 설정 부재
**문제점**: VocCategory와의 연관관계가 설정되지 않아 객체지향적 접근 제한
**라인**: 28-29번 라인
```java
@Column(name = "VOC_CTG_CD", length = 12, nullable = false)
private String vocCategoryCode; // VocCategory와의 @ManyToOne 관계 설정 필요
```

#### 과도하게 긴 필드명
**문제점**: 필드명이 너무 길어 가독성과 유지보수성 저하
**라인**: 40, 46, 51, 57, 62, 67번 라인
```java
private String vocChargePersonCorporationCode; // 너무 긴 필드명
private String vocChargePersonDepartmentCode; // 너무 긴 필드명
private String vocChargePersonEmployeeNumber; // 너무 긴 필드명
private String vocDesignationThePersonInChargeYn; // 너무 긴 필드명
```

#### 미사용 Import
**문제점**: Swagger 어노테이션을 import했지만 사용하지 않음
**라인**: 4번 라인
```java
import io.swagger.v3.oas.annotations.media.Schema; // 사용되지 않는 import
```

#### 비즈니스 로직 부재
**문제점**: 담당자 관련 비즈니스 로직이 전혀 없음
**라인**: 전체 엔티티
```java
public class VocChargePerson extends BaseEntity {
    // 담당자 지정/해제, 활성화/비활성화, 권한 검증 등의 로직 없음
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 컬럼명과 필드명 패턴 불일치
**문제점**: 일부 필드의 컬럼명 패턴이 다른 필드들과 일관성 부족
**라인**: 61번 라인
```java
@Column(name = "VOC_CHPR_EMP_NM", length = 100)
private String vocChargePersonEmployeeName;
// 컬럼명 길이는 100이지만 다른 NAME 필드들과 패턴이 다름
```

#### 기본값 설정 부재
**문제점**: 삭제 여부나 담당자 지정 여부 등의 기본값 설정이 없음
**라인**: 67, 72번 라인
```java
private String vocDesignationThePersonInChargeYn; // 기본값 설정 없음
private String deleteYn; // 기본값 설정 없음
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.entity;

import com.osstem.ow.model.BaseEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TB_VOC_CHPR_M", indexes = {
    @Index(name = "idx_voc_charge_person_category", columnList = "VOC_CTG_CD"),
    @Index(name = "idx_voc_charge_person_dept", columnList = "CHPR_DEPT_CD"),
    @Index(name = "idx_voc_charge_person_employee", columnList = "CHPR_EMP_NO"),
    @Index(name = "idx_voc_charge_person_active", columnList = "DEL_YN, DSNT_CHPR_YN")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(callSuper = false)
public class VocChargePerson extends BaseEntity {

    // 상수 정의
    public static final String DESIGNATED_YES = "Y";
    public static final String DESIGNATED_NO = "N";
    public static final String DELETED_YES = "Y";
    public static final String DELETED_NO = "N";

    @Id
    @Column(name = "VOC_CHPR_NO", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long chargePersonNumber;

    // VocCategory와의 연관관계 설정
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VOC_CTG_CD", nullable = false)
    @NotNull(message = "VOC 카테고리는 필수입니다")
    private VocCategory vocCategory;

    @Column(name = "ITM_CD", length = 90)
    @Size(max = 90, message = "아이템 코드는 90자를 초과할 수 없습니다")
    private String itemCode;

    // 담당자 정보 - Value Object로 분리 고려
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "corporationCode", column = @Column(name = "CHPR_CPRN_CD", length = 3, nullable = false)),
        @AttributeOverride(name = "departmentCode", column = @Column(name = "CHPR_DEPT_CD", length = 30, nullable = false)),
        @AttributeOverride(name = "departmentName", column = @Column(name = "CHPR_DEPT_NM", length = 500, nullable = false)),
        @AttributeOverride(name = "employeeNumber", column = @Column(name = "CHPR_EMP_NO", length = 60)),
        @AttributeOverride(name = "employeeName", column = @Column(name = "CHPR_EMP_NM", length = 100))
    })
    @NotNull(message = "담당자 정보는 필수입니다")
    private ChargePersonInfo chargePersonInfo;

    // Boolean 필드로 개선
    @Column(name = "DSNT_CHPR_YN", length = 1, nullable = false)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean designated = false;

    @Column(name = "DEL_YN", length = 1, nullable = false)
    @Convert(converter = YesNoToBooleanConverter.class)
    @Builder.Default
    private Boolean deleted = false;

    // 추가 필드들
    @Column(name = "CHPR_EMAIL", length = 100)
    @Email(message = "올바른 이메일 형식이어야 합니다")
    @Size(max = 100, message = "이메일은 100자를 초과할 수 없습니다")
    private String email;

    @Column(name = "CHPR_PHONE", length = 20)
    @Pattern(regexp = "^\\d{2,3}-\\d{3,4}-\\d{4}$", message = "올바른 전화번호 형식이어야 합니다")
    private String phoneNumber;

    @Column(name = "CHPR_MOBILE", length = 20)
    @Pattern(regexp = "^01[016789]-\\d{3,4}-\\d{4}$", message = "올바른 휴대폰번호 형식이어야 합니다")
    private String mobileNumber;

    @Column(name = "CHPR_START_DT")
    private LocalDateTime chargeStartDateTime;

    @Column(name = "CHPR_END_DT")
    private LocalDateTime chargeEndDateTime;

    @Column(name = "CHPR_DESC", length = 500)
    @Size(max = 500, message = "담당자 설명은 500자를 초과할 수 없습니다")
    private String description;

    // 양방향 연관관계
    @OneToMany(mappedBy = "vocChargePerson", fetch = FetchType.LAZY)
    private List<Voc> assignedVocs;

    /**
     * 담당자를 지정합니다.
     *
     * @param processorId 처리자 ID
     */
    public void designate(String processorId) {
        validateProcessorId(processorId);
        
        if (Boolean.TRUE.equals(this.deleted)) {
            throw new IllegalStateException("삭제된 담당자는 지정할 수 없습니다");
        }
        
        this.designated = true;
        this.chargeStartDateTime = LocalDateTime.now();
        updateModificationInfo(processorId);
    }

    /**
     * 담당자 지정을 해제합니다.
     *
     * @param processorId 처리자 ID
     */
    public void undesignate(String processorId) {
        validateProcessorId(processorId);
        
        // 할당된 VOC가 있는 경우 지정 해제 불가
        if (hasActiveAssignedVocs()) {
            throw new IllegalStateException("할당된 VOC가 있어 담당자 지정을 해제할 수 없습니다");
        }
        
        this.designated = false;
        this.chargeEndDateTime = LocalDateTime.now();
        updateModificationInfo(processorId);
    }

    /**
     * 담당자를 논리적으로 삭제합니다.
     *
     * @param processorId 처리자 ID
     */
    public void markAsDeleted(String processorId) {
        validateProcessorId(processorId);
        
        // 할당된 VOC가 있는 경우 삭제 불가
        if (hasActiveAssignedVocs()) {
            throw new IllegalStateException("할당된 VOC가 있어 담당자를 삭제할 수 없습니다");
        }
        
        this.deleted = true;
        this.designated = false; // 삭제 시 자동으로 지정 해제
        this.chargeEndDateTime = LocalDateTime.now();
        updateModificationInfo(processorId);
    }

    /**
     * 담당자 정보를 수정합니다.
     *
     * @param newChargePersonInfo 새로운 담당자 정보
     * @param processorId 처리자 ID
     */
    public void updateChargePersonInfo(ChargePersonInfo newChargePersonInfo, String processorId) {
        validateChargePersonInfo(newChargePersonInfo);
        validateProcessorId(processorId);
        
        this.chargePersonInfo = newChargePersonInfo;
        updateModificationInfo(processorId);
    }

    /**
     * 연락처 정보를 수정합니다.
     *
     * @param email 이메일
     * @param phoneNumber 전화번호
     * @param mobileNumber 휴대폰번호
     * @param processorId 처리자 ID
     */
    public void updateContactInfo(String email, String phoneNumber, String mobileNumber, String processorId) {
        validateProcessorId(processorId);
        
        if (email != null) {
            validateEmail(email);
            this.email = email;
        }
        
        if (phoneNumber != null) {
            validatePhoneNumber(phoneNumber);
            this.phoneNumber = phoneNumber;
        }
        
        if (mobileNumber != null) {
            validateMobileNumber(mobileNumber);
            this.mobileNumber = mobileNumber;
        }
        
        updateModificationInfo(processorId);
    }

    /**
     * 아이템 코드를 설정합니다.
     *
     * @param itemCode 아이템 코드
     * @param processorId 처리자 ID
     */
    public void setItemCode(String itemCode, String processorId) {
        validateProcessorId(processorId);
        
        if (itemCode != null && itemCode.length() > 90) {
            throw new IllegalArgumentException("아이템 코드는 90자를 초과할 수 없습니다");
        }
        
        this.itemCode = itemCode;
        updateModificationInfo(processorId);
    }

    /**
     * 담당자가 지정되었는지 확인합니다.
     *
     * @return 지정 여부
     */
    public boolean isDesignated() {
        return Boolean.TRUE.equals(this.designated) && Boolean.FALSE.equals(this.deleted);
    }

    /**
     * 담당자가 활성 상태인지 확인합니다.
     *
     * @return 활성 여부
     */
    public boolean isActive() {
        return Boolean.FALSE.equals(this.deleted);
    }

    /**
     * 담당자가 삭제된 상태인지 확인합니다.
     *
     * @return 삭제 여부
     */
    public boolean isDeleted() {
        return Boolean.TRUE.equals(this.deleted);
    }

    /**
     * 특정 카테고리의 담당자인지 확인합니다.
     *
     * @param categoryCode 카테고리 코드
     * @return 해당 카테고리 담당자 여부
     */
    public boolean isChargePersonForCategory(String categoryCode) {
        return this.vocCategory != null && 
               this.vocCategory.getVocCategoryCode().equals(categoryCode) && 
               isDesignated();
    }

    /**
     * 담당 기간이 유효한지 확인합니다.
     *
     * @return 유효 여부
     */
    public boolean isChargePeritumvalid() {
        LocalDateTime now = LocalDateTime.now();
        
        if (this.chargeStartDateTime != null && this.chargeStartDateTime.isAfter(now)) {
            return false; // 아직 담당 시작 전
        }
        
        if (this.chargeEndDateTime != null && this.chargeEndDateTime.isBefore(now)) {
            return false; // 이미 담당 종료
        }
        
        return isDesignated();
    }

    /**
     * 담당자에게 VOC를 할당할 수 있는지 확인합니다.
     *
     * @return 할당 가능 여부
     */
    public boolean canAssignVoc() {
        return isDesignated() && isChargePeritumvalid();
    }

    /**
     * 할당된 활성 VOC가 있는지 확인합니다.
     *
     * @return 활성 VOC 존재 여부
     */
    public boolean hasActiveAssignedVocs() {
        return assignedVocs != null && 
               assignedVocs.stream().anyMatch(voc -> !voc.isDeleted() && !voc.isCompleted());
    }

    /**
     * 담당자 정보 요약을 생성합니다.
     *
     * @return 담당자 정보 요약
     */
    public String generateSummary() {
        StringBuilder summary = new StringBuilder();
        
        if (chargePersonInfo != null) {
            summary.append(chargePersonInfo.getEmployeeName())
                   .append(" (").append(chargePersonInfo.getDepartmentName()).append(")");
        }
        
        if (vocCategory != null) {
            summary.append(" - ").append(vocCategory.getVocCategoryName());
        }
        
        if (isDesignated()) {
            summary.append(" [지정됨]");
        }
        
        return summary.toString();
    }

    @PrePersist
    protected void onCreate() {
        if (this.designated == null) {
            this.designated = false;
        }
        if (this.deleted == null) {
            this.deleted = false;
        }
    }

    // private 검증 메서드들
    private void validateProcessorId(String processorId) {
        if (processorId == null || processorId.trim().isEmpty()) {
            throw new IllegalArgumentException("처리자 ID는 필수입니다");
        }
    }

    private void validateChargePersonInfo(ChargePersonInfo chargePersonInfo) {
        if (chargePersonInfo == null) {
            throw new IllegalArgumentException("담당자 정보는 필수입니다");
        }
    }

    private void validateEmail(String email) {
        if (email.length() > 100) {
            throw new IllegalArgumentException("이메일은 100자를 초과할 수 없습니다");
        }
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new IllegalArgumentException("올바른 이메일 형식이어야 합니다");
        }
    }

    private void validatePhoneNumber(String phoneNumber) {
        if (!phoneNumber.matches("^\\d{2,3}-\\d{3,4}-\\d{4}$")) {
            throw new IllegalArgumentException("올바른 전화번호 형식이어야 합니다");
        }
    }

    private void validateMobileNumber(String mobileNumber) {
        if (!mobileNumber.matches("^01[016789]-\\d{3,4}-\\d{4}$")) {
            throw new IllegalArgumentException("올바른 휴대폰번호 형식이어야 합니다");
        }
    }

    private void updateModificationInfo(String processorId) {
        this.setModProcDtm(LocalDateTime.now());
        this.setModProcrId(processorId);
    }
}

// Value Object 클래스
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChargePersonInfo {
    
    @Size(max = 3, message = "회사 코드는 3자를 초과할 수 없습니다")
    @NotBlank(message = "회사 코드는 필수입니다")
    private String corporationCode;
    
    @Size(max = 30, message = "부서 코드는 30자를 초과할 수 없습니다") 
    @NotBlank(message = "부서 코드는 필수입니다")
    private String departmentCode;
    
    @Size(max = 500, message = "부서명은 500자를 초과할 수 없습니다")
    @NotBlank(message = "부서명은 필수입니다")
    private String departmentName;
    
    @Size(max = 60, message = "직원 번호는 60자를 초과할 수 없습니다")
    private String employeeNumber;
    
    @Size(max = 100, message = "직원명은 100자를 초과할 수 없습니다")
    private String employeeName;
    
    /**
     * 담당자 정보가 완전한지 확인합니다.
     *
     * @return 완전성 여부
     */
    public boolean isComplete() {
        return corporationCode != null && !corporationCode.trim().isEmpty() &&
               departmentCode != null && !departmentCode.trim().isEmpty() &&
               departmentName != null && !departmentName.trim().isEmpty();
    }
    
    /**
     * 표시용 이름을 생성합니다.
     *
     * @return 표시용 이름
     */
    public String getDisplayName() {
        if (employeeName != null && !employeeName.trim().isEmpty()) {
            return employeeName;
        }
        return employeeNumber != null ? employeeNumber : "Unknown";
    }
}
```

## 3. 다른 접근법

### 3.1 담당자 역할 기반 설계
```java
@Entity
@Table(name = "TB_VOC_CHPR_ROLE")
public class VocChargePersonRole {
    @Id
    @GeneratedValue
    private Long roleId;
    
    @ManyToOne
    @JoinColumn(name = "VOC_CHPR_NO")
    private VocChargePerson chargePerson;
    
    @Enumerated(EnumType.STRING)
    private ChargePersonRoleType roleType;
    
    @Column(name = "ROLE_START_DT")
    private LocalDateTime roleStartDateTime;
    
    @Column(name = "ROLE_END_DT")
    private LocalDateTime roleEndDateTime;
}

public enum ChargePersonRoleType {
    PRIMARY("주담당자"),
    SECONDARY("보조담당자"),
    BACKUP("대체담당자"),
    SUPERVISOR("감독자");
    
    private final String description;
    
    ChargePersonRoleType(String description) {
        this.description = description;
    }
}

@Entity
public class VocChargePerson extends BaseEntity {
    
    @OneToMany(mappedBy = "chargePerson", cascade = CascadeType.ALL)
    private List<VocChargePersonRole> roles = new ArrayList<>();
    
    /**
     * 특정 역할을 가지고 있는지 확인
     */
    public boolean hasRole(ChargePersonRoleType roleType) {
        return roles.stream()
                .anyMatch(role -> role.getRoleType() == roleType && 
                         role.isActiveAt(LocalDateTime.now()));
    }
}
```

### 3.2 담당자 그룹 관리
```java
@Entity
@Table(name = "TB_VOC_CHPR_GROUP")
public class VocChargePersonGroup {
    @Id
    @GeneratedValue
    private Long groupId;
    
    @Column(name = "GROUP_NM")
    private String groupName;
    
    @Column(name = "GROUP_DESC")
    private String groupDescription;
    
    @OneToMany(mappedBy = "chargePersonGroup")
    private List<VocChargePerson> members = new ArrayList<>();
    
    /**
     * 그룹 내에서 가용한 담당자 조회
     */
    public List<VocChargePerson> getAvailableChargePersons() {
        return members.stream()
                .filter(VocChargePerson::isDesignated)
                .filter(cp -> !cp.isOverloaded())
                .collect(Collectors.toList());
    }
}

@Entity
public class VocChargePerson extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CHPR_GROUP_ID")
    private VocChargePersonGroup chargePersonGroup;
    
    @Column(name = "MAX_VOC_COUNT")
    private Integer maxVocCount = 10; // 최대 담당 가능한 VOC 수
    
    /**
     * 담당자가 과부하 상태인지 확인
     */
    public boolean isOverloaded() {
        long currentVocCount = assignedVocs.stream()
                .filter(voc -> !voc.isCompleted() && !voc.isDeleted())
                .count();
        return currentVocCount >= maxVocCount;
    }
}
```

### 3.3 담당자 자동 할당 전략
```java
public interface ChargePersonAssignmentStrategy {
    VocChargePerson assignChargePerson(Voc voc, List<VocChargePerson> candidates);
}

@Component
public class RoundRobinAssignmentStrategy implements ChargePersonAssignmentStrategy {
    @Override
    public VocChargePerson assignChargePerson(Voc voc, List<VocChargePerson> candidates) {
        // 라운드 로빈 방식으로 담당자 할당
        return candidates.get(voc.getVocNumber().intValue() % candidates.size());
    }
}

@Component
public class WorkloadBasedAssignmentStrategy implements ChargePersonAssignmentStrategy {
    @Override
    public VocChargePerson assignChargePerson(Voc voc, List<VocChargePerson> candidates) {
        // 업무량 기준으로 가장 적게 할당된 담당자 선택
        return candidates.stream()
                .min(Comparator.comparing(cp -> cp.getAssignedVocs().size()))
                .orElse(null);
    }
}

@Service
public class VocAssignmentService {
    
    @Autowired
    private Map<String, ChargePersonAssignmentStrategy> strategies;
    
    public VocChargePerson autoAssignChargePerson(Voc voc, String strategyName) {
        ChargePersonAssignmentStrategy strategy = strategies.get(strategyName);
        List<VocChargePerson> candidates = getAvailableChargePersons(voc.getVocCategoryCode());
        return strategy.assignChargePerson(voc, candidates);
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **지연 로딩**: 연관관계에서 적절한 FetchType.LAZY 사용
- **인덱싱**: 카테고리별, 부서별 조회를 위한 복합 인덱스 설정
- **캐싱**: 자주 조회되는 담당자 정보에 대한 캐싱 적용

### 4.2 데이터 일관성 측면
- **참조 무결성**: VocCategory와의 외래키 제약조건 설정
- **동시성 제어**: 담당자 지정/해제 시 동시성 문제 방지
- **트랜잭션**: 담당자 변경과 관련 VOC 업데이트의 일관성 보장

### 4.3 비즈니스 로직 측면
- **권한 관리**: 담당자별 처리 가능한 VOC 유형 제한
- **알림 기능**: 담당자 변경 시 관련자들에게 알림 발송
- **워크로드 관리**: 담당자별 업무량 분산 및 모니터링

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 컬럼 길이와 검증 일치 | 높음 | 30분 | 데이터 정합성 핵심 |
| Y/N Boolean 변환 | 높음 | 1시간 | 타입 안전성 핵심 |
| 선택적 Setter 일관성 개선 | 높음 | 2시간 | 객체 상태 관리 개선 |
| 연관관계 설정 | 중간 | 2시간 | 객체지향 설계 개선 |
| 필드명 개선 | 중간 | 2시간 | 가독성 향상 |
| 비즈니스 로직 추가 | 중간 | 4시간 | 도메인 로직 강화 |
| Value Object 분리 | 낮음 | 3시간 | 코드 구조 개선 |
| 미사용 Import 제거 | 낮음 | 5분 | 코드 정리 |

**총 예상 소요 시간**: 14시간 35분
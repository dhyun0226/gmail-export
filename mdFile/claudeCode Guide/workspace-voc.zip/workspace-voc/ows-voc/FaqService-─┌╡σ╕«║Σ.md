# FaqService.java 코드 리뷰

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### 예외 처리 부재
**문제점**: Feign Client 호출 실패 시 예외 처리가 없어 장애 전파 가능
**라인**: 전체 메서드 (19-41번 라인)
```java
public ResultDto<FaqResponseDto> getAllFaqs(FaqRequestDto dto) {
    return faqServiceClient.getAllFaqs(dto); // 예외 처리 없음
}
```

#### 파라미터 검증 부재  
**문제점**: null 파라미터에 대한 검증이 없어 NPE 발생 가능
**라인**: 19, 23, 27, 31, 39번 라인
```java
public FaqResponseDto create(FaqRequestDto dto) {
    // dto null 검증 없음
    return faqServiceClient.createFaq(dto);
}

public void delete(Long id) {
    // id null 검증 없음
    faqServiceClient.deleteFaq(id);
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 로깅 부재
**문제점**: 비즈니스 로직 추적과 디버깅이 어려움
**라인**: 전체 클래스
```java
@Service
@RequiredArgsConstructor
public class FaqService {
    // @Slf4j 애노테이션 없음
    // 로깅 구문 없음
}
```

#### 사용자 컨텍스트 추적 부재
**문제점**: 누가 어떤 작업을 수행했는지 추적 불가
**라인**: 전체 메서드
```java
public FaqResponseDto create(FaqRequestDto dto) {
    // 사용자 정보 로깅 없음
    return faqServiceClient.createFaq(dto);
}
```

#### 주석 처리된 코드
**문제점**: 사용하지 않는 코드가 남아있어 코드 가독성 저하
**라인**: 35-37번 라인
```java
//    public ResultDto<FaqResponseDto> search(FaqRequestDto dto) {
//        return faqServiceClient.searchFaqs(dto);
//    }
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 트랜잭션 관리 부재
**문제점**: 외부 서비스 호출에 대한 트랜잭션 전략이 명확하지 않음
**라인**: 전체 메서드
```java
// @Transactional 애노테이션 없음
public void delete(Long id) {
    faqServiceClient.deleteFaq(id);
}
```

#### 미사용 Import
**문제점**: FaqResponseWrapper 클래스가 import되었지만 사용되지 않음
**라인**: 7번 라인
```java
import com.osstem.ow.voc.model.customer.FaqResponseWrapper; // 미사용
```

## 2. 개선 코드 예시

### 2.1 종합 개선 버전
```java
package com.osstem.ow.voc.domain;

import com.osstem.ow.voc.feign.FaqServiceClient;
import com.osstem.ow.voc.model.base.ResultDto;
import com.osstem.ow.voc.model.customer.FaqRequestDto;
import com.osstem.ow.voc.model.customer.FaqResponseDto;
import com.osstem.ow.voc.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class FaqService {

    private final FaqServiceClient faqServiceClient;

    /**
     * FAQ 목록 조회
     * @param dto 조회 조건
     * @return FAQ 목록
     */
    public ResultDto<FaqResponseDto> getAllFaqs(FaqRequestDto dto) {
        log.info("FAQ 목록 조회 시작 - dto: {}", dto);
        
        // 파라미터 검증
        validateFaqRequestDto(dto);
        
        try {
            ResultDto<FaqResponseDto> result = faqServiceClient.getAllFaqs(dto);
            log.info("FAQ 목록 조회 완료 - count: {}", result.getList().size());
            return result;
        } catch (Exception e) {
            log.error("FAQ 목록 조회 실패 - dto: {}, error: {}", dto, e.getMessage(), e);
            throw new BusinessException("faq.retrieval.failed", e);
        }
    }

    /**
     * FAQ 생성
     * @param dto FAQ 생성 요청 정보
     * @return 생성된 FAQ 정보
     */
    public FaqResponseDto create(FaqRequestDto dto) {
        log.info("FAQ 생성 시작 - title: {}", dto != null ? dto.getTitle() : "null");
        
        // 파라미터 검증
        validateFaqRequestDto(dto);
        validateFaqCreateRequest(dto);
        
        try {
            FaqResponseDto result = faqServiceClient.createFaq(dto);
            log.info("FAQ 생성 완료 - id: {}", result.getId());
            return result;
        } catch (Exception e) {
            log.error("FAQ 생성 실패 - dto: {}, error: {}", dto, e.getMessage(), e);
            throw new BusinessException("faq.creation.failed", e);
        }
    }

    /**
     * FAQ 수정
     * @param id FAQ ID
     * @param dto FAQ 수정 요청 정보
     * @return 수정된 FAQ 정보
     */
    public FaqResponseDto update(Long id, FaqRequestDto dto) {
        log.info("FAQ 수정 시작 - id: {}, title: {}", id, dto != null ? dto.getTitle() : "null");
        
        // 파라미터 검증
        validateFaqId(id);
        validateFaqRequestDto(dto);
        validateFaqUpdateRequest(dto);
        
        try {
            FaqResponseDto result = faqServiceClient.updateFaq(id, dto);
            log.info("FAQ 수정 완료 - id: {}", id);
            return result;
        } catch (Exception e) {
            log.error("FAQ 수정 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("faq.update.failed", e);
        }
    }

    /**
     * FAQ 삭제  
     * @param id FAQ ID
     */
    public void delete(Long id) {
        log.info("FAQ 삭제 시작 - id: {}", id);
        
        // 파라미터 검증
        validateFaqId(id);
        
        try {
            faqServiceClient.deleteFaq(id);
            log.info("FAQ 삭제 완료 - id: {}", id);
        } catch (Exception e) {
            log.error("FAQ 삭제 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("faq.deletion.failed", e);
        }
    }

    /**
     * FAQ 단건 조회
     * @param id FAQ ID
     * @return FAQ 정보
     */
    public FaqResponseDto getFaqById(Long id) {
        log.info("FAQ 단건 조회 시작 - id: {}", id);
        
        // 파라미터 검증
        validateFaqId(id);
        
        try {
            FaqResponseDto result = faqServiceClient.getFaqById(id);
            log.info("FAQ 단건 조회 완료 - id: {}", id);
            return result;
        } catch (Exception e) {
            log.error("FAQ 단건 조회 실패 - id: {}, error: {}", id, e.getMessage(), e);
            throw new BusinessException("faq.retrieval.failed", e);
        }
    }

    // 검증 메서드들
    private void validateFaqId(Long id) {
        if (Objects.isNull(id) || id <= 0) {
            throw new BusinessException("faq.invalid.id");
        }
    }

    private void validateFaqRequestDto(FaqRequestDto dto) {
        if (Objects.isNull(dto)) {
            throw new BusinessException("faq.invalid.request");
        }
    }

    private void validateFaqCreateRequest(FaqRequestDto dto) {
        if (Objects.isNull(dto.getTitle()) || dto.getTitle().trim().isEmpty()) {
            throw new BusinessException("faq.invalid.title");
        }
        if (Objects.isNull(dto.getContent()) || dto.getContent().trim().isEmpty()) {
            throw new BusinessException("faq.invalid.content");
        }
    }

    private void validateFaqUpdateRequest(FaqRequestDto dto) {
        // 수정 시에는 최소한 하나의 필드는 있어야 함
        if ((dto.getTitle() == null || dto.getTitle().trim().isEmpty()) &&
            (dto.getContent() == null || dto.getContent().trim().isEmpty())) {
            throw new BusinessException("faq.invalid.update.request");
        }
    }
}
```

## 3. 다른 접근법

### 3.1 캐싱 적용
```java
@Service
@RequiredArgsConstructor
@Slf4j
public class FaqService {
    
    private final FaqServiceClient faqServiceClient;
    
    @Cacheable(value = "faq", key = "#id")
    public FaqResponseDto getFaqById(Long id) {
        log.info("FAQ 조회 (캐시 미적중) - id: {}", id);
        return faqServiceClient.getFaqById(id);
    }
    
    @CacheEvict(value = "faq", key = "#id")
    public FaqResponseDto update(Long id, FaqRequestDto dto) {
        log.info("FAQ 수정 및 캐시 무효화 - id: {}", id);
        return faqServiceClient.updateFaq(id, dto);
    }
    
    @CacheEvict(value = "faq", key = "#id")
    public void delete(Long id) {
        log.info("FAQ 삭제 및 캐시 무효화 - id: {}", id);
        faqServiceClient.deleteFaq(id);
    }
}
```

### 3.2 Retry 패턴 적용
```java
@Service
@RequiredArgsConstructor
public class FaqService {
    
    private final FaqServiceClient faqServiceClient;
    
    @Retryable(value = {Exception.class}, maxAttempts = 3, backoff = @Backoff(delay = 1000))
    public ResultDto<FaqResponseDto> getAllFaqs(FaqRequestDto dto) {
        return faqServiceClient.getAllFaqs(dto);
    }
    
    @Recover
    public ResultDto<FaqResponseDto> recoverGetAllFaqs(Exception ex, FaqRequestDto dto) {
        log.error("FAQ 목록 조회 최종 실패 - dto: {}, error: {}", dto, ex.getMessage());
        return ResultDto.empty();
    }
}
```

### 3.3 이벤트 발행 패턴
```java
@Service
@RequiredArgsConstructor
public class FaqService {
    
    private final FaqServiceClient faqServiceClient;
    private final ApplicationEventPublisher eventPublisher;
    
    public FaqResponseDto create(FaqRequestDto dto) {
        FaqResponseDto result = faqServiceClient.createFaq(dto);
        
        // 이벤트 발행
        eventPublisher.publishEvent(new FaqCreatedEvent(result.getId(), result.getTitle()));
        
        return result;
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **캐싱 전략**: 자주 조회되는 FAQ에 대한 Redis 캐싱 적용
- **페이징 처리**: getAllFaqs 메서드에서 대용량 데이터 처리 최적화
- **Connection Pool**: Feign Client HTTP 연결 풀 설정

### 4.2 보안 측면  
- **권한 검증**: FAQ 생성/수정/삭제 시 사용자 권한 확인
- **XSS 방지**: FAQ 내용에 대한 HTML 태그 필터링
- **SQL Injection 방지**: 검색 조건에 대한 파라미터 검증 강화

### 4.3 사용성 측면
- **검색 기능**: 주석 처리된 search 메서드 구현 여부 결정
- **카테고리별 조회**: FAQ 카테고리별 조회 기능 고려
- **조회수 관리**: FAQ 조회수 증가 로직 추가

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|
| 예외 처리 추가 | 높음 | 2시간 | 서비스 안정성 핵심 |
| 파라미터 검증 | 높음 | 1.5시간 | NPE 방지 필수 |
| 로깅 추가 | 중간 | 1시간 | 운영 모니터링 필요 |
| 주석 코드 정리 | 낮음 | 10분 | 코드 정리 |
| 미사용 Import 제거 | 낮음 | 5분 | 코드 정리 |
| 캐싱 적용 | 중간 | 3시간 | 성능 개선 |

**총 예상 소요 시간**: 7시간 45분
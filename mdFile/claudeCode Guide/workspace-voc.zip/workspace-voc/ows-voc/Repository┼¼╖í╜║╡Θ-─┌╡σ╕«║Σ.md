# Repository 클래스들 코드 리뷰
## (VocRepository.java, VocQueryRepository.java, VocCategoryRepository.java, VocCategoryQueryRepository.java, VocAnswerDetailRepository.java, VocChangeHistoryRepository.java, VocChargePersonRepository.java, VocStatisticsQueryRepository.java)

## 1. 문제 식별

### 1.1 심각도 높음 (Critical) - 🔴

#### God Object 패턴 (거대한 클래스)
**문제점**: VocQueryRepository(643라인)와 VocStatisticsQueryRepository(553라인)가 과도하게 많은 책임을 담당
**파일**: VocQueryRepository.java / VocStatisticsQueryRepository.java
```java
// VocQueryRepository - 643라인, 20개 이상의 메서드
@Repository
@RequiredArgsConstructor
public class VocQueryRepository {
    // findByIdWithAnswer, findItemCodesWithCounts, findRegistererDeptCodes...
    // search, count, findDistinctItemCodes, findVocsByItemCodes...
    // 총 20개 이상의 복잡한 메서드들
}

// VocStatisticsQueryRepository - 553라인, 12개의 통계 메서드
@Repository  
@RequiredArgsConstructor
public class VocStatisticsQueryRepository {
    // getVocStatisticsByDayWithConditions, getVocStatisticsByWeekWithConditions...
    // 거의 동일한 구조의 메서드 12개가 반복됨
}
```

#### 중복된 코드 (Code Duplication)
**문제점**: 두 QueryRepository 클래스 간 동일한 private 메서드들이 중복으로 존재
**파일**: VocQueryRepository.java vs VocStatisticsQueryRepository.java
```java
// VocQueryRepository
private BooleanExpression vocCategoryCodeEquals(String code) {
    return code != null ? voc.vocCategoryCode.eq(code) : null;
}
private BooleanExpression itemCodeEquals(String itemCode) {
    if (itemCode == null || itemCode.isEmpty()) {
        return null;
    }
    return voc.itemCode.eq(itemCode);
}

// VocStatisticsQueryRepository - 완전히 동일한 메서드들
private BooleanExpression vocCategoryCodeEquals(String code) {
    return code != null ? voc.vocCategoryCode.eq(code) : null;
}
private BooleanExpression itemCodeEquals(String itemCode) {
    if (itemCode == null || itemCode.isEmpty()) {
        return null;
    }
    return voc.itemCode.eq(itemCode);
}
```

#### 하드코딩된 값들 (Magic Numbers/Strings)
**문제점**: 코드 전반에 하드코딩된 상수값들이 직접 사용됨
**파일**: 모든 QueryRepository 클래스들
```java
// 하드코딩된 문자열들
.where(voc.deleteYesOrNo.ne("Y"))
.where(vocChargePerson.deleteYn.ne("Y"))
.where(vocChargePerson.vocCategoryCode.like("%VOC%"))
info.setCorpCode(corpCode != null ? corpCode : "KR1");

// 하드코딩된 상태 코드
private static final String VOC_STATE_RECEIVED = "01"; // 하드코딩

// 하드코딩된 템플릿 문자열
Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime)
Expressions.stringTemplate("concat('d', weekday({0}))", voc.vocRegistrationDateTime)
```

#### 복잡한 비즈니스 로직이 Repository에 포함
**문제점**: 데이터 접근이 아닌 비즈니스 규칙이 Repository 레이어에 존재
**파일**: VocQueryRepository.java 591-608번 라인
```java
private BooleanExpression vocStateCodeEquals(String code, boolean isDay) {
    if (code == null) {
        return null;
    }
    
    // 복잡한 비즈니스 규칙이 Repository에 있음
    if (StatusType.PROCESSING.getStatusCode().equals(code)) {
        if (isDay) {
            return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), 
                                     StatusType.PROCESSING.getStatusCode(), 
                                     StatusType.COMPLETE.getStatusCode());
        }
        return voc.vocStateCode.in(StatusType.RECEIPT.getStatusCode(), 
                                 StatusType.PROCESSING.getStatusCode());
    }
    // 복잡한 상태 전환 로직이 계속됨...
}
```

### 1.2 심각도 중간 (High) - 🟡

#### 무한 루프 가능성 (Potential Infinite Loop)
**문제점**: 카테고리 계층 구조에서 순환 참조 시 무한 루프 발생 가능
**파일**: VocCategoryQueryRepository.java 48-62번 라인
```java
public VocCategory findRootCategory(String categoryCode) {
    // 최상위 카테고리를 찾을 때까지 반복
    VocCategory current = category;
    while (current.getUpVocCategoryCode() != null) {
        current = queryFactory
                .selectFrom(vocCategory)
                .where(vocCategory.vocCategoryCode.eq(current.getUpVocCategoryCode().getVocCategoryCode()))
                .fetchOne();
        
        if (current == null) {
            break; // null 체크만 있고 순환 참조 체크가 없음
        }
    }
    // A -> B -> A 같은 순환 참조 시 무한 루프 발생
}
```

#### 일관성 없는 Repository 패턴
**문제점**: 일부는 단순 JpaRepository, 일부는 복잡한 QueryRepository로 구성이 불일치
**파일**: 모든 Repository 클래스들
```java
// 단순한 Repository들
@Repository
public interface VocRepository extends JpaRepository<Voc, Long> {
    Voc findByDenallVocNumber(Long denallVocNumber); // 단순한 메서드 1개
}

@Repository
public interface VocAnswerDetailRepository extends JpaRepository<VocAnswerDetail, Long> {
    // 아무런 메서드 없음
}

// 복잡한 QueryRepository들
@Repository
public class VocQueryRepository {
    // 643라인의 복잡한 쿼리 로직들
}
```

#### 메서드명의 명확성 부족
**문제점**: 메서드명이 너무 길거나 의도가 명확하지 않음
**파일**: VocCategoryRepository.java / VocChargePersonRepository.java
```java
// 너무 긴 메서드명
List<VocCategory> findByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);
boolean existsByUpVocCategoryCode_VocCategoryCode(String parentCategoryCode);

// Y/N 필드명이 메서드에 그대로 노출
Optional<VocChargePerson> findByVocCategoryCodeAndVocDesignationThePersonInChargeYn(
    String vocCategoryCode, String vocDesignationThePersonInChargeYn);
```

#### 비효율적인 N+1 쿼리 패턴
**문제점**: 여러 메서드에서 개별 조회 후 반복문으로 처리하는 패턴
**파일**: VocCategoryQueryRepository.java 90-110번 라인
```java
public List<VocCategory> findLowestLevelCategoriesByRootCode(String rootCategoryCode) {
    // 1. 모든 카테고리 조회
    List<VocCategory> allCategories = queryFactory
            .selectFrom(vocCategory)
            .where(vocCategory.vocCategoryCode.like(rootCategoryCode + "%"))
            .fetch();

    // 2. 부모 카테고리 코드 목록 조회 (별도 쿼리)
    List<String> parentCategoryCodes = queryFactory
            .select(vocCategory.upVocCategoryCode.vocCategoryCode)
            .from(vocCategory)
            .where(vocCategory.upVocCategoryCode.vocCategoryCode.like(rootCategoryCode + "%"))
            .distinct()
            .fetch();

    // 3. Java Stream으로 필터링 (메모리에서 처리)
    return allCategories.stream()
            .filter(category -> !parentCategoryCodes.contains(category.getVocCategoryCode()))
            .toList();
}
```

### 1.3 심각도 낮음 (Medium) - 🟢

#### 반복적인 쿼리 구조
**문제점**: 유사한 통계 쿼리들이 템플릿만 다르고 구조가 동일함
**파일**: VocStatisticsQueryRepository.java
```java
// 시간별, 요일별, 일별, 월별 통계 메서드들이 거의 동일한 구조
public Map<String, Map<String, Integer>> getVocStatisticsByDayWithConditions(...) {
    List<Tuple> results = queryFactory
            .select(
                    voc.registererDepartmentCode,
                    Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime).as("hourKey"),
                    voc.count()
            )
            // 동일한 join과 where 절
            .from(voc)
            .innerJoin(vocChargePerson)...
}

// 거의 동일한 구조가 12번 반복됨
```

#### 예외 처리 부재
**문제점**: 쿼리 실행 중 발생할 수 있는 예외에 대한 처리가 없음
**파일**: 모든 QueryRepository 클래스들
```java
public Optional<VocResponseDto> findByIdWithAnswer(Long vocNumber) {
    VocResponseDto result = queryFactory
            .select(...)
            .from(voc)
            .fetchOne(); // SQLException 등 예외 처리 없음
    
    return Optional.ofNullable(result);
}
```

## 2. 개선 코드 예시

### 2.1 공통 쿼리 조건 추출 및 상수화
```java
package com.osstem.ow.voc.repository.common;

import com.osstem.ow.voc.constant.StatusType;
import com.querydsl.core.types.dsl.BooleanExpression;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 쿼리를 위한 공통 조건 유틸리티 클래스
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class VocQueryConditions {

    // 상수 정의
    public static final String DELETED_FLAG = "Y";
    public static final String NOT_DELETED_FLAG = "N";
    public static final String DEFAULT_CORP_CODE = "KR1";
    public static final String VOC_CATEGORY_PATTERN = "%VOC%";

    /**
     * 삭제되지 않은 VOC 조건
     */
    public static BooleanExpression isNotDeleted() {
        return voc.deleteYesOrNo.ne(DELETED_FLAG);
    }

    /**
     * VOC 카테고리 코드 일치 조건
     */
    public static BooleanExpression vocCategoryCodeEquals(String categoryCode) {
        return categoryCode != null ? voc.vocCategoryCode.eq(categoryCode) : null;
    }

    /**
     * 품목 코드 일치 조건
     */
    public static BooleanExpression itemCodeEquals(String itemCode) {
        if (itemCode == null || itemCode.trim().isEmpty()) {
            return null;
        }
        return voc.itemCode.eq(itemCode);
    }

    /**
     * 등록 일자 범위 조건
     */
    public static BooleanExpression registrationDateBetween(LocalDateTime startDate, LocalDateTime endDate) {
        if (startDate != null && endDate != null) {
            return voc.vocRegistrationDateTime.between(startDate, endDate);
        } else if (startDate != null) {
            return voc.vocRegistrationDateTime.goe(startDate);
        } else if (endDate != null) {
            return voc.vocRegistrationDateTime.loe(endDate);
        }
        return null;
    }

    /**
     * 담당자 부서 코드 포함 조건
     */
    public static BooleanExpression chargerDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return vocChargePerson.vocChargePersonDepartmentCode.in(departmentCodes);
    }

    /**
     * 등록자 부서 코드 포함 조건
     */
    public static BooleanExpression registererDepartmentCodeIn(List<String> departmentCodes) {
        if (departmentCodes == null || departmentCodes.isEmpty()) {
            return null;
        }
        return voc.registererDepartmentCode.in(departmentCodes);
    }

    /**
     * VOC 상태 코드 조건 (비즈니스 로직을 서비스로 이동 후 단순화)
     */
    public static BooleanExpression vocStateCodeIn(List<String> stateCodes) {
        if (stateCodes == null || stateCodes.isEmpty()) {
            return null;
        }
        return voc.vocStateCode.in(stateCodes);
    }

    /**
     * 담당자 활성 상태 조건
     */
    public static BooleanExpression isChargePersonActive() {
        return vocChargePerson.deleteYn.ne(DELETED_FLAG)
                .and(vocChargePerson.vocCategoryCode.like(VOC_CATEGORY_PATTERN));
    }
}
```

### 2.2 분리된 VOC 조회 Repository
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.model.request.VocSearchCriteria;
import com.osstem.ow.voc.model.response.VocResponseDto;
import com.osstem.ow.voc.repository.common.VocQueryConditions;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocAnswerDetail.vocAnswerDetail;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 기본 조회를 담당하는 Repository
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocSearchRepository {

    private final JPAQueryFactory queryFactory;

    /**
     * VOC 번호로 상세 정보 조회 (답변 정보 포함)
     */
    public Optional<VocResponseDto> findDetailById(Long vocNumber) {
        try {
            VocResponseDto result = createBaseQuery()
                    .where(voc.vocNumber.eq(vocNumber)
                            .and(VocQueryConditions.isNotDeleted()))
                    .fetchOne();

            return Optional.ofNullable(result);
            
        } catch (Exception e) {
            log.error("VOC 상세 조회 중 오류 발생: vocNumber={}", vocNumber, e);
            return Optional.empty();
        }
    }

    /**
     * 검색 조건에 따른 VOC 목록 조회 (페이징)
     */
    public Page<VocResponseDto> searchVocs(VocSearchCriteria criteria, Pageable pageable) {
        try {
            // 데이터 조회
            List<VocResponseDto> content = createBaseQuery()
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocCategoryCodeEquals(criteria.getVocCategoryCode()),
                            VocQueryConditions.itemCodeEquals(criteria.getItemCode()),
                            VocQueryConditions.vocStateCodeIn(criteria.getStateCodes()),
                            VocQueryConditions.registrationDateBetween(criteria.getStartDate(), criteria.getEndDate()),
                            VocQueryConditions.chargerDepartmentCodeIn(criteria.getChargerDepartmentCodes()),
                            VocQueryConditions.registererDepartmentCodeIn(criteria.getRegistererDepartmentCodes())
                    )
                    .orderBy(voc.vocRegistrationDateTime.desc())
                    .offset(pageable.getOffset())
                    .limit(pageable.getPageSize())
                    .fetch();

            // 전체 개수 조회
            long total = countVocs(criteria);

            return new PageImpl<>(content, pageable, total);
            
        } catch (Exception e) {
            log.error("VOC 검색 중 오류 발생: criteria={}", criteria, e);
            return Page.empty(pageable);
        }
    }

    /**
     * 검색 조건에 맞는 VOC 총 개수 조회
     */
    public long countVocs(VocSearchCriteria criteria) {
        try {
            return queryFactory
                    .selectFrom(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocCategoryCodeEquals(criteria.getVocCategoryCode()),
                            VocQueryConditions.itemCodeEquals(criteria.getItemCode()),
                            VocQueryConditions.vocStateCodeIn(criteria.getStateCodes()),
                            VocQueryConditions.registrationDateBetween(criteria.getStartDate(), criteria.getEndDate()),
                            VocQueryConditions.chargerDepartmentCodeIn(criteria.getChargerDepartmentCodes()),
                            VocQueryConditions.registererDepartmentCodeIn(criteria.getRegistererDepartmentCodes())
                    )
                    .fetchCount();
                    
        } catch (Exception e) {
            log.error("VOC 개수 조회 중 오류 발생: criteria={}", criteria, e);
            return 0L;
        }
    }

    /**
     * 기본 VOC 조회 쿼리 생성
     */
    private JPAQuery<VocResponseDto> createBaseQuery() {
        return queryFactory
                .select(Projections.bean(VocResponseDto.class,
                        voc.vocNumber,
                        voc.vocChargePersonNumber,
                        voc.vocCategoryCode,
                        voc.itemCode,
                        voc.vocItemName,
                        voc.vocDetailsItemName,
                        voc.denallVocNumber,
                        voc.vocRegistererDivisionCode,
                        voc.registererMemberId,
                        voc.vocCustomerName,
                        voc.vocCustomerCustomerName,
                        voc.vocCustomerEmailAddress,
                        voc.vocCustomerTelephoneNumber,
                        voc.vocCustomerHandPhoneNumber,
                        voc.vocTitle,
                        voc.vocContent,
                        voc.fileId.as("vocFileId"),
                        voc.vocCompletionTypeCode,
                        voc.vocStateCode,
                        voc.vocRegistrationDateTime,
                        vocChargePerson.vocChargePersonEmployeeNumber,
                        vocChargePerson.vocChargePersonEmployeeName.as("vocChargePersonName"),
                        vocAnswerDetail.vocAnswerDateTime,
                        vocAnswerDetail.vocAnswerContent,
                        vocAnswerDetail.fileId.as("answerFileId"),
                        vocAnswerDetail.isNotNull().as("hasAnswer")
                ))
                .from(voc)
                .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                .leftJoin(vocAnswerDetail).on(voc.vocNumber.eq(vocAnswerDetail.vocNumber));
    }
}
```

### 2.3 통계 전용 Repository 개선
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.model.statistic.StatisticsPeriod;
import com.osstem.ow.voc.model.statistic.VocStatisticsResult;
import com.osstem.ow.voc.repository.common.VocQueryConditions;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Expression;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.osstem.ow.voc.entity.QVoc.voc;
import static com.osstem.ow.voc.entity.QVocChargePerson.vocChargePerson;

/**
 * VOC 통계 전용 Repository
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocStatisticsRepository {

    private final JPAQueryFactory queryFactory;

    /**
     * 부서별 VOC 통계 조회 (기간별)
     */
    public VocStatisticsResult getDepartmentStatistics(StatisticsPeriod period, 
                                                     LocalDateTime startDate, 
                                                     LocalDateTime endDate,
                                                     List<String> stateCodes,
                                                     String vocCategoryCode,
                                                     String itemCode,
                                                     List<String> chargerDepartmentCodes,
                                                     List<String> registererDepartmentCodes) {
        try {
            Expression<String> periodExpression = getPeriodExpression(period);
            
            List<Tuple> results = queryFactory
                    .select(
                            voc.registererDepartmentCode,
                            periodExpression,
                            voc.count()
                    )
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocCategoryCodeEquals(vocCategoryCode),
                            VocQueryConditions.itemCodeEquals(itemCode),
                            VocQueryConditions.vocStateCodeIn(stateCodes),
                            VocQueryConditions.registrationDateBetween(startDate, endDate),
                            VocQueryConditions.chargerDepartmentCodeIn(chargerDepartmentCodes),
                            VocQueryConditions.registererDepartmentCodeIn(registererDepartmentCodes)
                    )
                    .groupBy(voc.registererDepartmentCode, periodExpression)
                    .fetch();

            return VocStatisticsResult.builder()
                    .period(period)
                    .statisticsData(mapResultsToStatistics(results))
                    .totalCount(results.stream().mapToLong(tuple -> tuple.get(2, Long.class)).sum())
                    .build();
                    
        } catch (Exception e) {
            log.error("부서별 VOC 통계 조회 중 오류 발생: period={}, startDate={}, endDate={}", 
                     period, startDate, endDate, e);
            return VocStatisticsResult.empty(period);
        }
    }

    /**
     * 품목별 VOC 통계 조회 (기간별)
     */
    public VocStatisticsResult getItemStatistics(StatisticsPeriod period,
                                               LocalDateTime startDate,
                                               LocalDateTime endDate,
                                               List<String> stateCodes,
                                               String vocCategoryCode,
                                               String itemCode,
                                               List<String> chargerDepartmentCodes,
                                               List<String> registererDepartmentCodes) {
        try {
            Expression<String> periodExpression = getPeriodExpression(period);
            
            List<Tuple> results = queryFactory
                    .select(
                            voc.itemCode,
                            periodExpression,
                            voc.count()
                    )
                    .from(voc)
                    .innerJoin(vocChargePerson).on(voc.vocChargePersonNumber.eq(vocChargePerson.vocChargePersonNumber))
                    .where(
                            VocQueryConditions.isNotDeleted(),
                            VocQueryConditions.vocCategoryCodeEquals(vocCategoryCode),
                            VocQueryConditions.itemCodeEquals(itemCode),
                            VocQueryConditions.vocStateCodeIn(stateCodes),
                            VocQueryConditions.registrationDateBetween(startDate, endDate),
                            VocQueryConditions.chargerDepartmentCodeIn(chargerDepartmentCodes),
                            VocQueryConditions.registererDepartmentCodeIn(registererDepartmentCodes),
                            voc.itemCode.isNotNull()
                    )
                    .groupBy(voc.itemCode, periodExpression)
                    .fetch();

            return VocStatisticsResult.builder()
                    .period(period)
                    .statisticsData(mapResultsToStatistics(results))
                    .totalCount(results.stream().mapToLong(tuple -> tuple.get(2, Long.class)).sum())
                    .build();
                    
        } catch (Exception e) {
            log.error("품목별 VOC 통계 조회 중 오류 발생: period={}, startDate={}, endDate={}", 
                     period, startDate, endDate, e);
            return VocStatisticsResult.empty(period);
        }
    }

    /**
     * 기간별 표현식 생성
     */
    private Expression<String> getPeriodExpression(StatisticsPeriod period) {
        return switch (period) {
            case HOURLY -> Expressions.stringTemplate("concat('h', hour({0}))", voc.vocRegistrationDateTime);
            case DAILY -> Expressions.stringTemplate("concat('d', dayofmonth({0}))", voc.vocRegistrationDateTime);
            case WEEKLY -> Expressions.stringTemplate("concat('w', week({0}))", voc.vocRegistrationDateTime);
            case MONTHLY -> Expressions.stringTemplate("concat('m', month({0}))", voc.vocRegistrationDateTime);
            case YEARLY -> Expressions.stringTemplate("concat('y', year({0}))", voc.vocRegistrationDateTime);
        };
    }

    /**
     * 쿼리 결과를 통계 맵으로 변환
     */
    private Map<String, Map<String, Integer>> mapResultsToStatistics(List<Tuple> results) {
        Map<String, Map<String, Integer>> statistics = new HashMap<>();

        for (Tuple tuple : results) {
            String groupKey = tuple.get(0, String.class);
            String periodKey = tuple.get(1, String.class);
            Long count = tuple.get(2, Long.class);

            if (groupKey != null && periodKey != null && count != null) {
                statistics
                        .computeIfAbsent(groupKey, k -> new HashMap<>())
                        .put(periodKey, count.intValue());
            }
        }

        return statistics;
    }
}
```

### 2.4 카테고리 계층 구조 안전 처리
```java
package com.osstem.ow.voc.repository;

import com.osstem.ow.voc.entity.VocCategory;
import com.osstem.ow.voc.exception.CircularReferenceException;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.*;

import static com.osstem.ow.voc.entity.QVocCategory.vocCategory;

/**
 * VOC 카테고리 계층 구조 처리 Repository
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class VocCategoryHierarchyRepository {

    private final JPAQueryFactory queryFactory;
    private static final int MAX_HIERARCHY_DEPTH = 10; // 최대 계층 깊이 제한

    /**
     * 특정 카테고리의 최상위 카테고리 조회 (순환 참조 방지)
     */
    public Optional<VocCategory> findRootCategory(String categoryCode) {
        try {
            VocCategory category = queryFactory
                    .selectFrom(vocCategory)
                    .where(vocCategory.vocCategoryCode.eq(categoryCode))
                    .fetchOne();

            if (category == null) {
                return Optional.empty();
            }

            // 상위 카테고리가 없는 경우 현재 카테고리가 최상위
            if (category.getUpVocCategoryCode() == null) {
                return Optional.of(category);
            }

            // 순환 참조 방지를 위한 방문 기록
            Set<String> visited = new HashSet<>();
            VocCategory current = category;
            int depth = 0;

            while (current.getUpVocCategoryCode() != null && depth < MAX_HIERARCHY_DEPTH) {
                String currentCode = current.getVocCategoryCode();
                
                // 순환 참조 체크
                if (visited.contains(currentCode)) {
                    log.warn("카테고리 계층에 순환 참조 발견: {}", visited);
                    throw new CircularReferenceException("카테고리 계층에 순환 참조가 존재합니다: " + currentCode);
                }
                
                visited.add(currentCode);
                depth++;
                
                String parentCode = current.getUpVocCategoryCode().getVocCategoryCode();
                current = queryFactory
                        .selectFrom(vocCategory)
                        .where(vocCategory.vocCategoryCode.eq(parentCode))
                        .fetchOne();

                if (current == null) {
                    log.warn("존재하지 않는 상위 카테고리 참조: {}", parentCode);
                    break;
                }
            }

            if (depth >= MAX_HIERARCHY_DEPTH) {
                log.warn("카테고리 계층 깊이 제한 초과: maxDepth={}, categoryCode={}", MAX_HIERARCHY_DEPTH, categoryCode);
            }

            return Optional.ofNullable(current);
            
        } catch (Exception e) {
            log.error("최상위 카테고리 조회 중 오류 발생: categoryCode={}", categoryCode, e);
            return Optional.empty();
        }
    }

    /**
     * 효율적인 최하위 카테고리 조회 (단일 쿼리 사용)
     */
    public List<VocCategory> findLeafCategoriesByRootCode(String rootCategoryCode) {
        try {
            return queryFactory
                    .selectFrom(vocCategory)
                    .where(
                            vocCategory.vocCategoryCode.like(rootCategoryCode + "%"),
                            vocCategory.vocCategoryCode.notIn(
                                    queryFactory
                                            .select(vocCategory.upVocCategoryCode.vocCategoryCode)
                                            .from(vocCategory)
                                            .where(vocCategory.upVocCategoryCode.vocCategoryCode.isNotNull())
                            )
                    )
                    .orderBy(vocCategory.sortOrder.asc())
                    .fetch();
                    
        } catch (Exception e) {
            log.error("최하위 카테고리 조회 중 오류 발생: rootCategoryCode={}", rootCategoryCode, e);
            return Collections.emptyList();
        }
    }

    /**
     * 카테고리 트리 구조 조회 (한 번의 쿼리로 전체 조회 후 메모리에서 구성)
     */
    public List<VocCategory> buildCategoryTree(String rootCategoryCode) {
        try {
            // 전체 카테고리 조회
            List<VocCategory> allCategories = queryFactory
                    .selectFrom(vocCategory)
                    .where(vocCategory.vocCategoryCode.like(rootCategoryCode + "%"))
                    .orderBy(vocCategory.sortOrder.asc())
                    .fetch();

            // 메모리에서 트리 구조 구성
            Map<String, VocCategory> categoryMap = new HashMap<>();
            Map<String, List<VocCategory>> childrenMap = new HashMap<>();

            for (VocCategory category : allCategories) {
                categoryMap.put(category.getVocCategoryCode(), category);
                childrenMap.computeIfAbsent(
                        category.getUpVocCategoryCode() != null ? 
                                category.getUpVocCategoryCode().getVocCategoryCode() : null,
                        k -> new ArrayList<>()
                ).add(category);
            }

            // 루트 카테고리들 반환
            return childrenMap.getOrDefault(null, Collections.emptyList());
            
        } catch (Exception e) {
            log.error("카테고리 트리 구성 중 오류 발생: rootCategoryCode={}", rootCategoryCode, e);
            return Collections.emptyList();
        }
    }
}
```

### 2.5 검색 조건 DTO 개선
```java
package com.osstem.ow.voc.model.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * VOC 검색 조건 DTO
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Schema(description = "VOC 검색 조건")
public class VocSearchCriteria {

    @Schema(description = "VOC 번호")
    private Long vocNumber;

    @Schema(description = "VOC 카테고리 코드")
    private String vocCategoryCode;

    @Schema(description = "품목 코드")
    private String itemCode;

    @Schema(description = "고객명")
    private String customerName;

    @Schema(description = "VOC 제목")
    private String vocTitle;

    @Schema(description = "VOC 상태 코드 목록")
    private List<String> stateCodes;

    @Schema(description = "검색 시작 일자")
    private LocalDateTime startDate;

    @Schema(description = "검색 종료 일자")
    private LocalDateTime endDate;

    @Schema(description = "담당자 부서 코드 목록")
    private List<String> chargerDepartmentCodes;

    @Schema(description = "등록자 부서 코드 목록")
    private List<String> registererDepartmentCodes;

    /**
     * 검색 조건이 유효한지 확인합니다.
     */
    public boolean isValid() {
        return vocNumber != null || 
               hasTextSearch() || 
               hasDateRange() || 
               hasDepartmentFilter();
    }

    /**
     * 텍스트 검색 조건이 있는지 확인합니다.
     */
    public boolean hasTextSearch() {
        return (vocCategoryCode != null && !vocCategoryCode.trim().isEmpty()) ||
               (itemCode != null && !itemCode.trim().isEmpty()) ||
               (customerName != null && !customerName.trim().isEmpty()) ||
               (vocTitle != null && !vocTitle.trim().isEmpty());
    }

    /**
     * 날짜 범위 검색 조건이 있는지 확인합니다.
     */
    public boolean hasDateRange() {
        return startDate != null || endDate != null;
    }

    /**
     * 부서 필터링 조건이 있는지 확인합니다.
     */
    public boolean hasDepartmentFilter() {
        return (chargerDepartmentCodes != null && !chargerDepartmentCodes.isEmpty()) ||
               (registererDepartmentCodes != null && !registererDepartmentCodes.isEmpty());
    }

    /**
     * 단일 날짜 검색인지 확인합니다.
     */
    public boolean isSingleDateSearch() {
        return startDate != null && endDate != null && 
               startDate.toLocalDate().isEqual(endDate.toLocalDate());
    }
}
```

## 3. 다른 접근법

### 3.1 Specification 패턴 사용
```java
public class VocSpecifications {
    
    public static Specification<Voc> hasVocNumber(Long vocNumber) {
        return (root, query, criteriaBuilder) -> 
            vocNumber != null ? criteriaBuilder.equal(root.get("vocNumber"), vocNumber) : null;
    }
    
    public static Specification<Voc> isNotDeleted() {
        return (root, query, criteriaBuilder) -> 
            criteriaBuilder.notEqual(root.get("deleteYesOrNo"), "Y");
    }
    
    public static Specification<Voc> hasDateRange(LocalDateTime start, LocalDateTime end) {
        return (root, query, criteriaBuilder) -> {
            if (start != null && end != null) {
                return criteriaBuilder.between(root.get("vocRegistrationDateTime"), start, end);
            }
            return null;
        };
    }
}

// 사용법
public Page<Voc> searchVocs(VocSearchCriteria criteria, Pageable pageable) {
    Specification<Voc> spec = Specification
            .where(VocSpecifications.isNotDeleted())
            .and(VocSpecifications.hasVocNumber(criteria.getVocNumber()))
            .and(VocSpecifications.hasDateRange(criteria.getStartDate(), criteria.getEndDate()));
            
    return vocRepository.findAll(spec, pageable);
}
```

### 3.2 Repository 계층 분리
```java
// 기본 CRUD
public interface VocRepository extends JpaRepository<Voc, Long> {
    Optional<Voc> findByDenallVocNumber(Long denallVocNumber);
}

// 복잡한 검색
public interface VocSearchRepository {
    Page<VocResponseDto> searchVocs(VocSearchCriteria criteria, Pageable pageable);
    List<VocResponseDto> findVocsByDepartment(String departmentCode);
}

// 통계 전용
public interface VocStatisticsRepository {  
    VocStatisticsResult getDepartmentStatistics(StatisticsPeriod period, ...);
    VocStatisticsResult getItemStatistics(StatisticsPeriod period, ...);
}

// 계층 구조 전용
public interface VocCategoryHierarchyRepository {
    Optional<VocCategory> findRootCategory(String categoryCode);
    List<VocCategory> findLeafCategories(String rootCode);
}
```

### 3.3 캐싱 전략 적용
```java
@Repository
@RequiredArgsConstructor
public class CachedVocCategoryRepository {
    
    private final VocCategoryRepository vocCategoryRepository;
    
    @Cacheable(value = "categoryHierarchy", key = "#rootCode")
    public List<VocCategory> findCategoryHierarchy(String rootCode) {
        return vocCategoryRepository.findByRootCode(rootCode);
    }
    
    @CacheEvict(value = "categoryHierarchy", allEntries = true)
    public void evictCategoryCache() {
        // 카테고리 변경 시 캐시 무효화
    }
}
```

## 4. 추가 고려사항

### 4.1 성능 측면
- **인덱스 최적화**: 자주 사용되는 검색 조건에 복합 인덱스 적용
- **쿼리 최적화**: N+1 문제 해결을 위한 fetch join 사용
- **캐싱**: 자주 조회되는 카테고리 정보 캐싱
- **페이징**: 대량 데이터 처리를 위한 효율적인 페이징 구현

### 4.2 유지보수 측면
- **책임 분리**: Repository를 용도별로 분리하여 단일 책임 원칙 준수
- **공통 로직 추출**: 중복 코드를 유틸리티 클래스로 분리
- **예외 처리**: 통일된 예외 처리 및 로깅 전략
- **테스트**: Repository 계층의 단위 테스트 작성

### 4.3 확장성 측면
- **동적 쿼리**: 검색 조건에 따른 동적 쿼리 생성
- **다중 데이터베이스**: 읽기/쓰기 분리를 위한 Repository 구조
- **이벤트 기반**: 데이터 변경 시 이벤트 발행
- **모니터링**: 쿼리 성능 모니터링 및 슬로우 쿼리 감지

## 5. 우선순위 및 예상 소요 시간

| 항목 | 우선순위 | 예상 소요 시간 | 비고 |
|------|----------|--------------|------|  
| 공통 쿼리 조건 유틸리티 분리 | 높음 | 4시간 | 중복 코드 제거 |
| God Object 분리 (Repository 분할) | 높음 | 8시간 | 아키텍처 개선 핵심 |
| 하드코딩 상수화 | 높음 | 2시간 | 유지보수성 향상 |
| 순환 참조 방지 로직 | 높음 | 3시간 | 안정성 확보 |
| 비즈니스 로직 서비스 이동 | 중간 | 4시간 | 책임 분리 |
| 예외 처리 및 로깅 추가 | 중간 | 3시간 | 안정성 향상 |
| 통계 쿼리 템플릿화 | 중간 | 5시간 | 코드 중복 제거 |
| 검색 조건 DTO 개선 | 낮음 | 2시간 | 사용성 개선 |

**총 예상 소요 시간**: 31시간